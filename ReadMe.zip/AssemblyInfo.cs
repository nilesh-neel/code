﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DecryptPluralSightVideos")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("DecryptPluralSightVideos")]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("1d117714-a0fb-4186-8e2c-349b9bdb45e3")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyVersion("1.0.0.0")]
