Sample directory file: DecryptPluralSightVideos /F "C:\Users\Kelsey\Desktop\PluralSight\courses" /DB "C:\Users\Kelsey\AppData\Local\Pluralsight\pluralsight.db" /TRANS /RM /OUT "C:\course"


DecryptPluralSightVideos.exe /F "C:\Users\niles\AppData\Local\Pluralsight\courses\" /DB "C:\Users\niles\AppData\Local\Pluralsight \pluralsight.db" /TRANS /OUT "C:\course"




DecryptPluralSightVideos /F "C:\Users\niles\Desktop\courses" /DB "C:\Users\niles\AppData\Local\Pluralsightt\pluralsight.db" /TRANS /RM /OUT "C:\course"
