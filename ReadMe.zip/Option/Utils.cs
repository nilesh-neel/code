﻿// Decompiled with JetBrains decompiler
// Type: DecryptPluralSightVideos.Option.Utils
// Assembly: DecryptPluralSightVideos, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D1AB3809-1ECE-4CD9-B948-DB32CFDE1E5B
// Assembly location: F:\nilesh\plurualsight\DecryptPluralSightVideos_v1.0\DecryptPluralSightVideos.exe

using System;
using System.IO;

namespace DecryptPluralSightVideos.Option
{
    public class Utils
    {
        private static object console_lock = new object();
        private static ConsoleColor color_default = Console.ForegroundColor;

        public static void WriteToConsole(string Text, ConsoleColor color = ConsoleColor.Gray)
        {
            lock (Utils.console_lock)
            {
                Console.ForegroundColor = color;
                Console.WriteLine(Text);
                Console.ForegroundColor = Utils.color_default;
            }
        }

        public static void HelpCommand()
        {
            Utils.WriteToConsole("This tool is published by Loc Nguyen and shared on J2Team", ConsoleColor.Gray);
            Utils.WriteToConsole("Source code of this tool published on: https://github.com/vinhloc1996/DecryptPluralSightVideos", ConsoleColor.Gray);
            Utils.WriteToConsole(Environment.NewLine + Environment.NewLine + "Flags: ", ConsoleColor.Gray);
            Utils.WriteToConsole("\t/F [PATH] Source path contains all downloaded courses. (Mandatory)", ConsoleColor.Gray);
            Utils.WriteToConsole("\t/RM\tRemoves courses in databases after decryption is complete. (Optional)", ConsoleColor.Gray);
            Utils.WriteToConsole("\t/DB [PATH] Use Database to rename folder course, module... (Mandatory)", ConsoleColor.Gray);
            Utils.WriteToConsole("\t/OUT [PATH] Specifies an output directory instead of using the same source path. (Optional)", ConsoleColor.Gray);
            Utils.WriteToConsole("\t/TRANS\tGenerate subtitles file (.srt) if the course are supported. (Optional)", ConsoleColor.Gray);
            Utils.WriteToConsole("\t/HELP\tSee usage of other commands. (Optional)", ConsoleColor.Gray);
            Utils.WriteToConsole("**Note**\nIf you want to use /RM flag, please make sure the output path that not the same with the source path.\n", ConsoleColor.Yellow);
        }

        public static DecryptorOptions ParseCommandLineArgs(string[] args)
        {
            args = new string[] { "/F", @"C:\Users\niles\Desktop\courses", "/DB", @"C:\Users\niles\AppData\Local\Pluralsightt\pluralsight.db", "/TRANS", "/RM", "/OUT", @"C:\course" };


            DecryptorOptions decryptorOptions = new DecryptorOptions();
            int num = 0;
            int length = args.Length;
            foreach (string str in args)
            {
                if (string.IsNullOrWhiteSpace(str))
                {
                    ++num;
                }
                else
                {
                    string upper = str.ToUpper();
                    if (!(upper == "/F"))
                    {
                        if (!(upper == "/DB"))
                        {
                            if (!(upper == "/RM"))
                            {
                                if (!(upper == "/OUT"))
                                {
                                    if (!(upper == "/TRANS"))
                                    {
                                        if (upper == "/HELP")
                                            decryptorOptions.UsageCommand = true;
                                    }
                                    else
                                        decryptorOptions.CreateTranscript = true;
                                }
                                else
                                {
                                    decryptorOptions.UseOutputFolder = true;
                                    if (args.Length - 1 > num)
                                        decryptorOptions.OutputPath = args[num + 1];
                                }
                            }
                            else
                                decryptorOptions.RemoveFolderAfterDecryption = true;
                        }
                        else
                        {
                            decryptorOptions.UseDatabase = true;
                            if (length - 1 > num)
                                decryptorOptions.DatabasePath = args[num + 1];
                        }
                    }
                    else if (length - 1 > num)
                    {
                        decryptorOptions.InputPath = args[num + 1];
                        Utils.WriteToConsole("Start to decrypt all courses...", ConsoleColor.Yellow);
                    }
                    else
                    {
                        Utils.WriteToConsole("The directory path is missing..." + Environment.NewLine, ConsoleColor.Red);
                        throw new FileNotFoundException("Directory path is missing or specified directory was not found!");
                    }
                    ++num;
                }
            }
            return decryptorOptions;
        }
    }
}
