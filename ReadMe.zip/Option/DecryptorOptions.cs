﻿// Decompiled with JetBrains decompiler
// Type: DecryptPluralSightVideos.Option.DecryptorOptions
// Assembly: DecryptPluralSightVideos, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D1AB3809-1ECE-4CD9-B948-DB32CFDE1E5B
// Assembly location: F:\nilesh\plurualsight\DecryptPluralSightVideos_v1.0\DecryptPluralSightVideos.exe

namespace DecryptPluralSightVideos.Option
{
  public class DecryptorOptions
  {
    public bool UseDatabase { get; set; }

    public bool UseOutputFolder { get; set; }

    public bool RemoveFolderAfterDecryption { get; set; }

    public bool UsageCommand { get; set; }

    public bool CreateTranscript { get; set; }

    public string InputPath { get; set; }

    public string DatabasePath { get; set; }

    public string OutputPath { get; set; }
  }
}
