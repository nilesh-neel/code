﻿// Decompiled with JetBrains decompiler
// Type: DecryptPluralSightVideos.Model.Course
// Assembly: DecryptPluralSightVideos, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D1AB3809-1ECE-4CD9-B948-DB32CFDE1E5B
// Assembly location: F:\nilesh\plurualsight\DecryptPluralSightVideos_v1.0\DecryptPluralSightVideos.exe

namespace DecryptPluralSightVideos.Model
{
  public class Course
  {
    public string CourseName { get; set; }

    public string CourseTitle { get; set; }

    public int HasTranscript { get; set; }
  }
}
