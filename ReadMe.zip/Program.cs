﻿// Decompiled with JetBrains decompiler
// Type: DecryptPluralSightVideos.Program
// Assembly: DecryptPluralSightVideos, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D1AB3809-1ECE-4CD9-B948-DB32CFDE1E5B
// Assembly location: F:\nilesh\plurualsight\DecryptPluralSightVideos_v1.0\DecryptPluralSightVideos.exe

using DecryptPluralSightVideos.Option;
using System;
using System.IO;

namespace DecryptPluralSightVideos
{
  internal class Program
  {
    private static void Main(string[] args)
    {
      DecryptorOptions decryptorOptions = new DecryptorOptions();
      try
      {
        DecryptorOptions commandLineArgs = Utils.ParseCommandLineArgs(args);
        Decryptor decryptor = new Decryptor(commandLineArgs);
        if (commandLineArgs.UsageCommand)
          Utils.HelpCommand();
        else if (!string.IsNullOrWhiteSpace(commandLineArgs.InputPath))
        {
          decryptor.DecryptAllFolders(commandLineArgs.InputPath, commandLineArgs.OutputPath);
          if (commandLineArgs.RemoveFolderAfterDecryption)
          {
            Utils.WriteToConsole("Removing course in database after decryption." + Environment.NewLine, ConsoleColor.Yellow);
            foreach (string directory in Directory.GetDirectories(commandLineArgs.InputPath, "*", SearchOption.TopDirectoryOnly))
            {
              decryptor.RemoveCourseInDb(directory);
              Utils.WriteToConsole("Course " + decryptor.GetFolderName(directory, false) + " has been deleted in database." + Environment.NewLine, ConsoleColor.Yellow);
            }
          }
        }
        else
          Utils.WriteToConsole("\t/F\t flag is mandatory. Please you the /HELP flag to more information.", ConsoleColor.Gray);
      }
      catch (Exception ex)
      {
        Utils.WriteToConsole("Error occured: " + ex.Message + "\n" + ex.StackTrace + Environment.NewLine, ConsoleColor.Red);
        Utils.WriteToConsole("Please use\t/HELP\tflag to know more about other commands or contact with the publisher.", ConsoleColor.Gray);
      }
      Utils.WriteToConsole(Environment.NewLine + "Press any key to exit the program...", ConsoleColor.Gray);
      Console.ReadKey();
    }
  }
}
