﻿// Decompiled with JetBrains decompiler
// Type: DecryptPluralSightVideos.Decryptor
// Assembly: DecryptPluralSightVideos, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: D1AB3809-1ECE-4CD9-B948-DB32CFDE1E5B
// Assembly location: F:\nilesh\plurualsight\DecryptPluralSightVideos_v1.0\DecryptPluralSightVideos.exe

using DecryptPluralSightVideos.Encryption;
using DecryptPluralSightVideos.Model;
using DecryptPluralSightVideos.Option;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DecryptPluralSightVideos
{
  public class Decryptor
  {
    private List<char> InvalidPathCharacters = new List<char>();
    private List<char> InvalidFileCharacters = new List<char>();
    public DecryptorOptions Options = new DecryptorOptions();
    private List<Task> TaskList = new List<Task>();
    private SemaphoreSlim Semaphore = new SemaphoreSlim(5);
    private object SemaphoreLock = new object();
    private VirtualFileStream playingFileStream;
    private IStream iStream;
    private SQLiteConnection DatabaseConnection;
    private ConsoleColor color_default;

    public Decryptor()
    {
      this.InvalidPathCharacters.AddRange((IEnumerable<char>) Path.GetInvalidPathChars());
      this.InvalidPathCharacters.AddRange((IEnumerable<char>) new char[5]
      {
        ':',
        '?',
        '"',
        '\\',
        '/'
      });
      this.InvalidFileCharacters.AddRange((IEnumerable<char>) Path.GetInvalidFileNameChars());
      this.InvalidFileCharacters.AddRange((IEnumerable<char>) new char[5]
      {
        ':',
        '?',
        '"',
        '\\',
        '/'
      });
      this.color_default = Console.ForegroundColor;
    }

    public Decryptor(DecryptorOptions options)
      : this()
    {
      this.Options = options;
      if (!options.UseDatabase)
        return;
      this.Options.UseDatabase = this.InitDB(options.DatabasePath);
    }

    private string CleanPath(string path)
    {
      foreach (char invalidPathCharacter in this.InvalidPathCharacters)
        path = path.Replace(invalidPathCharacter, '-');
      return path;
    }

    public string ModuleHash(string moduleName, string moduleAuthorName)
    {
      string s = moduleName + "|" + moduleAuthorName;
      using (MD5 md5 = MD5.Create())
        return Convert.ToBase64String(md5.ComputeHash(Encoding.UTF8.GetBytes(s))).Replace('/', '_');
    }

    public void DecryptAllFolders(string folderPath, string outputFolder = "")
    {
      if (!Directory.Exists(folderPath))
        throw new DirectoryNotFoundException();
      if (string.IsNullOrWhiteSpace(outputFolder))
        outputFolder = folderPath;
      else if (!Directory.Exists(outputFolder))
        throw new DirectoryNotFoundException();
      foreach (string directory in Directory.GetDirectories(folderPath, "*", SearchOption.TopDirectoryOnly))
      {
        Course courseFromDb = this.GetCourseFromDb(directory);
        if (courseFromDb != null)
        {
          string path1 = Path.Combine(outputFolder, this.CleanPath(courseFromDb.CourseTitle));
          DirectoryInfo directoryInfo1 = Directory.Exists(path1) ? new DirectoryInfo(path1) : Directory.CreateDirectory(path1);
          List<Module> modulesFromDb = this.GetModulesFromDb(courseFromDb.CourseName);
          if (modulesFromDb.Count > 0)
          {
            foreach (Module module in modulesFromDb)
            {
              string path2 = this.ModuleHash(module.ModuleName, module.AuthorHandle);
              string str = Path.Combine(directory, path2);
              string path3 = Path.Combine(directoryInfo1.FullName, module.ModuleIndex.ToString() + ". " + this.CleanPath(module.ModuleTitle));
              if (path3.Length > 240)
                path3 = Path.Combine(directoryInfo1.FullName, string.Concat((object) module.ModuleIndex));
              if (Directory.Exists(str))
              {
                DirectoryInfo directoryInfo2 = Directory.Exists(path3) ? new DirectoryInfo(path3) : Directory.CreateDirectory(path3);
                this.DecryptAllVideos(str, module.ModuleId, directoryInfo2.FullName);
              }
              else
                DecryptPluralSightVideos.Option.Utils.WriteToConsole("Foler " + path2 + " cannot be found in the current course path.", ConsoleColor.Red);
            }
          }
          DecryptPluralSightVideos.Option.Utils.WriteToConsole("Decryption " + courseFromDb.CourseTitle + " has been completed!", ConsoleColor.Magenta);
        }
      }
    }

    public bool RemoveCourseInDb(string coursePath)
    {
      string folderName = this.GetFolderName(coursePath, false);
      SQLiteCommand command = this.DatabaseConnection.CreateCommand();
      command.CommandText = "DELETE FROM Course \r\n                                WHERE Name = @courseName";
      command.Parameters.Add(new SQLiteParameter("@courseName", (object) folderName));
      return command.ExecuteNonQuery() > 0;
    }

    public void DecryptAllVideos(string folderPath, int moduleId, string outputPath)
    {
      List<Clip> clipsFromDb = this.GetClipsFromDb(moduleId);
      if (clipsFromDb.Count <= 0)
        return;
      foreach (Clip clip1 in clipsFromDb)
      {
        Clip clip = clip1;
        string str = Path.Combine(folderPath, clip.ClipName + ".psv");
        if (File.Exists(str))
        {
          string newPath = Path.Combine(outputPath, clip.ClipIndex.ToString() + ". " + this.CleanPath(clip.ClipTitle) + ".mp4");
          if (newPath.Length > 240)
            newPath = Path.Combine(outputPath, clip.ClipIndex.ToString() + ".mp4");
          this.playingFileStream = new VirtualFileStream(str);
          this.playingFileStream.Clone(out this.iStream);
          string fileName = Path.GetFileName(str);
          Console.ForegroundColor = ConsoleColor.Yellow;
          Console.WriteLine("Start to Decrypt File \"{0}\"", (object) fileName);
          Console.ForegroundColor = this.color_default;
          this.Semaphore.Wait();
          this.TaskList.Add(Task.Run((Action) (() =>
          {
            this.DecryptVideo(this.iStream, newPath);
            if (this.Options.CreateTranscript)
              this.WriteTranscriptFile(clip.ClipId, newPath);
            lock (this.SemaphoreLock)
              this.Semaphore.Release();
          })));
          Console.ForegroundColor = ConsoleColor.Green;
          Console.WriteLine("Decryption File \"{0}\" successfully", (object) Path.GetFileName(newPath));
          Console.ForegroundColor = this.color_default;
        }
        else
        {
          Console.ForegroundColor = ConsoleColor.Gray;
          Console.WriteLine("File \"{0}\" cannot be found.", (object) Path.GetFileName(str));
          Console.ForegroundColor = this.color_default;
        }
      }
    }

    public void WriteTranscriptFile(int clipId, string clipPath)
    {
      List<ClipTranscript> trasncriptFromDb = this.GetTrasncriptFromDb(clipId);
      if (trasncriptFromDb.Count <= 0)
        return;
      string path = Path.Combine(Path.GetDirectoryName(clipPath), Path.GetFileNameWithoutExtension(clipPath) + ".srt");
      if (!File.Exists(path))
      {
        StreamWriter streamWriter = new StreamWriter(path);
        int num = 1;
        foreach (ClipTranscript clipTranscript in trasncriptFromDb)
        {
          TimeSpan timeSpan = TimeSpan.FromMilliseconds((double) clipTranscript.StartTime);
          string str1 = timeSpan.ToString("hh\\:mm\\:ss\\,fff");
          timeSpan = TimeSpan.FromMilliseconds((double) clipTranscript.EndTime);
          string str2 = timeSpan.ToString("hh\\:mm\\:ss\\,fff");
          streamWriter.WriteLine(num++);
          streamWriter.WriteLine(str1 + " --> " + str2);
          streamWriter.WriteLine(clipTranscript.Text);
          streamWriter.WriteLine();
        }
        streamWriter.Close();
        DecryptPluralSightVideos.Option.Utils.WriteToConsole("Transcript of " + Path.GetFileName(clipPath) + "has been generated scucessfully.", ConsoleColor.DarkBlue);
      }
    }

    public string RenameIfDuplicated(string path)
    {
      string empty = string.Empty;
      int num = 1;
      string path1;
      if (Path.HasExtension(path))
      {
        string withoutExtension = Path.GetFileNameWithoutExtension(path);
        string extension = Path.GetExtension(path);
        string directoryName = Path.GetDirectoryName(path);
        string str;
        for (path1 = path; File.Exists(path1); path1 = Path.Combine(directoryName, str + extension))
          str = string.Format("{0} ({1})", (object) withoutExtension, (object) num++);
      }
      else
      {
        string folderName = this.GetFolderName(path, false);
        string directoryName = Path.GetDirectoryName(path);
        string path2;
        for (path1 = path; Directory.Exists(path1); path1 = Path.Combine(directoryName, path2))
          path2 = string.Format("{0} ({1})", (object) folderName, (object) num++);
      }
      return path1;
    }

    public string GetFileNameIfItExisted(string filePath, bool checkExisted = false)
    {
      if (checkExisted && !File.Exists(filePath))
        throw new FileNotFoundException();
      return filePath.Substring(filePath.LastIndexOf("\\") + 1);
    }

    public string GetFolderName(string folderPath, bool checkExisted = false)
    {
      if (checkExisted && !Directory.Exists(folderPath))
        throw new DirectoryNotFoundException();
      return folderPath.Substring(folderPath.LastIndexOf("\\") + 1);
    }

    public bool CompareTwoFiles(string fileOne, string fileTwo)
    {
      return (long) File.ReadAllBytes(fileOne).Length == (long) File.ReadAllBytes(fileTwo).Length;
    }

    public void DecryptVideo(IStream curStream, string newPath)
    {
      STATSTG pstatstg;
      curStream.Stat(out pstatstg, 0);
      IntPtr pcbRead = (IntPtr) 0;
      int cbSize = (int) pstatstg.cbSize;
      byte[] numArray = new byte[cbSize];
      curStream.Read(numArray, cbSize, pcbRead);
      File.WriteAllBytes(newPath, numArray);
    }

    public List<ClipTranscript> GetTrasncriptFromDb(int clipId)
    {
      List<ClipTranscript> clipTranscriptList = new List<ClipTranscript>();
      SQLiteCommand command = this.DatabaseConnection.CreateCommand();
      command.CommandText = "SELECT StartTime, EndTime, Text\r\n                                FROM ClipTranscript\r\n                                WHERE ClipId = @clipId\r\n                                ORDER BY Id ASC";
      command.Parameters.Add(new SQLiteParameter("@clipId", (object) clipId));
      SQLiteDataReader sqLiteDataReader = command.ExecuteReader();
      while (sqLiteDataReader.Read())
      {
        ClipTranscript clipTranscript = new ClipTranscript()
        {
          StartTime = sqLiteDataReader.GetInt32(sqLiteDataReader.GetOrdinal("StartTime")),
          EndTime = sqLiteDataReader.GetInt32(sqLiteDataReader.GetOrdinal("EndTime")),
          Text = sqLiteDataReader.GetString(sqLiteDataReader.GetOrdinal("Text"))
        };
        clipTranscriptList.Add(clipTranscript);
      }
      return clipTranscriptList;
    }

    public List<Clip> GetClipsFromDb(int moduleId)
    {
      List<Clip> clipList = new List<Clip>();
      SQLiteCommand command = this.DatabaseConnection.CreateCommand();
      command.CommandText = "SELECT Id, Name, Title, ClipIndex\r\n                                FROM Clip \r\n                                WHERE ModuleId = @moduleId";
      command.Parameters.Add(new SQLiteParameter("@moduleId", (object) moduleId));
      SQLiteDataReader sqLiteDataReader = command.ExecuteReader();
      while (sqLiteDataReader.Read())
      {
        Clip clip = new Clip()
        {
          ClipId = sqLiteDataReader.GetInt32(sqLiteDataReader.GetOrdinal("Id")),
          ClipName = sqLiteDataReader.GetString(sqLiteDataReader.GetOrdinal("Name")),
          ClipTitle = sqLiteDataReader.GetString(sqLiteDataReader.GetOrdinal("Title")),
          ClipIndex = sqLiteDataReader.GetInt32(sqLiteDataReader.GetOrdinal("ClipIndex"))
        };
        clipList.Add(clip);
      }
      sqLiteDataReader.Close();
      return clipList;
    }

    public List<Module> GetModulesFromDb(string courseName)
    {
      List<Module> moduleList = new List<Module>();
      SQLiteCommand command = this.DatabaseConnection.CreateCommand();
      command.CommandText = "SELECT Id, Name, Title, AuthorHandle, ModuleIndex\r\n                                FROM Module \r\n                                WHERE CourseName = @courseName";
      command.Parameters.Add(new SQLiteParameter("@courseName", (object) courseName));
      SQLiteDataReader sqLiteDataReader = command.ExecuteReader();
      while (sqLiteDataReader.Read())
      {
        Module module = new Module()
        {
          ModuleId = sqLiteDataReader.GetInt32(sqLiteDataReader.GetOrdinal("Id")),
          AuthorHandle = sqLiteDataReader.GetString(sqLiteDataReader.GetOrdinal("AuthorHandle")),
          ModuleName = sqLiteDataReader.GetString(sqLiteDataReader.GetOrdinal("Name")),
          ModuleTitle = sqLiteDataReader.GetString(sqLiteDataReader.GetOrdinal("Title")),
          ModuleIndex = sqLiteDataReader.GetInt32(sqLiteDataReader.GetOrdinal("ModuleIndex"))
        };
        moduleList.Add(module);
      }
      sqLiteDataReader.Close();
      return moduleList;
    }

    public Course GetCourseFromDb(string folderCoursePath)
    {
      Course course = (Course) null;
      string lower = this.GetFolderName(folderCoursePath, true).Trim().ToLower();
      SQLiteCommand command = this.DatabaseConnection.CreateCommand();
      command.CommandText = "SELECT Name, Title, HasTranscript \r\n                                FROM Course \r\n                                WHERE Name = @courseName";
      command.Parameters.Add(new SQLiteParameter("@courseName", (object) lower));
      SQLiteDataReader sqLiteDataReader = command.ExecuteReader();
      if (sqLiteDataReader.Read())
        course = new Course()
        {
          CourseName = sqLiteDataReader.GetString(sqLiteDataReader.GetOrdinal("Name")),
          CourseTitle = sqLiteDataReader.GetString(sqLiteDataReader.GetOrdinal("Title")),
          HasTranscript = sqLiteDataReader.GetInt32(sqLiteDataReader.GetOrdinal("HasTranscript"))
        };
      sqLiteDataReader.Close();
      return course;
    }

    public bool InitDB(string dbPath)
    {
      if (File.Exists(dbPath))
      {
        if (Path.GetExtension(dbPath).Equals(".db"))
        {
          this.DatabaseConnection = new SQLiteConnection(string.Format("Data Source={0}; Version=3;FailIfMissing=True", (object) dbPath));
          this.DatabaseConnection.Open();
          DecryptPluralSightVideos.Option.Utils.WriteToConsole("The Database Connection has been open completely." + Environment.NewLine, ConsoleColor.Green);
          return true;
        }
        DecryptPluralSightVideos.Option.Utils.WriteToConsole("The database file isn't corrected.", ConsoleColor.Red);
        return false;
      }
      DecryptPluralSightVideos.Option.Utils.WriteToConsole("Cannot find the database path.", ConsoleColor.Red);
      return false;
    }
  }
}
