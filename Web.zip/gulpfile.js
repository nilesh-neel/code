﻿/// <binding AfterBuild='build' Clean='clean' />
"use strict";

var gulp = require("gulp"),
    concat = require("gulp-concat"),
    cssmin = require("gulp-cssmin"),
    htmlmin = require("gulp-htmlmin"),
    uglify = require("gulp-uglify"),
    merge = require("merge-stream"),
    sourcemaps = require('gulp-sourcemaps'),
    //imagemin = require('gulp-imagemin'),
    rename = require('gulp-rename'),
    rimraf = require("rimraf"),
    gzip = require('gulp-gzip'),
    minifyCshtml = require('gulp-cshtml-minify'),
    //jshint = require("gulp-jshint"),
    bundleconfig = require("./bundleconfig.json");

var regex = {
    css: /\.css$/,
    html: /\.(html|htm)$/,
    cshtml: /\.cshtml$/,
    js: /\.js$/
};

gulp.task("min:js", function () {
    var tasks = getBundles(regex.js).map(function (bundle) {
        var options = {
            compress: false

        }

        return gulp.src(bundle.inputFiles, { base: "." })
            // .pipe(sourcemaps.init())
            //.pipe(jshint())
            .pipe(concat(bundle.outputFileName))
            .pipe(uglify())
            .pipe(gzip({ append: true }))
            // .pipe(sourcemaps.write('./'))
            .pipe(gulp.dest("./bundles"));
    });
    return merge(tasks);
});



gulp.task("min:image", function () {

    var appImg = gulp.src('images/**/*')
        //.pipe(imagemin())
        .pipe(gulp.dest('./bundles/images'));

    var contentImg = gulp.src('Content/images/*')
        //.pipe(imagemin())

        .pipe(gulp.dest('./bundles/css/images'));
    return merge(appImg, contentImg);
});

gulp.task("min:css", function () {
    var tasks = getBundles(regex.css).map(function (bundle) {
        return gulp.src(bundle.inputFiles, { base: "." })
            .pipe(concat(bundle.outputFileName))
            .pipe(cssmin())
            .pipe(gzip({ append: true }))
            .pipe(gulp.dest("./bundles"));
    });
    return merge(tasks);
});

gulp.task("min:html", function () {
    var tasks = getBundles(regex.html).map(function (bundle) {
        return gulp.src(bundle.inputFiles, { base: "." })
            .pipe(concat(bundle.outputFileName))
            .pipe(htmlmin({ collapseWhitespace: true, minifyCSS: true, minifyJS: true }))
            .pipe(gulp.dest("./bundles"));
    });
    return merge(tasks);
});


gulp.task("min:cshtml", function () {
    //rimraf(paths.concatCssDest, cb);
    return merge(gulp.src('Views/**/*.cshtml')

        .pipe(rename({ suffix: ".min" }))
        .pipe(minifyCshtml())
        //.pipe(minifyCshtml({
        //    removeHtmlComments: true,
        //    removeRazorComments: true,
        //    removeCssComments: true,
        //    minifyCss: true,
        //    minifyJs: true,
        //    collapseWhitespace: false, /* collapses whitespace to one space */
        //    optionalClosingTags: true, /* removes optional tags */
        //    urlSchemes: true, /* https:// -> // */
        //    uglifyjsOptions: {}, /* options for uglifyjs */
        //    cleancssOptions: {} /* options for cleancss */
        //}))
        .pipe(gulp.dest("./Views"))
    );
});



gulp.task("pdfjs", function () {
    return gulp.src('Scripts/pdf-js/locale/**/*')
        .pipe(gulp.dest('./bundles/pdf-js/locale'));
});

gulp.task("clean:cshtml", function (cb) {
    return rimraf('Views/**/*.min.cshtml', cb);
});

gulp.task("clean:bundles", function (cb) {
    return rimraf('./bundles/**/*', cb);
});

gulp.task("clean", gulp.series(["clean:cshtml", "clean:bundles"]));


gulp.task("watch", function () {
    getBundles(regex.js).forEach(function (bundle) {
        gulp.watch(bundle.inputFiles, ["min:js"]);
    });

    getBundles(regex.css).forEach(function (bundle) {
        gulp.watch(bundle.inputFiles, ["min:css"]);
    });

    //getBundles(regex.html).forEach(function (bundle) {
    //    gulp.watch(bundle.inputFiles, ["min:html"]);
    //});
});

function getBundles(regexPattern) {
    return bundleconfig.filter(function (bundle) {

        console.log(process.env.ASPNET_ENV);

        return regexPattern.test(bundle.outputFileName);
    });
} 

gulp.task("min", gulp.series(["min:js", "min:image", "min:css", "pdfjs", "min:cshtml"]));

gulp.task('build', gulp.series("clean", 'min'));