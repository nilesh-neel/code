﻿using Heathrow.BIPM.Utility.Common;
using Heathrow.BIPM.Utility.Constants;
using Heathrow.BIPM.Web.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Heathrow.BIPM.Web.Controllers
{
    public class MyBagListController : BaseController
    {
        // GET: MyBagList
        public ActionResult Index()
        {
            return View();
        }
    }
}