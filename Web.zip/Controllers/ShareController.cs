﻿/****************************************************************************************************************
Class Name   : ShareController.cs 
Purpose      : This is the share file in the application. To handle sharing of report URL to the selected Users...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetch organisation/recipients using logged-in user's EmailId instead of userId | 05/Dec/2018 | Logic changed
Vignesh (686552)   | code cleanup and updated                                                       | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                                                 | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System.Web.Mvc;
using System.Threading.Tasks;
using System;
using Heathrow.BIPM.Utility.Common;
using Heathrow.BIPM.Utility.Constants;
using System.Text;
using System.Net.Mail;
using System.Net.Mime;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.ViewModel;

namespace Heathrow.BIPM.Web.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class ShareController : BaseController
    {
        private string _HtmlString = string.Empty;

        /// <summary>
        /// Constructor
        /// </summary>
        public ShareController()
        {
        }

        #region Sending Email through Office365
        /// <summary>
        /// To Send the Report Url via Email to the selected Recipients
        /// </summary>
        /// <param name="selectedRecipients"> Selected Recipients as input parameter</param>
        /// <param name="url">Report Url as input parameter</param>
        /// <returns>Mail Response</returns>
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public async Task<ActionResult> SendMail(string selectedRecipients, string pattern, string reportName,string headerDate)
        {
            try
            {
                string reportLink = pattern.Replace(" ", "%20").ToString();
                var loggedinUser = SessionUtility.Get<UserVM>(SessionConstants.LoggedUser).DisplayName;
                string htmlReportName = MessageConstants.ReportNameStartTag + reportName != null ?
                                        reportName.Replace("-", "").Trim() : "";

                string htmlReportLink = MessageConstants.ReportLinkStartTag + reportLink.Trim()
                                        + MessageConstants.ReportLinkMiddleTag + reportLink.Substring(0, 56).Trim()
                                        + MessageConstants.ReportLinkEndTag;

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(MessageConstants.HtmlStructureStart);
                stringBuilder.Append(loggedinUser);
                stringBuilder.Append(MessageConstants.HtmlSharedWithYou);
                stringBuilder.Append(htmlReportName);
                stringBuilder.Append(MessageConstants.HtmlReportAccess);
                stringBuilder.Append(htmlReportLink);
                stringBuilder.Append(MessageConstants.HtmlStructureEnd);
                var alternateView = getEmbeddedImage(AppDomain.CurrentDomain.BaseDirectory
                                                    + MessageConstants.KestrelLogoPath, stringBuilder);
                string mailBody = _HtmlString;
                string mailSubject = reportName.Replace("-", "").Trim();
                mailSubject = mailSubject + " - " + headerDate;
                if (!string.IsNullOrEmpty(selectedRecipients) && !string.IsNullOrEmpty(pattern))
                {
                    var objMail = new MailUtility();
                    var Mailresponse = await Task.Run(() => objMail.SendMail(selectedRecipients,
                                                                                 mailSubject, mailBody,
                                                                                 alternateView)).ConfigureAwait(false); // Send Mail using Office365
                    return JsonSuccess(Mailresponse);
                }
                // throw will be take care by Exception Handdler..
                throw new Exception("Mail not Sent");
            }
            catch (SmtpException)
            {
                throw;
            }


        }
        #endregion
        /// <summary>
        /// To Embed the kestrel Logo Image in the signature of Email 
        /// </summary>
        /// <param name="filePath">Filepath</param>
        /// <param name="stringBuilder">String Builder for Email body</param>
        /// <returns></returns>
        private AlternateView getEmbeddedImage(String filePath, StringBuilder stringBuilder)
        {
            LinkedResource res = new LinkedResource(filePath, MediaTypeNames.Image.Jpeg);
            res.ContentId = Guid.NewGuid().ToString();
            string imageTag = MessageConstants.ImageStartTag + res.ContentId + MessageConstants.ImageEndTag;
            stringBuilder.Append(imageTag);
            stringBuilder.Append(MessageConstants.HtmlResponseMonitored);
            stringBuilder.Append(MessageConstants.HtmlEndTag);
            _HtmlString = stringBuilder.ToString();
            AlternateView alternateView = AlternateView.CreateAlternateViewFromString(_HtmlString,
                                                                                        null,
                                                                                        MediaTypeNames.Text.Html);
            alternateView.LinkedResources.Add(res);
            return alternateView;
        }
    }
}