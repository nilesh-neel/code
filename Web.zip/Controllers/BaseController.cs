﻿/****************************************************************************************************************
Class Name   : BaseController.cs 
Purpose      : This authenticate each and every call/route/method before executing 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;
using Microsoft.Owin.Security.Cookies;
using Heathrow.BIPM.Web.Helper;
using System.Linq;
using Heathrow.BIPM.Web.Filter;
using Heathrow.BIPM.Utility.Constants;
using Heathrow.BIPM.Utility.Common;
using System.IO.Compression;
using Heathrow.BIPM.Web.ViewModel;
using System.Web.Routing;
using System.Globalization;

namespace Heathrow.BIPM.Web.Controllers
{
    //  [Authorize(Roles = "Administrators, SuperUsers, Approvers,StandardUser")]
    [Authorize]
    [ExceptionHandling]
    public abstract class BaseController : Controller
    {
        internal string SignedInUserId
        {
            get
            {
                if (Request.IsAuthenticated)
                {
                    return ClaimsPrincipal.Current.FindFirst("preferred_username").Value;
                }
                return "";
            }
        }

        private bool IsDevelopment()
        {
            return false;
            //Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "";//EnvironmentName.Development;
        }

        /// <summary>
        /// on action executing
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext == null) return;
            if (!Request.IsAuthenticated)
            {
                // The session has lost data. This happens often
                Request.GetOwinContext().Authentication.SignOut(CookieAuthenticationDefaults.AuthenticationType);
                filterContext.Result = RedirectToAction(MessageConstants.SignIn, MessageConstants.Account);
            }
            else
            {
                var user = SessionUtility.Get<UserVM>(SessionConstants.LoggedUser);
                if (user == null)
                {
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary
                    {
                        {"Controller", "Account"},
                        {"Action", "SignIn"}

                    });
                    return;
                }

                ViewBag.LogInUser = SessionUtility.Get<UserVM>(SessionConstants.LoggedUser);
                ViewBag.Avatar = SessionUtility.Get<string>(SessionConstants.UserPhoto);

                if (Convert.ToBoolean(AppSettingsUtility.GetAppSettingsKeyValue("Compression"), CultureInfo.InvariantCulture))
                { CompressReponse(filterContext); }

            }
            base.OnActionExecuting(filterContext);
        }

        /// <summary>
        /// Compress the response.
        /// </summary>
        /// <param name="actionExecutingContext"></param>
        private static void CompressReponse(ActionExecutingContext actionExecutingContext)
        {
            HttpRequestBase request = actionExecutingContext.HttpContext.Request;

            string acceptEncoding = request.Headers["Accept-Encoding"];

            if (!string.IsNullOrEmpty(acceptEncoding))
            {
                acceptEncoding = acceptEncoding.ToUpperInvariant();

                HttpResponseBase response = actionExecutingContext.HttpContext.Response;

                if (acceptEncoding.Contains("GZIP"))
                {
                    response.AppendHeader("Content-encoding", "gzip");
                    response.Filter = new GZipStream(response.Filter, CompressionMode.Compress);
                }
                else
                {
                    response.AppendHeader("content-encoding", "deflate");
                    response.Filter = new DeflateStream(response.Filter, CompressionMode.Compress);
                }
            }
        }
        /*
        protected override ViewResult View(string viewName, string masterName, object model)
        {
            if (!IsDevelopment())
            {
                string action = ControllerContext.RouteData.Values["action"].ToString();

                if (string.IsNullOrEmpty(viewName))
                {
                    viewName = $"{action}.min";
                }
                else if (viewName == action)
                {
                    viewName += ".min";
                }
            }

            return base.View(viewName, masterName, model);
        }
        protected override PartialViewResult PartialView(string viewName, object model)
        {
            if (!IsDevelopment())
            {
                string action = ControllerContext.RouteData.Values["action"].ToString();

                if (!string.IsNullOrEmpty(viewName))
                {
                    viewName = $"{viewName}.min";
                }
                else if (viewName == action)
                {
                    viewName += ".min";
                }
            }

            return base.PartialView(viewName, model);
        }
        */
        #region "Standared json response to communicate with client"

        //get model state validation error
        protected JsonResultHelper JsonValidationError()
        {
            var result = new JsonResultHelper();

            foreach (var validationError in ModelState.Values.SelectMany(v => v.Errors))
            {
                result.AddError(validationError.ErrorMessage);
            }
            return result;
        }

        /// <summary>
        /// To return value if json success
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="data"></param>
        /// <returns></returns>
        protected static JsonResultHelper<T> JsonSuccess<T>(T data)
        {
            return new JsonResultHelper<T> { Data = data };
        }
        #endregion
    }
}