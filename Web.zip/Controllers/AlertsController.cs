﻿/****************************************************************************************************************
Class Name   : Alerts.cs 
Purpose      : Provides action Method for Alerts 
Created By   : Vaishnavi.R
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By            | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh(405285)         | CAST                                      |02/12/2019         | CAST Fix        
Gayathri Kannan(153661)| CCAP                                      |02/07/2019         | CCAP Fix
Anupama Kumari(694315)  | Validation                                |01/28/2019         | Server side validation included to post call
Vaishanvi.R(687417)    | API Implementation                        |01/16/2019         | Updated api implementation to bind with view model
Nilesh(405285)         | API implementation                        |12/29/2018         | Updated web methods with API call to fetch data                                
****************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.ViewModel;
using System.Net.Http;
using Heathrow.BIPM.Web.Helper;
using Newtonsoft.Json;
using System.Linq;
using Heathrow.BIPM.Utility.Constants;
using System.Net;
using System;
using System.Text;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace Heathrow.BIPM.Web.Controllers
{

    public class AlertsController : BaseController
    {

        private readonly IMapper<AlertVM, Alerts> _map;

        /// <summary>
        /// Constructor implementation with dependency injection
        /// </summary>
        /// <param name="map"></param>
        public AlertsController(IMapper<AlertVM, Alerts> map)
        {
            _map = map;
        }


        /// <summary>
        /// Loads the landing page view
        /// </summary>
        /// <returns>landingpage view</returns>
        public ActionResult Index()
        {
            return View(MessageConstants.LandingPage);
        }


        /// <summary>
        /// Dropdown data is loaded from the api and mapped to viewmodel
        /// </summary>
        /// <returns>Partial View for new alert</returns>
        public async Task<ActionResult> NewAlert()
        {
            var responseAlert = await WebAPIClient.GetResponseContent(MessageConstants.AlertById + 0,
                                        HttpMethod.Get, null, "").ConfigureAwait(false);
            string json = JsonConvert.SerializeObject(responseAlert.Result);
            var result = JsonConvert.DeserializeObject<AlertVM>(json);
            result.IsOnscreen = true;
            result.IsEmail = true;
            result.CreatedDate = System.DateTime.Now;
            result.StartDate = Convert.ToString(System.DateTime.Now);
            result.EndDate = Convert.ToString(System.DateTime.Now);
            return PartialView(MessageConstants.NewAlert, result);
        }


        /// <summary>
        /// Loads record of corresponding id from api and is mapped to viewmodel- Standard User level
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Partial view to edit alert setting</returns>
        public async Task<ActionResult> AlertSetting(int id)
        {
            var responseAlert = await WebAPIClient.GetResponseContent(MessageConstants.AlertById + id,
                                        HttpMethod.Get, null, "").ConfigureAwait(false);
            string json = JsonConvert.SerializeObject(responseAlert.Result);
            var result = JsonConvert.DeserializeObject<AlertVM>(json);
            if (responseAlert.StatusCode == HttpStatusCode.OK)
            {
                return PartialView(MessageConstants.EditAlertSettings, result);
            }
            else
            {
                return new EmptyResult();
            }
        }

        /// <summary>
        /// Loads record of corresponding id from api and is mapped to viewmodel - Admin level configuration
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Partial view to edit configure alert</returns>
        public async Task<ActionResult> Edit(int id)
        {

            var responseAlert = await WebAPIClient.GetResponseContent(MessageConstants.ConfigureAlertById + id,
                                      HttpMethod.Get, null, "").ConfigureAwait(false);
            string json = JsonConvert.SerializeObject(responseAlert.Result);
            var result = JsonConvert.DeserializeObject<AlertVM>(json);

            return PartialView(MessageConstants.EditAlertConfigure, result);
        }

        /// <summary>
        /// Posts data to api 
        /// </summary>
        /// <param name="alertData"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> Edit(AlertVM alertData)
        {
            if (alertData != null && ModelState.IsValid)
            {
                if (Convert.ToDateTime(alertData.StartDate) > Convert.ToDateTime(alertData.EndDate))
                {
                    return JsonSuccess(MessageConstants.StartDateGTEndDate);
                }
                if (Convert.ToDateTime(alertData.EndDate).Date < DateTime.Now.Date && alertData.Measure == "newAlert")
                {
                    return JsonSuccess(MessageConstants.EndDatelessCurrentDate);
                }
                else
                {
                    var result = await WebAPIClient.GetResponseContent(MessageConstants.ApiAlert,
                                       HttpMethod.Post, _map.MapTo(alertData), "").ConfigureAwait(false);
                    if (result.Result.ToString() == MessageConstants.SaveFail)
                    {
                        return JsonSuccess(MessageConstants.AlertFail);
                    }
                    else
                    {
                        switch (alertData.Measure)
                        {
                            case "EditAlertForm":
                                return JsonSuccess(MessageConstants.EditSuccess);
                            case "configureAlert":
                                return JsonSuccess(MessageConstants.ConfigureSuccess);
                            case "newAlert":
                                return JsonSuccess(MessageConstants.AlertSuccess);
                            default:
                                return JsonSuccess(result.Result);
                        }
                    }
                }
            }
            else if (!ModelState.IsValid)
            {
                StringBuilder message = new StringBuilder();
                foreach (var validationError in ModelState.Values.SelectMany(v => v.Errors))
                {
                    switch (message)
                    {
                        case null:
                            //message = validationError.ErrorMessage;                        
                            message.Append(validationError.ErrorMessage);
                            break;
                        default:
                            //message = message + "," + validationError.ErrorMessage;
                            message.Append(",");
                            message.Append(validationError.ErrorMessage);
                            break;
                    }
                }
                return JsonSuccess(message);
            }
            else
            {
                switch (alertData.Measure)
                {
                    case "configureAlert":
                        return JsonSuccess(MessageConstants.AlertConfigureFail);
                    case "newAlert":
                        return JsonSuccess(MessageConstants.AlertFail);
                    default:
                        return JsonSuccess(MessageConstants.AlertFail);
                }
            }
        }


        /// <summary>
        /// Posts data to api 
        /// </summary>
        /// <param name="alertData"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> EditMyAlertSettings(AlertVM alertData)
        {
            if (alertData != null)
            {
                await WebAPIClient.GetResponseContent(MessageConstants.ApiAlert, HttpMethod.Put,
                    _map.MapTo(alertData), "").ConfigureAwait(false);
                return JsonSuccess(MessageConstants.EditSuccess);
            }
            else
            {
                return JsonSuccess(MessageConstants.AlertSettingFail);
            }
        }

        [HttpPost]
        public async Task<ActionResult> GetConfiguredAlert(DataTableRequest param)
        {
            string JsonResult = string.Empty;
            var responseAlert = await WebAPIClient.GetResponseContent(MessageConstants.ApiConfiguredAlert,
                                     HttpMethod.Post, param, "").ConfigureAwait(false);
            JsonResult = JsonConvert.SerializeObject(responseAlert.Result, Formatting.Indented);

            var AlertCount = (from s in JArray.Parse(JsonResult)
                              select s["alertCount"]).FirstOrDefault();

            return Json(new
            {
                draw = param.Draw,
                recordsTotal = Convert.ToInt32(AlertCount),
                recordsFiltered = Convert.ToInt32(AlertCount),
                data = JsonResult,
            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public async Task<ActionResult> GetMyAlertSettings(DataTableRequest param)
        {
            string JsonResult = string.Empty;
            var responseAlert = await WebAPIClient.GetResponseContent(MessageConstants.ApiMyAlertSetting,
                                    HttpMethod.Post, param, "").ConfigureAwait(false);
            JsonResult = JsonConvert.SerializeObject(responseAlert.Result, Formatting.Indented);

            var AlertCount = (from s in JArray.Parse(JsonResult)
                              select s["alertCount"]).FirstOrDefault();
            return Json(new
            {
                draw = param.Draw,
                recordsTotal = Convert.ToInt32(AlertCount),
                recordsFiltered = Convert.ToInt32(AlertCount),
                data = JsonConvert.SerializeObject(responseAlert.Result)
            }, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public async Task<ActionResult> GetTodayAlert(DataTableRequest param)
        {
            string JsonResult = string.Empty;
            var responseAlert = await WebAPIClient.GetResponseContent(MessageConstants.ApiTodayAlert,
                                    HttpMethod.Post, param, "").ConfigureAwait(false);
            JsonResult = JsonConvert.SerializeObject(responseAlert.Result, Formatting.Indented);

            var AlertCount = (from s in JArray.Parse(JsonResult)
                              select s["alertCount"]).FirstOrDefault();
            return Json(new
            {
                draw = param.Draw,
                recordsTotal = Convert.ToInt32(AlertCount),
                recordsFiltered = Convert.ToInt32(AlertCount),
                data = JsonConvert.SerializeObject(responseAlert.Result)
            }, JsonRequestBehavior.AllowGet);
        }


    }
}