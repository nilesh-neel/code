﻿/****************************************************************************************************************
Class Name   : AccountController.cs 
Purpose      : Account Controller use to login and logout user from the application.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.Web;
using System.Web.Mvc;
using Heathrow.BIPM.Core.Entity;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.OpenIdConnect;

namespace Heathrow.BIPM.Web.Controllers
{
    [AllowAnonymous]
    public class AccountController : Controller
    {

        /// <summary>
        /// Here we sign in to web app. 
        /// </summary>
        public void SignIn()
        {
            // Signal OWIN to send an authorization request to Azure.
            Request.GetOwinContext().Authentication.Challenge(new AuthenticationProperties
            { RedirectUri = AzureAdConfig.RedirectUrl.ToString() },
                OpenIdConnectAuthenticationDefaults.AuthenticationType);
        }

        /// <summary>
        /// Here we sign out from web app. 
        /// </summary>
        public void SignOut()
        {
            if (Session != null)
            {
                Session.Clear();
                Session.RemoveAll();
                Session.Abandon();
            }
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            //            Request.GetOwinContext().Authentication.SignOut();
            Request.GetOwinContext().Authentication.SignOut(OpenIdConnectAuthenticationDefaults.AuthenticationType,
                CookieAuthenticationDefaults.AuthenticationType);

        }

        /// <summary>
        /// When the token recieved is invalid
        /// </summary>
        public void InvalidToken()
        {
            // Get the user's token cache and clear it.

            if (Session != null)
            {
                Session.Clear();
                Session.RemoveAll();
                Session.Abandon();

            }
            Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetNoStore();
            //Request.GetOwinContext().Authentication.SignOut();
            Request.GetOwinContext().Authentication.SignOut(new AuthenticationProperties
            { RedirectUri = AzureAdConfig.RedirectUrl.ToString() },
                OpenIdConnectAuthenticationDefaults.AuthenticationType, 
                CookieAuthenticationDefaults.AuthenticationType);
        }
    }
}