﻿/****************************************************************************************************************
Class Name   : ExceptionHandling.cs 
Purpose      : This file is used to handle the Exceptions globally across the application in Web project and track those exceptions in the Azure Appinsights .......
Created By   : Vignesh AshokKumar 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Utility.Common;
using Heathrow.BIPM.Utility.Constants;
using Heathrow.BIPM.Web.Helper;
using Heathrow.BIPM.Web.ViewModel;
using Newtonsoft.Json;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.Routing;

namespace Heathrow.BIPM.Web.Controllers
{
    /// <summary>
    /// Authorization controller
    /// </summary>
    public class AuthController : BaseController
    {
        /// <summary>
        /// Get access token
        /// </summary>
        /// <returns>string</returns>
        [HttpGet]
        public async Task<ActionResult> Token()
        {
            if (string.IsNullOrEmpty(SignedInUserId))
                RedirectToAction(MessageConstants.SignIn, MessageConstants.Account);


            var result = await TokenUtility.GetAccessTokenAsync(AzureAdConfig.WebApiResourceId, false)
                    .ConfigureAwait(false);

            return JsonSuccess(new
            {
                Token = result,
            });

        }

        [HttpGet]
        public async Task<ActionResult> UpdateUserSession()
        {
            using (var client = new HttpClient())
            {
                var user = SessionUtility.Get<UserVM>(SessionConstants.LoggedUser);
                var response = await client.GetAsync(AzureAdConfig.WebApiUrl.ToString() + MessageConstants.GetUserDetails +
                                                     user.Email.ToString());
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var registration = JsonConvert.DeserializeObject<ResponseMetadataVM>(result);
                    if (registration.StatusCode == HttpStatusCode.OK || registration.Result != null)
                    {
                        string json = JsonConvert.SerializeObject(registration.Result);
                        var objDbUser = JsonConvert.DeserializeObject<UserVM>(json);
                        user.OperationalArea = objDbUser.OperationalArea;
                        user.Location = objDbUser.Location;
                        SessionUtility.Set(SessionConstants.LoggedUser, user);
                    }
                }
            }

            return JsonSuccess("OK");

        }

    }
}