﻿/****************************************************************************************************************
Class Name   : ExceptionController.cs 
Purpose      : Provides action Method for ExceptionHandling
Created By   : Vignesh 
Created Date : 04/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
696761 - Anand Babu P | 25/APR/2019 | Added generic error handler
405285 - Nilesh | 26/APR/2019 | Removed Unwanted and commented code.
****************************************************************************************************************/

using System.Web.Mvc;

namespace Heathrow.BIPM.Web.Controllers
{
    [AllowAnonymous]
    public class ExceptionController : Controller
    {
        /// <summary>
        /// Handle Un-Authorized exception
        /// </summary>
        /// <param name="message">Error message to show to client</param>
        /// <returns>Un-authorized view</returns>
        // GET: /Exception/Error
        public ActionResult Unauthorized(string message)
        {
            ViewBag.ErrorMessage = message;
            return View("_Unauthroized");
        }

        /// <summary>
        /// Handle exception
        /// </summary>
        /// <param name="message">Error message to show to client</param>
        /// <returns>Error view</returns>
        // GET: /Exception/Error
        public ActionResult Error(string message)
        {
            ViewBag.ErrorMessage = message;
            return View("Error");
        }
    }
}