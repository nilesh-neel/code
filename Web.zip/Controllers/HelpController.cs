﻿/****************************************************************************************************************
Class Name   : Help.cs 
Purpose      : Provides action Method for Help 
Created By   : Vivekanandan.S
Created Date : 13/May/2019
Version      : 1.0
History      :
Modified By            | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments                          
****************************************************************************************************************/

using System.Web.Mvc;

namespace Heathrow.BIPM.Web.Controllers
{

    public class HelpController : BaseController
    {
        /// <summary>
        /// Help viewer page
        /// </summary>
        /// <returns>pdf view</returns>
        public ActionResult Viewer()
        {
            return View();
        }

    }

}