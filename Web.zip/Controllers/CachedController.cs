﻿/****************************************************************************************************************
Class Name   : CachedController.cs 
Purpose      : CachedController file use to get menu, filterconfiguration details and faourites in the application.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using Heathrow.BIPM.Web.Helper;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Heathrow.BIPM.Web.Controllers
{
    public class CachedController : BaseController
    {

        [OutputCache(Duration = 1200, Location = System.Web.UI.OutputCacheLocation.Client)]
        [HttpGet]
        public async Task<ActionResult> GetMenu()
        {
            var response = await WebAPIClient.GetResponseContent("api/menu", HttpMethod.Get, null, "")
                                             .ConfigureAwait(false);
            return JsonSuccess(response);
        }
        [OutputCache(Duration = 1200, Location = System.Web.UI.OutputCacheLocation.Client)]
        [HttpGet]
        public async Task<ActionResult> GetFilterConfig()
        {

            var response = await WebAPIClient.GetResponseContent("api/Filter", HttpMethod.Get, null, "")
                                             .ConfigureAwait(false);
            return JsonSuccess(response);
        }

        [OutputCache(Duration = 1200, Location = System.Web.UI.OutputCacheLocation.Client, VaryByParam = "id")]
        [HttpGet]
        public async Task<ActionResult> GetFavorites(string id)
        {
            var response = await WebAPIClient.GetResponseContent("api/Favorites", HttpMethod.Get, null, "")
                                             .ConfigureAwait(false);
            return JsonSuccess(response);
        }


    }
}