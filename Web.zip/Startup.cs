﻿/****************************************************************************************************************
Class Name   : Startup.cs 
Purpose      : Used as Owin Startup class to implements authentication and authorization in Application. 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using Microsoft.Owin;
using Microsoft.Owin.Cors;
using System.Web.Optimization;
using System.Web.Routing;
using Owin;
using Heathrow.BIPM.Core.Entity;
using System.Web.Mvc;
using System.Web.Cors;
using System.Threading.Tasks;
using Heathrow.BIPM.Utility.Constants;
using WebGrease.Css.Extensions;
using Microsoft.Owin.StaticFiles;

[assembly: OwinStartup(typeof(Heathrow.BIPM.Web.Startup))]
namespace Heathrow.BIPM.Web
{
    public partial class Startup
    {
        /// <summary>
        /// In this method we are configration application security details such as CROS, XSS 
        /// ,X-Content-Type-Options etc..
        /// Also call the Unity Depedency Injection to inject all the application module/class depedency
        /// </summary>
        /// <param name="app">Object Of Owin App builder inject By Owin Startup dll.</param>
        public void Configuration(IAppBuilder app)
        {
            Bootstrap.Initialize();//Unity DI
            BuildConfiguration();//SET Route, Filter Config.
            ConfigureAuth(app);
            app.UseStaticFiles(new StaticFileOptions
            {
                OnPrepareResponse = context =>
                {
                    IHeaderDictionary headers = context.OwinContext.Response.Headers;
                    string contentType = headers["Content-Type"];
                    if (contentType == "application/x-gzip")
                    {
                        if (context.File.Name.EndsWith("js.gz"))
                        {
                            contentType = "application/javascript";
                        }
                        else if (context.File.Name.EndsWith("css.gz"))
                        {
                            contentType = "text/css";
                        }
                        headers.Add("Content-Encoding", new[] { "gzip" });
                        headers["Content-Type"] = contentType;
                    }
                }
            });

            var corsPolicy = new CorsPolicy
            {
                PreflightMaxAge = 21600,
                SupportsCredentials = true,
                Origins = { AzureAdConfig.AadAuthorityUri.ToString().TrimEnd('/'),
                    AzureAdConfig.RedirectUrl.ToString().TrimEnd('/'),
                    AzureAdConfig.WebApiUrl.ToString().TrimEnd('/')

                }
            };

            MessageConstants.CrosHeaders.ForEach(d => corsPolicy.Headers.Add(d));
            MessageConstants.CrosMethods.ForEach(d => corsPolicy.Methods.Add(d));

            //remove the asp.net version from the response.
            app.Use(async (context, next) =>
            {
                context.Response.OnSendingHeaders(state =>
                {
                    ((OwinResponse)state).Headers.Remove("server");
                    ((OwinResponse)state).Headers.Remove("x-aspnet-version");
                    ((OwinResponse)state).Headers.Remove("x-powered-by");
                }, context.Response);

                await next().ConfigureAwait(false);
            });

            //Configuring X-Content-Type-Options
            app.UseXContentTypeOptions();
            //Configuring X-Frame - Options
            app.UseXfo(options => options.Deny());
            //Configuring Strict-Transport - Security
            app.UseHsts(options => options.MaxAge(days: 1).IncludeSubdomains());
            //Configuring X-XSS - Protection
            app.UseXXssProtection(options => options.EnabledWithBlockMode());
            //Configuring X-Download-Options
            app.UseXDownloadOptions();
            //Redirect validation
            app.UseRedirectValidation(options =>
                options.AllowedDestinations(AzureAdConfig.RedirectUrl.ToString(), AzureAdConfig.WebApiUrl.ToString())
                    .AllowSameHostRedirectsToHttps());
            app.UseCors(new CorsOptions
            {
                PolicyProvider = new CorsPolicyProvider
                {
                    //PolicyResolver = context => Task.FromResult(corsPolicy)
                    PolicyResolver = context => Task.FromResult(new CorsPolicy()
                    {
                        AllowAnyHeader = true,
                        AllowAnyMethod = true,
                        AllowAnyOrigin = true
                    })
                }
            });
        }
        /// <summary>
        /// in this method we set the mvc application Filters, route and bundle config details.
        /// </summary>
        private static void BuildConfiguration()
        {
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            // For Handling the Exceptions globally across Web project

            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
    }
}