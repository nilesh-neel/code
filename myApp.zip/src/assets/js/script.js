$(document).ready(function () {
	//onscroll fix for combobox
	jQuery('#filterOptions.scrollbar-inner,#ShareOptions.scrollbar-inner,.errorField.scrollbar-inner,.internalDiv.scrollbar-inner').scrollbar({
    "onScroll": function(y, x){
	$('.custom-combobox-input').each(function (index, item) {
				 if(!($(item).css("display")=='none'))
					  {        	 

					      $.when($(item).autocomplete("close")).done(
							function() 
							{   
								return false;
							});
			
                 }
		});   
		
       
    }
	
	
	
});
//for hidding combobox hidding 
$(document).on('mouseleave', '.ui-autocomplete,.custom-combobox-input,.slidingRow .ui-autocomplete,.slidingRow .custom-combobox-input', function(e){
if($(e.currentTarget).hasClass('custom-combobox-input')){
if(!$(e.relatedTarget).hasClass('ui-autocomplete')){
	
$('.custom-combobox-input').each(function (index, item) {
				 if(!($(item).css("display")=='none'))
					  {        	 

					      $.when($(item).autocomplete("close")).done(
							function() 
							{   
								return false;
							});
			
                 }
		});   
}
}	

else if($(e.currentTarget).hasClass('ui-autocomplete'))
{
	$('.custom-combobox-input').each(function (index, item) {
				 if(!($(item).css("display")=='none'))
					  {        	 

					      $.when($(item).autocomplete("close")).done(
							function() 
							{   
								return false;
							});
			
                 }
		});   
}
});
menuSlidingCount=null;
menuSlidingInitialVal=null;//global variable
});


/* View All Link click start */

$("#viewAllLink").click(function () {
  $('a[href="#notification"]').click();
  
  function calNotifSettingsTab(){
    $('#tabs a[href="#todaysNotifications"]').trigger('click');
  }
  
  setTimeout(calNotifSettingsTab, 200);
  
});
$("#viewAllBtn").click(function () {
  $('a[href="#alerts"]').click();
  
  function calTodaysAlertTab(){
    $('#tabs a[href="#todaysAlerts"]').trigger('click');
  }
  
  setTimeout(calTodaysAlertTab, 200);
  
});

/* View All Link click end */



/*datatables initialization  code*/
$(function () {
	

  $('table tbody td ').on('click', '.Edit', function () {
    var nTr = $(this).parents('tr')[0];
    var me = this;
    var Show_details = '.Show_details';
    var tableName = $(this).closest('table').attr('id');

    $(this).closest('table').find('tr.show_row').removeClass('show_row');
    $(nTr).addClass('show_row');
    if (tableName === 'alertSettingTable') {

      triggerRowExpansion(nTr, Show_details, alertsSettings, me, fnFormatEditAlertsDetails);
	  multiSelectFnCall();
	      }

    if (tableName === 'configureAlertsTable') {

      triggerRowExpansion(nTr, Show_details, oTable, me, fnFormatEditConfDetails);
	  multiSelectFnCall();//multiselect function call
      
    }

    if (tableName === 'ConfigureNotificationTable') {

      triggerRowExpansion(nTr, Show_details, configureNotif, me, fnFormatEditConfNotificationDetails);
	  	  multiSelectFnCall();//multiselect function call

    }

    if (tableName === 'notificationSettingsTable') {


      triggerRowExpansion(nTr, Show_details, notifiSettings, me, fnFormatEditNotificationDetails);
	  multiSelectFnCall();// multiselect function call

    }

    if (tableName === 'reportsTable') {
      triggerRowExpansion(nTr, Show_details, reportDataTable, me, fnFormatEditNotificationDetails);

    }
	  /***datepicker***/
    $(".formCalendarIcon").daterangepicker({
      singleDatePicker: true,
      showDropdowns: true
    });
    /***datepicker ends***/

    $(".combobox").combobox();
    $(".custom-combobox-input ").attr("placeholder", "Select");
    $("#verticalTabs").height($(".zeroStyling:last-child").height());//to calculate the height if verticalTabs
 });


  $('table tbody td ').on('click', '.Show_details', function () {


    var nTr = $(this).parents('tr')[0];

    $(this).closest('table').find('tr.show_row').removeClass('show_row');
    $(nTr).addClass('show_row');


    var me = this;
    var Edit = '.Edit';
    var tableName = $(this).closest('table').attr('id');

    

    if (tableName === 'alertSettingTable') {

      triggerRowExpansion(nTr, Edit, alertsSettings, me, fnFormatalertsSettings);

    }

    if (tableName === 'configureAlertsTable') {

      triggerRowExpansion(nTr, Edit, oTable, me, fnFormatDetails);

    }

    if (tableName === 'ConfigureNotificationTable') {

      triggerRowExpansion(nTr, Edit, configureNotif, me, fnFormatConfNotification);

    }

    if (tableName === 'notificationSettingsTable') {


      triggerRowExpansion(nTr, Edit, notifiSettings, me, fnFormatNotification);

    }

    if (tableName === 'todaysAlertTable') {

      triggerRowExpansion(nTr, Edit, todaysAlerts, me, fnFormatTodaysAlerts);

    }

    if (tableName === 'TodaysNotificationsTable') {

      triggerRowExpansion(nTr, Edit, todaysNotif, me, fnFormatTodaysNotif);

    }

    if (tableName === 'reportsTable') {
      triggerRowExpansion(nTr, Edit, reportDataTable, me, fnFormatReportsTable);

    }
   $("#verticalTabs").height($(".zeroStyling:last-child").height());//to calculate the height if verticalTabs
  });


 var numberOfRows=rowCountFn(); 
 var bagListRows=rowCountFnBagSearchList();

  var todaysAlerts = $('#todaysAlertTable').dataTable({
    "pagingType": "full_numbers",
    "ordering": true,
    "info": false,
    "bLengthChange": false,
    "bAutoWidth": false,
    "searching": false,
    "iDisplayLength": numberOfRows,
    "responsive": true,
    "oLanguage": {
      "oPaginate": {
        "sFirst": "First",
        "sNext": '<img class="Next" src="" />',
        "sPrevious": '<img class="Previous" src="" />',
        "sLast": "Last"
      }
    },
	'aoColumnDefs': [{
        'bSortable': false,
        'aTargets': ['nosort']
    }]

  });

  var alertsSettings = $('#alertSettingTable').dataTable({
    "pagingType": "full_numbers",
    "ordering": true,
    "info": false,
    "bLengthChange": false,
    "bAutoWidth": false,
    "searching": false,
    "iDisplayLength": numberOfRows,
    "responsive": true,
    "oLanguage": {
      "oPaginate": {
        "sFirst": "First",
        "sNext": '<img class="Next" src="" />',
        "sPrevious": '<img class="Previous" src="" />',
        "sLast": "Last"
      }
    },
	'aoColumnDefs': [{
        'bSortable': false,
        'aTargets': ['nosort']
    }]
  });

  var oTable = $('#configureAlertsTable').dataTable({
    "pagingType": "full_numbers",
    "ordering": true,
    "info": false,
    "bLengthChange": false,
    "bAutoWidth": false,
    "iDisplayLength": numberOfRows,
    "searching": false,
    "responsive": true,
    "oLanguage": {
      "oPaginate": {
        "sFirst": "First",
        "sNext": '<img class="Next" src="" />',
        "sPrevious": '<img class="Previous" src="" />',
        "sLast": "Last"
      }
    },
   'aoColumnDefs': [{
        'bSortable': false,
        'aTargets': ['nosort']
    }]
  });





  var todaysNotif = $('#TodaysNotificationsTable').dataTable({
    "pagingType": "full_numbers",
    "ordering": true,
    "info": false,
    "bLengthChange": false,
    "bAutoWidth": false,
    "iDisplayLength": numberOfRows,
    "searching": false,
    "responsive": true,
    "oLanguage": {
      "oPaginate": {
        "sFirst": "First",
        "sNext": '<img class="Next" src="" />',
        "sPrevious": '<img class="Previous" src="" />',
        "sLast": "Last"
      }
    },
	'aoColumnDefs': [{
        'bSortable': false,
        'aTargets': ['nosort']
    }]
  });

  var notifiSettings = $('#notificationSettingsTable').dataTable({
    "pagingType": "full_numbers",
    "ordering": true,
    "info": false,
    "bLengthChange": false,
    "bAutoWidth": false,
    "iDisplayLength": numberOfRows,
    "searching": false,
    "responsive": true,
    "oLanguage": {
      "oPaginate": {
        "sFirst": "First",
        "sNext": '<img class="Next" src="" />',
        "sPrevious": '<img class="Previous" src="" />',
        "sLast": "Last"
      }
    },
	'aoColumnDefs': [{
        'bSortable': false,
        'aTargets': ['nosort']
    }]
  });

  var configureNotif = $('#ConfigureNotificationTable').dataTable({
    "pagingType": "full_numbers",
    "ordering": true,
    "info": false,
    "bLengthChange": false,
    "bAutoWidth": false,
    "iDisplayLength": numberOfRows,
    "searching": false,
    "responsive": true,
    "oLanguage": {
      "oPaginate": {
        "sFirst": "First",
        "sNext": '<img class="Next" src="" />',
        "sPrevious": '<img class="Previous" src="" />',
        "sLast": "Last"
      }
    },
	'aoColumnDefs': [{
        'bSortable': false,
        'aTargets': ['nosort']
    }]
  });

  var reportDataTable = $('#reportsTable').dataTable({
    "pagingType": "full_numbers",
    "ordering": true,
    "info": false,
    "bLengthChange": false,
    "bAutoWidth": false,
    "iDisplayLength": numberOfRows,
    "searching": false,
    "responsive": true,
    "oLanguage": {
      "oPaginate": {
        "sFirst": "First",
        "sNext": '<img class="Next" src="" />',
        "sPrevious": '<img class="Previous" src="" />',
        "sLast": "Last"
      }
    },
	'aoColumnDefs': [{
        'bSortable': false,
        'aTargets': ['nosort']
    }]
  });  
  
  var bagSearchListTable = $('#bagSearchListTable').dataTable({
    "pagingType": "full_numbers",
    "ordering": true,
    "info": false,
    "bLengthChange": false,
    "bAutoWidth": false,
    "iDisplayLength": bagListRows,
    "searching": false,
    "responsive": true,
    "oLanguage": {
      "oPaginate": {
        "sFirst": "First",
        "sNext": '<img class="Next" src="" />',
        "sPrevious": '<img class="Previous" src="" />',
        "sLast": "Last"
      }
    },
	'aoColumnDefs': [{
        'bSortable': false,
        'aTargets': ['nosort']
    }]
  });
  

  function triggerRowExpansion(nTr, prevClickedIcon, otable, me, tempName) {

    console.log($(nTr));

    otable.api().rows().every(function () {
      //&& !$(this.node()).hasClass('show_row')
      if (otable.fnIsOpen(this) && !($(this.node()).hasClass('show_row'))) {
        console.log(this.node());
        console.log(nTr);
        console.log($(nTr));
        otable.fnClose(this);
        // $(this.node()).removeClass('show_row')
        // $(this.node()).removeClass();
        $(this.node()).find("td").removeClass("showDetailsActive");
        $(this.node()).find("td span.clickedIcons").removeClass("clickedIcons").removeClass('customBorderSmall');
      }

    });

    // if ( !otable.fnIsOpen(nTr) )
    // {

    if ($(nTr).find(prevClickedIcon).hasClass('customBorderSmall')) {
      $(nTr).find(prevClickedIcon).closest("tr").find("td").toggleClass("showDetailsActive");
      $(nTr).find(prevClickedIcon).next().toggleClass("clickedIcons");
      $(nTr).find(prevClickedIcon).toggleClass("customBorderSmall");
      $(nTr).find(prevClickedIcon).closest("td").find("span").removeClass("clickedIcons");
      otable.fnClose(nTr);

    }

    if (otable.fnIsOpen(nTr)) {
      /* This row is already open - close it */
      // $(nTr).removeClass('show_row');
      otable.fnClose(nTr);
      $(me).closest("tr").find("td").toggleClass("showDetailsActive");
      $(me).removeClass("clickedIcons");
      $(me).toggleClass("customBorderSmall");
      $(me).next().toggleClass("clickedIcons");
      $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
      // $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
    }
    else {
      /* Open this row */
      // $(nTr).addClass('show_row');
      $(me).closest("tr").find("td").toggleClass("showDetailsActive");
      $(me).addClass("clickedIcons");
      $(me).next().toggleClass("clickedIcons");
      $(me).toggleClass("customBorderSmall");
      $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
      otable.fnOpen(nTr, tempName(otable, nTr), 'details');

      //$("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
    }

    //}
  }


  /* Pin Icon functionality in filters panel start */

  $('#pinIcon').click(function (event) {


    $('#pinIcon').toggleClass("Pin");
    $('#pinIcon').toggleClass("pinclicked");
  });

  $('#pinIconLink').hover(function (event) {

    $(this).removeClass('hovered-content');
    if ($('#pinIcon').hasClass("pinclicked")) {
      $('#pinIconLink').tooltip("hide");
      $(this).addClass('hovered-content');


    }
  });

  /* Pin Icon functionality in filters panel end */


  /* vertical tabs click functionality*/

  $('a[href="#alerts"]').click(function (event) {
    $('#tabs ul li').css('display', 'none');
    $('.configureAlertForm').css('display', 'none'); $('.configureNotificationForm').css('display', 'none');
    $("#ConfigureNotificationTable_wrapper").show();
    $('.alertTabs').css('display', 'block');
    $(".dataTables_paginate").css('display', 'block');
    $('a[href="#todaysAlerts"]').trigger('click');
  });

  $('a[href="#notification"]').click(function (event) {
    $('#tabs ul li').css('display', 'none');
    $('.configureAlertForm').css('display', 'none'); $('.configureNotificationForm').css('display', 'none');
	$("#configureAlertsTable_wrapper").show();
    $('.notificationTabs').css('display', 'block');
	
    $(".dataTables_paginate").css('display', 'block');
    $('a[href="#todaysNotifications"]').trigger('click');
  });

  $('a[href="#reports"]').click(function (event) {

    $('#tabs ul li').css('display', 'none');
    $('.configureAlertForm').css('display', 'none'); $('.configureNotificationForm').css('display', 'none');
    $('.reportTabs').css('display', 'block');
    $(".dataTables_paginate").css('display', 'block');
    $('a[href="#reportsTab"]').trigger('click');


  });

  $('#tabs a[href="#todaysAlerts"]').click(function (event) {
    $('.configureAlertForm').css('display', 'none'); $('.configureNotificationForm').css('display', 'none');
    $('.configureBtn').css('display', 'block');
    $('.configureBtn button').css('display', 'none');
	$('.configureBtnNotification').css('display', 'block');
    $('.configureBtnNotification button').css('display', 'none');


  });


  $('#tabs a[href="#alertSettings"]').click(function (event) {
    $('.configureAlertForm').css('display', 'none'); $('.configureNotificationForm').css('display', 'none');
    $('.configureBtn').css('display', 'block');
    $('.configureBtn button').css('display', 'none');
		$('.configureBtnNotification').css('display', 'block');
    $('.configureBtnNotification button').css('display', 'none');


  });

  $('#tabs a[href="#configureAlerts"]').click(function (event) {
    $('.configureBtn').css('display', 'block');
    $('.configureBtn button').css('display', 'none');
    $('#congigureNewAlertBtn').css('display', 'block');
    $('.configureBtnNotification').css('display', 'block');
    $('.configureBtnNotification button').css('display', 'none');

  });

  $('#tabs a[href="#configureNotifications"]').click(function (event) {
    $('.configureBtn').css('display', 'none');$('.configureNotificationForm').css('display', 'none');
    $('.configureBtn button').css('display', 'none');
    
    $('.configureBtnNotification').css('display', 'block');
    $('.configureBtnNotification button').css('display', 'none');
	$('#configureNewNotificationBtn').css('display', 'block');
});

  $('#tabs a[href="#notificationSettings"]').click(function (event) {
        $('.configureAlertForm').css('display', 'none'); $('.configureNotificationForm').css('display', 'none');
    $('.configureBtn').css('display', 'block');
	$('.configureBtn button').css('display', 'none');
		$('.configureBtnNotification').css('display', 'block');
    $('.configureBtnNotification button').css('display', 'none');


  });




  $('#tabs a[href="#reportsTab"]').click(function (event) {
    $('.configureAlertForm').css('display', 'none'); $('.configureNotificationForm').css('display', 'none');

    $('.configureBtn').css('display', 'block');
    $('.configureBtn button').css('display', 'none');
		$('.configureBtnNotification').css('display', 'block');
    $('.configureBtnNotification button').css('display', 'none');
    $('#newReportBtn').css('display', 'block');

  });

  $('#tabs a[href="#assignHomePagePanel"]').click(function (event) {
    $('.configureAlertForm').css('display', 'none'); $('.configureNotificationForm').css('display', 'none');

    $('.configureBtn').css('display', 'block');
    $('.configureBtn button').css('display', 'none');
		$('.configureBtnNotification').css('display', 'block');
    $('.configureBtnNotification button').css('display', 'none');


  });





  $('a[href="#reports"]').click(function (event) {

    $('#tabs ul li').css('display', 'none');
    $('.configureAlertForm').css('display', 'none'); $('.configureNotificationForm').css('display', 'none');
    $('.reportTabs').css('display', 'block');
    $('#newReportBtn').css('display', 'block');
    $(".dataTables_paginate").css('display', 'block');
    $('a[href="#reportsTab"]').trigger('click');


  });





  $('a[href="#assignHomePageNav"]').click(function (event) {
    $('#tabs ul li').css('display', 'none');
    $('.configureAlertForm').css('display', 'none'); $('.configureNotificationForm').css('display', 'none');
    $('.assignHomeTabs').css('display', 'block');
    $(".dataTables_paginate").css('display', 'none');
    $('a[href="#assignHomePagePanel"]').trigger('click');

  });


 // /* congigureNewAlertBtn button functionality in configureSettings tab start*/
  $("#congigureNewAlertBtn").click(function () {

       $('#tabs ul li').css('display', 'none');
    $('.congigureTab').css('display', 'block');
    $("#configureAlertsTable_wrapper").css('display', 'none');
	  //$("#ConfigureNotificationTable_wrapper").css('display', 'none');
    $('.configureBtn').css('display', 'block');
    $('.configureBtn button').css('display', 'none');
	
    $('#configureBackBtn').css('display', 'block');
    $('.configureAlertForm').css('display', 'block');
    


  });

  $("#configureBackBtn").click(function () {
    $('#tabs ul li').css('display', 'none');
    $('.alertTabs').css('display', 'block');
    $('.configureBtn').css('display', 'block');
    $('.configureBtn button,.configureAlertForm').css('display', 'none');
    // $("#tabs a[href='#alertSettings'] , #tabs a[href='#todaysAlerts']").css('display','block');
    $("#configureAlertsTable_wrapper").show();
    $("#tabs a[href='#configureAlerts']").click();


  });
  

	  // /* congigureNewNotificationBtn button functionality in configureSettings tab start*/
	  $("#configureNewNotificationBtn").click(function () {

		$('#tabs ul li').css('display', 'none');
		$('.configureNotificationTab ').css('display', 'block');
	    //$("#configureAlertsTable_wrapper").css('display', 'none');
        $("#ConfigureNotificationTable_wrapper").css('display', 'none');
	    $('.configureBtnNotification').css('display', 'block');
		$('.configureBtnNotification button').css('display', 'none');	
		$('#configureBackNotificationBtn').css('display', 'block');
		$('.configureNotificationForm').css('display', 'block');
	  });

	  $("#configureBackNotificationBtn").click(function () {
		$('#tabs ul li').css('display', 'none');
		$('.notificationTabs').css('display', 'block');
		$('.configureBtnNotification').css('display', 'block');
		$('.configureBtnNotification button,.configureNotificationForm').css('display', 'none');
		// $("#tabs a[href='#alertSettings'] , #tabs a[href='#todaysAlerts']").css('display','block');
		$("#ConfigureNotificationTable_wrapper").show();
		$("#tabs a[href='#configureNotifications']").click();


	  });




  function fittabletoscreen() {

    if ($(window).width() <= 1024 && $(window).width() >= 768) {


      alertsSettings.fnSetColumnVis(6, false, false);
      alertsSettings.fnSetColumnVis(7, false, false);
      alertsSettings.fnSetColumnVis(0, true, true);
      alertsSettings.fnSetColumnVis(3, true, true);
      alertsSettings.fnSetColumnVis(4, true, true);
      oTable.fnSetColumnVis(0, true, true);
      oTable.fnSetColumnVis(3, true, true);
      oTable.fnSetColumnVis(5, true, true);
      oTable.fnSetColumnVis(4, false, false);
      oTable.fnSetColumnVis(6, false, false);
      oTable.fnSetColumnVis(7, false, false);
      configureNotif.fnSetColumnVis(4, false, false);
      configureNotif.fnSetColumnVis(6, false, false);
      configureNotif.fnSetColumnVis(7, false, false);
      configureNotif.fnSetColumnVis(8, false, false);
      configureNotif.fnSetColumnVis(3, true, true);
      configureNotif.fnSetColumnVis(5, true, true);
      todaysAlerts.fnSetColumnVis(1, true, true);
      notifiSettings.fnSetColumnVis(3, true, true);

    }

    else if ($(window).width() <= 767 && $(window).width() >= 320) {
      todaysAlerts.fnSetColumnVis(1, false, false);
      alertsSettings.fnSetColumnVis(0, false, false);
      alertsSettings.fnSetColumnVis(3, false, false);
      alertsSettings.fnSetColumnVis(4, false, false);
      alertsSettings.fnSetColumnVis(6, false, false);
      alertsSettings.fnSetColumnVis(7, false, false);
      notifiSettings.fnSetColumnVis(3, false, false);

      oTable.fnSetColumnVis(0, false, false);
      oTable.fnSetColumnVis(3, false, false);
      oTable.fnSetColumnVis(4, false, false);
      oTable.fnSetColumnVis(5, false, false);
      oTable.fnSetColumnVis(6, false, false);
      oTable.fnSetColumnVis(7, false, false);

      configureNotif.fnSetColumnVis(3, false, false);
      configureNotif.fnSetColumnVis(4, false, false);
      configureNotif.fnSetColumnVis(5, false, false);
      configureNotif.fnSetColumnVis(6, false, false);
      configureNotif.fnSetColumnVis(7, false, false);
      configureNotif.fnSetColumnVis(8, false, false);



    }

    else {
      alertsSettings.fnSetColumnVis(6, true, true);
      alertsSettings.fnSetColumnVis(7, true, true);
      alertsSettings.fnSetColumnVis(0, true, true);
      alertsSettings.fnSetColumnVis(3, true, true);
      alertsSettings.fnSetColumnVis(4, true, true);

      oTable.fnSetColumnVis(4, true, true);
      oTable.fnSetColumnVis(6, true, true);
      oTable.fnSetColumnVis(7, true, true);
      oTable.fnSetColumnVis(0, true, true);
      oTable.fnSetColumnVis(3, true, true);
      oTable.fnSetColumnVis(5, true, true);
      configureNotif.fnSetColumnVis(3, true, true);
      configureNotif.fnSetColumnVis(4, true, true);
      configureNotif.fnSetColumnVis(5, true, true);
      configureNotif.fnSetColumnVis(6, true, true);
      configureNotif.fnSetColumnVis(7, true, true);
      configureNotif.fnSetColumnVis(8, true, true);
      todaysAlerts.fnSetColumnVis(1, true, true);
      notifiSettings.fnSetColumnVis(3, true, true);
    }

  };


  fittabletoscreen();  //initial call
  $(window).resize(function () {
    //change in landscape and portrait view
    console.log('resize called');
	calComponentsHeight();
	PanelHeight();
    fittabletoscreen();
	checkPosition();
	
	//countMenuItems();
	rowCountFn();
    //location.reload();
	if($(".hamburgerSideBar").height()<$(".menu li").innerHeight()*$(".menu li").length)
	{
	listPopulation($(".menu li"));
	}
	if (window.matchMedia('(min-width:768px)').matches) {
      $(".searchDivMobile").hide();
    
	}
	if (window.matchMedia('(min-width:640px)').matches) {
      if($(".searchDivMobile").css("display")=="none")
	  {
	  $(".searchImgMobile").show();
	  }
	}
	
  });

});

$(document).ready(function () {
	  
 /*$(".comboStylings").on("click",".custom-combobox",function(event){
var saveClickEvent=event;
$('ul.ui-autocomplete').each(function (index, item) {
				  
					if (!this.style.display) {
						 /*$(item).parent().css("top", 0);
						  $(item).parent().css("left", 0);
						  
						  var topPosition, bottomPositon;
						  topPosition = $(item).css("top");
						  leftPosition = $(item).css("left");
						console.log(topPosition)
						//  console.log(topPosition, leftPosition);
                        
						  $(item).parent().css("top", topPosition);
						  $(item).parent().css("left", leftPosition);
						  $(item).parent().css('border','1px solid #c5c5c5');
						  $(item).parent().css('width',listWidth);
						  $(this).removeAttr('style');*/
						 /* var comboboxDiv=$(this).parent().detach(); // detaching
						  $(saveClickEvent.target).parent().append(comboboxDiv);
						  var  topPosition = $(comboboxDiv).children('ul').css("top");
						  var  leftPosition = $(comboboxDiv).children('ul').css("left");
						  $(comboboxDiv).css("top", topPosition);
						  $(comboboxDiv).css("left", leftPosition);
						  $(comboboxDiv).css('border','1px solid #c5c5c5');
						  
						  $( ".selector" ).autocomplete( "option", "appendTo", "#someElem" );
						  return false
						  
						}

			  });
});*/
	checkPosition();
	multiSelectFnCall();
	calComponentsHeight();
	rowCountFn();
	linkingEmbedded("Settings");
	if($(".hamburgerSideBar").height()<$(".menu li").innerHeight()*$(".menu li").length)
	{
	listPopulation($(".menu li"));
	}
  /***datepicker***/

  $(".formCalendarIcon").daterangepicker({

    singleDatePicker: true,
    showDropdowns: true

  });
  /***datepicker ends***/
  multipleDatesSelector();
  
  /**search**/

  $(".searchImg").click(function () {
    if ($(this).siblings(".searchIcon").val())
	{
      $(".loader").css("display", "inline-block");
      $(".breadcrumb li").remove();
	  $(".verticalNavigation li").remove();
	  var elm='';
	   if ($(".breadcrumb").css("display") !="none") {
          elm= "<li class='active'><a href='#' data-type='Settings'> ALERTS </a></li>";
		  //$(".breadcrumb").append(elm);
        }
        else {
          elm= "<li class='customStyling active' data-type='Settings'><a href='#' >ALERTS</a></li>";
		  //$(".verticalNavigation").append(elm);
        }
    
		setTimeout(function() { 
		$(".loader").css("display", "none");
		linkingEmbedded("BagSearchList");
		
    }, 1000);
	}
  
  });

  /**search ends**/
  /***vertical breadcrumb****/
  $(".navADPBreadCrumb").click(function () {
    event.stopPropagation();
    $(".verticalNavigation").toggle();

  });


  /***refresh***/
  $(".refresh").click(function () {

    $(".refreshMessage").css("display", "block");
  });


  $(".closeText").click(function () {
    $(".refreshMessage").css("display", "none");
  });

  /***refresh close***/

  $('.hamburger').click(function (event) {
	  
    event.stopPropagation();
	$(".menu li.subDropdown .dropdown-content").css("display","none");
    $('#homeNavigationBar').toggleClass('active');
	$('.hamburger').toggleClass("clickedIcons").toggleClass("defaultIcons");
	$('.hambergerDiv').toggleClass('hambergerActive');
	$('.hamburgerSideBar').toggleClass('SideBarActive');
	$(".menu").css("margin-top","0");//reseting the margin value to 0
		menuSlidingCount,menuSlidingInitialVal=0;
		if($('#homeNavigationBar').hasClass('active'))
	    {
		//countMenuItems();
		//listPopulation($(".menu li"));
		/*$(".headerPosition").css("z-index",($(".headerPosition").css("z-index"))*10);*/
		}
		
		else
		{
			$("#bottomArrow,#topArrow").hide();
			/*$(".headerPosition").css("z-index",($(".headerPosition").css("z-index"))/10);*/
		}
  });
  

/*$(document).on('mouseleave', '#homeNavigationBar', function () {
        $('#homeNavigationBar').removeClass('active');
		$("#topArrow,#bottomArrow").hide();
		 $('.hamburger').removeClass("clickedIcons").addClass("defaultIcons");
		 $('.hambergerDiv').removeClass('hambergerActive');
});*/
$(document).on('mouseenter', '#homeNavigationBar', function () {
       $('.hamburger').addClass("clickedIcons").removeClass("defaultIcons");
	   $('.hambergerDiv').addClass('hambergerActive');
	   $('.hamburgerSideBar').addClass('SideBarActive');
	   
});
//logout popup
  $(".logout").click(function () {
    $("#logoutPopup").modal('show');
  });
 
//delete popup 
 $(".delete").click(function () {
    $("#notesDeletePopup").modal('show');
  }); 
  
//cancel popup  
  $(".dataTables_wrapper").on("click",".cancelButton",function () {
    $("#cancelBtnPopup").modal('show');
  });
    
	

  /**logout toggle***/
  $(".user").click(function (event) {
   event.stopPropagation();
    $(".settingsLogout").toggle();
	 $(".alertPopup").hide();
  });

  $("#userDetailsPanel").click(function (event) {
    event.stopPropagation();
    $('.settingsLogout').attr("style", "display: inline-block !important");
  });

  $(document).click(function (e) {
  
    //inorder to reduce the z-index navposition
	/*if($(e.target).parent().hasClass("navIconsList"))
	{
		  if($(".navPosition").css("z-index")<$(".headerPosition").css("z-index"))
		  {
		   $(".navPosition").css("z-index",($(".headerPosition").css("z-index"))*10);//inorder to show the tooltip we are reducing the z-index of header than nav
		  }
	}
   else
	{
		  if($(".navPosition").css("z-index")>$(".headerPosition").css("z-index"))
		   {
		    $(".navPosition").css("z-index",($(".headerPosition").css("z-index"))/10);
		   }
		   
	}*/
	
	
    $(".settingsLogout,.alertPopup").hide();
	 
	 if (e.target.id !== "bottomArrow" && e.target.id !== "topArrow")
	{
		
    $('#homeNavigationBar').removeClass('active');
	 $('.hamburgerSideBar').removeClass('SideBarActive');
	$("#bottomArrow,#topArrow").hide();
	$(".hambergerDiv").removeClass("hambergerActive");
	$(".hamburger").removeClass("clickedIcons").addClass("defaultIcons");

	}
	$(".alerts").removeClass("alertsClicked");
  
    if (e.target.id !== "mobileSearchInputBox" && e.target.id !== "searchMobile")
    {
      $(".searchDivMobile").css("display", "none");
      $('.searchImgMobile').attr("style", "display: inline-block !important");
   
    
	}
	if (e.target.id !== "verticalBreadCrumb") 
	{
		$(".verticalNavigation").hide();
	}
	if (e.target.id == "userDetailsPanel") 
	{
		   $('.settingsLogout').attr("style", "display: inline-block !important");
	}
	$(".dropdown-content").css("display", "none");
  });


  /**logout toggle ends***/



  /**note script**/
  $('.notes,.filter,.share,.cancel').click(function (event) {
   // event.stopPropagation();
    $(".sideNavBar").not("#" + $(this).data("sidepanel")).css("display", "none");
    $(this).children(".spanNotification").css("display", "none");
    $("#" + $(this).data("sidepanel")).toggle();

    if ($(this).parent().data("iconclick"))//cancel click
    {

      $("." + $(this).parent().data("subDropdown")).toggleClass("clickedIcons");
      $("." + $(this).parent().data("iconclick")).toggleClass("customBorderSmall");
    }

    else//icon click
    {
      $('.notes,.filter,.share,.cancel').not(this).removeClass("clickedIcons");
      $('.notes,.filter,.share,.cancel').not(this).removeClass("customBorderSmall");
      $(this).toggleClass("clickedIcons");
      $(this).toggleClass("customBorderSmall");
    }
	PanelHeight();

  });




  /**note script Ends**/
  $(".alerts").click(function (event) {
    event.stopPropagation();
   /* $(this).children(".spanNotification").css("display", "none");*/
	$(this).toggleClass("alertsClicked");
    $(".alertPopup").toggle();
	 $(".settingsLogout").hide();
  });

  /** alert Popup**/
  $(".alertPopup").click(function (event) {
    event.stopPropagation();
  });


  /***hambereger hover***/
 /* jQuery('.hambergerDiv').hover(function () {

    jQuery(this).find('.defaultIcons').toggleClass("clickedIcons").toggleClass("defaultIcons");
  }, function () {
    jQuery(this).find('.clickedIcons').toggleClass("clickedIcons").toggleClass("defaultIcons");
  });*/

  /***Menu  hover***/
  jQuery('ul.menu li').hover(function () {

    $(".menu li.subDropdown .dropdown-content").css("display","none");

    jQuery(this).find('span').toggleClass("clickedIcons").toggleClass("defaultIcons");
   
    //$(this).tooltip("show");

  });/*, function () {
    jQuery(this).find('span').toggleClass("clickedIcons").toggleClass("defaultIcons");
	$(".menu li.subDropdown .dropdown-content").css("display","none");
  });*/
  /****vertical tabs hover***/

  jQuery('#verticalTabs li').click(function () {
    jQuery('#verticalTabs li').find('span:first-child').removeClass("clickedIcons").addClass("defaultIcons");
    jQuery(this).find('span:first-child').toggleClass("clickedIcons").toggleClass("defaultIcons");

  });

  /***groomcroll***/


  /***groomscroll Ends***/
  
  
  /***doument scroll***/
  $(document).scroll(function(){
	 // $("#topArrow").css("top",$(".hambergerDiv").innerHeight());

	   if(screen.height<650)
	  {
	   $(".hambergerDiv").removeClass('hambergerActive');
	   $("#bottomArrow,#topArrow").hide();
	   $("#homeNavigationBar").removeClass('active');
	    $('.hamburgerSideBar').removeClass('SideBarActive');
	   $(".hamburger").removeClass("clickedIcons").addClass("defaultIcons");
	  }
	  if(screen.width<768) // to hide first header in mobile on scroll
	  {
		  if ($(document).scrollTop()!=0)
		  {
			 $(".headerPosition").css("top",-$(".headerPosition").innerHeight()); 
		     $(".navPosition").css("top",0);
		      $("#topArrow").css("top",$(".hambergerDiv").innerHeight());
		  }
		  else
		  {
			  	 $(".navPosition").css("top",$(".headerPosition").innerHeight()); 
		         $(".headerPosition").css("top",0);
				 $("#topArrow").css("top",$(".header").innerHeight() + $(".hambergerDiv").innerHeight());
			
		  }
		 
	  }
	  
	
  });
  
 /***doumentscroll ends***/ 
});
// Example starter JavaScript for disabling form submissions if there are invalid fields

/***Date Range Picker***/


//disabling dates
  function getTodayDate() {
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is not 0!
        var yyyy = today.getFullYear();
        if (dd < 10) { dd = '0' + dd }
        if (mm < 10) { mm = '0' + mm }
        today = dd+'/'+mm+'/'+yyyy;
        return today;
    };
    function getYearAgo(){
    var lastYear = new Date();
    var dd = lastYear.getDate();
    var mm = lastYear.getMonth()-2+1; //go back t0 14 months 
    var yyyy = lastYear.getFullYear(getTodayDate) - 1;//go back t0 14 months 
	if(mm<=0){mm=mm+12}
    if (dd < 10) { dd = '0' + dd }
    if (mm < 10) { mm = '0' + mm }
    lastYear = dd+'/'+mm+'/'+yyyy;  
   
    return lastYear;
    };

/** single datepicker **/
 function singleDateSelector()
 {
var today=getTodayDate();
var lastYearDate=getYearAgo();
 $('#headerDate').daterangepicker(
 
	{
      
	 // "autoApply": false,
	  "singleDatePicker": true,
      "startDate": today,
      "endDate": today,
	  "maxDate":today,
	  "minDate":lastYearDate,
	  "locale": {
		firstDay: 1 ,  
        format: 'DD/MM/YYYY',

      }
	 
    });
 }
 /** single datepicker  ends  **/
 
 /** Multiple datepicker **/
  function multipleDatesSelector()
 {
var today=getTodayDate();
var lastYearDate=getYearAgo();
 $('#headerDate').daterangepicker(
 
	{
      
	 // "autoApply": false,
	  "singleDatePicker": false,
      "startDate": today,
      "endDate": today,
	  "maxDate":today,
	  "minDate":lastYearDate,
	  "locale": {
		firstDay: 1 ,  
        format: 'DD/MM/YYYY',

      }
    });
 }
  /** Multiple datepicker ends**/

/*** Date Range Picker End ***/

/*** Form validation***/
(function () {
  'use strict';
  window.addEventListener('load', function () {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function (form) {
      form.addEventListener('submit', function (event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();

/****Form Validation End ***/

var expanded = false;

function showCheckboxes() {
  //var checkboxes = $("#checkboxes");
  if (!expanded) {
    //checkboxes.style.display = "block";
    $("#checkmarkOuterDiv").css('display', 'block');
    expanded = true;
  } else {
    //checkboxes.style.display = "none";
    $("#checkmarkOuterDiv").css('display', 'none');
    expanded = false;
  }
}

var panelSlided = false;
// $(".slidePanel").css('display','none');

function showAlertDetails() {

  if (!panelSlided) {
    //checkboxes.style.display = "block";
    $(".slidePanel").css('display', 'block');
    panelSlided = true;
  } else {
    //checkboxes.style.display = "none";
    $(".slidePanel").css('display', 'none');
    panelSlided = false;
  }

}


/* Range slider */

$("#range_35").ionRangeSlider({
  type: "double",
  min: 0,
  max: 24,
  from: 10,
  to: 18,
  grid: true,
  postfix: ".00"

});

/* daterangePicker for single calender*/



/* tooltip styling and html */

$('[data-toggle="tooltip"]').each(function () {
  var options = {
    html: true,
	position: {
            my: "center bottom", // the "anchor point" in the tooltip element
            at: "center top", // the position of that anchor point relative to selected element
        }
  };

  if ($(this)[0].hasAttribute('data-type')) {
    options['template'] =
      '<div class="tooltip ' + $(this).attr('data-type') + '" role="tooltip">' +
      ' <div class="tooltip-arrow"></div>' +
      ' <div class="tooltip-inner"></div>' +
      '</div>';
  }

  $(this).tooltip(options);
});

/* Row expansion Template for configure Alerts Table */
function fnFormatDetails(oTable, nTr) {
  var aData = oTable.fnGetData(nTr);
  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td>Alert ID:</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Measure Name:</td><td>Probon namepue</td></tr>';
  sOut += '<tr><td>Title:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Organisation:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Operational Area:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Description:</td><td>Lorem ipsum peutriea haver baker dovery tragic hebnac looping fidharo.</td></tr>';
  sOut += '<tr><td>Topic:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Locations:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Thershold:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Thershold Value:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Frequency:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Time Window:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Mandatory/optional:</td><td>optional</td></tr>';
  sOut += '<tr><td>Start Date:</td><td>12/01/2018</td></tr>';
  sOut += '<tr><td>End Date:</td><td>20/01/2018</td></tr>';
  sOut += '<tr><td>Disable Alert:</td><td>No</td></tr>';
  sOut += '<tr><td>On Screen:</td><td>No</td></tr>';
  sOut += '<tr><td>Email:</td><td>No</td></tr>';
  sOut += '<tr><td>Mobile:</td><td>No</td></tr>';
  sOut += '<tr><td>Created By:</td><td>' + aData[4] + '</td></tr>';
  sOut += '<tr><td>Created:</td><td>' + aData[5] + '</td></tr>';
  sOut += '<tr><td>Modified By:</td><td>' + aData[7] + '</td></tr>';
  sOut += '<tr><td>Modified:</td><td>' + aData[6] + '</td></tr>';
  sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label></td></tr>';
  sOut += '</table>';

  return sOut;
}

function fnFormatEditAlertsDetails(oTable, nTr) {
  var aData = oTable.fnGetData(nTr);
  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td> <label class="formItalictext">*Mandatory Fields</label></td><td></td></tr>';
  sOut += '<tr><td>Alert ID:</td><td>ALT_02</td></tr>';
  sOut += '<tr><td>Measure Name* :</td><td><div class="multiselectCombo"><select class="multiSelectComponent" multiple="multiple"  data-error="*Mandatory Field" class="form-control" ><option value="Lorem ipsum">Lorem ipsum</option><option value="fiat">Fiat</option><option value="Lorem ipsum2">Lorem ipsum2</option><option value="Lorem ipsum1">Lorem ipsum1</option><option value="audi">Audi</option><option value="ActionScript">ActionScript</option></select></div></div></td></tr>';
  sOut += '<tr><td>Title*:</td><td><input type="text" class="form-control" id="inputName" placeholder="Enter Title (50 characters)" data-error="*Mandatory Field" required></td></tr>';
  sOut += '<tr><td>Description*:</td><td><textarea type="textarea" width="262px" height="50px" data-error="*Mandatory Field" class="form-control" placeholder="Enter Description (140 characters)" required></textarea></td></tr>';
  sOut += '<tr><td>Topic*:</td><td><div class="multiselectCombo"><select class="multiSelectComponent" multiple="multiple"  data-error="*Mandatory Field" class="form-control" ><option value="Lorem ipsum">Lorem ipsum</option><option value="fiat">Fiat</option><option value="Lorem ipsum2">Lorem ipsum2</option><option value="Lorem ipsum1">Lorem ipsum1</option><option value="audi">Audi</option><option value="ActionScript">ActionScript</option></select></div></div></td></tr>';
  sOut += '<tr><td>Locations*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Location*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Thershold*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Thershold Value*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold Value*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Mandatory/optional*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Mandatory/optional*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Subscribe:</td><td><input type="text"  class="formCalendarIcon " /></td></tr>';
  // sOut += '<tr><td>Snooze:</td><td> <input type="text" class="formCalendarIcon " /></td></tr>';
  // sOut += '<tr><td>On Screen:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Disable Alert*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Email:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  // sOut += '<tr><td>Mobile:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  sOut += '<tr><td><label for"Subscribe" class="textLabel">Subscribe</td><td><label for"Subscribe" class="textLabel panelCheckBox"><input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
  sOut += '<tr><td><label for"Snooze" class="textLabel">Snooze</td><td><label for"Snooze" class="textLabel panelCheckBox"><input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
  
  sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
  sOut += '<tr><td></td><td style="text-align:right;"><button class="btn btn-sm btn-default cancelButton">Cancel</button><button class="btn btn-default ">Save</button></td></tr>';
  sOut += '</table>';

  return sOut;
}
function fnFormatEditConfDetails(oTable, nTr){
  var aData = oTable.fnGetData(nTr);
  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td> <label class="formItalictext">*Mandatory Fields</label></td><td></td></tr>';
  sOut += '<tr><td>Alert ID:</td><td>ALT_02</td></tr>';
  sOut += '<tr><td>Measure Name*:</td><td><div class="multiselectCombo"><select class="multiSelectComponent" multiple="multiple"  data-error="*Mandatory Field" class="form-control" ><option value="Lorem ipsum">Lorem ipsum</option><option value="fiat">Fiat</option><option value="Lorem ipsum2">Lorem ipsum2</option><option value="Lorem ipsum1">Lorem ipsum1</option><option value="audi">Audi</option><option value="ActionScript">ActionScript</option></select></div></td></tr>';
  sOut += '<tr><td>Title*:</td><td><input type="text" class="form-control" id="inputName" placeholder="Enter Title (50 characters)" data-error="*Mandatory Field" required></td></tr>';
  sOut += '<tr><td>Organisation*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Mandatory/optional*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Operational Area*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Mandatory/optional*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Description*:</td><td><textarea type="textarea" width="262px" height="50px" data-error="*Mandatory Field" class="form-control" placeholder="Enter Description (140 characters)" required></textarea></td></tr>';
  sOut += '<tr><td>Topic*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Topic*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Locations*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Location*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Thershold*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Thershold Value*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold Value*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  
  sOut += '<tr><td>Frequency*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Mandatory/optional*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Time Window*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Mandatory/optional*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Mandatory/optional*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Mandatory/optional*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Start Date*:</td><td><input type="text"  class="formCalendarIcon " /></td></tr>'; 
  sOut += '<tr><td>End Date*:</td><td><input type="text"  class="formCalendarIcon " /></td></tr>';
  sOut += '<tr><td>Created By:</td><td> <input type="text" class="form-control" id="inputName" placeholder="Enter Title (50 characters)" data-error="*Mandatory Field" required></td></tr>';
  sOut += '<tr><td>Created:</td><td> <input type="text" class="formCalendarIcon " /></td></tr>';
  sOut += '<tr><td>Modified By:</td><td> <input type="text" class="form-control" id="inputName" placeholder="Enter Title (50 characters)" data-error="*Mandatory Field" required></td></tr>';
  sOut += '<tr><td>Modified:</td><td> <input type="text" class="formCalendarIcon " /></td></tr>';
 
  // sOut += '<tr><td>On Screen:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Disable Alert*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Email:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  // sOut += '<tr><td>Mobile:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
   sOut += '<tr><td><label for"Disable Alert" class="textLabel">Disable Alert</td><td><label for"Disable Alert" class="textLabel panelCheckBox"><input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
  
  sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
  sOut += '<tr><td></td><td style="text-align:right;"><button class="btn btn-sm btn-default cancelButton">Cancel</button><button class="btn btn-default ">Save</button></td></tr>';
  sOut += '</table>';
  return sOut;
}
function fnFormatEditNotificationDetails(oTable, nTr) {
  var aData = oTable.fnGetData(nTr);
  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td> <label class="formItalictext">*Mandatory Fields</label></td><td></td></tr>';
  sOut += '<tr><td>Notification ID:</td><td>ALT_02</td></tr>';
  sOut += '<tr><td>Notification:</td><td>Lorem ipsum</td></tr>';
  // sOut += '<tr><td>Measure Name:</td><td><div class="multiselect"><select multiple="multiple" name="Measure Name*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="Lorem ipsum">Lorem ipsum</option><option value="fiat">Fiat</option><option value="Lorem ipsum2">Lorem ipsum2</option><option value="Lorem ipsum1">Lorem ipsum1</option><option value="audi">Audi</option><option value="ActionScript">ActionScript</option></select></div></td></tr>';
  // sOut += '<tr><td>Title:</td><td><input type="text" class="form-control" id="inputName" placeholder="Enter Title (50 characters)" data-error="*Mandatory Field" required></td></tr>';
  // sOut += '<tr><td>Audience Group:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Audience Group*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Recipients:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Recipients*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Description:</td><td><textarea type="textarea" width="262px" height="50px" data-error="*Mandatory Field" class="form-control" placeholder="Enter Description (140 characters)" required></textarea></td></tr>';
  sOut += '<tr><td>Topic:</td><td><div class="multiselectCombo"><select class="multiSelectComponent" multiple="multiple"  data-error="*Mandatory Field" class="form-control" ><option value="Lorem ipsum">Lorem ipsum</option><option value="fiat">Fiat</option><option value="Lorem ipsum2">Lorem ipsum2</option><option value="Lorem ipsum1">Lorem ipsum1</option><option value="audi">Audi</option><option value="ActionScript">ActionScript</option></select></div></td></tr>';
  sOut += '<tr><td>Locations:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Location*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Thershold:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Thershold Value:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold Value*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Mandatory/optional:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Mandatory/optional*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Start Date:</td><td><input type="text"  class="formCalendarIcon " /></td></tr>';
  // sOut += '<tr><td>End Date:</td><td> <input type="text" class="formCalendarIcon " /></td></tr>';
  // sOut += '<tr><td>Disable Alert:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Disable Alert*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Created By:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  // sOut += '<tr><td>Created:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  // sOut += '<tr><td>Modified By:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  // sOut += '<tr><td>Modified:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Application<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
  sOut += '<tr><td></td><td style="text-align:right;"><button class="btn btn-sm btn-default cancelButton">Cancel</button><button class="btn btn-default ">Save</button></td></tr>';
  sOut += '</table>';

  return sOut;
}

function fnFormatEditConfNotificationDetails(oTable, nTr) {
  var aData = oTable.fnGetData(nTr);
  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td> <label class="formItalictext">*Mandatory Fields</label></td><td></td></tr>';
  sOut += '<tr><td>Notification ID:</td><td>ALT_02</td></tr>';
  sOut += '<tr><td>Notification Text*:</td><td>Lorem ipsum</td></tr>';
  sOut += '<tr><td>Organisation*:</td><td><div class="multiselectCombo"><select class="multiSelectComponent" multiple="multiple"  data-error="*Mandatory Field" class="form-control" ><option value="Lorem ipsum">Lorem ipsum</option><option value="fiat">Fiat</option><option value="Lorem ipsum2">Lorem ipsum2</option><option value="Lorem ipsum1">Lorem ipsum1</option><option value="audi">Audi</option><option value="ActionScript">ActionScript</option></select></div></div></td></tr>';
  sOut += '<tr><td>Operational Area*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Operational Area*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Additional Information URL:</td><td><textarea type="textarea" width="262px" height="50px" data-error="*Mandatory Field" class="form-control" placeholder="Enter Description (140 characters)" required></textarea></td></tr>';
  // sOut += '<tr><td>Measure Name:</td><td><div class="multiselect"><select multiple="multiple" name="Measure Name*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="Lorem ipsum">Lorem ipsum</option><option value="fiat">Fiat</option><option value="Lorem ipsum2">Lorem ipsum2</option><option value="Lorem ipsum1">Lorem ipsum1</option><option value="audi">Audi</option><option value="ActionScript">ActionScript</option></select></div></td></tr>';
  // sOut += '<tr><td>Title:</td><td><input type="text" class="form-control" id="inputName" placeholder="Enter Title (50 characters)" data-error="*Mandatory Field" required></td></tr>';

  
  sOut += '<tr><td>Topic*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Topic*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Locations*:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Location*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Thershold:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Thershold Value:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold Value*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Mandatory/optional:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Mandatory/optional*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  sOut += '<tr><td>Start Date*:</td><td><input type="text"  class="formCalendarIcon " /></td></tr>';
  sOut += '<tr><td>End Date*:</td><td> <input type="text" class="formCalendarIcon " /></td></tr>';
  sOut += '<tr><td>Disable Notification:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Disable Alert*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
  // sOut += '<tr><td>Created By:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  // sOut += '<tr><td>Created:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  // sOut += '<tr><td>Modified By:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  // sOut += '<tr><td>Modified:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
  sOut += '<tr><td>&nbsp;</td><td><label  for"Application" class="textLabel panelCheckBox">Application<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
  sOut += '<tr><td></td><td style="text-align:right;"><button class="btn btn-sm btn-default cancelButton">Cancel</button><button class="btn btn-default ">Save</button></td></tr>';
  sOut += '</table>';

  return sOut;
}

/*Row expansion Template for notificationSettings Table */
function fnFormatNotification(oTable, nTr) {
  var aData = oTable.fnGetData(nTr);
  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td>Notification ID:</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Notification:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Topic:</td><td>' + aData[2] + '</td></tr>';
  sOut += '<tr><td>Location:</td><td>' + aData[3] + '</td></tr>';
  sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label></td></tr>';
  sOut += '</table>';

  return sOut;
}



function fnFormatalertsSettings(oTable, nTr) {
  var aData = oTable.fnGetData(nTr);
  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td>Alerts ID:</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Measure Name:</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Title:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Description:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Topic:</td><td>' + aData[2] + '</td></tr>';
  sOut += '<tr><td>Locations:</td><td>' + aData[3] + '</td></tr>';
  sOut += '<tr><td>Threshold:</td><td>' + aData[3] + '</td></tr>';
  sOut += '<tr><td>Threshold Value:</td><td>' + aData[3] + '</td></tr>';
  sOut += '<tr><td>Mandatory/Optional:</td><td>' + aData[3] + '</td></tr>';
  // sOut += '<tr><td>Subcribe:</td><td>' + aData[4] + '</td></tr>';
  // sOut += '<tr><td>Snooze:</td><td>' + aData[5] + '</td></tr>';
  // sOut += '<tr><td>Email:</td><td>' + aData[6] + '</td></tr>';
  // sOut += '<tr><td>Mobile:</td><td>' + aData[7] + '</td></tr>';
  sOut += '<tr><td>Subscribe</td><td><label  for"Subscribe" class="textLabel panelCheckBox"><input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label></td></tr>';
  sOut += '<tr><td>Snooze</td><td><label  for"Snooze" class="textLabel panelCheckBox"><input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label></td></tr>';
  sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label></td></tr>';
  sOut += '</table>';

  return sOut;
}

function fnFormatTodaysAlerts(oTable, nTr) {

  var aData = oTable.fnGetData(nTr);

  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td>Alert Message:</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Title:</td><td>' + aData[1] + '</td></tr>'; 
  sOut += '<tr><td>Time:</td><td>' + aData[2] + '</td></tr>';
  sOut += '<tr><td>Response:</td><td>' + aData[3] + '</td></tr>';
  sOut += '<tr><td>Topic:</td><td>' + aData[4] + '</td></tr>';
  sOut += '<tr><td>Locations:</td><td>' + aData[5] + '</td></tr>';
  sOut += '</table>';

  return sOut;
}

function fnFormatTodaysNotif(oTable, nTr) {

  var aData = oTable.fnGetData(nTr);

  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td>Notification:</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Topic:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Locations:</td><td>' + aData[2] + '</td></tr>';
  sOut += '<tr><td>Date & Time:</td><td>' + aData[3] + '</td></tr>';
  sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label></td></tr>';
  sOut += '</table>';

  return sOut;
}

function fnFormatConfNotification(oTable, nTr) {

  var aData = oTable.fnGetData(nTr);

  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td>Notification ID:</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Notification Text:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>Organisation:</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Operational Area:</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Additional Information URL:</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Topic:</td><td>' + aData[2] + '</td></tr>';
  sOut += '<tr><td>Locations:</td><td>' + aData[3] + '</td></tr>';
  sOut += '<tr><td>Start Date:</td><td>' + aData[4] + '</td></tr>';
  sOut += '<tr><td>End Date:</td><td>' + aData[5] + '</td></tr>';
  sOut += '<tr><td>Disable Notification:</td><td disabled>' + aData[6] + '</td></tr>';
  // sOut += '<tr><td>Application:</td><td>' + aData[0] + '</td></tr>';
  // sOut += '<tr><td>Email:</td><td>' + aData[0] + '</td></tr>';
  // sOut += '<tr><td>Mobile</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Created By</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Created</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Modified By</td><td>' + aData[7] + '</td></tr>';
  sOut += '<tr><td>Modified</td><td>' + aData[8] + '</td></tr>';
  sOut += '<tr><td>&nbsp;</td><td><label  for"Application" class="textLabel panelCheckBox">Application<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label></td></tr>';
  sOut += '</table>';

  return sOut;
}

function fnFormatReportsTable(oTable, nTr) {

  var aData = oTable.fnGetData(nTr);

  var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
  sOut += '<tr><td>NOT_ID</td><td>' + aData[0] + '</td></tr>';
  sOut += '<tr><td>Topic:</td><td>' + aData[1] + '</td></tr>';
  sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" disabled><span class="checkmark"></span></label></td></tr>';
  sOut += '</table>';

  return sOut;
}

$("span.Show_details").closest("td").addClass("showdetailsTDstyle");
$("span.Edit").closest("td").addClass("showdetailsTDstyle");
$('.ui-autocomplete-input').css('width', '100px');
$('table tr td label.container').closest("td").addClass("tableCheckmarkStyleOveride");

/***breadcrumbs***/
$(".hamburgerSideBar").on("click",".menu li.subDropdown",function(){
event.stopPropagation();	// will not trigger document ready and it will close dropdown-content
$(".menu li").tooltip("destroy");
$(".menu li.subDropdown .dropdown-content").css("display","none");
$(this).find(".dropdown-content").css("display","block");
	});
	
	
 	
$(".myBaggListStyles,.hamburgerSideBar").on("click",".menu li.subDropdown .dropdown-content a,.menu li:not(.subDropdown)",function () {
	
	var breadcrumbActive=$(this).text();
	if($(this).is("a"))
	{
	var index=$(this).index();//finding the index value to highlight the breadcrumbs
	}
	else
	{
		index=0;
	}
	var reportType="";
  $(".breadcrumb li").remove();
  $(".verticalNavigation li").remove();
  var menuVal = $(this).closest("li").data("menulist");
 
 
  $.each(menu, function (key, value) {
    if (menuVal == key) {
     
	 if(menuVal=="Home")
	 {   if($(".breadcrumb").css("display")=='none')
		 {
			 $(".navADPBreadCrumb").attr("style", "display: none !important");
		 }
		 return false;
	 }
	 else if(menuVal=="Favourites" && $(".breadCrumb li .favourite").find('.dropdown-content').length == 0)
	 {
         if($(".breadcrumb").css("display")=='none')
		 {
			 $(".navADPBreadCrumb").attr("style", "display: none !important"); // hidding breadcrumb arrow in mobile
		 }
		 return false;
	 }
	 else
	 {
		 if($(".breadcrumb").css("display")=='none')
		 {
			 $(".navADPBreadCrumb").attr("style", "display: inline-block !important");
		 }
	 }
      
	  var elm = "";
	  var indexOfElm=0;
	  var typeOfElm=false;
	  var otherReportType="";
	 
      $.each(value, function (submenu, submenuValues) {
		  if(indexOfElm==index)
		  {
			  typeOfElm=true;// to find the type of element whether PBI/Settings... etc
			  
		  }
		  indexOfElm++;
		  $.each(submenuValues, function (k, val) {
			  if(k=='type') // "to assign data-type value when key = type" 
			  {
				otherReportType=val;  
			  }
			  
	     if(typeOfElm==true&&k=='type')
		 {
			 reportType=val;
			  typeOfElm=false;
			 
		 }
		 
 	   else if(k=='breadCrumb')
			  {
        if ($(".breadcrumb").css("display") !="none") {
          elm += "<li><a href='#' data-type="+otherReportType+">" + val.toUpperCase() + "</a></li>";
        }
        else {
          elm += "<li class='customStyling' data-type="+otherReportType+"><a href='#' >" + val.toUpperCase() + "</a></li>";
        }
			  }//if k=type ends
		});//third each
      });//secong each
      $(".breadcrumb").append(elm);
	  $(".verticalNavigation").append(elm);
	  
	  if(index!=null)
	  {
		  if($(".breadcrumb").css("display")!='none')
		  {
         $(".breadcrumb li:eq("+index+")").addClass("active");
	   //$(".navADP").html($('.breadcrumb li:eq('+index+')').text());
	      }
		  else
		  {
			  $(".verticalNavigation li:eq("+index+")").addClass("active");
		  }
	  }
	  else
	  {
		  if($(".breadcrumb").css("display")!=='none' && menuVal!='Home')
		  {
		   $(".breadcrumb li:eq(0)").addClass("active");
		   $(".navADP").html($('.breadcrumb li:eq(0)').text());
		  }
		  else
		  {
			  $(".verticalNavigation li:eq(0)").addClass("active");
			  
		  }
	  }
     
	  
	 linkingEmbedded(reportType);
	  
	  
	  return false;
     
    }
  });
 $(".menu li.subDropdown .dropdown-content").css("display","none");
 $("#homeNavigationBar").removeClass("active");
  $('.hamburgerSideBar').removeClass('SideBarActive');
 $("#bottomArrow,#topArrow").hide();
 $(".hamburger").removeClass("clickedIcons").addClass("defaultIcons");
 $(".hambergerDiv").removeClass("hambergerActive");
 
});


$('.disabledIcons').hover(function(e){

  e.preventDefault();

});

$(".settings").click(function(){
	      $(".breadcrumb li").remove();
		  $(".verticalNavigation li").remove();
	  var elm='';
	   if ($(".breadcrumb").css("display") !="none") {
          elm= "<li class='active'><a href='#' data-type='Settings'> ALERTS </a></li>";
		  $(".breadcrumb").append(elm);
        }
        else {
          elm= "<li class='customStyling active' data-type='Settings'><a href='#' >ALERTS</a></li>";
		  $(".verticalNavigation").append(elm);
        }
    
	linkingEmbedded("Settings");
});
function linkingEmbedded(report)
{
	 /*************linking embeeded logic**************/ 
	
	  var reportType=report;
	  $(".notificationWrapper").show();
	  if(window.innerWidth<768)
	  {
		   $(".dataTables_wrapper .dataTables_paginate").css("padding-bottom","48px");
	  } 
	  else
	  {
		 $(".dataTables_wrapper .dataTables_paginate").css("padding-bottom","60px");  
	  }
	 
	  $(".filter,.share,.print,.notes").removeClass("clickedIcons customBorderSmall");
	  $(".notes").attr("style", "display: none !important");
	  $(".sideNavBar").css("display","none");
	  //type of report
	  if(reportType=="Settings")
	  {
		     	  $(".favorite,.filter,.share,.print").addClass("disabledIcons");
		          $(".txtMarginLastRefresh").hide();
				  $(".dateDiv").css('visibility','hidden');
				  $('.refresh,.fullScreen,.notes').attr("style", "display: none !important");
				  $(".addMBLDiv").hide();  
				  $(".bagglistDiv,.removeMBLDiv").hide();
				  $(".PBIContainer,.bagSearchListTableDiv,.myBagListDiv").hide();
				  $(".tabArea").show();
		 
				
	  }	    
	   
	  else if(reportType=="myBagList")
	  {   
         // $(".favorite").addClass("defaultIcons");
		   $(".favorite").removeClass("disabledIcons");
		  $(".filter,.share,.print").addClass("disabledIcons");
		  $(".txtMarginLastRefresh,.dateDiv").hide();
		  $('.notes,.refresh').attr("style", "display: none !important");
		  $(".addMBLDiv").hide();
		  $(".bagglistDiv,.removeMBLDiv").show();
		  $(".PBIContainer,.bagSearchListTableDiv,.tabArea").hide();
		  $(".myBagListDiv").show();
		   
		 
	  } 
	  
	  //PBI screens
	  else
	  {   
          //for all PBI Screens
		   $('.fullScreen').attr("style", "display: inline-block !important");
		   $('.notes').attr("style", "display: none !important");
		   $(".addMBLDiv").hide();
		   $(".bagglistDiv,.removeMBLDiv").hide();
		   $(".dateDiv").show();
		   $(".bagSearchListTableDiv,.myBagListDiv,.tabArea").hide();
		   $(".PBIContainer").show();
		  
		  // to find whether operation(current) / business date             
		  
		  var d = new Date();//today date
		  var currentDate = d.getMonth()+1+ "/" +d.getDate()+ "/" + d.getFullYear();
		  var reportDate=null;
		  if ($("#headerDate").val().indexOf('-') > -1)
			{
			  reportDate=$("#headerDate").val().split('-')[1];
			}
		 else
		 {
	      reportDate=$("#headerDate").val();
		 }
		  reportDate=reportDate.trim();
		 
		  //changing the format of report type date to  mm/dd/yyyy
			  var arrReportDate = reportDate.valueOf().split("/");//since it is string use valueOf
			  var selectedDate= arrReportDate[1]+"/"+arrReportDate[0]+"/"+arrReportDate[2];
		
		      var currentDateVal = new Date(currentDate);// changing to date object for comparision 
              var reportDateVal = new Date(selectedDate);
		  
	  
		  
		   
		   /****PBI Business****/
		  if(Date.parse(reportDateVal)<Date.parse(currentDateVal))//comapring report date with current date
		  {
			    //alert("business");
			    $('.refresh').attr("style", "display: none !important");
			    $(".txtMarginLastRefresh").hide();
				
				 
			  if(reportType=="PBIBagDetails")
			  {
				//  $(".favorite,.filter,.share").addClass("defaultIcons");
				  $(".favorite,.filter,.share").removeClass("disabledIcons");
				  $(".print").addClass("disabledIcons");
				  $(".dateDiv").css('visibility','visible');
				  $('.notes').attr("style", "display: inline-block !important");
				  $(".addMBLDiv").show();
				 
				   
			  }
			  else if(reportType=="PBIBagListGen")
			  {
				 //$(".favorite,.filter,.print,.share").addClass("defaultIcons");  
				 $(".favorite,.filter,.print,.share").removeClass("disabledIcons"); 
				 $(".dateDiv").css('visibility','visible');
				 $(".addMBLDiv").show();
				 
				    
			  }
			  else
			  {    
				  // $(".favorite,.filter,.print,.share").addClass("defaultIcons");
				   $(".favorite,.filter,.print,.share").removeClass("disabledIcons");

				   $(".dateDiv").css('visibility','visible');
				 
				  if(reportType=="PBIFlightDetailsInbound"||reportType=="FlightDetailsOutbound")
					{
					  $('.notes').attr("style", "display: inline-block !important");	
					  $(".favorite").addClass("disabledIcons");
					}
					if(reportType=="IB Flights"||reportType=="OB Flights")
					{
					  $('.favorite').addClass("disabledIcons");
					}
					if(reportType=="BagSearchList")
					{ 
				      $(".PBIContainer").hide();
					  $(".favorite,.filter,.share,.print").addClass("disabledIcons");
					  $(".bagSearchListTableDiv").show();
					  $(".bagSearchListTableDiv").css("margin-top","0");
					  $(".bagSearchListTableDiv").css("margin-top",$(".navBg").innerHeight()+$(".header").innerHeight());
					  $(".notificationWrapper").show();
					 }	 
			  }
		  } /****PBI Business Ends****/
		  
		  /****PBI Operational ****/
		  else if(Date.parse(reportDateVal)==Date.parse(currentDateVal))
		  {
			  //alert("Operatinal");
			  $('.refresh').attr("style", "display: inline-block !important"); 
			  $(".txtMarginLastRefresh").show();
			   
			   if(reportType=="PBIBagDetails")
			  {    $(".notes").attr("style","display:inline-block !important");	
				 // $(".favorite,.filter,.share").addClass("defaultIcons");
				  $(".favorite,.filter,.share").removeClass("disabledIcons");
				  $(".dateDiv").css('visibility','visible');
				  $(".print").addClass("disabledIcons");
				  $(".addMBLDiv").show();
			     
				   
			  }
				
			  else if(reportType=="PBIBagListGen")
			  {
				// $(".favorite,.filter,.print,.share").addClass("defaultIcons");
				 $(".favorite,.filter,.print,.share").removeClass("disabledIcons");

				 $(".dateDiv").css('visibility','visible');
				 $(".addMBLDiv").show();
			  	
				  
				  
			  }
		     else
			  {     $(".favorite,.filter,.print,.share").removeClass("disabledIcons");
		            
					//$(".favorite,.filter,.print,.share,.fullScreen").addClass("defaultIcons");
				    $(".dateDiv").css('visibility','visible');//show calender
					$(".addMBLDiv").hide();
					//condition for Notes
					if(reportType=="PBIFlightDetailsInbound"||reportType=="FlightDetailsOutbound")
					{
					  $('.notes').attr("style", "display: inline-block !important");	
					  $(".favorite").addClass("disabledIcons");
					}
					if(reportType=="IB Flights"||reportType=="OB Flights")
					{
					  $('.favorite').addClass("disabledIcons");
					}
					if(reportType=="BagSearchList")
					{
					   $(".PBIContainer").hide();
					   $(".favorite,.filter,.share,.print").addClass("disabledIcons");
					   $(".bagSearchListTableDiv").show();
					   $(".bagSearchListTableDiv").css("margin-top","0");
					   $(".bagSearchListTableDiv").css("margin-top",$(".navBg").innerHeight()+$(".header").innerHeight());
					   $(".notificationWrapper").show();
					 }	 
								
					//condition for MBL menuSlidingCount
					
			  }
		  
		  
		  }/****PBI Operational Ends****/
		  else
		  {
			  alert("please select a valid date less than or equal to current date");
		  }
	  
		  
		  
		 
			  
			  
	  }//PBI Screens
	  
	   /*************linking embeeded logic**************/ 
		 
			  
}//function ends.

var menu={
	
 "Favourites": {
		"null": {    
		 "type": 'null', 
		 "breadCrumb": ''
			    }
              }	,
 "Home": {
		"null": {    
		 "type": '', 
		 "breadCrumb": ''
			   }
         },
  "Bag List":{
	  
      "General": {   
         "type": 'PBIBagListGen', 
         "breadCrumb": 'Bag List'
		
                },
       
    "Not Loaded Bags": {   
         "type": 'PBI', 
         "breadCrumb": 'Not Loaded Bag List'
               }
             },
   "Bag Details": {
		"null": {    
		 "type": 'PBIBagDetails', 
		 "breadCrumb": 'Bag Details'
		
			}
         },
  "Status": {
     "IB Flights": {    
		 "type": 'PBI', 
		 "breadCrumb": 'IB Flights Bag Status'
		 		   },
     "OB Flights": {    
		 "type": 'PBI', 
		 "breadCrumb": 'OB Flights Bag Status'
		 		   }
         },
 "FlightDetailsInbound": {
	"null": {    
	 "type": 'PBIFlightDetailsInbound', 
	 "breadCrumb": 'IB Flight Details'
		}
	 },
 "FlightDetailsOutbound": {
	"null": {    
	 "type": 'PBIFlightDetailsInbound', 
	 "breadCrumb": 'OB Flight Details'
		}
 },

  
 "ARR": {
     "Next 2 Hours": {    
		 "type": 'PBI', 
		 "breadCrumb": 'Arriving Flights Next 2 Hours'
		 		   },
         
     "Dashboard": {    
		 "type": 'PBI', 
		 "breadCrumb": 'Flight Arrivals Dashboard'
		 		   }
         },
"ADP": {
    "Dashboard": {   
         "type": 'PBI', 
         "breadCrumb": 'ADP Dashboard'
                },
       
    "summary": {   
         "type": 'PBI', 
         "breadCrumb": 'ADP summary'
               },
	 
    "Details": {   
         "type": 'PBI', 
         "breadCrumb": 'ADP Details'
               }
         },
 		 
  "BJP": {
		"Dashboard": {   
			 "type": 'PBI', 
			 "breadCrumb": 'BJP Dashboard '
					},
		   
		"summary": {   
			 "type": 'PBI', 
			 "breadCrumb": 'BJP Summary'
				   },
		 
		"Details": {   
			 "type": 'PBI', 
			 "breadCrumb": 'BJP Detail'
				   }
			 },
"ITT": {
     "Dashboard": {    
		 "type": 'PBI', 
		 "breadCrumb": 'ITT Dashboard'
		 		   },
         
     "Detail": {    
		 "type": 'PBI', 
		 "breadCrumb": 'ITT Detail'
		 		   }
         },		 
    
 "DDP": {
     "Dashboard": {    
		 "type": 'PBI', 
		 "breadCrumb": 'DDP Dashboard'
		 		   },
         
     "Summary": {    
		 "type": 'PBI', 
		 "breadCrumb": 'DDP Summary'
		 		},
        	 
     "Detail": {    
		 "type": 'PBI', 
		 "breadCrumb": 'DDP Detail'
		 	   }
         },		 
 "NLB": {
	 "Dashboard": {    
		 "type": 'PBI', 
		 "breadCrumb": 'NLB Dashboard'
				   },
		 
	 "Summary": {    
		 "type": 'PBI', 
		 "breadCrumb": 'NLB SUMMARY'
				},
		 	 
	 "Detail": {    
		 "type": 'PBI', 
		 "breadCrumb": "NLB DETAIL"
			   }
		 },	
 "VOL": {
		"null": {    
		 "type": 'PBI', 
		 "breadCrumb": 'DEPARTURE VOLUME SUMMARY'
			}
         },		 
 "BSM": {
		"BSM": {    
		 "type": 'PBI', 
		 "breadCrumb": 'LATE BSM SUMMARY'
			}
         },	
 "MDR": {
     "Summary": {    
		 "type": 'PBI', 
		 "breadCrumb": 'MASS DISRUPTION SUMMARY'
		 		},
         
     "Detail": {    
		 "type": 'PBI', 
		 "breadCrumb": 'MASS DISRUPTION  DETAIL'
		 	   }
         },

"Settings": {
		"null": {    
		 "type": 'Settings', 
		 "breadCrumb": 'ALERTS'
			}
         },
"BagSearchList": {
		"null": {    
		 "type": 'PBI', 
		 "breadCrumb": 'BAG SEARCH LIST'
			}
         },
"My Bag List": {
		"null": {    
		 "type": 'myBagList', 
		 "breadCrumb": 'My Bag List'
			}
         }
 
};
/***breadcrumbs End***/

$('body').on('click', '.breadcrumb li a', function () {
  $(".breadcrumb li").removeClass("active");
  $(this).parent().addClass("active");
  linkingEmbedded($(this).data('type'));
});
$('body').on('click', '.verticalNavigation li a', function () {
  $(".verticalNavigation li").removeClass("active");
  $(this).parent().addClass("active");
});

$(".searchImgMobile").click(function () {
  event.stopPropagation();
  $(".searchDivMobile").css("display", "block");
  $('.searchImgMobile').attr("style", "display: none !important");
});


// Apply click 

$('#headerDate').on('apply.daterangepicker', function(ev, picker) {
  var endDate , today;
  endDate=$('#headerDate').data('daterangepicker').endDate.format('DD/MM/YYYY');
  today=getTodayDate();
  //checking wether range's end date is current date
  if(($('#headerDate').data('daterangepicker').endDate>$('#headerDate').data('daterangepicker').startDate)&& endDate==today)
  {
	   $("#datePickerMessage").modal('show');
  }
  else
  {
	var reportType=($(".breadcrumb li.active a").data("type"));
	linkingEmbedded(reportType);
  }
});

//settings breadcrumbs
$(".nav-tabs li a").on("click",function(){
$(".breadcrumb li").not(".active").remove();
$(".breadcrumb li.active").text($(this).data("breadcrumb"));//updating breacrumbname in settings
  setTimeout(function () {
  //updating the height of vertical tabs
  $("#verticalTabs").height($(".zeroStyling:last-child").height());
}, 500);
});
//close icon click	

$(".closeIcon").on("click",function(){
	$(".notificationWrapper").hide();
     $(".dataTables_wrapper .dataTables_paginate").css("padding-bottom","0px");
	});
	
//Add to my bag list click	
$(".addMBL").on("click",function(){
	$(".breadcrumb li").not(".active").remove();
$(".breadcrumb li.active").text("MY BAG LIST");//updating breacrumbname in settings
      linkingEmbedded("myBagList");
	  
	});

function checkPosition() {
    if (window.matchMedia('(max-width:639px)').matches) {
        $("#lowerResolutionDevices").css("display","block");
    
	} else {
        $("#lowerResolutionDevices").css("display","none");
    }
}
  
$(".myBaggListStyle").click(function(e){
	e.preventDefault();
	$(".PBIContainer,.bagSearchListTableDiv,.tabArea").hide();
	$(".myBagListDiv").show();
})
  window.addEventListener("orientationchange", function() {
        var orientation = window.orientation;  	
            switch(orientation) { 
                case 0:window.location.reload();
                case 90:window.location.reload();
                case -90: window.location.reload(); 
                break; } 
    });
	
   /*multi select*/
   
    /***Menu  hover***/
 /*$('.navIconsList li:not(".disabled")').hover(function () {

    if($(".headerPosition").css("z-index")>$(".navPosition").css("z-index"))
		{
	      $(".navPosition").css("z-index",($(".headerPosition").css("z-index"))*10);//inorder to show the tooltip we are reducing the z-index of header than nav
		} 
  }, function () {
      $(".navPosition").css("z-index",($(".headerPosition").css("z-index"))/10);
  });*/
	
	function multiSelectFnCall()
	{
	$('.multiSelectComponent').multiselect({
			enableFiltering: true,
			buttonWidth:'100%',
			filterPlaceholder: 'Search for something...',
			nonSelectedText: 'Select'
			
		
		});
		 $('.multiselect-container').addClass('scrollbar-inner');
		 $('.scrollbar-inner').scrollbar();
		 $('ul.multiselect-container').removeClass('dropdown-menu');
		 
		 //show all items tooltip 
		 $(".multiselectCombo button").removeAttr('title');
		 $(".multiselectCombo button b").attr("data-toggle","tooltip");
		 $(".multiselectCombo button b").attr("data-original-title","Show All Items");
		 $(".multiselectCombo button b").tooltip();
	 
	}/*multiselect end */
	

	
   $("#bottomArrow").on("click",function(){
	 
	var marginTopPosition;
	
   if(screen.height>650)
   {
	  marginTopPosition=Math.round($(".menu li").innerHeight())*3;//showing 3 more elements
   }   
   else
   {
	 marginTopPosition=$(".hamburgerSideBar").height()-($("#bottomArrow").height()+ $("#topArrow").height());

   }
   
   $(".menu").animate({"margin-top" : (parseInt($(".menu").css("margin-top").split("px")[0]))-marginTopPosition});                
   $("#topArrow").show();	  
   
   menuSlidingCount--;
   if(menuSlidingCount<=0)
   {
	      $("#bottomArrow").hide();
   }
   });
   $("#topArrow").on("click",function(){
	  $("#bottomArrow").show(); 
	  menuSlidingCount++;
	var marginTopPosition;
	if(screen.height>650)
   {
	  marginTopPosition=Math.round($(".menu li").innerHeight())*3;//as we are trying to show 3 elements 
   }   
   else
   {
	 marginTopPosition=$(".hamburgerSideBar").height()-($("#bottomArrow").height()+ $("#topArrow").height());

   }
	
   $(".menu").animate({"margin-top":(parseInt($(".menu").css("margin-top").split("px")[0]))+marginTopPosition});
   
	if(screen.height>650)//for devices greater height
	{
		if(menuSlidingCount>=menuSlidingInitialVal)
		{
			$("#topArrow").hide();
			$(".menu").css("margin-top","0px");
		}
	}
	else 
	{
		if(menuSlidingCount>=Math.round($("#homeNavigationBar").height()/$(".hamburgerSideBar").height()))
		{
			$("#topArrow").hide();
			$(".menu").css("margin-top","0px");
		}
	}
   });
   
  function countMenuItems()
  {
	  var numberOfItems,menuHeight,itemHeight,visibleItems,itemsDisplayed;
	   
	  numberOfItems=$("ul.menu li:not(:empty)").length;
	   
	  menuHeight=window.innerHeight-($(".header").innerHeight() + $(".headerTopNav").innerHeight());
		
	  itemHeight=$("ul.menu li").innerHeight();
	  //calculate number of li elements that can be accomidated in the given container without scrolling
	  visibleItems= parseInt(menuHeight)/parseInt(itemHeight);
	  if(screen.height>=650)
	  {
		  menuSlidingCount=Math.round(numberOfItems-visibleItems)/3;
		  if(menuSlidingCount<0)
		  {
			  menuSlidingCount,menuSlidingInitialVal=1;
		  }
		  menuSlidingInitialVal=menuSlidingCount;//storing the value to compare top arrow position 
		 
	  }    
	  else
	  {
	  menuSlidingCount=Math.round($("#homeNavigationBar").height()/$(".hamburgerSideBar").height());
	  itemsDisplayed=Math.round($(".hamburgerSideBar").height()/$("ul.menu li").innerHeight());
	  }
	  if(menuSlidingCount<0) 
	  {
		  $("#bottomArrow").hide();
	  }
	  else
	  {
		  if($("#homeNavigationBar").hasClass("active")&& $(".hambergerDiv").hasClass("hambergerActive")&&($(".menu").height()>menuHeight))
		  {
		   $("#bottomArrow").show();
		   
		  }
	  }
  }  
  
function calComponentsHeight()
{
var PBIContainer= window.innerHeight - ($(".header").innerHeight() + $(".navBg").innerHeight() + $(".notificationWrapper").outerHeight());
var menuHeight=window.innerHeight - ($(".header").outerHeight() + $(".headerTopNav").outerHeight());// 24px height and notification height is calculated since datatables will not be loaded first.
var topPosition=$(".header").innerHeight() + $(".headerTopNav").innerHeight();
var errorFieldOverride=window.innerHeight - ($(".header").innerHeight() + $(".navBg").innerHeight() + $(".notificationWrapper").outerHeight()+$('#tabs').outerHeight()+$('.table th').innerHeight()+50);
$(".errorFieldOverride").css("height",errorFieldOverride);
$(".errorFieldOverride").css("max-height",errorFieldOverride);
$(".hamburgerSideBar").height(menuHeight);
//$(".hamburgerSideBar").css("top",topPosition);
$("#topArrow").css("top",topPosition);
$("#bottomArrow").css("bottom","0px");
$(".myBagListDiv,.PBIContainer,.tabArea,#verticalTabs").css("min-height", PBIContainer); 
$("#verticalTabs").css("height",$(".zeroStyling:last-child").height());//to calculate height of verticaltabs
$(".AssignHomePage").outerHeight(errorFieldOverride);
$(".navPosition").css("top",$(".headerPosition").innerHeight());
$(".tabArea,.PBIContainer").css("margin-top",$(".navBg").innerHeight()+$(".header").innerHeight());

//menu li height in higher resolution devices
if(screen.height>=768&&screen.height<=1024)
{
	$(".menu li").css("padding","8px 0 8px 0");
}
$(".container-fluid").css("min-height",window.innerHeight);
}

//counting number of rows

function rowCountFn()
{
var numberOfRows;
if(window.innerWidth<768)
{
numberOfRows= window.innerHeight - ($(".header").innerHeight() + $(".navPosition").innerHeight() + $(".notificationWrapper").outerHeight()+$('#tabs').outerHeight()+$('.table th').innerHeight());//for datatables pagination
}
else
{
numberOfRows= window.innerHeight - ($(".header").innerHeight() + $(".navPosition").innerHeight() + $(".notificationWrapper").outerHeight()+$('#tabs').outerHeight()+$('.table th').innerHeight()+60);//for datatables pagination
}
numberOfRows=Math.round(numberOfRows/($('.table th').innerHeight()+10));// on load styles are not applied for 'th' so not calculating properly 
return numberOfRows;
}


function rowCountFnBagSearchList()
{
var numberOfRows;
if(window.innerWidth<768)
{
numberOfRows= window.innerHeight - ($(".header").innerHeight() + $(".navPosition").innerHeight() + $(".notificationWrapper").outerHeight()+$('.table th').innerHeight());//for datatables pagination
}
else
{
numberOfRows= window.innerHeight - ($(".header").innerHeight() + $(".navPosition").innerHeight()+$('.table th').innerHeight());//for datatables pagination
}
numberOfRows=Math.round(numberOfRows/($('.table td').innerHeight()));// on load styles are not applied for 'th' so not calculating properly 
return numberOfRows;
}

function PanelHeight()
{
	$.when($('.scrollbar-inner').scrollbar() ).done(function() {
    var windowHeight,notesHeight;
	windowHeight=window.innerHeight;
	windowHeight=windowHeight-(parseInt($(".sideNavBar").css("padding-top").split("px")[0])+parseInt($(".shareInternalDiv").css("padding-bottom").split("px")[0])+$(".btnPanel").innerHeight()+$(".header").innerHeight()+$(".headerTopNav").innerHeight());/* 140 padding + remove header height from window height to calculate hide of shareInternalDiv*/
	notesHeight=window.innerHeight-(10+parseInt($(".sideNavBar").css("padding-top").split("px")[0])+parseInt($(".internalDiv").css("margin-top").split("px")[0])+parseInt($(".internalDiv").css("margin-bottom").split("px")[0])+$(".btnPanel").innerHeight()+$(".header").innerHeight()+$(".headerTopNav").innerHeight()+$(".dateStyling").outerHeight());// removing  noteDiv internal div margins  
	windowHeight=windowHeight+'px';
	notesHeight=notesHeight+'px';
	$(".shareInternalDiv>div,#filterOptions,#ShareOptions").attr('style','max-height:'+windowHeight+';min-height:'+windowHeight+'');
    $(".filterMenu>div,.internalDiv").attr('style','max-height:'+notesHeight+';min-height:'+notesHeight+'');
});
}

function listPopulation(menuList)
{
	var startPoint=0
	var Endpoint=0;
	var numberOFElements=Math.round($(".hamburgerSideBar").height()/$(".menu li").innerHeight())-1;
	var menuSlidingCount=Math.round($(".menu li").innerHeight()*$(menuList).length/$(".hamburgerSideBar").height());
	Endpoint=numberOFElements;
	$("#homeNavigationBar").empty();
	for(var i=0;i<=menuSlidingCount;i++)
    {
		var ul=document.createElement('ul');
		var menu=$(menuList).slice(startPoint,Endpoint);
		$(ul).addClass('menu')
		$.each(menu,function(key,value){
			ul.append(menu[key]);
		});
		$("#homeNavigationBar").append(ul);
		startPoint=Endpoint;
		Endpoint=numberOFElements+startPoint;
	}
	$(".menu").height($(".hamburgerSideBar").height());
	$(".hamburgerSideBar").hide();
}
