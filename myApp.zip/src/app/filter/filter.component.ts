import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ks-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.css']
})
export class FilterComponent implements OnInit {
  public isViewable: boolean;
  constructor() { }

  ngOnInit() {
    debugger;
    this.isViewable = true;
  }
  public toggle(): void { this.isViewable = !this.isViewable; }

}
