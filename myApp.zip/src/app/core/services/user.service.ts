import { Injectable } from '@angular/core';
import { MsalService } from '@azure/msal-angular';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient, private msalService: MsalService) { }


  getAll() {
  

    this.http.get(`${environment.apiUrl}api/Menu`)
      .subscribe(
        data => console.log(data),
        err => console.log(err)
      );
    return this.http.get<any[]>(`${environment.apiUrl}api/ValidateUser?email=nilesh.more@heathrow.com`);
  }

  //   getHomeDetails(): Observable<any> {
  //     let headers = new Headers();
  //     headers.append('Content-Type', 'application/json');
  //     let authToken = localStorage.getItem('auth_token');
  //     headers.append('Authorization', `Bearer ${authToken}`);

  //     return this.http.get(`${environment.apiUrl}/api/Menu`,{headers})
  //       .map(response => response.json())
  //       .catch(this.handleError);
  //   }  
  // }



}
