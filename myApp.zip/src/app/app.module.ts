import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
//import { DataTablesModule } from "angular-datatables";
import { IonRangeSliderModule } from "ng2-ion-range-slider";
import { NgxDaterangepickerMd } from 'ngx-daterangepicker-material';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { AppComponent } from './app.component';
import { FilterComponent } from './filter/filter.component';


import { MsalInterceptor, MsalModule } from "@azure/msal-angular";
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AlertsComponent } from './alerts/alerts.component';
import { UserComponent } from './core/user/user.component';
import { RouterModule } from '@angular/router';
import { CustomHttpInterceptor } from './helper/auth.Interceptor';

export const protectedResourceMap: [string, string[]][] = [
  ['https://graph.microsoft.com/v1.0/me', ['user.read']],
  ['https://heathrow.com/ksdevapi//write', ['user.read', 'user.write']]
];


@NgModule({
  declarations: [
    AppComponent,
    FilterComponent,
    DashboardComponent,
    AlertsComponent,
    UserComponent,
  ],
  imports: [
    MsalModule.forRoot(
      {
        clientID: 'fcd6989c-b117-47bb-b133-cd338987d7c3',
        authority: 'https://login.microsoftonline.com/2133b7ab-6392-452c-aa20-34afbe98608e',
        consentScopes: ["user.read", 'https://graph.microsoft.com/v1.0/me', 'https://heathrow.com/ksdevapi/'],
        protectedResourceMap: protectedResourceMap,
        redirectUri: 'https://localhost:44300/dashboard',
        popUp: false,
        cacheLocation : "localStorage",
        validateAuthority : true
      }),
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    // DataTablesModule,
    IonRangeSliderModule,
    NgxDaterangepickerMd.forRoot({ separator: ' - ', applyLabel: 'Okay', }),
    NgMultiSelectDropDownModule.forRoot()
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: CustomHttpInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
