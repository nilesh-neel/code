//----------------------------------------------------------------------
//Class Name   : UserProfile
//Purpose      : egt the login in user details profile photo, email organization etc..
//Created By   : Anupama Kumari
//Created Date : 01/March/2019
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Anupama               FDS Change                                  12/03/2019         Change related to the confirmation popup on change of dropdown values in profile pane
//----------------------------------------------------------------------

var $document = $(document);
$document.ready(function() {
    //onscroll fix for combobox
    jQuery('#dvPowerBiEmbed.scrollbar-inner,#filterOptions.scrollbar-inner,#ShareOptions.scrollbar-inner,.errorField.scrollbar-inner,.internalDiv.scrollbar-inner').scrollbar({
        /**
         //scroll dimensions
         * @param {any} y y axis
         * @param {any} x x axis
         */
        "onScroll": function(y, x) {
            $('.custom-combobox-input').each(function(index, item) {
                if (!($(item).css("display") === 'none')) {

                    $.when($(item).autocomplete("close")).done(
                        function() {
                            return false;
                        });

                }
            });
        }
    });
    //for hidding combobox hiding 
    $(document).on('mouseleave', '.ui-autocomplete,.custom-combobox-input,.slidingRow .ui-autocomplete,.slidingRow .custom-combobox-input', function comboboxHide(e) {
        if ($(e.currentTarget).hasClass('custom-combobox-input')) {
            if (!$(e.relatedTarget).hasClass('ui-autocomplete')) {

                $('.custom-combobox-input').each(function(index, item) {
                    if (!($(item).css("display") === 'none')) {

                        $.when($(item).autocomplete("close")).done(
                            function() {
                                return false;
                            });
                    }
                });
            }
        } else if ($(e.currentTarget).hasClass('ui-autocomplete')) {
            $('.custom-combobox-input').each(function(index, item) {
                if (!($(item).css("display") === 'none')) {

                    $.when($(item).autocomplete("close")).done(
                        function() {
                            return false;
                        });
                }
            });
        }
    });



    menuSlidingCount = null;
    menuSlidingInitialVal = null; //global variable


}); /** document ready ends ***/

/*datatables initialization  code*/
$(function() {

    //click of assign homepage
    $('#tabs a[href="#assignHomePagePanel"]').click(function assignHomepageClick(event) {
        $('.configureAlertForm').css('display', 'none');
        $('.configureNotificationForm').css('display', 'none');

        $('.configureBtn').css('display', 'block');
        $('.configureBtn button').css('display', 'none');
        $('.configureBtnNotification').css('display', 'block');
        $('.configureBtnNotification button').css('display', 'none');
    });

    //click of assign homepage navigation
    $('a[href="#assignHomePageNav"]').click(function assignHomeNavClick(event) {
        $('#tabs ul li').css('display', 'none');
        $('.configureAlertForm').css('display', 'none');
        $('.configureNotificationForm').css('display', 'none');
        $('.assignHomeTabs').css('display', 'block');
        $(".dataTables_paginate").css('display', 'none');
        $('a[href="#assignHomePagePanel"]').trigger('click');
    });

    //initial call
    $(window).resize(function() {
        //change in landscape and portrait view
        calComponentsHeight();
        PanelHeight();
        checkPosition();
        //    countMenuItems();
        if (window.matchMedia('(min-width:768px)').matches) {
            $(".searchDivMobile").hide();
        }
        if (window.matchMedia('(min-width:640px)').matches) {
            if ($(".searchDivMobile").css("display") === "none") {
                $(".searchImgMobile").show();
            }
        }
        //Menu.prototype.listPopulation.call(this, $(".menu li"));
        // if (!_.isNil(Utility.embedReportObjct)) {
        //     ReportConfig.prototype.setPbiContainerHeight.call(this, Utility.embedReportObjct.isMbl, Utility.embedReportObjct.$powerBiContainer);
        // }
    });
});

$(document).ready(function() {
    checkPosition();
    multiSelectFnCall();
    calComponentsHeight();
    PanelHeight();

    /***datepicker***/

    $(".formCalendarIcon").daterangepicker({

        singleDatePicker: true,
        showDropdowns: true

    });
    /**
     * @param {object} e event
      ** /
    /***vertical breadcrumb****/

    var navADPBreadCrumbClick = function(e) {
        e.stopPropagation();
        $(".verticalNavigation").toggle();
    };

    $(".navADPBreadCrumb").click(navADPBreadCrumbClick);

    /***refresh***/
    var refreshClick = function() {
        // $(".refreshMessage").css("display", "block");
    };

    $(".refresh").click(refreshClick);

    //click on close text
    var closeTextClick = function() {
        $(".refreshMessage").css("display", "none");
    };

    $(".closeText").click(closeTextClick);

    /***refresh close***/

    $('.hamburger').off('click').on('click', function refreshClose(event) {
        event.stopPropagation();
        $(".menu li.subDropdown .dropdown-content").css("display", "none");
        $('#homeNavigationBar').toggleClass('active');

        //Menu items toggle functionality
        $('.hamburger').toggleClass("clickedIcons").toggleClass("defaultIcons");
        $('.hambergerDiv').toggleClass('hambergerActive');
        $('.hamburgerSideBar').toggleClass('SideBarActive');
        $(".menu").css("margin-top", "0"); //reseting the margin value to 0
    });



    //click of userDetails panel
    $("#userDetailsPanel").click(function userDetailsPanelClick(event) {
        // close the other panel if it is opened
        Utility.ClosePanel();
        event.stopPropagation();
        $('.settingsLogout').attr("style", "display: inline-block !important");
    });
    var isDropdownValChanged = true;
    //click of document
    $(document).click(function documentClick(e) {

        documentClicked = true;
        if (!isDropdownValChanged) {
            $(".settingsLogout,.alertPopup").hide();
            $(".alerts").removeClass("alertsClicked");

            if (!e.target.classList.contains('clickedIcons')) {
                $('#homeNavigationBar').removeClass('active');
                //Hiding menu items
                $('.hamburgerSideBar').removeClass('SideBarActive');
                $("#bottomArrow,#topArrow").hide();
                $(".hambergerDiv").removeClass("hambergerActive");
                $(".hamburger").removeClass("clickedIcons").addClass("defaultIcons");

            }



            if (e.target.id !== "mobileSearchInputBox" && e.target.id !== "searchMobile" && e.target.id === "userDetailsPanel")
            //if(e.target.id!=="mobileSearchInputBox" && e.target.id!=="searchMobile")
            {
                $(".searchDivMobile").css("display", "none");
                $('.searchImgMobile').attr("style", "display: inline-block !important");
                $('.settingsLogout').attr("style", "display: inline-block !important");

            }
            if (e.target.id !== "verticalBreadCrumb") {
                $(".verticalNavigation").hide();
            }

        }
    });

    /***Menu  hover***/
    var menuHover = function() {

        $(".menu li.subDropdown .dropdown-content").css("display", "none");

        jQuery(this).find('span').toggleClass("clickedIcons").toggleClass("defaultIcons");

        $(this).tooltip("show");
    };

    /****vertical tabs hover***/
    var verticalTabsClick = function() {
        jQuery('#verticalTabs li').find('span:first-child').removeClass("clickedIcons").addClass("defaultIcons");
        jQuery(this).find('span:first-child').toggleClass("clickedIcons").toggleClass("defaultIcons");
    };

    /****vertical tabs hover***/
    jQuery('#verticalTabs li').click(verticalTabsClick);

    //click of scroll
    var documentScroll = function() {
        //  $("#topArrow").css("top", $(".hambergerDiv").innerHeight());
        $(".alertPopup").hide();
        if (screen.height < 650) {
            $(".hambergerDiv").removeClass('hambergerActive');
            //      $("#bottomArrow,#topArrow").hide();
            $("#homeNavigationBar").removeClass('active');
            //removing background
            $('.hamburgerSideBar').removeClass('SideBarActive');
            $(".hamburger").removeClass("clickedIcons").addClass("defaultIcons");
        }
        if (screen.width < 768) // to hide first header in mobile on scroll
        {
            if ($(document).scrollTop() !== 0) {
                $(".headerPosition").css("top", -$(".headerPosition").innerHeight());
                $(".navPosition").css("top", 0);
            } else {

                $(".navPosition").css("top", $(".headerPosition").innerHeight());
                $(".headerPosition").css("top", 0);
                //     $("#topArrow").css("top", $(".header").innerHeight() + $(".hambergerDiv").innerHeight());
            }
        }
    };

    //click of scroll
    $(document).scroll(documentScroll);
});

//multi select function
var multiSelectFnCall = function() {
    $('.multiSelectComponent').multiselect({
        enableFiltering: true,
        buttonWidth: '100%',
        filterPlaceholder: 'Search for something...',
        nonSelectedText: 'Select'
    });
    $('.multiselect-container').addClass('scrollbar-inner');
    $('.scrollbar-inner').scrollbar();
    $('ul.multiselect-container').removeClass('dropdown-menu');

    //show all items tooltip 
    $(".multiselectCombo button").removeAttr('title');
    $(".multiselectCombo button b").attr("data-toggle", "tooltip");
    $(".multiselectCombo button b").attr("data-original-title", "Show All Items");
    $(".multiselectCombo button b").tooltip();

}; /*multiselect end */

// Example starter JavaScript for disabling form submissions if there are invalid fields

/*** Form validation***/
(function() {
    'use strict';
    window.addEventListener('load', function() {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function(form) {
            form.addEventListener('submit', function(event) {
                if (form.checkValidity() === false) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    }, false);
})();

/****Form Validation End ***/

var expanded = false;

//show the checkboxes
var showCheckboxes = function() {
    if (!expanded) {
        $("#checkmarkOuterDiv").css('display', 'block');
        expanded = true;
    } else {
        $("#checkmarkOuterDiv").css('display', 'none');
        expanded = false;
    }
};

var panelSlided = false;

//show alert details
var showAlertDetails = function() {

    if (!panelSlided) {
        $(".slidePanel").css('display', 'block');
        panelSlided = true;
    } else {
        $(".slidePanel").css('display', 'none');
        panelSlided = false;
    }

};

$("span.Show_details").closest("td").addClass("showdetailsTDstyle");
$("span.Edit").closest("td").addClass("showdetailsTDstyle");
$('.ui-autocomplete-input').css('width', '100px');
$('table tr td label.container').closest("td").addClass("tableCheckmarkStyleOveride");

/***breadcrumbs***/
var menuSubClick = function() {
    // will not trigger document ready and it will close dropdown-content
    event.stopPropagation();
    $(".menu li").tooltip("destroy");
    $(".menu li.subDropdown .dropdown-content").css("display", "none");
    $(this).find(".dropdown-content").css("display", "block");
};

$('.disabledIcons').hover(function disabledIconHover(e) {
    e.preventDefault();
});


var menu = {

    "Favourites": {
        "null": {
            "type": 'null',
            "breadCrumb": ''
        }
    }
};

//click of search in mobile
var searchImgMobileClick = function() {
    event.stopPropagation();
    $(".searchDivMobile").css("display", "block");
    $('.searchImgMobile').attr("style", "display: none !important");
};

//click of search in mobile
$(".searchImgMobile").click(searchImgMobileClick);

//settings breadcrumbs
var breadcrumbsClick = function() {
    $(".breadcrumb li").not(".active").remove();
    //updating breacrumbname in settings
    $(".breadcrumb li.active").text($(this).data("breadcrumb"));
    setTimeout(function() {
        //updating the height of vertical tabs
        $("#verticalTabs").height($(".zeroStyling:last-child").height());
    }, 500);
};

//settings breadcrumbs
$(".nav-tabs li a").on("click", breadcrumbsClick);

//close icon clickapply.daterangepicker
var closeIconClick = function() {
    $(".notificationWrapper").hide();
    $(".dataTables_wrapper .dataTables_paginate").css("padding-bottom", "0px");
};

//close icon clickapply.daterangepicker
$(".closeIcon").on("click", closeIconClick);

//Add to my bag list click
$(".addMBL").on("click", addToBaglistClick);

//Add to my bag list click
var addToBaglistClick = function() {
    $(".breadcrumb li").not(".active").remove();
    //updating breacrumbname in settings
    $(".breadcrumb li.active").text("MY BAG LIST");
    // linkingEmbedded("myBagList");
};

//Resolution settings
var checkPosition = function() {
    if (window.matchMedia('(max-width:639px)').matches) {
        $("#lowerResolutionDevices").css("display", "block");

    } else {
        $("#lowerResolutionDevices").css("display", "none");
    }
};
window.addEventListener("orientationchange", function() {
    var orientation = window.orientation;
    switch (orientation) {
        case 0:
            window.location.reload();
            break;
        case 90:
            window.location.reload();
            break;
        case -90:
            window.location.reload();
            break;
        default:
            break;
    }
});

//calculate components height
var calComponentsHeight = function() {
    var PBIContainer = window.innerHeight - ($(".header").innerHeight() + $(".navBg").innerHeight() + $(".notificationWrapper").outerHeight());
    var menuHeight = window.innerHeight - ($(".header").outerHeight() + $(".headerTopNav").outerHeight()); // 24px height and notification height is calculated since datatables will not be loaded first.
    var topPosition = $(".header").innerHeight() + $(".headerTopNav").innerHeight();
    var errorFieldOverride = window.innerHeight - ($(".header").innerHeight() + $(".navBg").innerHeight() + $(".notificationWrapper").outerHeight() + $('#tabs').outerHeight() + $('.table th').innerHeight() + 50);
    $(".errorFieldOverride").css("height", errorFieldOverride);
    $(".errorFieldOverride").css("max-height", errorFieldOverride);
    $(".hamburgerSideBar").height(menuHeight);
    //$(".hamburgerSideBar").css("top",topPosition);
    $(".myBagListDiv,.tabArea,#verticalTabs").css("min-height", PBIContainer);
    $(".tabArea").css("height", PBIContainer);
    $("#verticalTabs").css("height", $(".zeroStyling:last-child").height()); //to calculate height of verticaltabs

    $(".AssignHomePage").outerHeight(errorFieldOverride);

    if ($(".headerPosition").innerHeight() > 100) {
        if (screen.height < 650) {
            $(".navPosition").css("top", $(".navPosition").css("top", 44));
        }
        if (screen.height > 768) {
            $(".navPosition").css("top", $(".navPosition").css("top", 63));
        } else {
            $(".navPosition").css("top", $(".navPosition").css("top", 74));
        }
    } else {
        $(".navPosition").css("top", $(".headerPosition").innerHeight());
    }

    $(".tabArea").css("margin-top", $(".navBg").innerHeight() + $(".header").innerHeight());

    //menu li height in higher resolution devices
    if (screen.height >= 768 && screen.height <= 1024) {
        $(".menu li").css("padding", "8px 0 8px 0");
    }
    $(".container-fluid").css("min-height", window.innerHeight);
};

//set the panel height
var PanelHeight = function() {
    $.when($('.scrollbar-inner').scrollbar()).done(function() {
        var windowHeight, notesHeight;
        windowHeight = window.innerHeight;
        windowHeight = windowHeight - (parseInt($(".sideNavBar").css("padding-top").split("px")[0]) + parseInt($(".shareInternalDiv").css("padding-bottom").split("px")[0]) + $(".btnPanel").innerHeight() + $(".header").innerHeight() + $(".headerTopNav").innerHeight()); /* 140 padding + remove header height from window height to calculate hide of shareInternalDiv*/
        notesHeight = window.innerHeight - (10 + parseInt($(".sideNavBar").css("padding-top").split("px")[0]) + parseInt($(".internalDiv").css("margin-top").split("px")[0]) + parseInt($(".internalDiv").css("margin-bottom").split("px")[0]) + $(".btnPanel").innerHeight() + $(".header").innerHeight() + $(".headerTopNav").innerHeight() + $(".dateStyling").outerHeight()); // removing  noteDiv internal div margins  
        windowHeight = windowHeight + 'px';
        notesHeight = notesHeight + 'px';
        $(".shareInternalDiv>div,#filterOptions,#ShareOptions").attr('style', 'max-height:' + windowHeight + ';min-height:' + windowHeight + '');
        $(".filterMenu>div,.internalDiv").attr('style', 'max-height:' + notesHeight + ';min-height:' + notesHeight + '');
    });
};