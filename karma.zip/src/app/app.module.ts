import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataTablesModule } from "angular-datatables";
import { AssignHomepageComponent } from './configuration/assign-homepage/assign-homepage.component';
import { NotificationsComponent } from './configuration/notifications/notifications.component';
import { AlertsComponent } from './configuration/alerts/alerts.component';
import { MybaglistComponent } from './mybaglist/mybaglist.component';
import { AdminMasterComponent } from './configuration/admin-master/admin-master.component';
import { NavbarComponent,  ValuesPipe } from './core/navbar/navbar.component';
import { CalendarComponent } from './core/calendar/calendar.component';
import { HeaderComponent } from './core/header/header.component';
import { ModalComponent } from './core/modal/modal.component';
import { PbiDashboardComponent } from './pbi-dashboard/pbi-dashboard.component';


import { MsalModule, MsalInterceptor } from '@azure/msal-angular';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { AuthInterceptor } from './core/interceptors/auth.interceptor';


export const protectedResourceMap: [string, string[]][] = [
  ['https://graph.microsoft.com/v1.0/me', ['user.read']],
  ['https://heathrow.com/ksdevapi//write', ['user.read', 'user.write']]
];

import * as $ from 'jquery';


@NgModule({
  declarations: [
    AppComponent,
    AssignHomepageComponent,
    NotificationsComponent,
    AlertsComponent,
    MybaglistComponent,
    AdminMasterComponent,
    NavbarComponent,
    CalendarComponent,
    HeaderComponent,
    ModalComponent,
    PbiDashboardComponent,
    ValuesPipe
  ],
  imports: [
    MsalModule.forRoot({
      clientID: 'fcd6989c-b117-47bb-b133-cd338987d7c3',
      authority: 'https://login.microsoftonline.com/2133b7ab-6392-452c-aa20-34afbe98608e',
      consentScopes: ["user.read", 'https://graph.microsoft.com/v1.0/me', 'https://heathrow.com/ksdevapi/'],
      protectedResourceMap: protectedResourceMap,
      redirectUri: 'https://localhost:44300/Dashboard',
      popUp: false,
      cacheLocation: "localStorage",
      validateAuthority: true
    }),
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    DataTablesModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
