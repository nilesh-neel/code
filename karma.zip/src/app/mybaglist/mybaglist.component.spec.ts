import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MybaglistComponent } from './mybaglist.component';

describe('MybaglistComponent', () => {
  let component: MybaglistComponent;
  let fixture: ComponentFixture<MybaglistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MybaglistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MybaglistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
