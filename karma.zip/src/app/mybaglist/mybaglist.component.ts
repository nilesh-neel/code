import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mybaglist',
  templateUrl: './mybaglist.component.html',
  styleUrls: ['./mybaglist.component.css']
})
export class MybaglistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
