import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PbiDashboardComponent } from './pbi-dashboard.component';

describe('PbiDashboardComponent', () => {
  let component: PbiDashboardComponent;
  let fixture: ComponentFixture<PbiDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PbiDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PbiDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
