import { Component, OnInit } from '@angular/core';
import * as pbi from 'powerbi-client';
import { IPbiDetails } from '../shared/interfaces';
import { PbiService } from '../shared/services/pbi.service';


@Component({
  selector: 'app-pbi-dashboard',
  templateUrl: './pbi-dashboard.component.html',
  styleUrls: ['./pbi-dashboard.component.css']
})
export class PbiDashboardComponent implements OnInit {
  pbiData: IPbiDetails;
  screenHeight: number;

  constructor(private pbiService: PbiService) { }

  ngOnInit() {
    let ratio = 1280 / 620;
    let pbiContainerHeight: number = screen.width / ratio;
    this.screenHeight = pbiContainerHeight;
    this.embedPowerBIReport();
  }

  embedPowerBIReport() {
    this.pbiService.getDashboard(2, 1).subscribe((res) => {
      this.pbiData = res.result[0];
      const config = {
        type: this.pbiData.powerBIType, //'dashboard',
        tokenType: pbi.models.TokenType.Embed,
        id: this.pbiData.id,
        embedUrl: this.pbiData.embedUrl,
        accessToken: this.pbiData.embedToken,
      };

      const reportsContainer = <HTMLElement>document.getElementById(
        'embedContainer'
      );
      let powerbi = new pbi.service.Service(pbi.factories.hpmFactory, pbi.factories.wpmpFactory, pbi.factories.routerFactory);
      const report = powerbi.embed(reportsContainer, config);

      // Report.off removes a given event handler if it exists.
      report.off('loaded');
      report.on('loaded', (event) => {
        console.log('loaded: ' + event);
        // this.setTokenExpirationListener(Token.expiration,
        //   2 minutes before expiration*);
      });

      report.on('error', function (event) {
        console.log(event.detail);
        report.off('error');
      });
    },
      (error) => {
        console.log(error);
      })


  }
  /*
  embedPowerBIReport() {
    this.http.get(`${environment.apiUrl}api/PbiToken?menuId=2&reportType=1`).subscribe((res) => {
      let response = res;
      let Token = response.embedToken;
      const config = {
        type: 'dashboard',
        tokenType: pbi.models.TokenType.Embed,
        id: response.id,
        embedUrl: response.embedUrl,
        accessToken: Token.token,
      };

      // Grab the reference to the div HTML element that will host the report.
      const reportsContainer = <HTMLElement>document.getElementById(
        'embedReport'
      );


      const report = this.powerbi.embed(
        reportsContainer,
        config
      );

      // Report.off removes a given event handler if it exists.
      report.off('loaded');

      // Report.on will add an event handler which prints to Log window.      
      report.on('loaded', (event) => {
        console.log('loaded: ' + event);
        // this.setTokenExpirationListener(Token.expiration,
        //   2 minutes before expiration*);
})

report.off('pageChanged');
report.on('pageChanged', e => {
  console.log(e);
});

report.on('error', function (event) {
  console.log(event.detail);
  report.off('error');
});
    },
(error) => {
  console.log(error);
})
  }
*/
}
