import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlertsComponent } from './configuration/alerts/alerts.component';
import { NotificationsComponent } from './configuration/notifications/notifications.component';
import { AssignHomepageComponent } from './configuration/assign-homepage/assign-homepage.component';
import { AdminMasterComponent } from './configuration/admin-master/admin-master.component';
import { PbiDashboardComponent } from './pbi-dashboard/pbi-dashboard.component';
import { MsalGuard } from '@azure/msal-angular';


const routes: Routes = [
  { path: '', component: PbiDashboardComponent, canActivate: [MsalGuard] },
  {
    path: 'admin', component: AdminMasterComponent, children: [
      { path: 'alerts', component: AlertsComponent },
      { path: 'notifications', component: NotificationsComponent },
      { path: 'homepage', component: AssignHomepageComponent }
    ]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
