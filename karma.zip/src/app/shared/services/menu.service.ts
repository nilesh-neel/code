import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IResponseHelper, IPbiDetails, IMenu } from '../interfaces';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor(private http: HttpClient) { }


  getDashboard(menuid: number, reportType: number): Observable<IResponseHelper<IPbiDetails>> {
    return this.http.get<IResponseHelper<IPbiDetails>>(`${environment.apiUrl}api/PbiToken?menuId=${menuid}&reportType=${reportType}`);
  }
  getMenu(): Observable<IResponseHelper<IMenu>> {
    return this.http.get<IResponseHelper<IMenu>>(`${environment.apiUrl}api/Menu`);
  }

}
