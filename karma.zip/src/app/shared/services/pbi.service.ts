import { Injectable } from '@angular/core';
import { IResponseHelper, IPbiDetails } from '../interfaces';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { tap, catchError } from "rxjs/operators";
import { throwError, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PbiService {

  constructor(private http: HttpClient) { }


  getDashboard(menuid: number, reportType: number): Observable<IResponseHelper<IPbiDetails>> {
    return this.http.get<IResponseHelper<IPbiDetails>>(`${environment.apiUrl}api/PbiToken?menuId=${menuid}&reportType=${reportType}`);
  }
  private handleError(err: HttpErrorResponse) {
    let errorMessage = '';
    if (err.error instanceof ErrorEvent) {
      errorMessage = `An error Occured: ${err.error.message}`;
    } else {
      errorMessage = `Server returned code : ${err.status}, error message is: ${err.message}`
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }
}
