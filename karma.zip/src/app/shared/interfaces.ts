
export interface IPbiDetails {
    id: string;
    embedUrl: string;
    embedToken: string;
    lastRefreshDateTime?: any;
    isEffectiveIdentityRolesRequired?: any;
    isEffectiveIdentityRequired?: any;
    enableRls: boolean;
    userName: string;
    roles: string;
    filterType?: any;
    reportSection?: any;
    errorMessage?: any;
    powerBIType: string;
    values: any[];
    filterDetails?: any;
}

export interface IMenu {
    menuId: number;
    description: string;
    operationalReportId?: any;
    businessReportId?: any;
    organization?: any;
    parentId: number;
    orderId: number;
    cssIcon: string;
    isReport: boolean;
    tooltip: string;
    favouritesDescription: string;
    breadcrumb: string;
    isVisible: boolean;
    isMultilevel: boolean;
}



export interface IResponseHelper<T> {
    version: string;
    statusCode: number;
    errorMessage: string;
    result: T[];
    timestamp: Date;
    size: number;
}