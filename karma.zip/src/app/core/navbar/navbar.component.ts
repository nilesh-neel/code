import { Component, OnInit, AfterViewInit, Pipe, PipeTransform } from '@angular/core';
import { MenuService } from 'src/app/shared/services/menu.service';
import { IMenu } from 'src/app/shared/interfaces';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  ngAfterViewInit() {
    $('[data-toggle="tooltip"]').each(function () {
      var options = {
        html: true,
        position: {
          // the "anchor point" in the tooltip element
          my: "center bottom",
          // the position of that anchor point relative to selected element
          at: "center top"
        }
      };

      if ($(this)[0].hasAttribute('data-type')) {
        options['template'] =
          '<div class="tooltip ' + $(this).attr('data-type') + '" role="tooltip">' +
          ' <div class="tooltip-arrow"></div>' +
          ' <div class="tooltip-inner"></div>' +
          '</div>';
      }

      ($(this) as any).tooltip(options);
    });
  }

  menuList: IMenu[];
  parentMenuList: IMenu[];
  childMenuList: IMenu[];

  constructor(private menuService: MenuService) { }

  ngOnInit() {
    this.menuService.getMenu().subscribe((resp) => {
      this.menuList = resp.result;
      this.parentMenuList = resp.result.filter(m => m.parentId == 0);
      this.childMenuList = resp.result.filter(m => m.parentId != 0);
    })

  }
  changeStyle(e) {
    $('ul.menu li').hover(function (e) {
      $(".menu li.subDropdown .dropdown-content a")
        .css("display", "none");
      $(e.target).find('span')
        .addClass("clickedIcons").removeClass("defaultIcons");
      $(e.currentTarget).find('span')
        .addClass("clickedIcons").removeClass("defaultIcons");
      ($(e.target) as any).tooltip("show");
    },
      function (e) {
        jQuery(this).find('span')
          .removeClass("clickedIcons").addClass("defaultIcons");
        $(e.currentTarget).find('span')
          .removeClass("clickedIcons").addClass("defaultIcons");
      });

    $('.dropdown-content a').hover(function () {
      $(e.target).find('span')
        .toggleClass("clickedIcons").toggleClass("defaultIcons");
      ($(e.target) as any).tooltip("show");

    });

    /****vertical tabs hover***/

    jQuery('#verticalTabs li').click(function () {
      jQuery('#verticalTabs li').find('span:first-child')
        .removeClass("clickedIcons").addClass("defaultIcons");
      jQuery(this).find('span:first-child')
        .toggleClass("clickedIcons").toggleClass("defaultIcons");
    });

    /***breadcrumbs***/
    $(".menu li.subDropdown,.menu li:not(.subDropdown)").off('click').on("click",
      function (e) {

        // will not trigger document ready and it will close dropdown-content
        e.stopPropagation();
       ( $(".menu li") as any).tooltip("destroy");
        $(".menu li.subDropdown .dropdown-content").css("display", "none");
        $(e.currentTarget).find('.dropdown-content').css("display", "block");
        $(e.currentTarget).find('.dropdown-content a').css("display", "block");
        ($(e.target) as any).tooltip("show");
      });
  }

}

@Pipe({ name: 'values' })
export class ValuesPipe implements PipeTransform {
  transform(value, args: string[]): any {
    let values = []
    debugger;

    return value.filter(m => m.parentId == args);

    // for (let key in value) {
    //   values.push(value[key])
    // }
    // return values
  }
}