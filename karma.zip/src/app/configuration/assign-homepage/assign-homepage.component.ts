import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign-homepage',
  templateUrl: './assign-homepage.component.html',
  styleUrls: ['./assign-homepage.component.css']
})
export class AssignHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
