import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignHomepageComponent } from './assign-homepage.component';

describe('AssignHomepageComponent', () => {
  let component: AssignHomepageComponent;
  let fixture: ComponentFixture<AssignHomepageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignHomepageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignHomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
