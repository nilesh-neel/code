﻿/****************************************************************************************************************
Class Name   : IAssignHomePageModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Vignesh
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetching the user groups by logged-in EmailId  | 05/Dec/2018       | Logic changed
Vignesh (686552)   | Fetch Dashboard list in groups                 | 10/Dec/2018       | Logic changed
Vignesh (686552)   | code cleanup and updated                       | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                 | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System.Collections.Generic;
using Heathrow.BIPM.Core.Entity;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Interface
{
    public interface IAssignHomePageModule
    {

        Task<IList<AssignHomePage>> GetUserGroups(string userEmailId);
        Task<IList<AssignHomePage>> GetGroupRecipients(int userGroupId);
        Task<string> SaveHomepage(AssignHomePage assignHomePage,string updatedUserEmailId);
        Task<PowerBiReportDetails> GetUserDashboard(string userId);
    }
}