﻿/****************************************************************************************************************
Class Name   : IuserModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.IO;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Business.Interface
{
    public interface IUserModule
    {
        Task<Stream> GetUserProfilePhoto();
        Task<AzureAdUser> GetUserDetailsAsync();
        Task<AzureAdUser> GetUser(string id);
         byte[] GetMyProfilePhoto(string accessToken);

    }
}