﻿/****************************************************************************************************************
Class Name   : IAlertsModule.cs 
Purpose      : Interface consists of method declarations implemented in Business Layer
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Business.Interface
{
    public interface IAlertsModule
    {
        Task<MyAlertSettings> GetAlertsById(string userId,int alertId);
        Task<IEnumerable<MyAlertSettings>> GetAlerts(string id);
        Task<string > InsertUpdate(Alerts alerts);
       Task<IEnumerable<TodaysAlert>> GetAlertNotification(string userId);
        Task<int> GetAlertCount(string userId);
        Task<IEnumerable<TodaysAlert>> GetTodaysAlert(string userId);
        Task<IEnumerable<ConfigureAlerts>> GetConfiguredAlert(string userId);
        Task<Alerts> GetConfiguredAlertById(string userId, int alertId);
        Task<Alerts> GetTopicForMeasure(string selectedId);
    }
}