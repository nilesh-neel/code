﻿/****************************************************************************************************************
Class Name   : IFilterModule.cs 
Purpose      : This class implements the Business Interface for the Filter Module to the web API project.
Created By   : Kannan
Created Date : 12/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Business.Interface
{

    public interface IFilterModule
    {
        Task<FilterEntity> FilterByMenuId(int menuId, string userId);

        Task<FilterControlEntity> FilterConfiguration();

        Task<int> SaveFilter(FilterEntity filterData);
    }
}