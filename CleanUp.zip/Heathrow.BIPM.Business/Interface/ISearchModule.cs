﻿/****************************************************************************************************************
Class Name   : ISearchModule.cs 
Purpose      : This class implements the Business Interface for the Search Module to the web API project.
Created By   : Kannan
Created Date : 13/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Business.Interface
{

    public interface ISearchModule
    {
   
        System.Threading.Tasks.Task<ReportConfiguration> SearchData(string searchQuery, string searchPrefix);
    }
}