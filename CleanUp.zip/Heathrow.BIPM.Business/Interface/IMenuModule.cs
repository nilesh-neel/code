﻿/****************************************************************************************************************
Class Name   : IMenuModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Collections.Generic;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Business.Interface
{
    public interface IMenuModule
    {
        IEnumerable<Menu> GetAllMenu();
        IList<PowerBiReportDetails> GetUserReports(string strUserId);
    }
}