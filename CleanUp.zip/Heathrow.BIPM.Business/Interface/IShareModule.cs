﻿/****************************************************************************************************************
Class Name   : IShareModule.cs 
Purpose      : This class implements the Business Interfacce for the Share Module to the web application project.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetch organisation/recipients using logged-in user's EmailId instead of userId | 05/Dec/2018 | Logic changed
Vignesh (686552)   | code cleanup and updated                                                       | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                                                 | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/
using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Business.Interface
{
       public interface IShareModule
    {
    
        Task<IList<Share>> GetAudienceGroup(string userEmailId);
      
        Task<IList<Share>> GetGroupRecipients(int audienceGroupId);
    }
}