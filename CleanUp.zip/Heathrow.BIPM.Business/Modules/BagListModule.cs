﻿/****************************************************************************************************************
Class Name   : BagListModule.cs 
Purpose      : This class implements the Business Logic of the BagList Module.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetch/Remove/Save bagtags using user's EmailId instead of userId   | 05/Dec/2018       | Logic changed
Vignesh (686552)   | BagList Entitiy as param for Post method                           | 10/Dec/2018       | Entity properties added
Vignesh (686552)   | code cleanup and updated                                           | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                                     | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System.Threading.Tasks;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.Business.Modules
{
    public class BagListModule : IBagListModule
    {
        private readonly IBagList _baglist;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="bagList"></param>
        public BagListModule(IBagList bagList)
        {
            _baglist = bagList;
        }

        /// <summary>
        ///  Fetching the Existing BagTags of the respective User
        /// </summary>
        /// <param name="userId">userId as input parameter</param>
        /// <returns>Existing Bagtags as string</returns>
        public async Task<string> GetUserExistingbagtags(string userEmailId)
        {
            if (string.IsNullOrEmpty(userEmailId))
            {
                return string.Empty;
            }
            return await _baglist.GetUserExistingBagTags(userEmailId).ConfigureAwait(false);
        }

        /// <summary>
        /// Removing BagTags selected by the User
        /// </summary>
        /// <param name="bagTags">Bagtags as input parameter</param>
        /// <param name="userId">userId as input parameter</param>
        /// <returns>Remaining Bagtags as string</returns>
        public async Task<string> RemoveBagTags(string bagTags, string userEmailId)
        {
            if (string.IsNullOrEmpty(bagTags))
            {
                return string.Empty;
            }
            return await _baglist.RemoveBagTags(bagTags, userEmailId).ConfigureAwait(false);

        }

        /// <summary>
        /// Saving the Added BagTags selected by the User
        /// </summary>
        /// <param name="bagTags">Bagtags as input parameter</param>
        /// <param name="userId">userId as input parameter</param>
        /// <returns>Updated Bagtags as string</returns>
        public async Task<string> SaveBagTags(string bagTags, string userEmailId)
        {
            if (string.IsNullOrEmpty(bagTags))
            {
                return string.Empty;
            }
            return await _baglist.SaveBagTags(bagTags, userEmailId).ConfigureAwait(false);
        }
    }
}
