﻿/****************************************************************************************************************
Class Name   : ShareModule.cs 
Purpose      : This class implements the Business Logic of the Share Module.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetch organisation/recipients using logged-in user's EmailId instead of userId | 05/Dec/2018 | Logic changed
Vignesh (686552)   | code cleanup and updated                                                       | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                                                 | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/


using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.Business.Modules
{
    public class ShareModule : IShareModule
    {
        private readonly IShare _share;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="share"></param>
        public ShareModule(IShare share)
        {
            _share = share;
        }

        /// <summary>
        ///  Fetching the Audience Group
        /// </summary>
        /// <returns>Audience Group as List</returns>
        public async Task<IList<Share>> GetAudienceGroup(string userEmailId) => await _share.FetchAudienceGroup(userEmailId).ConfigureAwait(false);

        /// <summary>
        /// Fetching the Group Recipients based on the selected Audience Group
        /// </summary>
        /// <param name="audienceGroupId">Selected AudienceGrpId as input parameter</param>
        /// <returns>Recipients as List</returns>
        public async Task<IList<Share>> GetGroupRecipients(int audienceGroupId)
        {
            if (audienceGroupId > 0)
            {
                return await _share.FetchRecipients(audienceGroupId).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }
    }
}
