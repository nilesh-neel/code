﻿/****************************************************************************************************************
Class Name   : PowerBiModule.cs 
Purpose      : PowerBiModule use to get Access token for the power bi report embadded.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh               FDS Change                                  26/03/2019         Powerbi filter code update
****************************************************************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.PowerBI.Api.V2.Models;
using Microsoft.Rest;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.Utility.Common;
using Microsoft.PowerBI.Api.V2;
using Heathrow.BIPM.Utility.Constants;
using System.Globalization;
namespace Heathrow.BIPM.Business.Modules
{
    public class PowerBIModule : IBpmPowerBi
    {
        private readonly IMenuModule _menuModule;
        private readonly string _userId;
        private readonly IFilterModule _filterModule;
        private readonly IAssignHomePageModule _homePage;
        private readonly IPowerBi _powerBiRepository;
        private readonly string _pbiUserId;

        /// <summary>
        /// </summary>
        /// <param name="menu"></param>
        /// <param name="filterModule"></param>
        /// <param name="homePage"></param>
        /// <param name="powerBiRepository"></param>
        public PowerBIModule(IMenuModule menu, IFilterModule filterModule, IAssignHomePageModule homePage, IPowerBi powerBiRepository)
        {
            _menuModule = menu;
            _filterModule = filterModule;
            _homePage = homePage;
            _powerBiRepository = powerBiRepository;
            _pbiUserId = KestrelKeyVaultUtility.Get(AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.PBUserName)).Result;
            _userId = (ClaimsPrincipal.Current.FindFirst(ClaimTypes.Upn) == null) ?
                ClaimsPrincipal.Current.FindFirst(ClaimTypes.Email).Value :
                ClaimsPrincipal.Current.FindFirst(ClaimTypes.Upn).Value;
        }


        /// <summary>
        /// return report or dashboard details with power bi client v2.
        /// </summary>
        /// <param name="menuId">login user role</param>
        /// <param name="reportType">current menu id</param>
        /// <returns></returns>
        public async Task<List<PowerBiEmbedConfig>> EmbedReportV2(int menuId, int reportType)
        {
            var result = new List<PowerBiEmbedConfig>();
            FilterEntity filterData = null;
            try
            {
                if (menuId == 2)
                {
                    result.Add(await EmbedUserDashboard().ConfigureAwait(false));
                    return result;
                }

                #region "Token With PowerBi Client"
                // Create a Power BI Client object. It will be used to call Power BI APIs.
                using (var client = await GetPbiClient().ConfigureAwait(false))
                {
                    var reportDbDetails = _powerBiRepository.GetReportDetails(_userId).ToList();
                    if (menuId > 3)
                    {
                        filterData = await _filterModule.FilterByMenuId(menuId, _userId).ConfigureAwait(false);
                    }

                    var reportDetails = reportDbDetails.FirstOrDefault(d => d.MenuId == menuId && d.ReportType == reportType);

                    if (reportDetails != null)
                        result = new List<PowerBiEmbedConfig>
                        {
                            await GetPowerBiEmbedConfig(_userId, reportDetails.PbiRoles, reportDetails, client)
                                .ConfigureAwait(false)
                        };
                    PowerBiEmbedConfig first = result.FirstOrDefault();
                    if (first != null) first.FilterDetails = filterData;
                }
                #endregion
            }
            catch (HttpOperationException exc)
            {
                result.Add(new PowerBiEmbedConfig
                {
                    ErrorMessage = string.Format(CultureInfo.InvariantCulture, MessageConstants.ErrFormat, exc.Response.StatusCode,
                    (int)exc.Response.StatusCode, exc.Response.Content, exc.Response.Headers[MessageConstants.RequestId].FirstOrDefault())
                });
            }
            catch (Exception exc)
            {
                result.Add(new PowerBiEmbedConfig
                {
                    ErrorMessage = exc.ToString()
                });
            }
            return result;
        }

        private async Task<PowerBiEmbedConfig> GetPowerBiEmbedConfig(string userName, string roles, PowerBiReportDetails reportDetails, IPowerBIClient client)
        {
            var result = new PowerBiEmbedConfig { UserName = _pbiUserId, Roles = roles };

            if (reportDetails == null)
            {
                result.ErrorMessage = MessageConstants.NoReportInWorkspace;
                return result;
            }

            var groupId = reportDetails.WorkSpaceId;
            var reportId = string.IsNullOrEmpty(reportDetails.ReportId)
                ? MessageConstants.DefaultReport
                : reportDetails.ReportId;

            #region"Working Embeded token "

            var report = await client.Reports.GetReportAsync(groupId, reportId).ConfigureAwait(false);
            //  var report = reports.Value.FirstOrDefault(r => r.Id.Equals(reportId));


            if (report == null)
            {
                result.ErrorMessage = MessageConstants.NoReportInWorkspace;
                return result;
            }

            var datasets = await client.Datasets.GetDatasetByIdInGroupAsync(groupId, report.DatasetId).ConfigureAwait(false);
            result.IsEffectiveIdentityRequired = datasets.IsEffectiveIdentityRequired;
            result.IsEffectiveIdentityRolesRequired = datasets.IsEffectiveIdentityRolesRequired;
            GenerateTokenRequest generateTokenRequestParameters;

            if (!string.IsNullOrWhiteSpace(userName))
            {
                var rls = new EffectiveIdentity(result.UserName, new List<string> { report.DatasetId });
                if (!string.IsNullOrWhiteSpace(roles))
                {
                    var rolesList = new List<string>();
                    rolesList.AddRange(roles.Split(','));
                    rls.Roles = rolesList;
                    rls.CustomData = userName;
                }

                // Generate Embed Token with effective identities.
                generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view",
                    identities: new List<EffectiveIdentity> { rls });
            }
            else
            {
                // Generate Embed Token for reports without effective identities.
                generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view");
            }

            var reportEmbedToken = await client.Reports.GenerateTokenAsync(groupId, report.Id, generateTokenRequestParameters).ConfigureAwait(false);

            if (reportEmbedToken == null)
            {
                result.ErrorMessage = MessageConstants.EmbedTokenFailed;
                return result;
            }

            #endregion

            // Generate Embed Configuration.
            result.FilterType = reportDetails.FilterType;
            result.EmbedToken = reportEmbedToken.Token;
            var pageName = !string.IsNullOrEmpty(reportDetails.ReportSection)
                ? FormattableString.Invariant($"&pageName=ReportSection{reportDetails.ReportSection}")
                : "&pageName=ReportSection";

            result.EmbedUrl = new Uri(report.EmbedUrl + pageName);
            result.LastRefreshDateTime = reportDetails.ReportRefreshDateTime;
            result.ReportSection = !string.IsNullOrEmpty(reportDetails.ReportSection)
                ? FormattableString.Invariant($"ReportSection{reportDetails.ReportSection}")
                : "";
            result.PowerBIType = MessageConstants.Report;
            result.Id = report.Id;
            return result;
        }

        private async Task<PowerBiEmbedConfig> EmbedUserDashboard()
        {
            var result = new PowerBiEmbedConfig { UserName = _pbiUserId };

            using (var client = await GetPbiClient().ConfigureAwait(false))
            {
                var dashboardDetails = await _homePage.GetUserDashboard(_userId).ConfigureAwait(false);

                var dashboard = await client.Dashboards.GetDashboardInGroupAsync(dashboardDetails.WorkSpaceId, dashboardDetails.ReportId).ConfigureAwait(false);

                if (dashboard == null)
                {
                    result.ErrorMessage = MessageConstants.NoReportInWorkspace;
                    return result;
                }

                // Generate Embed Token.
                var generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view");
                var dashboardEmbedToken = await client.Dashboards.GenerateTokenInGroupAsync(dashboardDetails.WorkSpaceId, dashboard.Id, generateTokenRequestParameters).ConfigureAwait(false);

                if (dashboardEmbedToken == null)
                {
                    result.ErrorMessage = MessageConstants.EmbedTokenFailed;
                    return result;
                }

                // Generate Embed Configuration.
                result.EmbedToken = dashboardEmbedToken.Token;
                result.EmbedUrl = new Uri(dashboard.EmbedUrl);
                result.PowerBIType = MessageConstants.Dashboard;
                result.Id = dashboard.Id;
                return result;
            }

        }

        /// <summary>
        /// Get the power bi dashboard details under the workspace
        /// </summary>
        /// <returns>List of dashboad under the workspace</returns>
        public async Task<PowerBiEmbedConfig> GetDashboardInGroup()
        {
            var result = new PowerBiEmbedConfig();
            try
            {
                using (var client = await GetPbiClient().ConfigureAwait(false))
                {
                    var reportDbDetails = _menuModule.GetUserReports(_userId).ToList();
                    var dataResponseListDashboard = await client.Dashboards.GetDashboardsInGroupAsync(reportDbDetails.FirstOrDefault()?.WorkSpaceId).ConfigureAwait(false);
                    List<object> dashboardList = new List<object>();
                    foreach (var dashboard in dataResponseListDashboard.Value.OrderBy(x => x.DisplayName))
                    {
                        dashboardList.Add(new
                        {
                            dashboard.DisplayName,
                            dashboard.Id
                        });
                    }

                    ((List<object>)result.Values).AddRange(dashboardList);

                    if (result.Values == null)
                    {
                        result.ErrorMessage = MessageConstants.NoReportInWorkspace;
                        return result;
                    }
                }
            }
            catch (HttpOperationException exc)
            {
                result.ErrorMessage = string.Format(CultureInfo.InvariantCulture, MessageConstants.ErrFormat, exc.Response.StatusCode, (int)exc.Response.StatusCode,
                    exc.Response.Content, exc.Response.Headers[MessageConstants.RequestId].FirstOrDefault());
            }
            catch (Exception exc)
            {
                result.ErrorMessage = exc.ToString();
            }

            return result;
        }

        /// <summary>
        /// Create the object for teh power bi client v2
        /// </summary>
        /// <returns></returns>
        private async Task<IPowerBIClient> GetPbiClient(string token = null)
        {
            if (token != null)
            {
                var tokenCred = new TokenCredentials(token, "Bearer");
                return new PowerBIClient(PowerBIConfig.PowerBIApiUrl, tokenCred);
            }

            var tokenCredentials = await CacheUtility.GetOrSet(CacheConstants.PbiClientCache, 60, GetCachePbiClient).ConfigureAwait(false);
            if (tokenCredentials != null)
            {
                return new PowerBIClient(PowerBIConfig.PowerBIApiUrl, tokenCredentials);
            }

            return new PowerBIClient(PowerBIConfig.PowerBIApiUrl, await GetCachePbiClient().ConfigureAwait(false));
        }

        private async Task<TokenCredentials> GetCachePbiClient()
        {
            return new TokenCredentials(await TokenUtility.GetAccessTokenAsync(PowerBIConfig.PowerBIApiResource, true).ConfigureAwait(false), "Bearer");
        }

        public string ReportLastRefreshDateTime(int reportType)
        {
            return _powerBiRepository.ReportLastRefreshDateTime(reportType);
        }
    }
}
