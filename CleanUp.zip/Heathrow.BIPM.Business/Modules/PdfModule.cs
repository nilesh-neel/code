﻿/****************************************************************************************************************
Class Name   : PdfModule.cs 
Purpose      : Provides GET for Pdf Entity
Created By   : Vivekanandan
Created Date : 04/Dec/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh               FDS Change                                  09/01/2019         update for reference errror in solution
****************************************************************************************************************/

using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.Business.Modules
{

    public class PdfModule : IPdfModule
    {
        private readonly IPdf _pdfInstance;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pdfInstance"></param>
        public PdfModule(IPdf pdfInstance)
        {
            _pdfInstance = pdfInstance;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="menuId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<PdfMappings>> Getpdfmenu(int menuId)
        {
            return await _pdfInstance.GetPdfMenu(menuId).ConfigureAwait(false);
        }

    }
}
