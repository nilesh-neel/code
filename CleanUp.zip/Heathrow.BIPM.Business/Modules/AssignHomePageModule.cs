﻿/****************************************************************************************************************
Class Name   : AssignHomePageModule.cs 
Purpose      : 
Created By   : Vignesh
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetching the user groups by logged-in EmailId  | 05/Dec/2018       | Logic changed
Vignesh (686552)   | Fetch Dashboard list in groups                 | 10/Dec/2018       | Logic changed
Vignesh (686552)   | code cleanup and updated                       | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                 | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.Business.Modules
{
    public class AssignHomePageModule : IAssignHomePageModule
    {
        private readonly IAssignHomePage _assignHomePageRepository;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="assignHomepage"></param>
        public AssignHomePageModule(IAssignHomePage assignHomepage)
        {
            _assignHomePageRepository = assignHomepage;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<IList<AssignHomePage>> GetUserGroups(string userEmailId)
        {
            return await _assignHomePageRepository.GetUserGroups(userEmailId).ConfigureAwait(false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userGroupId"></param>
        /// <returns></returns>
        public async Task<IList<AssignHomePage>> GetGroupRecipients(int userGroupId)
        {
            if (userGroupId > 0)
            {
                return await _assignHomePageRepository.GetGroupRecipients(userGroupId).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="homepages"></param>
        /// <returns></returns>

        public async Task<string> SaveHomepage(AssignHomePage homepages, string updatedUserEmailId)
        {
            if (homepages != null && homepages.UsersHomePage.Count > 0)
            {
                string homepage = string.Empty;
                for (int i = 0; i < homepages.UsersHomePage.Count; i++)
                {
                    homepage += "<UserHomePage> <PageName>" + homepages.UsersHomePage[i].PageName.ToString() + "</PageName> <UserId>" + homepages.UsersHomePage[i].UserId.ToString() + "</UserId> <GroupId>" + homepages.UsersHomePage[i].GroupId.ToString() + "</GroupId> <ReportId>" + homepages.UsersHomePage[i].ReportId.ToString() + "</ReportId> <UpdatedBy>" + updatedUserEmailId + "</UpdatedBy> </UserHomePage>";
                }
                string usersHomepage = "<AssignHomePage>" + homepage + "</AssignHomePage>";
                return await _assignHomePageRepository.SaveHomepage(usersHomepage).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }

        public async Task<PowerBiReportDetails> GetUserDashboard(string userId)
        {
            if (string.IsNullOrEmpty(userId))
            {
                return null;
            }
            return await _assignHomePageRepository.FetchUserHomepage(userId).ConfigureAwait(false);
        }


    }
}
