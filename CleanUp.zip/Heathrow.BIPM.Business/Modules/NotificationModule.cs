﻿/*************************************************************************************************************************************
Class Name   : NotificationModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer,to retrieve the records
Created By   : Vaishnavi.R 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Vaishanvi.R(687417)| FDS Requirement                           |01/08/2019         | Included new method for marquee text
**********************************************************************************************************************************************/


using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.Business.Modules
{
    public class NotificationModule : INotificationModule
    {

        private readonly INotification NotificationRepository;
     
        /// <summary>
        /// Constructor implementation 
        /// </summary>
        /// <param name="notification"></param>
        public NotificationModule(INotification notification)
        {
            NotificationRepository = notification;
           
        }

        /// <summary>
        /// To get Notification of given Notification id
        /// </summary>
        /// <param name="notificationId"></param>
        /// <returns>notification</returns>
        public async Task<Notification> GetNotificationById(string userId,int notificationId)
        {
            if (userId!=null && notificationId!=0)
            {
                return await NotificationRepository.GetNotificationByNotificationId(userId, notificationId).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// To get all notifications based on user id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Notification list</returns>
        public async Task<IEnumerable<Notification>> GetUsersNotification(string userId)
        {
            if (userId != null)
            {
                return await NotificationRepository.GetUserNotification(userId).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// To save or update a notification
        /// </summary>
        /// <param name="notification"></param>
        /// <returns></returns>
        public async Task<string> InsertUpdate(Notification notification)
        {
                return await NotificationRepository.InsertUpdate(notification).ConfigureAwait(false);

        }

        /// <summary>
        /// To get all scrolling 
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Notification list</returns>
        public async Task<IEnumerable<Notification>> GetScrollingNotification(string userId)
        {
            if (userId != null)
            {
                return await NotificationRepository.GetScrollingNotification(userId).ConfigureAwait(false);
            }
            else
            {
                return null;
            }

        }
    }
}
