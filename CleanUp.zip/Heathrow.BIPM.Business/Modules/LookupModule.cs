﻿/****************************************************************************************************************
Class Name   : LookUpModule.cs 
Purpose      : This module is used to get the dropdown values from DataAccess
Created By   : Vaishnavi.R
Created Date : 11/Sep/2018
Version      : 1.0
History      : 
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh               FDS Change                                  13/01/2019         Supress rename warning
Vignesh (686552)   | CCAP issue                                |02/07/2019         | CCAP issue fix
****************************************************************************************************************/
using System.Collections.Generic;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.Business.Modules
{
    public class LookupModule : ILookupModule
    {
        private readonly ILookup _lookup;

        /// <summary>
        /// Constructor implementation
        /// </summary>
        /// <param name="lookup"></param>
        public LookupModule(ILookup lookup)
        {

            _lookup = lookup;
        }

        /// <summary>
        /// To get list of Measures
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> BagMeasureList => _lookup.AllMeasure();

        /// <summary>
        /// To get values for Topics
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> BagTopicList => _lookup.AllTopic();

        /// <summary>
        /// To get list of Locations
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> BagLocationList => _lookup.AllLocation();

        /// <summary>
        /// To get list of Threshold
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> BagThresholdList => _lookup.AllThreshold();

        /// <summary>
        /// To get list of Frequencies
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> BagFrequencyList => _lookup.AllFrequency();

        /// <summary>
        /// To get list of TimeWindow
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> BagTimeWindowList => _lookup.AllTimeWindow();
        /// <summary>
        /// To get list of Organisation
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> BagOrganisationList => _lookup.AllOrganisation();

        /// <summary>
        /// To get list of Locations
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> BagOperationalAreaList => _lookup.AllOperationalArea();
    }
}
