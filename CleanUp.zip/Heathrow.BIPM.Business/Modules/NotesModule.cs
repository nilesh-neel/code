﻿/****************************************************************************************************************
Class Name   : NotesModule.cs 
Purpose      : This class implements the Business Logic of the Notes Module.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Getting the logged-in userId globally from SignedInUserId  | 10/Dec/2018       | Logic changed
Vignesh (686552)   | Notes Entitiy param updated for Post method                | 10/Dec/2018       | Logic changed
Vignesh (686552)   | code cleanup and updated                                   | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                             | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.Business.Modules
{
    public class NotesModule : INotesModule
    {
        private readonly INotes _notes;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="notes"></param>
        public NotesModule(INotes notes)
        {
            _notes = notes;
        }

        /// <summary>
        /// To delete the respective note
        /// </summary>
        /// <param name="notesId">NotesId value as input parameter</param>
        /// <param name="bagTag">Bagtag value as input parameter</param>
        /// <param name="flightNumber">Flight number value as input parameter</param>
        /// <param name="organizationId">organisation value as input parameter</param>
        /// <param name="userId">Logged-in UserId value as input parameter</param>
        /// <returns>Notes as List</returns>
        public async Task<IList<NotesEntity>> DeleteNotes(int notesId, string notesValue, string notesType, string userId)
        {
            return await _notes.DeleteNotes(notesId, notesValue, notesType, userId).ConfigureAwait(false);
        }

        /// <summary>
        /// To Fetch the existing notes
        /// </summary>
        /// <param name="bagTag">Bagtag value as input parameter</param>
        /// <param name="flightNumber">Flight number value as input parameter</param>
        /// <param name="organizationId">organisation value as input parameter</param>
        /// <param name="userId">Logged-in UserId value as input parameter</param>
        /// <returns>Notes as List</returns>
        public async Task<IList<NotesEntity>> Fetch(string notesValue, string notesType, string notesUblValue, string userId)
        {
            return await _notes.FetchNotes(notesValue, notesType, notesUblValue, userId).ConfigureAwait(false);
        }

        /// <summary>
        /// To save the newly created note
        /// </summary>
        /// <param name="notes">Notes Entity as input parameter</param>
        /// <returns></returns>
        public async Task<IList<NotesEntity>> Save(NotesEntity notes)
        {
            return await _notes.SaveNotes(notes).ConfigureAwait(false);
        }

    }
}
