﻿/****************************************************************************************************************
Class Name   : SearchModule.cs 
Purpose      : This class implements the Business Logic of the Search Module.
Created By   : Kannan 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Kannan              FDS Change                                   05/02/2019        Administration level handling
Kannan              FDS Change                                   15/02/2019        CodeShare Flight included
****************************************************************************************************************/

using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.Utility.Constants;

namespace Heathrow.BIPM.Business.Modules
{
    /// <summary>
    ///  Search Module business
    /// </summary>
    public class SearchModule : ISearchModule
    {

        private readonly ISearch _searchInstance;
        private readonly IBpmPowerBi _bpmPowerBi;

        /// <summary>
        /// Search Module constructor
        /// </summary>
        /// <param name="searchObj"></param>
        /// <param name="bpmPowerBi"></param>
        /// <param name="authProvider"></param>
        public SearchModule(ISearch searchObj, IBpmPowerBi bpmPowerBI)
        {
            _searchInstance = searchObj;
            _bpmPowerBi = bpmPowerBI;
        }

        /// <summary>
        /// Return the report configuration  data 
        /// </summary>
        /// <param name="searchQuery"></param>
        /// <param name="searchPrefix"></param>
        /// <returns></returns>
        public async Task<ReportConfiguration> SearchData(string searchQuery, string searchPrefix)
        {
            var objRepConfig = await _searchInstance.SearchData(searchQuery, searchPrefix).ConfigureAwait(false);
            int reportId = objRepConfig.MenuId;
            var powerBiReport = await _bpmPowerBi.EmbedReportV2(reportId, AppSettingsConstants.ReportType).ConfigureAwait(false);
            var pbiReport = powerBiReport.FirstOrDefault();
            objRepConfig.EmbedToken = pbiReport.EmbedToken;
            objRepConfig.PowerBIType = pbiReport.PowerBIType;
            objRepConfig.EmbedUrl = pbiReport.EmbedUrl;
            objRepConfig.Id = pbiReport.Id;
            objRepConfig.ReportSection = pbiReport.ReportSection;
            return objRepConfig;
        }


    }
}
