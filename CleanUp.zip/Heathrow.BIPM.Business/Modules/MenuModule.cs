﻿/****************************************************************************************************************
Class Name   : MenuModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh               FDS Change                                  31/01/2019         Security code update
Nilesh               FDS Change                                  14/01/2019         Exception handling and exception logging
****************************************************************************************************************/


using System.Collections.Generic;
using System.Linq;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Utility.Constants;
using Heathrow.BIPM.Utility.Common;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.Business.Modules
{
    public class MenuModule : IMenuModule
    {
        private readonly IMenu _menuRepository;
        /// <summary>
        /// Constructor of Menu Module use to inject the depedency of IMenu
        /// </summary>
        /// <param name="menu"></param>
        /// <param name="cache"></param>
        public MenuModule(IMenu menu)
        {
            _menuRepository = menu;

        }

        /// <summary>
        /// Used to store menu list in memory cache
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Menu> GetAllMenu()
        {
            var result = CacheUtility.GetOrSet(CacheConstants.MenuList, 30, GetMenus);
            return result != null ? result.Where(s => s.IsVisible == true) : null;
        }

        /// <summary>
        /// Use to Reture the Menu list from database.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Menu> GetMenus()
        {
            return _menuRepository.GetAllMenu();
        }

        /// <summary>
        /// Use to get the all type of reports from database and store in user specific report in session.
        /// </summary>
        /// <param name="strUserId">Login user user id</param>
        /// <returns></returns>
        public IList<PowerBiReportDetails> GetUserReports(string strUserId)
        {
            return _menuRepository.GetReportDetails(strUserId);
        }
    }
}
