﻿/****************************************************************************************************************
Class Name   : AlertsModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Vaishnavi.R 
Created Date : 11/Sep/2018
Version      : 1.0
History      :             
Modified By          | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Vaishnavi.R(687417)  | FDS requirement                           |03/20/2019         | Included 'GetAlertCount' method
Anupama Kumari(694315)| FDS requirement                           |02/14/2019         | Included 'GetTopicForMeasure' method 
Vignesh(686552)      | CCAP Issue                                |02/04/2019         | CCAP issue fixed
Vaishnavi.R (687417) | Coding convention                         |01/09/2019         | Null check
Vaishnavi.R (687417) | FDS requirement                           |01/07/2019         | Included method 'GetAlertNotification'
****************************************************************************************************************/


using System.Collections.Generic;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Modules
{
    public class AlertsModule : IAlertsModule
    {
        private readonly IAlerts _alertsRepository;

        /// <summary>
        /// Constructor implementation
        /// </summary>
        /// <param name="alerts"></param>
        public AlertsModule(IAlerts alerts)
        {
            _alertsRepository = alerts;
        }

        /// <summary>
        ///  To get Alert of given Notification id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>alert</returns>
        public async Task<MyAlertSettings> GetAlertsById(string userId, int alertId)
        {
            if (userId != null && alertId > 0)
            {
                return await _alertsRepository.GetAlertsById(userId, alertId).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// To get all alerts based on user id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Alert list</returns>
        public async Task<IEnumerable<MyAlertSettings>> GetAlerts(string id)
        {
            if (id != null)
            {
                return await _alertsRepository.GetMyAlertSettings(id).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// To save or update a notification
        /// </summary>
        /// <param name="alerts"></param>
        /// <returns></returns>
        public async Task<string> InsertUpdate(Alerts alerts)
        {
                return await _alertsRepository.InsertUpdate(alerts).ConfigureAwait(false);
            
        }

        /// <summary>
        /// To retrieve triggered alerts
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<TodaysAlert>> GetAlertNotification(string userId)
        {
            if (userId != null)
            {
                return await _alertsRepository.GetAlertNotification(userId).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// To retrieve triggered alerts count
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<int> GetAlertCount(string userId)
        {
            if (userId != null)
            {
                return await _alertsRepository.GetAlertCount(userId).ConfigureAwait(false);
            }
            else
            {
                return 0;
            }
        }
        /// <summary>
        /// To retrieve todays alert
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<TodaysAlert>> GetTodaysAlert(string userId)
        {
            if (userId != null)
            {
                return await _alertsRepository.GetTodaysAlert(userId).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// To retrieve configured alert
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<ConfigureAlerts>> GetConfiguredAlert(string userId)
        {
            if (userId != null)
            {
                return await _alertsRepository.GetConfiguredAlert(userId).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        ///  To get configured Alert of given alert id
        /// </summary>
        /// <param name="id"></param>
        /// <returns>alert</returns>
        public async Task<Alerts> GetConfiguredAlertById(string userId, int alertId)
        {
            if (userId != null && alertId > 0)
            {
                return  await _alertsRepository.GetConfiguredAlertById(userId, alertId).ConfigureAwait(false);
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        ///  To get topic if measure is selected or vice versa
        /// </summary>
        /// <param name="selectedId"></param>
        /// <returns>Topic or Measure corresponding to selected id</returns>
        public async Task<Alerts> GetTopicForMeasure(string selectedId)
        {
            if (selectedId != null)
            {
                return await _alertsRepository.GetTopicForMeasure(selectedId).ConfigureAwait(false);
            }
            else {
                return null;
            }
        }
    }
}
