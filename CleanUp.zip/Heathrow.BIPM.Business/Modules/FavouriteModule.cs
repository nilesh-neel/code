﻿/****************************************************************************************************************
Class Name   : FavouritesModule.cs 
Purpose      : 
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh                  FDS Change                                 05/02/2019         Administration level handling
****************************************************************************************************************/

using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.Business.Modules
{
    public class FavouriteModule : IFavouriteModule
    {
        private readonly IFavourites _favouriteRepo;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fav"></param>
        public FavouriteModule(IFavourites fav)
        {
            _favouriteRepo = fav;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="fav"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Favourites>> Save(Favourites fav)
        {

            List<Favourites> favMenuList = null;

            var result = await _favouriteRepo.Save(fav).ConfigureAwait(false);
            if (result == 0)
            {
                favMenuList = await _favouriteRepo.GetUserFavourites(fav.UserId).ConfigureAwait(false);

            }

            return favMenuList;

        }

        /// <summary>
        /// get favourites for the user id
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Favourites>> GetUserFavourites(string userId)
        {
            List<Favourites> result = await _favouriteRepo.GetUserFavourites(userId).ConfigureAwait(false);
            result.ForEach(c => c.FavouriteLink.ParentId = 1);
            return result;
        }
    }
}
