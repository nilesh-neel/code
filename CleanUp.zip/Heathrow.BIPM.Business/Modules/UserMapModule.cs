﻿/****************************************************************************************************************
Class Name   : UserMapModule.cs 
Purpose      : This class implements the Business Logic of the user Module.
Created By   : Anupama Kumari
Created Date : 10/March/2019
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Anupama             FDS Change                                    20/03/2019       Getting the user details already in database
****************************************************************************************************************/

using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Modules
{
    public class UserMapModule : IUserMapModule
    {
        private readonly IUser _userRepository;

        /// <summary>
        /// Constructor implementation
        /// </summary>
        /// <param name="alerts"></param>
        public UserMapModule(IUser users)
        {
            _userRepository = users;
        }
        public Task<int> UpdateOperationalAreaAndLocation(User userData) => _userRepository.UpdateOperationalAreaAndLocation(userData);

        public async Task<IList<User>> Fetch(string userId)
        {
            return await _userRepository.Fetch(userId).ConfigureAwait(false);
        }

    }
}
