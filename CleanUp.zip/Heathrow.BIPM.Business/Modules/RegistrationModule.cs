﻿/****************************************************************************************************************
Class Name   : RegistrationModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, to save user registration request
Created By   : Vaishnavi.R
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh               FDS Change                                  31/01/2019         Security code update
Nilesh               FDS Change                                  06/02/2019         Rename
****************************************************************************************************************/

using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using System.Threading.Tasks;
using Heathrow.BIPM.Utility.Constants;
using System;

namespace Heathrow.BIPM.Business.Modules
{
    public class RegistrationModule : IRegistrationModule
    {

        private readonly IRegistration Registration;
        /// <summary>
        /// Constructor Implementation
        /// </summary>
        /// <param name="registration"></param>
        public RegistrationModule(IRegistration registration)
        {
            Registration = registration;
         
        }

        /// <summary>
        /// To save a registration request
        /// </summary>
        /// <param name="registration"></param>
        /// <returns></returns>
        public async Task<string> Save(Registration registration)
        {
            try
            {
                if (registration != null)
                {
                    return await Registration.Save(registration).ConfigureAwait(false);
                }
                else
                {

                    return MessageConstants.SuperAdmin;
                }
            }
            catch(Exception)
            {
                throw;
            }
        }

    }
}
