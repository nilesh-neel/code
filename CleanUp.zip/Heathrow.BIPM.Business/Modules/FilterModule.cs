﻿/****************************************************************************************************************
Class Name   : Filter Module.cs 
Purpose      : Save & retrieve filter data
Created By   : Kannan 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Kannan              FDS Change                                   05/02/2019        Administration level handling
Kannan              FDS Change                                   15/02/2019        Passing user Id to business level
Kannan              FDS Change                                   10/01/2019        Change in dropdown values
Anupama             FDS Change                                   01/03/2019        Change in Filter Mapping
****************************************************************************************************************/
using System.Threading.Tasks;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.Business.Modules
{

    /// <summary>
    ///  Baggage filter business 
    /// </summary>
    public class FilterModule : IFilterModule
    {
        private readonly IFilter _filterRepository;
        /// <summary>
        /// Filter module constructor
        /// </summary>
        /// <param name="filterData"></param>
        public FilterModule(IFilter filterData)
        {
            _filterRepository = filterData;
        }

        /// <summary>
        /// Create Filter business 
        /// </summary>
        /// <param name="filterEntity"></param>
        /// <returns></returns>
        public Task<int> SaveFilter(FilterEntity filterData) => _filterRepository.SaveFilter(filterData);

        /// <summary>
        /// Get Filter data based on the menu Id 
        /// </summary>
        /// <param name="menuId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<FilterEntity> FilterByMenuId(int menuId, string userId) => await _filterRepository.FilterByMenuId(menuId, userId).ConfigureAwait(false);

        /// <summary>
        /// Get filter control data 
        /// </summary>
        /// <returns></returns>
        public async Task<FilterControlEntity> FilterConfiguration() => await _filterRepository.FilterConfiguration().ConfigureAwait(false);
    }
}
