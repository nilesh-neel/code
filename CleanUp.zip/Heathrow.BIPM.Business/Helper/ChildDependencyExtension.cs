﻿/****************************************************************************************************************
Class Name   : ChildDependencyExtension.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.DataAccess;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using System.Data.Entity;
using Unity;
using Unity.Extension;
using Unity.Injection;
using Unity.Lifetime;

namespace Heathrow.BIPM.Business.Helper
{
    public class ChildDependencyExtension : UnityContainerExtension
    {
        //Here register the repository with its abstractions for the dependency injection. 
        protected override void Initialize()
        {
            #region "Business  DI"
            Container.RegisterType<IAlertsModule, AlertsModule>();
            Container.RegisterType<IAssignHomePageModule, AssignHomePageModule>();
            Container.RegisterType<IBagListModule, BagListModule>();
            Container.RegisterType<IFavouriteModule, FavouriteModule>();
            Container.RegisterType<IFilterModule, FilterModule>();
            Container.RegisterType<IMenuModule, MenuModule>();
            Container.RegisterType<INotesModule, NotesModule>();
            Container.RegisterType<INotificationModule, NotificationModule>();
            Container.RegisterType<IBpmPowerBi, PowerBIModule>();
            //Container.RegisterType<IRegistrationModule, RegistrationModule>();
            Container.RegisterType<ISearchModule, SearchModule>();
            Container.RegisterType<IShareModule, ShareModule>();
            Container.RegisterType<ILookupModule, LookupModule>();
            Container.RegisterType<IPdfModule, PdfModule>();
            Container.RegisterType<IUserMapModule, UserMapModule>();

            #endregion

            #region "Repository DI"
            Container.RegisterType<IAlerts, AlertsRepository>();
            Container.RegisterType<INotification, NotificationRepository>();
            //Container.RegisterType<IRegistration, RegistrationRepository>();
            Container.RegisterType<IMenu, MenuRepository>();
            Container.RegisterType<ILookup, LookupRepository>();
            Container.RegisterType<IUser, UserRepository>();
            Container.RegisterType<IFavourites, FavouritesRepository>();
            Container.RegisterType<IFilter, FilterRepository>();
            Container.RegisterType<INotes, NotesRepository>();
            Container.RegisterType<IShare, ShareRepository>();
            Container.RegisterType<IBagList, BagListRepository>();
            Container.RegisterType<ISearch, SearchRepository>();
            Container.RegisterType<IPdf, PdfRepository>();
            Container.RegisterType<IAssignHomePage, AssignHomePageRepository>();
            Container.RegisterType<IPowerBi, PowerBiRepository>();
            Container.RegisterType(typeof(IRepository<>), typeof(GenericRepository<>));
            Container.RegisterType<DbContext, BaggageDbContext>(new PerResolveLifetimeManager(), new InjectionConstructor());
            #endregion



        }
    }
}
