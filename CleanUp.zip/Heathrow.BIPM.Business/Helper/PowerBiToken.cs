﻿/****************************************************************************************************************
Class Name   : PowerBIToken.cs 
Purpose      : This class use to generate power BI token
Created By   : Nilesh More 
Created Date : 11/Dec/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using Microsoft.PowerBI.Api.V2.Models;
using System;

namespace Heathrow.BIPM.Kestrel.Business.Helper
{
    public class PowerBiToken
    {
        public EmbedToken EmbedToken { get; set; }

        public int MinutesToExpiration
        {
            get
            {
                var minutesToExpiration = EmbedToken.Expiration.Value - DateTime.UtcNow;
                return minutesToExpiration.Minutes;
            }
        }
    }
}
