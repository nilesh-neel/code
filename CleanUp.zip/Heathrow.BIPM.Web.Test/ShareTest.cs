﻿//----------------------------------------------------------------------
//Class Name   : ShareTest.cs 
//Purpose      : This is the unit case implementation file for Share module. 
//Created By   : Vignesh AshokKumar
//Created Date : 21/Dec/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Results;

namespace Heathrow.BIPM.Test
{
    /// <summary>
    /// 
    /// </summary>
    [TestClass]
    public class ShareTest
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Get the Audience Group")]
        public async Task Get_ShouldReturnAudienceGroup()
        {
            Mock<IShareModule> shareBusinessLayer = new Mock<IShareModule>();

            var userModule = new Mock<IUserModule>();

            userModule.Setup(m => m.GetUser("Admin"))
                .Returns(Task.FromResult(new AzureAdUser { Id = "user2", Name = "TestUser" }));

            shareBusinessLayer.Setup(x => x.GetAudienceGroup("xyz@abc.com"))
                .Returns(GroupList());

            var controller = new ShareController(shareBusinessLayer.Object);
            var testshare = TestShareCollection();
            IHttpActionResult actionResult =await controller.Get();
            //Assert.AreEqual(((OkNegotiatedContentResult<IList<Share>>)actionResult).Content[0].GroupId, testshare[0].GroupId);
            Assert.IsNotNull(testshare[0].GroupId);
            Assert.IsNotNull(testshare[0].GroupName);
            Assert.IsNotNull(testshare[0].RecipientId);
            Assert.IsNotNull(testshare[0].RecipientName);
        }

        [TestMethod]
        [Description("Get the Audience Group")]
        public async Task Get_ShouldNotReturnAudienceGroup()
        {
            Mock<IShareModule> shareBusinessLayer = new Mock<IShareModule>();

            var userModule = new Mock<IUserModule>();

            userModule.Setup(m => m.GetUser("Admin"))
                .Returns(Task.FromResult(new AzureAdUser { Id = "user2", Name = "TestUser" }));

            shareBusinessLayer.Setup(x => x.GetAudienceGroup("xyz@abc.com"))
                .Returns(GroupList());

            var controller = new ShareController(shareBusinessLayer.Object);
            var testshare = TestShareCollection();
            IHttpActionResult actionResult =  await controller.Get();
            Assert.AreNotEqual(((OkNegotiatedContentResult<IList<Share>>)actionResult).Content, testshare);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static Task<IList<Share>> GroupList()
        {
            IList<Share> groupList = new List<Share>
            {
                new Share
                {
                    GroupId = 10,
                    GroupName = "Group1"
                }
            };
            return Task.FromResult(groupList);
        }

        /// <summary>
        /// Group Recipients
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Get the Recipients List based on AudienceGroup Id")]
        public async Task GroupRecipients_ShouldReturnAudienceGroup()
        {
            Mock<IShareModule> shareBusinessLayer = new Mock<IShareModule>();

            var userModule = new Mock<IUserModule>();

            userModule.Setup(m => m.GetUser("Admin"))
                .Returns(Task.FromResult(new AzureAdUser { Id = "user1", Name = "testUser" }));

            shareBusinessLayer.Setup(x => x.GetGroupRecipients(10))
                 .Returns(Task.FromResult(TestShareCollection()));

            var controller = new ShareController(shareBusinessLayer.Object);
            var testShare = TestShareCollection();
            IHttpActionResult actionResult =await controller.Get(10);
            Assert.AreEqual(((OkNegotiatedContentResult<IList<Share>>)actionResult).Content.Count, testShare.Count);
        }


        /// <summary>
        /// Group Recipients
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Get the Recipients List based on AudienceGroup Id")]
        public async Task GroupRecipients_ShouldNotReturnAudienceGroup()
        {
            Mock<IShareModule> shareBusinessLayer = new Mock<IShareModule>();

            var userModule = new Mock<IUserModule>();

            userModule.Setup(m => m.GetUser("Admin"))
                .Returns(Task.FromResult(new AzureAdUser { Id = "user1", Name = "testUser" }));

            shareBusinessLayer.Setup(x => x.GetGroupRecipients(999))
                .Returns(Task.FromResult(TestShareCollection()));

            var controller = new ShareController(shareBusinessLayer.Object);
            var testShare = TestShareCollection();
            IHttpActionResult actionResult =await controller.Get(999);
            Assert.AreNotEqual(((OkNegotiatedContentResult<IList<Share>>)actionResult).Content, testShare);
        }


        /// <summary>
        /// Test Share Collection
        /// </summary>
        /// <returns></returns>
        private static IList<Share> TestShareCollection() =>
            new List<Share>
            {
                new Share
                {
                    GroupId = 10,
                    GroupName = "Group1",
                    RecipientId = "recipient@heathrow.com",
                    RecipientName = "Recipient1",
                }
            };
    }
}
