﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Results;
using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class AssignHomePageTest
    {
        [TestMethod]
        public async Task GetUserGrps_ShouldReturnGroupValues()
        {
            var assignBusinessLayer = new Mock<IAssignHomePageModule>();

            var bpmPowerBI = new Mock<IBpmPowerBi>();
            assignBusinessLayer.Setup(x => x.GetUserGroups("xyz@abc.com")).Returns(GetTestAssignList());

            var testAssign = GetTestAssign();
            var controller = new AssignHomePageController(assignBusinessLayer.Object, bpmPowerBI.Object);
            IHttpActionResult actionResult = await controller.Get("xyz@abc.com", "1");
            //Assert.AreNotEqual(((OkNegotiatedContentResult<IList<AssignHomePage>>)actionResult).Content.Count, testAssign.Count);
        }

        [TestMethod]
        public async Task GetUserGrps_ShouldNotReturnGroupValues()
        {
            var assignBusinessLayer = new Mock<IAssignHomePageModule>();

            var bpmPowerBI = new Mock<IBpmPowerBi>();

            assignBusinessLayer.Setup(x => x.GetUserGroups("xyz@abc.com"))
            .Returns(GetTestAssignList());

            var testAssign = GetTestAssign();
            var controller = new AssignHomePageController(assignBusinessLayer.Object, bpmPowerBI.Object);
            IHttpActionResult actionResult = await controller.Get("xyz@abc.com", "1");
            Assert.AreNotEqual(((OkNegotiatedContentResult<IList<AssignHomePage>>)actionResult).Content, testAssign);
        }

        [TestMethod]
        public async Task GetGrpRecipients_ShouldReturnRecipientValues()
        {
            var assignBusinessLayer = new Mock<IAssignHomePageModule>();
            var bpmPowerBI = new Mock<IBpmPowerBi>();

            assignBusinessLayer.Setup(x => x.GetGroupRecipients(19))
            .Returns(GetTestAssignList());

            var testAssign = GetTestAssign();
            var controller = new AssignHomePageController(assignBusinessLayer.Object, bpmPowerBI.Object);
            IHttpActionResult actionResult = await controller.Get(19);
            Assert.AreEqual(((OkNegotiatedContentResult<IList<AssignHomePage>>)actionResult).Content.Count, testAssign.Count);

        }

        [TestMethod]
        public async Task GetGrpRecipients_ShouldNotReturnRecipientValues()
        {
            var assignBusinessLayer = new Mock<IAssignHomePageModule>();

            var bpmPowerBI = new Mock<IBpmPowerBi>();

            assignBusinessLayer.Setup(x => x.GetGroupRecipients(19)).Returns(GetTestAssignList());

            var testAssign = GetTestAssign();
            var controller = new AssignHomePageController(assignBusinessLayer.Object, bpmPowerBI.Object);
            IHttpActionResult actionResult = await controller.Get(19);
            Assert.AreNotEqual(((OkNegotiatedContentResult<IList<AssignHomePage>>)actionResult).Content, testAssign);
        }

        [TestMethod]
        public async Task SaveHomepage_ShouldReturnSaveHomePage()
        {
            var assignBusinessLayer = new Mock<IAssignHomePageModule>();
            var bpmPowerBI = new Mock<IBpmPowerBi>();
            string testAssign = "HomePage";

            List<UserHomePage> homeList = new List<UserHomePage>();
            homeList.Add(
            new UserHomePage
            {
                GroupId = "1",
                PageName = "HomePage1",
                ReportId = "1b29b902-273c-43e8-a92b-eda66b2043c5",
                UserId = "9"
            }
            );

            var data = new AssignHomePage
            {
                UsersHomePage = homeList
            };


            //return homeList;

            assignBusinessLayer.Setup(x => x.SaveHomepage(data, "xyz@abc.com")).Returns(GetSuccess());
            var controller = new AssignHomePageController(assignBusinessLayer.Object, bpmPowerBI.Object);
            IHttpActionResult actionResult = await controller.Post(data);
            Assert.IsNotNull(actionResult);
        }


        [TestMethod]
        public async Task SaveHomepage_ShouldNotReturnSaveHomePage()
        {
            var assignBusinessLayer = new Mock<IAssignHomePageModule>();
            var bpmPowerBI = new Mock<IBpmPowerBi>();

            List<UserHomePage> homeList = new List<UserHomePage>();
            homeList.Add(
            new UserHomePage
            {
                GroupId = "1",
                PageName = "HomePage1",
                ReportId = "1b29b902-273c-43e8-a92b-eda66b2043c5",
                UserId = "9"
            }
            );

            var data = new AssignHomePage
            {
                UsersHomePage = homeList
            };

            assignBusinessLayer.Setup(x => x.SaveHomepage(data, "xyz@abc.com")).Returns(GetSuccess());

            var testAssign = "HomePage2";
            var controller = new AssignHomePageController(assignBusinessLayer.Object, bpmPowerBI.Object);
            IHttpActionResult actionResult = await controller.Post(data);
            Assert.AreNotEqual(((OkNegotiatedContentResult<string>)actionResult).Content, testAssign);
        }

        [TestMethod]
        public async Task GetUserGrps_ShouldReturnDashboardValues()
        {
            var assignBusinessLayer = new Mock<IAssignHomePageModule>();

            var bpmPowerBI = new Mock<IBpmPowerBi>();
            bpmPowerBI.Setup(x => x.GetDashboardInGroup()).Returns(GetList());

            var testAssign = GetList();
            var controller = new AssignHomePageController(assignBusinessLayer.Object, bpmPowerBI.Object);
            IHttpActionResult actionResult = await controller.Get();
            Assert.IsNotNull(actionResult);
        }

        [TestMethod]
        public async Task GetUserGrps_ShouldNotReturnDashboardValues()
        {
            var assignBusinessLayer = new Mock<IAssignHomePageModule>();

            var bpmPowerBI = new Mock<IBpmPowerBi>();
            bpmPowerBI.Setup(x => x.GetDashboardInGroup()).Returns(GetList());

            var testAssign = GetList();
            var controller = new AssignHomePageController(assignBusinessLayer.Object, bpmPowerBI.Object);
            IHttpActionResult actionResult = await controller.Get();
            Assert.AreNotEqual(actionResult, testAssign);
        }

        private static Task<PowerBiEmbedConfig> GetList()
        {
            var testList = new PowerBiEmbedConfig()
            {
                EmbedUrl = new Uri("https://abc.com"),
                Id = "1",
            };
            return Task.FromResult(testList);
        }


        private static Task<string> GetSuccess()
        {
            return Task.FromResult("Success");
        }

        private static List<AssignHomePage> GetTestAssign()
        {
            var testAssign = new List<AssignHomePage>
            {
                new AssignHomePage()
                {
                    Description = "Page description",
                    Homepage = "Homepage1",
                    UserEmail = "xyz@abc.com",
                    UserFirstName = "Lawrence",
                    UserGroupId = 19,
                    UserId = 1
                }
            };

            return testAssign;
        }

        private static Task<IList<AssignHomePage>> GetTestAssignList()
        {
            IList<AssignHomePage> testAssign = new List<AssignHomePage>
            {
                new AssignHomePage()
                {
                    Description = "Page description",
                    Homepage = "Homepage1",
                    UserEmail = "xyz@abc.com",
                    UserFirstName = "Lawrence",
                    UserGroupId = 19,
                    UserId = 1
                }
            };

            return Task.FromResult(testAssign);
        }
    }
}
