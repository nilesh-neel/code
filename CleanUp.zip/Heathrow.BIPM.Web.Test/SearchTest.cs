﻿using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http.Results;
using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class SearchTest
    {
        [TestMethod]
        public async Task GetSearchData_ShouldReturnValues()
        {
            var searchBusinessLayer = new Mock<ISearchModule>();
            searchBusinessLayer.Setup(x => x.SearchData("10834948", "B"))
                .Returns(TestSearch());

            var testSearch = TestSearch();
            var controller = new SearchController(searchBusinessLayer.Object);

            var result = await controller.Get("10834948", "B");
            Assert.AreEqual(testSearch.Result.ColumnValue.Count, ((OkNegotiatedContentResult<ReportConfiguration>)result).Content.ColumnValue.Count);
        }

        [TestMethod]
        public async Task GetSearchData_ShouldNotReturnValues()
        {
            var searchBusinessLayer = new Mock<ISearchModule>();
            searchBusinessLayer.Setup(x => x.SearchData("10834948", "F"))
                .Returns(TestSearch());

            var testResult = TestSearch();
            var controller = new SearchController(searchBusinessLayer.Object);

            var response = await controller.Get("", "B");

            Assert.AreNotEqual(testResult.Result, ((OkNegotiatedContentResult<ReportConfiguration>)response).Content);
        }


        private static Task<ReportConfiguration> TestSearch()
        {
            var search = new ReportConfiguration
            {
                ColumnName = "bagItem",
                MenuId = 19,
                Operator = "In",
            };
            search.ColumnValue.AddRange(new List<string> { "0000103439" });
            return Task.FromResult(search);
        }
    }
}
