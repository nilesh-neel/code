﻿//----------------------------------------------------------------------
//Class Name   : NotesTest.cs 
//Purpose      : This is the unit case implementation file for Notes module. 
//Created By   : Vignesh AshokKumar
//Created Date : 21/Dec/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Results;


namespace Heathrow.BIPM.Test
{
    /// <summary>
    /// 
    /// </summary>
    [TestClass]
    public class NotesTest
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Fetching the Notes list and displaying it")]
        public async Task Get_ShouldReturnNotesValues()
        {
            Mock<INotesModule> notesBusinessLayer = new Mock<INotesModule>();

            var userModule = new Mock<IUserModule>();

            userModule.Setup(m => m.GetUser("Admin"))
                .Returns(Task.FromResult(new AzureAdUser() { Id = "user1", Name = "Admin" }));

            notesBusinessLayer.Setup(x => x.Fetch("Bt1", "Fl1", "5673", ""))
                .Returns(NotesList());

            var controller = new NotesController(notesBusinessLayer.Object);
            var testNotes = NotesList();
            IHttpActionResult actionResult = await controller.Get("Bt1", "Fl1", "5673");
            Assert.AreEqual(((OkNegotiatedContentResult<IList<NotesEntity>>)actionResult).Content.Count, testNotes.Result.Count);

        }

        [TestMethod]
        [Description("Fetching the Notes list and displaying it")]
        public async Task Get_ShouldNotReturnNotesValues()
        {
            Mock<INotesModule> notesBusinessLayer = new Mock<INotesModule>();

            var userModule = new Mock<IUserModule>();

            userModule.Setup(m => m.GetUser("Admin"))
                .Returns(Task.FromResult(new AzureAdUser() { Id = "user1", Name = "Admin" }));

            notesBusinessLayer.Setup(x => x.Fetch("Bt111", "Fl1", "5673", ""))
                .Returns(NotesList());

            var controller = new NotesController(notesBusinessLayer.Object);
            var testNotes = TestNotesCollection();
            IHttpActionResult actionResult = await controller.Get("Bt111", "Fl1", "5673");
            Assert.AreNotEqual(((OkNegotiatedContentResult<IList<NotesEntity>>)actionResult).Content, testNotes);

        }


        /// <summary>
        /// Delete NotesData ShouldDeleteNotes
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Deleting the Notes Data")]
        public async Task DeleteNotes_ShouldDeleteNotes()
        {
            Mock<INotesModule> notesBusinessLayer = new Mock<INotesModule>();

            notesBusinessLayer.Setup(x => x.DeleteNotes(15, "Bt1", "F", "use@xy.com"))
            .Returns(NotesList(true));

            var controller = new NotesController(notesBusinessLayer.Object);
            var testNotes = NotesList(true);
            IHttpActionResult actionResult = await controller.Delete(5, "Bt1", "F");
           // Assert.AreEqual(((OkNegotiatedContentResult<IList<NotesEntity>>)actionResult).Content[0].NotesId, testNotes.Result[0].NotesId);

        }


        /// <summary>
        /// Delete NotesData ShouldDeleteNotes
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Deleting the Notes Data")]
        public async Task DeleteNotes_ShouldNotDeleteNotes()
        {
            Mock<INotesModule> notesBusinessLayer = new Mock<INotesModule>();

            notesBusinessLayer.Setup(x => x.DeleteNotes(15, "Bt1", "B", "use@xy.com"))
                .Returns(NotesList(true));

            var controller = new NotesController(notesBusinessLayer.Object);
            var testNotes = NotesList();
            IHttpActionResult actionResult = await controller.Delete(15, "Bt1", "B");
           // Assert.AreNotEqual(((OkNegotiatedContentResult<IList<NotesEntity>>)actionResult).Content[0], testNotes.Result[0]);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Saving the created Notes Data")]
        public async Task SaveNotes_ShouldReturnSameNotes()
        {
            Mock<INotesModule> notesBusinessLayer = new Mock<INotesModule>();

            var data = new NotesEntity
            {
                NotesId = 0,
                NoteDescription = "Notes Description added",
                UblValue = "12345",
                OrganizationId = 1,
                IsPublic = 1,
                CreatedDate = "12/24/2018",
                UserId = "Admin",
            };

            notesBusinessLayer.Setup(x => x.Save(data))
                .Returns(NotesList());

            var controller = new NotesController(notesBusinessLayer.Object);
            var testnotesList = TestNotesCollection();
            IHttpActionResult actionResult = await controller.Post(data);
            Assert.AreEqual(((OkNegotiatedContentResult<IList<NotesEntity>>)actionResult).Content[0].NotesId, testnotesList.Result.NotesId);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [TestMethod]
        [Description("Saving the created Notes Data")]
        public async Task SaveNotes_ShouldNotReturnSameNotes()
        {
            Mock<INotesModule> notesBusinessLayer = new Mock<INotesModule>();


            var data = new NotesEntity();

            notesBusinessLayer.Setup(x => x.Save(data))
                .Returns(NotesList());

            var controller = new NotesController(notesBusinessLayer.Object);
            var testNotesList = TestNotesCollection();
            IHttpActionResult actionResult = await controller.Post(data);
            Assert.AreNotEqual(((OkNegotiatedContentResult<IList<NotesEntity>>)actionResult).Content, testNotesList.Result);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static Task<IList<NotesEntity>> NotesList(bool isDeleted = false)
        {
            IList<NotesEntity> notesList = new List<NotesEntity>
            {
                new NotesEntity
                {
                    NotesId = 5,
                    UblValue = "12345",
                    NoteDescription = "Flight is delayed",
                    OrganizationId=1,
                    IsPublic=1,
                    CreatedDate= "12/24/2018",
                   // IsDeleted=(isDeleted)? 1 : 0,
                    UserId="Admin",
                    UserFirstName="nilesh",


                }
            };
            return Task.FromResult(notesList);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static Task<NotesEntity> TestNotesCollection()
        {
            return Task.FromResult(new NotesEntity
            {
                NotesId = 5,
                NoteDescription = "Mock Desc",
                OrganizationId = 1,
                UblValue = "12345",
                IsPublic = 1,
                UserId = "Admin",
            });
        }
    }
}
