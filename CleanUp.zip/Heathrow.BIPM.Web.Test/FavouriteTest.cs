﻿using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http.Results;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class FavouriteTest
    {
        [TestMethod]
        public async Task GetUserFavourites_ShouldReturnValues()
        {
            var favouriteBusinessLayer = new Mock<IFavouriteModule>();
            favouriteBusinessLayer.Setup(x => x.GetUserFavourites("1"))
                .Returns(Task.FromResult(GetTestFavourites().AsEnumerable()));
            var testFavourites = GetTestFavourites();
            var controller = new FavoritesController(favouriteBusinessLayer.Object);

            var result = await controller.Get();
            Assert.IsNotNull(result);
            Assert.IsNotNull(testFavourites[0].FavouriteId);
        }

        [TestMethod]
        public async Task GetUserFavourites_ShouldNotReturnValues()
        {
            var favouriteBusinessLayer = new Mock<IFavouriteModule>();
            favouriteBusinessLayer.Setup(x => x.GetUserFavourites("1"))
                .Returns(Task.FromResult((new List<Favourites>()
                { new Favourites()
                    {
                        FavouriteId=1,
                        FavouriteLink= new Menu()
                        {
                            MenuId = 1,
                            BusinessReportId = "1",
                            Description = "desc",
                            FavouritesDescription = "desc",
                            CssIcon = "1",
                            IsReport = false,
                            OperationalReportId = "2",
                            OrderId = 1,
                            Organization = "org",
                            ParentId = 1,
                            Tooltip = "test"
                        },
                        UserId = "1"
                     }
                }).AsEnumerable()));

            var testFavourites = GetTestFavourites();
            var controller = new FavoritesController(favouriteBusinessLayer.Object);

            var result = await controller.Get();
            Assert.AreNotEqual(((OkNegotiatedContentResult<IEnumerable<Favourites>>)result).Content, testFavourites);
        }

        [TestMethod]
        public async Task Post_ShouldReturnSameFavourite()
        {
            var favouriteBusinessLayer = new Mock<IFavouriteModule>();
            favouriteBusinessLayer.Setup(x => x.Save(
              GetTestFavourites()[0]
                ));
            var data = GetTestFavourites()[0];
            var controller = new FavoritesController(favouriteBusinessLayer.Object);

            var result = await controller.Post(data);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task Post_ShouldNotReturnSameFavourite()
        {
            var favouriteBusinessLayer = new Mock<IFavouriteModule>();
            favouriteBusinessLayer.Setup(x => x.Save(
                 new Favourites()
                 {
                     FavouriteId = 1,
                     FavouriteLink = new Menu()
                     {
                         MenuId = 1,
                         BusinessReportId = "1",
                         Description = "desc",
                         FavouritesDescription = "desc",
                         CssIcon = "1",
                         IsReport = false,
                         OperationalReportId = "2",
                         OrderId = 1,
                         Organization = "org",
                         ParentId = 1,
                         Tooltip = "test"
                     },
                     UserId = "1"
                 }
                ));
            var data = new Favourites
            {
                FavouriteId = 1,
                UserId = "user1"
            };
            var controller = new FavoritesController(favouriteBusinessLayer.Object);

            var result = await controller.Post(data);
            Assert.AreNotEqual(1, result);
        }

        private static List<Favourites> GetTestFavourites()
        {
            var testFavourites = new List<Favourites>
            {
                new Favourites
                {
                    FavouriteId = 1,
                    FavouriteLink = new Menu()
                    {
                        MenuId = 1,
                        BusinessReportId = "url",
                        Description = "desc",
                        FavouritesDescription = "desc",
                        CssIcon = "1",
                        IsReport = false,
                        OperationalReportId = "url",
                        OrderId = 1,
                        Organization = "org",
                        ParentId = 1,
                        Tooltip = "test"
                    },
                    UserId = "1"
                }
            };

            return testFavourites;
        }
    }
}
