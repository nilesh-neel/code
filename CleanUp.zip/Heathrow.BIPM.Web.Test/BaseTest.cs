﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using Heathrow.BIPM.Api.Controllers;
using Unity;
using Unity.Injection;
using Unity.Lifetime;
using Unity.Registration;

namespace Heathrow.BIPM.Web.Test
{
    public abstract class BaseTest
    {
        protected UnityContainer Container;
        protected LifetimeResetter Resetter { get; set; }

        protected Mock<BaseApiController> BaseApiContrlMock { get; set; }

        protected BaseTest()
        {
            Resetter = new LifetimeResetter();
            Container = new UnityContainer();

            BaseApiContrlMock = new Mock<BaseApiController>();
            BaseApiContrlMock.SetupGet(x => x.SignedInUserId).Returns("acb@sdc.com");
            //var appIdentity = new ClaimsIdentity();
            //appIdentity.AddClaim(new Claim(ClaimTypes.Upn, "abc.def@hello.com"));
            //ClaimsPrincipal.Current.AddIdentity(appIdentity);
            // BaseApiContrlMock.Setup(x => x.SignedInUserId).Returns();
        }

        [TestInitialize]
        public void OnTestSetup()
        {
            Resetter.Reset();
        }

        protected void RegisterResettableType<T>(params InjectionMember[] injectionMembers)
        {
            Container.RegisterType<T>(new ResettableLifetimeManager(Resetter), injectionMembers);
        }

        protected void RegisterResettableType<T>(Func<Action<Mock<T>>> onCreatedCallbackFactory) where T : class
        {
            RegisterResettableType<T>(new InjectionFactory(c => CreateMockInstance(onCreatedCallbackFactory)));
        }

        protected T CreateMockInstance<T>(Func<Action<Mock<T>>> onCreatedCallbackFactory) where T : class
        {
            var mock = new Mock<T>();
            var onCreatedCallback = onCreatedCallbackFactory();
            onCreatedCallback?.Invoke(mock);
            return mock.Object;
        }

        protected class LifetimeResetter
        {
            public event EventHandler<EventArgs> OnReset;

            public void Reset()
            {
                OnReset?.Invoke(this, EventArgs.Empty);
            }
        }

        protected class ResettableLifetimeManager : LifetimeManager
        {
            public ResettableLifetimeManager(LifetimeResetter lifetimeResetter)
            {
                lifetimeResetter.OnReset += (o, args) => instance = null;
            }

            private object instance;

            public override object GetValue()
            {
                return instance;
            }

            public override void SetValue(object newValue)
            {
                instance = newValue;
            }

            public override void RemoveValue()
            {
                instance = null;
            }
        }
    }
}
