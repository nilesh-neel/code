using Heathrow.BIPM.Api.App_Start;
using Heathrow.BIPM.Business.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Web.Http.Controllers;

namespace Heathrow.BIPM.Web.Test.App_Start
{
    [TestClass]
    public class ValidateModelStateAttributeTests
    {
        private MockRepository mockRepository;



        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private ValidateModelStateAttribute CreateValidateModelStateAttribute()
        {
            return new ValidateModelStateAttribute();
        }

        [TestMethod]
        public void OnActionExecuting_StateUnderTest_ExpectedBehavior()
        {
            var menuModel = new Mock<IMenuModule>();

            var unitUnderTest = new ValidateModelStateAttribute();
            HttpActionContext actionContext = new HttpActionContext
            {
                //ControllerContext = new HttpControllerContext
                //{
                //    Request = new HttpRequestMessage(),
                //    Controller = new MenuController(menuModel.Object),

                //}

            };



            // Act
            unitUnderTest.OnActionExecuting(actionContext);

            // Assert
            Assert.IsTrue(true);
        }

        [TestMethod]
        public void OnActionExecuting_StateUnderTest_NullExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = new ValidateModelStateAttribute();
            // Act
            unitUnderTest.OnActionExecuting(null);

            // Assert
            Assert.IsTrue(true);
        }
    }
}
