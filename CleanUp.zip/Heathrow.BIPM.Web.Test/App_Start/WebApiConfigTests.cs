using Heathrow.BIPM.Api;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Dispatcher;
using System.Web.Http.Hosting;
using System.Web.Http.Routing;
using Heathrow.BIPM.Api.Controllers;
using System.Linq.Expressions;

namespace Heathrow.BIPM.Web.Test.App_Start
{
    [TestClass]
    public class WebApiConfigTests
    {
        [TestMethod]
        public void Register_StateUnderTest_ExpectedBehavior()
        {
            var _config = new HttpConfiguration
            {
                IncludeErrorDetailPolicy = IncludeErrorDetailPolicy.Always,
                DependencyResolver = new Unity.WebApi.UnityDependencyResolver(ApiBootstrap.BuildUnityContainer())
            };
            _config.Routes.MapHttpRoute(name: "Default", routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional });
            //_config.Routes.MapHttpRoute(name: "DefaultRPC", routeTemplate: "api/v2/{controller}/{action}/{id}",
            //    defaults: new { id = RouteParameter.Optional });
            //_config.Routes.MapHttpRoute(name: "DefaultRPC", routeTemplate: "api/v2/{controller}/{action}/{id}",
            //    defaults: new { id = RouteParameter.Optional });
            var request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/menu");

            var routeTester = new RouteTester(_config, request);
            WebApiConfig.Register(_config);
            Assert.AreEqual(typeof(MenuController), routeTester.GetControllerType());
            Assert.AreEqual(RouteTester.GetMethodName((MenuController p) => p.Get()), routeTester.GetActionName());
        }

        [TestMethod]
        public void RegisterIsNull_StateUnderTest_ExpectedBehavior()
        {
            // setups
            var request = new HttpRequestMessage(HttpMethod.Get, "https://localhost:44372/api/menu");
            // act
            WebApiConfig.Register(null);
            // asserts
            Assert.IsTrue(true);
        }
    }

    public class RouteTester
    {
        HttpConfiguration config;
        HttpRequestMessage request;
        IHttpRouteData routeData;
        IHttpControllerSelector controllerSelector;
        HttpControllerContext controllerContext;

        public RouteTester(HttpConfiguration conf, HttpRequestMessage req)
        {
            config = conf;
            request = req;
            routeData = config.Routes.GetRouteData(request);
            request.Properties[HttpPropertyKeys.HttpRouteDataKey] = routeData;
            controllerSelector = new DefaultHttpControllerSelector(config);
            controllerContext = new HttpControllerContext(config, routeData, request);
        }

        public string GetActionName()
        {
            if (controllerContext.ControllerDescriptor == null)
                GetControllerType();

            var actionSelector = new ApiControllerActionSelector();
            var descriptor = actionSelector.SelectAction(controllerContext);

            return descriptor.ActionName;
        }

        public Type GetControllerType()
        {
            var descriptor = controllerSelector.SelectController(request);
            controllerContext.ControllerDescriptor = descriptor;
            return descriptor.ControllerType;
        }

        public static string GetMethodName<T, U>(Expression<Func<T, U>> expression)
        {
            var method = expression.Body as MethodCallExpression;
            if (method != null)
                return method.Method.Name;

            throw new ArgumentException("Expression is wrong");
        }

    }


}