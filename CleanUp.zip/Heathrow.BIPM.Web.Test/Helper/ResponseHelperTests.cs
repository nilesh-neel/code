using Heathrow.BIPM.Api.Helper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Moq.Protected;
using System.Text;
using Newtonsoft.Json;

namespace Heathrow.BIPM.Web.Test.Helper
{
    [TestClass]
    public class ResponseHelperTests
    {
        private HttpClient _client;
        private HttpRequestMessage _httpRequest;
        private Mock<DelegatingHandler> _testHandler;
        [TestInitialize]
        public void TestInitialize()
        {
            _httpRequest = new HttpRequestMessage(HttpMethod.Get, "/api/get");
            _testHandler = new Mock<DelegatingHandler>();
        }

        [TestCleanup]
        public void TestCleanup()
        {

        }

        private ResponseHelper CreateResponseHelper()
        {
            return new ResponseHelper() // create subject
            {
                InnerHandler = _testHandler.Object //initialize InnerHandler with our mock
            };
        }

        [TestMethod]
        public void ResponseResult_StateUnderTest_ExpectedBehavior()
        {
            try
            {
                _client = new HttpClient(CreateResponseHelper())
                {
                    BaseAddress = new Uri("https://testapi.com")
                };
                //var mockResponse = new HttpResponseMessage
                //{
                //    StatusCode = HttpStatusCode.OK,
                //    Content = new StringContent("This is dummy response..", Encoding.UTF8, "application/json")
                //};

                string json = JsonConvert.SerializeObject(new ResponseMetadata
                {
                    Version = "1.0",
                    ErrorMessage = "",
                    Size = 25,
                    Timestamp = DateTime.Now,
                    Result = "OK",
                    StatusCode = HttpStatusCode.OK

                });

                var mockResponse = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };



                _testHandler.Protected()
                    .Setup<Task<HttpResponseMessage>>("SendAsync", _httpRequest, ItExpr.IsAny<CancellationToken>())
                    .Callback(
                        (Action<HttpRequestMessage, CancellationToken>)AssertThatRequestCorrect)
                    .ReturnsAsync(mockResponse);

                //Act
                var actualResponse = _client.SendAsync(_httpRequest);



                //_testHandler
                //    .Protected()
                //    .Verify("SendAsync", Times.Once(), _httpRequest, ItExpr.IsAny<CancellationToken>());


                //Task<HttpResponseMessage> result = logic.SendAsync(requestMessage, new CancellationToken(false),
                //    (rm, ct) =>
                //    {

                //        // Do some Asserts in here for any �Before� logic

                //        // This simulates what the inner handler (or ultimately the controller) would return 
                //        var task = new Task<HttpResponseMessage>(() => new HttpResponseMessage(HttpStatusCode.OK));
                //        task.Start();
                //        return task;
                //    });

                // Task<HttpResponseMessage> result = logic.SendAsync(requestMessage, new CancellationToken(false));

                //HttpResponseMessage resultMessage = result.Result;
                //var status = resultMessage.StatusCode;

                //// Arrange
                //var unitUnderTest = this.CreateResponseHelper();
                //HttpRequestMessage request = TODO;
                //HttpResponseMessage response = TODO;
                //object responseContent = TODO;
                //string errorMess = TODO;

                //// Act
                //var result = unitUnderTest.ResponseResult(
                //    request,
                //    response,
                //    responseContent,
                //    errorMess);

                //// Assert
                //Assert.Fail();

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        void AssertThatRequestCorrect(HttpRequestMessage request, CancellationToken token)
        {
            Assert.AreEqual(request, _httpRequest);
            //... Other asserts
        }

        protected Task<HttpResponseMessage> CallbackMethod(HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent("OK", Encoding.UTF8, "application/json")
            });
        }

        public async Task SendAsync_With_Get_Request_Should_Send_External_Request_Log_Message()
        {
            // Arrange
            var url = $"https://www.{Guid.NewGuid()}.com/";
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(url)
            };
            // More set up and mock go here.

            // Act
            //    var response = await _handler.(request, It.IsAny<CancellationToken>());

            // Assert
            // Assertion logic goes here
        }
    }
}
