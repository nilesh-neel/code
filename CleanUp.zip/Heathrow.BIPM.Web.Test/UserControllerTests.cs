﻿using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class UserControllerTests
    {
        private MockRepository mockRepository;

        private Mock<IUserMapModule> mockUserMapModule;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockUserMapModule = this.mockRepository.Create<IUserMapModule>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private UserController CreateUserController()
        {
            return new UserController(
                this.mockUserMapModule.Object);
        }

        [TestMethod]
        public async Task Post_StateUnderTest_ExpectedBehavior()
        {
            Mock<IUserMapModule> userMapBusinessLayer = new Mock<IUserMapModule>();

            var userModule = new Mock<IUserMapModule>();

            userMapBusinessLayer.Setup(x => x.UpdateOperationalAreaAndLocation(TestUserCollection()));

            var controller = new UserController(userMapBusinessLayer.Object);
            var testUser = TestUserCollection();

            var result1 = await controller.Post(new User()
            {
                UserId = "gayathri.kannan@heathrow.com",
                OperationalArea = new Lookup
                {
                    RowId = 2,
                    LookupTypeName = "Arrivals"
                },
                Location = new Lookup
                {
                    RowId = 2,
                    LookupTypeName = "Heathrow Terminal 2"
                },
                Email = "gayathri.kannan@heathrow.com",
                FirstName = "Gayathri",
                LastName = "Kannan"
            });
            Assert.AreNotEqual(1,result1);
        }

        [TestMethod]
        public async Task Post_StateUnderTest_NotExpectedBehavior()
        {
            Mock<IUserMapModule> userMapBusinessLayer = new Mock<IUserMapModule>();

            var userModule = new Mock<IUserMapModule>();

            userMapBusinessLayer.Setup(x => x.UpdateOperationalAreaAndLocation(TestUserCollection()));

            var controller = new UserController(userMapBusinessLayer.Object);
            var testUser = TestUserCollection();

            var result1 = await controller.Post(new User()
            {
                UserId = "gayathri.kannan@heathrow.com",
                OperationalArea = new Lookup
                {
                    RowId = 2,
                    LookupTypeName = "Arrivals"
                },
                Location = new Lookup
                {
                    RowId = 2,
                    LookupTypeName = "Heathrow Terminal 2"
                },
                Email = "gayathri.kannan@heathrow.com",
                FirstName = "Gayathri",
                LastName = "Kannan"
            });
            Assert.IsNotNull(result1);
        }

        [TestMethod]
        public async Task Get_StateUnderTest_ExpectedBehavior()
        {
            Mock<IUserMapModule> userMapBusinessLayer = new Mock<IUserMapModule>();

            var userModule = new Mock<IUserMapModule>();

            userMapBusinessLayer.Setup(x => x.Fetch("gayathri.kannan@heathrow.com"))
                .Returns(Task.FromResult(TestUserCollectionList()));
            var testUser = TestUserCollectionList();
            var controller = new UserController(userMapBusinessLayer.Object);

            var result = await controller.Get();
            Assert.IsNotNull(result);
        }
               

        private static User TestUserCollection()
        {
            var testUser = new User()
            {
                UserId = "gayathri.kannan@heathrow.com",
                OperationalArea = new Lookup
                {
                    RowId = 3,
                    LookupTypeName = "Ramp"
                },
                Location = new Lookup
                {
                    RowId = 4,
                    LookupTypeName = "Heathrow Terminal 3"
                },
                Email = "gayathri.kannan@heathrow.com",
                FirstName = "Gayathri",
                LastName = "Kannan"
            };
            return testUser;
        }

        private static IList<User> TestUserCollectionList()
        {
            List<User> testCollection = new List<User>();
            var testUser = new User()
            {
                UserId = "gayathri.kannan@heathrow.com",
                OperationalArea = new Lookup
                {
                    RowId = 3,
                    LookupTypeName = "Ramp"
                },
                Location = new Lookup
                {
                    RowId = 4,
                    LookupTypeName = "Heathrow Terminal 3"
                },
                Email = "gayathri.kannan@heathrow.com",
                FirstName = "Gayathri",
                LastName = "Kannan"
            };
            testCollection.Add(testUser);
            return testCollection;
        }
    }
}

