﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Hosting;
using System.Web.Http.Routing;
using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class AlertTest
    {

        [TestMethod]
        public void Get_ShouldReturnAlertCount()
        {

            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlertCount("user1"))
        .Returns(Task.FromResult(1));
            var testAlert = 1;
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/AlertCount");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/AlertCount");
            Controller.ControllerContext = new HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.GetAlertNotification();
            Assert.AreNotEqual(testAlert, result);
        }

        [TestMethod]
        public void Update_ShouldReturnValue()
        {
            var testAlert = GetTestAlerts();
            var _alerts = new List<Alerts>();
            var mock = new Mock<IAlertsModule>();
            mock.Setup(p => p.InsertUpdate(
                new Alerts()
                {
                    AlertId = 1,
                    Description = "desc",
                    BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    DateAndTime = DateTime.Now,
                    DisableAlert = false,
                    DisableNotification = false,
                    EndDate = DateTime.Now,

                    IsEmail = false,
                    IsMobile = true,
                    IsOnScreen = true,
                    IsSubscribe = false,

                    MandatoryOptional = 1,

                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,


                    ResponseType = 1,
                    SelectedFrequency = 1,
                    // SelectedLocation = new int[] { 1, 2 },
                    SelectedMeasure = 1,
                    // SelectedOperationalArea = new int[] { 1, 2 },
                    SelectedOrganisation = 1,
                    SelectedThreshold = 1,
                    SelectedTimeWindow = 1,
                    SelectedTopic = 1,
                    StartDate = DateTime.Now,
                    ThresholdValue = "1",
                    Measure = "1",
                    TimeWindow = 1,
                    Title = "title"

                }));
            AlertsController alert = new AlertsController(mock.Object, null);
            var result1 = alert.Put(new Alerts()
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,
                // Frequency = "1",
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                // Location = "1",
                MandatoryOptional = 1,
                //  Measure = "1",
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                //   OperationalArea = "1",
                //   Organization = "1",
                ResponseType = 1,
                SelectedFrequency = 1,
                // SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //   SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                //  Threshold = "1",
                ThresholdValue = "1",
                //   Time = "1",
                TimeWindow = 1,
                Title = "title"
                //   Topic = "test"
            });
            Assert.AreNotEqual(testAlert, result1);

            Assert.IsNotNull(testAlert[0].BagFrequency);
            Assert.IsNotNull(testAlert[0].BagLocation);
            Assert.IsNotNull(testAlert[0].BagMeasure);
            Assert.IsNotNull(testAlert[0].BagOperationalArea);
            Assert.IsNotNull(testAlert[0].BagOrganisation);
            Assert.IsNotNull(testAlert[0].BagThreshold);
            Assert.IsNotNull(testAlert[0].BagTimeWindow);
            Assert.IsNotNull(testAlert[0].BagTopic);
            Assert.IsNotNull(testAlert[0].DateAndTime);
            Assert.IsNotNull(testAlert[0].IsSnooze);
            Assert.IsNotNull(testAlert[0].IsSubscribe);

            Assert.IsNotNull(testAlert[0].AlertId);
            Assert.IsNotNull(testAlert[0].CreatedDate);
            Assert.IsNotNull(testAlert[0].ResponseType);
            Assert.IsNotNull(testAlert[0].Title);



        }

        [TestMethod]
        public void Get_ShouldReturnAlertNotification()
        {

            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlertNotification("user1"))
        .Returns(GetTodaysAlert());
            var testAlert = GetTodaysAlert();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/AlertNotification");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/AlertNotification");
            Controller.ControllerContext = new HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.Get();
            Assert.AreEqual(testAlert.Id, result.Id - 1);



        }

        [TestMethod]
        public void Get_ShouldNotReturnAlertNotification()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlertNotification("user1"))
        .Returns(GetTodaysAlert());
            var testAlert = GetTodaysAlert();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/AlertNotification");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/AlertNotification");
            Controller.ControllerContext = new HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.GetAlertNotification();
            Assert.AreEqual(testAlert.Id, result.Id - 1);
        }


        [TestMethod]
        public void TopicForMeasure_ShouldReturnValues()
        {
            var alertsBusinessLayer = new Mock<IAlertsModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            alertsBusinessLayer.Setup(x => x.GetTopicForMeasure("1"))
                .Returns(Task.FromResult(GetTestAlert()));

            var testNotification = GetTestAlert();
            var controller = new AlertsController(alertsBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = controller.TopicForMeasure("1");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void TodaysAlert_ShouldReturnAlertValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            alertBusinessLayer.Setup(x => x.GetTodaysAlert("1"))
        .Returns(GetTodaysAlert());

            var testAlert = GetTestAlertList();
            var controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = controller.TodaysAlert();
            Assert.AreEqual(testAlert.Id, result.Id - 1);
        }

        [TestMethod]
        public void GetAlertById_ShouldReturnValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();

            alertBusinessLayer.Setup(x => x.GetAlertsById("Admin", 0))
                .Returns(Task.FromResult(GetTestMyAlertSettings()));

            var testAlert = GetTestAlert();
            var testAlertSettings = GetTestMyAlertSettings();
            var controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);

            var result = controller.Get(0);
            Assert.IsNotNull(result);
            Assert.IsNotNull(testAlert.AlertId);
            Assert.IsNotNull(testAlert.CreatedBy);
            Assert.IsNotNull(testAlert.CreatedDate);
            Assert.IsNotNull(testAlertSettings.Description);
            Assert.IsNotNull(testAlert.DisableAlert);
            Assert.IsNotNull(testAlert.EndDate);
            Assert.IsNotNull(testAlertSettings.IsEmail);
            Assert.IsNotNull(testAlertSettings.IsMobile);
            Assert.IsNotNull(testAlertSettings.IsOnScreen);
            Assert.IsNotNull(testAlertSettings.IsSnooze);
            Assert.IsNotNull(testAlertSettings.IsSubscribe);
            Assert.IsNotNull(testAlertSettings.MandatoryOptional);
            Assert.IsNotNull(testAlertSettings.Measure);
            Assert.IsNotNull(testAlert.ModifiedBy);
            Assert.IsNotNull(testAlert.ModifiedDate);
            Assert.IsNotNull(testAlert.ResponseType);
            Assert.IsNotNull(testAlert.StartDate);
            Assert.IsNotNull(testAlertSettings.ThresholdValue);
            Assert.IsNotNull(testAlert.TimeWindow);
            Assert.IsNotNull(testAlertSettings.Title);
            Assert.IsNotNull(testAlertSettings.IsConfigureEmail);
            Assert.IsNotNull(testAlertSettings.Location);
            Assert.IsNotNull(testAlertSettings.Threshold);
            Assert.IsNotNull(testAlertSettings.Topic);
        }
        [TestMethod]
        public void GetAlertByID_ShouldReturnAlertValues()
        {

            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlerts("1"))
        .Returns(GetTestAlertList());
            var testAlert = GetTestAlertList();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/AlertByID");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/AlertByID");
            Controller.ControllerContext = new System.Web.Http.Controllers.HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.Get(1);
            //Assert.AreEqual(testAlert.Id, result.Id -1);

        }

        [TestMethod]
        public void GetConfigureAlertByID_ShouldReturnAlertValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlerts("1"))
          .Returns(GetTestAlertList());
            var testAlert = GetTestAlertList();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/ConfigureAlertByID");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/ConfigureAlertByID");
            Controller.ControllerContext = new System.Web.Http.Controllers.HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.Get(1);
            Assert.AreEqual(testAlert.Id, result.Id + 1);
        }


        [TestMethod]
        public void GetAlerts_ShouldReturnAlertValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();

            var lookupBusinessLayer = new Mock<ILookupModule>();

            alertBusinessLayer.Setup(x => x.GetAlerts("user1"))
        .Returns(GetTestAlertList());
            var testAlert = GetTestAlertList();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/GetAlert");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/GetAlert");
            Controller.ControllerContext = new HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.Get();
            Assert.AreEqual(testAlert.Id, result.Id - 1);
        }


        [TestMethod]
        public void GetConfiguredAlert_ShouldReturnAlertValues()
        {
            var alertBusinessLayer = new Mock<IAlertsModule>();
            var lookupBusinessLayer = new Mock<ILookupModule>();
            alertBusinessLayer.Setup(x => x.GetAlerts("user1"))
          .Returns(GetTestAlertList());
            var testAlert = GetTestAlertList();
            var config = new HttpConfiguration();
            var Controller = new AlertsController(alertBusinessLayer.Object, lookupBusinessLayer.Object);
            var Route = config.Routes.MapHttpRoute("DefaultApi", "api/GetConfiguredAlert");
            var RouteData = new HttpRouteData(Route, new HttpRouteValueDictionary { { "controller", "alerts" } });
            var Request = new HttpRequestMessage(HttpMethod.Get, "http://localhost:44372/api/GetConfiguredAlert");
            Controller.ControllerContext = new HttpControllerContext(config, RouteData, Request);
            Controller.Request = Request;
            Controller.Request.Properties[HttpPropertyKeys.HttpConfigurationKey] = config;
            var result = Controller.Get();
            Assert.AreEqual(testAlert.Id, result.Id - 1);
        }



        [TestMethod]
        public void Post_ShouldReturnNotification()
        {
            var testAlert = GetTestAlertList();
            var _alert = new List<Alerts>();
            var mock = new Mock<IAlertsModule>();
            mock.Setup(p => p.InsertUpdate(
                new Alerts()
                {
                    AlertId = 1,
                    Description = "desc",
                    BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    DateAndTime = DateTime.Now,
                    DisableAlert = false,
                    DisableNotification = false,
                    EndDate = DateTime.Now,

                    IsEmail = false,
                    IsMobile = true,
                    IsOnScreen = true,
                    IsSubscribe = false,
                    MandatoryOptional = 1,

                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,


                    ResponseType = 1,
                    SelectedFrequency = 1,
                    // SelectedLocation = new int[] { 1, 2 },
                    SelectedMeasure = 1,
                    // SelectedOperationalArea = new int[] { 1, 2 },
                    SelectedOrganisation = 1,
                    SelectedThreshold = 1,
                    SelectedTimeWindow = 1,
                    SelectedTopic = 1,
                    StartDate = DateTime.Now,

                    ThresholdValue = "1",

                    TimeWindow = 1,
                    Title = "title",

                }));
            AlertsController alerts = new AlertsController(mock.Object, null);
            var result1 = alerts.Post(new Alerts()
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,


                ResponseType = 1,
                SelectedFrequency = 1,
                // SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                // SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,

                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title",

            });
            Assert.AreNotEqual(testAlert, result1);
        }



        private static List<Alerts> GetTestAlerts()
        {
            var testProducts = new List<Alerts>();
            testProducts.Add(new Alerts
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                MandatoryOptional = 1,
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                // SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                ThresholdValue = "1",
                TimeWindow = 1,
                Title = "title",

            });
            testProducts.Add(new Alerts
            {
                AlertId = 2,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,


                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //   SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title",

            });
            testProducts.Add(new Alerts
            {
                AlertId = 3,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,


                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //  SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,

                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title",

            });
            testProducts.Add(new Alerts
            {
                AlertId = 4,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,

                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //  SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,

                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title",

            });

            return testProducts;
        }

        private static Task<IEnumerable<MyAlertSettings>> GetTestAlertList()
        {
            IEnumerable<MyAlertSettings> testProducts = new List<MyAlertSettings>()
            { new MyAlertSettings
            {
                AlertId = 1,
                Description = "desc",

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",
                MandatoryOptional = 1,
                Measure = "1",

                Threshold = "1",
                ThresholdValue = "1",

                Title = "title",
                Topic = "test"
            } };

            return Task.FromResult(testProducts);
        }


        private static Task<IEnumerable<TodaysAlert>> GetTodaysAlert()
        {
            IEnumerable<TodaysAlert> testProducts = new List<TodaysAlert>()
            { new TodaysAlert
            {
                AlertId = 4,
                CreatedDate = DateTime.Now,
                EventId=1,
                Mandatory=1,
                Message="test",
                Time="testTime",
                TodaysLocation="testLocation",
                ResponseType = 1,
                Title = "title",
                Topic = "test"
            } };

            return Task.FromResult(testProducts);
        }

        //public static Task<IEnumerable<Alerts>> GetAlertsList()
        //{
        //    IEnumerable<Alerts> testProducts = new List<Alerts>()
        //    { new Alerts
        //    {

        //        Title = "AlertMessage",
        //        AlertId = 1,
        //        ResponseType = 1
        //      //  Time = "1",     
        //     } };

        //    return Task.FromResult(testProducts);
        //}
        private static Alerts GetTestAlert()
        {
            var testAlert = new Alerts()
            {
                BagFrequency = new List<Lookup>() { },
                CreatedBy = "David",
                AlertId = 1,
                DisableAlert = true,
                EndDate = DateTime.Now,
                ModifiedBy = "Ram",
                ModifiedDate = DateTime.Now,
                ResponseType = 1,
                StartDate = DateTime.Now
            };

            return testAlert;
        }
        private static MyAlertSettings GetTestMyAlertSettings()
        {
            var testAlert = new MyAlertSettings()
            {
                AlertId = 1,
                Description = "desc",

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",
                MandatoryOptional = 1,
                Measure = "1",

                Threshold = "1",
                ThresholdValue = "1",

                Title = "title",
                Topic = "test",
                IsConfigureEmail = true,
                IsSnooze = true

            };

            return testAlert;
        }
      
    }
}
