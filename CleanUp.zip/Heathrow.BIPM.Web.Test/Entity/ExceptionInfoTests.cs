using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Heathrow.BIPM.Web.Test.Entity
{
    [TestClass]
    public class ExceptionInfoTests
    {
        private MockRepository mockRepository;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private ExceptionInfo CreateExceptionInfo()
        {
            return TestExceptionInfo();
        }

        [TestMethod]
        public void TestMethod1()
        {
            // Arrange
            var unitUnderTest = this.CreateExceptionInfo();

            // Assert
            Assert.IsNotNull(unitUnderTest);
        }
        private static ExceptionInfo TestExceptionInfo()
        {
            var excepDetails = new ExceptionInfo()
            {
                ApplicationName="kestrel",
                EmailId = "xy@test.com",
                ExceptionMessage="Internal server error",
                ExceptionSource="Web",
                InnerException="Connection failure",
                SignedInUserId="Admin",
                UserId="TestAdmin@xy.com",
                StackTrace="Sql server connection failure",
                TargetSite="kestrel"
            };
            return excepDetails;
        }
    }
}
