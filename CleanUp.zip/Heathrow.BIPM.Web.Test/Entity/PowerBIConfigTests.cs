using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Heathrow.BIPM.Web.Test.Entity
{
    [TestClass]
    public class PowerBIConfigTests
    {
        private MockRepository mockRepository;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        //private static PowerBIConfig CreatePowerBIConfig()
        //{
        //  // return PowerBIConfig.AadAuthorityUri{return "test"};

           
        //}

       // [TestMethod]
        //public void TestMethod1()
        //{
        //    // Arrange
        //    var unitUnderTest = this.CreatePowerBIConfig();

        //    // Assert
        //    Assert.IsNotNull(unitUnderTest);
        //}


    }
}
