using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace Heathrow.BIPM.Web.Test.Entity
{
    [TestClass]
    public class AzureAdConfigTests
    {
        private MockRepository mockRepository;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        //private AzureAdConfig CreateAzureAdConfig()
        //{
        //    return new AzureAdConfig();
        //}

        //[TestMethod]
        //public void TestMethod1()
        //{
        //    // Arrange
        //    var unitUnderTest = this.CreateAzureAdConfig();

        //    // Assert
        //    Assert.Fail();
        //}
    }
}
