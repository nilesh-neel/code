using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;

namespace Heathrow.BIPM.Web.Test.Entity
{
    [TestClass]
    public class AzureAdUserTests
    {
        private MockRepository mockRepository;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private AzureAdUser CreateAzureAdUser()
        {
            return new AzureAdUser();
        }

        [TestMethod]
        public void TestMethod1()
        {
            // Arrange
            var unitUnderTest = this.CreateAzureAdUser();
            // Act
            Assert.IsNotNull(unitUnderTest);
            // Assert
            //Assert.Fail();
            var testUser = GetTestAzureAdUser();

            Assert.IsNotNull(testUser.Id);
            Assert.IsNotNull(testUser.DisplayName);
            Assert.IsNotNull(testUser.Email);
            Assert.IsNull(testUser.Avatar);
            Assert.IsNotNull(testUser.Name);
            Assert.IsNotNull(testUser.JobRoles);
            Assert.IsNotNull(testUser.Phone);
            Assert.IsNotNull(testUser.Locations);
            Assert.IsNotNull(testUser.Organization);
            Assert.IsNotNull(testUser.Role);

        }

        private static AzureAdUser GetTestAzureAdUser()
        {

            var testAzureAdUser = new AzureAdUser()
            {
                Id = "1",
                DisplayName = "testDisplay",
                Email = "testEmail",
                Avatar = null,
                Name = "testName",
                JobRoles = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1} },
                Phone = "testPhone",
                Locations = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                Organization = "testOrganisation",
                Role = "testRole"
            };

            return testAzureAdUser;
        }
    }
}
