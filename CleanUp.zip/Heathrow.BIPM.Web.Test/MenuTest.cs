﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Results;
using Heathrow.BIPM.Api.Controllers;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.Test;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Unity;

namespace Heathrow.BIPM.Test
{
    [TestClass]
    public class MenuTest : BaseTest
    {
        [TestInitialize]
        public void TestSetup()
        {
            // setup the IMenuModule for all tests
            RegisterResettableType<IMenuModule>(() => mock =>
            {
                mock.Setup(s => s.GetAllMenu())
                    .Returns(GetTestMenu());
            });

        }


        [TestMethod]
        public void Get_ShouldReturnMenuList()
        {
            try
            {
                var controller = Container.Resolve<MenuController>();
                //BaseApiContrlMock.Object.SignedInUserId
                IHttpActionResult response = controller.Get();
                var result = (List<Menu>)(((OkNegotiatedContentResult<IEnumerable<Menu>>)response).Content);
                Assert.IsNotNull(result.Count);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        [TestMethod]
        public void Get_ShouldReturnMenuValues()
        {
            var menuBusinessLayer = new Mock<IMenuModule>();

            menuBusinessLayer.Setup(x => x.GetAllMenu())
                .Returns(GetTestMenuList());

            var testMenu = GetTestMenu();
            var controller = new MenuController(menuBusinessLayer.Object);

            IHttpActionResult response = controller.Get();
            var result = (List<Menu>)(((OkNegotiatedContentResult<IEnumerable<Menu>>)response).Content);
            Assert.AreEqual(result.Count, testMenu.Count);
            Assert.IsNotNull(result[0].BreadCrumb);
            Assert.IsNotNull(result[0].BusinessReportId);
            Assert.IsNotNull(result[0].CssIcon);
            Assert.IsNotNull(result[0].Description);
            Assert.IsNotNull(result[0].FavouritesDescription);
            Assert.IsNotNull(result[0].IsMultiLevel);
            Assert.IsNotNull(result[0].IsReport);
            Assert.IsNotNull(result[0].IsVisible);
            Assert.IsNotNull(result[0].OperationalReportId);
            Assert.IsNotNull(result[0].OrderId);
            Assert.IsNotNull(result[0].Organization);
            Assert.IsNotNull(result[0].ParentId);
            Assert.IsNotNull(result[0].Tooltip);
            Assert.IsNotNull(result[0].ParentId);
        }

        [TestMethod]
        public void Get_ShouldNotReturnMenuValues()
        {
            var menuBusinessLayer = new Mock<IMenuModule>();

            menuBusinessLayer.Setup(x => x.GetAllMenu())
                .Returns(GetTestMenuList());

            var testMenu = GetTestMenu();
            var controller = new MenuController(menuBusinessLayer.Object);

            var result = controller.Get();
            Assert.AreNotEqual(testMenu, result);
        }

        private List<Menu> GetTestMenu()
        {
            var testMenu = new List<Menu>
            {
                new Menu()
                {
                    BusinessReportId = "1",
                    Description = "desc",
                    FavouritesDescription = "fdesc",
                    MenuId = 19,
                    OrderId = 1,
                    Organization = "org",
                    CssIcon = "ico",
                    IsReport = true,
                    OperationalReportId = "2",
                    ParentId = 1,
                    Tooltip = "sample",


                }
            };

            return testMenu;
        }

        private static IEnumerable<Menu> GetTestMenuList()
        {
            var testMenu = new List<Menu>()
            { new Menu()
                {
                    BusinessReportId = "1",
                    Description = "desc",
                    FavouritesDescription = "fdesc",
                    MenuId = 19,
                    OrderId = 1,
                    Organization = "org",
                    CssIcon = "ico",
                    IsReport = true,
                    OperationalReportId = "2",
                    ParentId = 1,
                    Tooltip = "sample",
                    BreadCrumb="sampleBreadcrumb",
                    IsVisible=true,
                    IsMultiLevel=true
                }
            };

            return testMenu;
        }
    }
}
