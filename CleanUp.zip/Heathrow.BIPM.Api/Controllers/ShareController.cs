﻿/****************************************************************************************************************
Class Name   : ShareController.cs
Purpose      : Provides GET, PUT, POST, DELETE for Share Entity
Created By   : Vignesh 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No       | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No>      |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetch organisation/recipients using logged-in user's EmailId instead of userId | 05/Dec/2018 | Logic changed
Vignesh (686552)   | code cleanup and updated                                                       | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                                                 | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/
using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BIPM.Business.Interface;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class ShareController : BaseApiController
    {

        private readonly IShareModule _shareModule;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="shareObj"></param>
        /// <param name="userModule"></param>
        public ShareController(IShareModule shareObj)
        {
            _shareModule = shareObj;
        }

        // GET: Share

        /// <summary>
        ///  Fetching and loading the Audience Group in dropdown
        /// </summary>
        /// <returns>Json response</returns>
        [HttpGet]
        public async Task<IHttpActionResult> Get()
        {
            var result = await _shareModule.GetAudienceGroup(SignedInUserId).ConfigureAwait(false);

            return Ok(result);

        }



        /// <summary>
        ///  Fetching and loading the Group Recipients based on the selected Audience Group
        /// </summary>
        /// <param name="groupId">Selected AudienceGroupId as input parameter</param>
        /// <returns> Json response</returns>
        [HttpGet]
        public async Task<IHttpActionResult> Get(int groupId)
        {
            var result = await _shareModule.GetGroupRecipients(groupId).ConfigureAwait(false);

            return Ok(result);


        }

    }
}
