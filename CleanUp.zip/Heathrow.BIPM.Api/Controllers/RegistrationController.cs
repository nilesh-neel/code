﻿/****************************************************************************************************************
Class Name   : RegistrationController.cs
Purpose      : Provides GET and POST for Registration Entity
Created By   : Vaishnavi.R
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh               FDS Change                                  31/01/2019         Security code update
Nilesh               FDS Change                                  06/02/2019         Rename
****************************************************************************************************************/
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Utility.Constants;
using System.Threading.Tasks;
using System.Web.Http;
namespace Heathrow.BIPM.Api.Controllers
{
    [AllowAnonymous]
    [RoutePrefix("api")]
    public class RegistrationController : ApiController
    {
        private readonly IRegistrationModule _registrationModule;

        private readonly ILookupModule _lookupModule;
        private readonly IUserMapModule _userMapModule;
        /// <summary>
        /// Constructor implementation 
        /// </summary>
        /// <param name="registration"></param>      
        /// <param name="_lookup"></param>
        /// <param name="lookup"></param>
        public RegistrationController(IRegistrationModule registration, ILookupModule lookup, IUserMapModule userModule)
        {
            _registrationModule = registration;
            _lookupModule = lookup;
            _userMapModule = userModule;
        }

        /// <summary>
        /// This is used to populate the dropdown values
        /// </summary>
        /// <returns>Json data </returns>
        [HttpGet]
        public IHttpActionResult Get()
        {
            if (_lookupModule != null)
            {
                Registration registrationItem = new Registration
                {
                    BagLocation = _lookupModule.BagLocationList,
                    BagOperationalArea = _lookupModule.BagOperationalAreaList,
                    BagOrganisation = _lookupModule.BagOrganisationList
                };
                return Ok(registrationItem);
            }
            else
            {
                return Json(MessageConstants.DataUnavailable);
            }
        }

        /// <summary>
        /// This is used save a registration 
        /// </summary>
        /// <param name="registration"></param>
        /// <returns>returns email id</returns>
        [HttpPost]
        public async Task<string> Post([FromBody]Registration registration)
        {
            if (registration != null)
            {
                string email = await _registrationModule.Save(registration).ConfigureAwait(false);
                return email;
            }
            else
            {
                return MessageConstants.SuperAdmin;
            }
        }
        [Route("ValidateUser/{strEmail=strEmail}")]
        public async Task<bool> Get(string strEmail)
        {
            if (!string.IsNullOrEmpty(strEmail))
            {
                return await _userMapModule.ValidateUserEmail(strEmail).ConfigureAwait(false);
            }
            else
            {
                return false;
            }
        }




    }
}
