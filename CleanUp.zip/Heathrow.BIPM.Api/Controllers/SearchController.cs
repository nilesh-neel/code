﻿/****************************************************************************************************************
Class Name   : SearchController.cs
Purpose      : Provides GET for Search API
Created By   : Kannan 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Kannan              FDS Change                                   05/02/2019        Administration level handling
Kannan              FDS Change                                   15/02/2019        CodeShare Flight included
****************************************************************************************************************/
using Heathrow.BIPM.Business.Interface;
using System.Threading.Tasks;
using System.Web.Http;

namespace Heathrow.BIPM.Api.Controllers
{
    /// <summary>
    ///  Search API 
    /// </summary>
    [RoutePrefix("api")]
    public class SearchController : BaseApiController
    {
        private readonly ISearchModule _searchModule;

        /// <summary>
        /// Search Constructor
        /// </summary>
        /// <param name="searchInstance"></param>
        /// <param name="userModule"></param>
        public SearchController(ISearchModule searchInstance)
        {
            _searchModule = searchInstance;
        }

        /// <summary>
        /// Get search data based on the search criteria
        /// </summary>
        /// <param name="query"></param>
        /// <param name="searchType"></param>
        /// <returns>Json</returns>
        [HttpGet]
        public async Task<IHttpActionResult> Get(string query, string searchType)
        {
            return Ok(await _searchModule.SearchData(query, searchType).ConfigureAwait(false));
        }
    }
}
