﻿/****************************************************************************************************************
Class Name   : AlertsController.cs
Purpose      : Provides GET, PUT, POST, DELETE for Alerts Entity
Created By   : Vignesh 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No       | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No>      |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetching the user groups by logged-in EmailId  | 05/Dec/2018       | Logic changed
Vignesh (686552)   | Fetch Dashboard list in groups                 | 10/Dec/2018       | Logic changed
Vignesh (686552)   | code cleanup and updated                       | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                 | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class AssignHomePageController : BaseApiController
    {
        private readonly IAssignHomePageModule _assignHomPageModule;
        private readonly IBpmPowerBi _bpmPowerBi;
        public AssignHomePageController(IAssignHomePageModule assign, IBpmPowerBi bpmPowerBi)
        {
            _assignHomPageModule = assign;
            _bpmPowerBi = bpmPowerBi;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        //GetDashboardsList
        public async Task<IHttpActionResult> Get()
        {
            PowerBiEmbedConfig result = await _bpmPowerBi.GetDashboardInGroup().ConfigureAwait(false);
            return Ok(result.Values);
        }
        /// <summary>
        /// To fetch the usergroups
        /// </summary>
        /// <param name="userEmailId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpGet]
        //GetUserGroups

        //public async Task<IHttpActionResult> Get(string userGroup)
        public async Task<IHttpActionResult> Get(string userEmailId, string userId)
        {
            var result = await _assignHomPageModule.GetUserGroups(SignedInUserId).ConfigureAwait(false);
            return Ok(result);
        }

        #region Fetching and loading the Group Recipients based on the selected Audience Group
        /// <summary>
        /// To get the recipients based on the selected groupId
        /// </summary>
        /// <param name="userGroupId"></param>
        /// <returns></returns>
        [HttpGet]
        //GetGroupRecipients
        public async Task<IHttpActionResult> Get(int userGroupId)
        {
            var result = await _assignHomPageModule.GetGroupRecipients(userGroupId).ConfigureAwait(false);
            return Ok(result);
        }
        #endregion

        /// <summary>
        /// To save the homepage assigned to user
        /// </summary>
        /// <param name="assignHomePage"></param>
        /// <returns></returns>
        [HttpPost]

        public async Task<IHttpActionResult> Post(AssignHomePage assignHomePage)
        {
            
            var result = await _assignHomPageModule.SaveHomepage(assignHomePage,SignedInUserId).ConfigureAwait(false);
            return Ok(result);
        }

    }
}



