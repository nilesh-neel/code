﻿/****************************************************************************************************************
Class Name   :  NotificationsController.cs
Purpose      : Provides GET, PUT, POST, DELETE for Notification Entity
Created By   : Vaishnavi.R
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By           | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Vivekanandan(738022)  | CCAP issue                                | 02/05/2019        | CCAP issue fix
Vaishnavi.R (687417)  | Load dropdown                             | 01/03/2019        | Bind dropdown values in get call
Nilesh More(405285)   | FDS requirement                           | 12/28/2019        | Included user profile route to load dropdown values in user profile pane
Vaishnavi.R(687417)   | Naming Convention                         |  12/27/2018       | Renamed object names
****************************************************************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Utility.Constants;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class NotificationsController : BaseApiController
    {
        private readonly INotificationModule _notificationModule;
        private readonly ILookupModule _lookupModule;

        /// <summary>
        /// Constructor implementation along with dependency injection
        /// </summary>
        /// <param name="notifcationModule"></param>
        /// <param name="notification"></param>
        /// <param name="lookup"></param>
        public NotificationsController(INotificationModule notification, ILookupModule lookup)
        {
            _notificationModule = notification;
            _lookupModule = lookup;

        }

        // GET: Notifications
        /// <summary>          
        /// Retrieve records based on userid
        /// </summary>        
        /// <returns>JSON data</returns> 
        [HttpGet]
        [Route("Notification")]
        public async Task<IHttpActionResult> Get()
        {
            return Ok(await _notificationModule.GetUsersNotification(SignedInUserId).ConfigureAwait(false));
        }
        // GET: Notifications
        /// <summary>          
        /// Retrieve records for scroling notification
        /// </summary>        
        /// <returns>JSON data</returns> 
        [HttpGet]
        [Route("ScrollingNotification")]
        public async Task<IHttpActionResult> GetScrollingNotification()
        {
            return Ok(await _notificationModule.GetScrollingNotification(SignedInUserId).ConfigureAwait(false));
        }

        /// <summary>
        /// Saves notification configured by admin
        /// </summary>
        /// <param name="notification"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IHttpActionResult> Post([FromBody]Notification notification)
        {

            var message = MessageConstants.SaveFail;
            if (notification != null)
            {
                message = await _notificationModule.InsertUpdate(notification).ConfigureAwait(false);
            }           
            return Ok(message);
         
        }

      
        // GET: Notifications
        /// <summary>          
        /// Retrieve records based on notification id
        /// </summary>        
        /// <returns>JSON data</returns> 
        [HttpGet]
        [Route("NotificationByID")]
        [Route("UserProfile/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            Notification notificationItem = new Notification();
            if (id != 0)
            {
                notificationItem = (await _notificationModule.GetNotificationById(SignedInUserId, id).ConfigureAwait(false));                
            }
            if(id==0)
            {
                notificationItem.CreatedBy = SignedInUserId;
            }
            notificationItem.BagLocation = _lookupModule.BagLocationList;
            notificationItem.BagOperationalArea = _lookupModule.BagOperationalAreaList;
            notificationItem.BagOrganisation = _lookupModule.BagOrganisationList;
            notificationItem.BagTopic = _lookupModule.BagTopicList;
            notificationItem.ModifiedBy = SignedInUserId;
            return Ok(notificationItem);

        }
    }
}
