﻿/****************************************************************************************************************
Class Name   : NotesController.cs
Purpose      : Provides GET, PUT, POST, DELETE for Notes Entity
Created By   : Vignesh AshokKumar  
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Getting the logged-in userId globally from SignedInUserId  | 10/Dec/2018       | Logic changed
Vignesh (686552)   | Notes Entitiy param updated for Post method                     | 10/Dec/2018       | Logic changed
Vignesh (686552)   | code cleanup and updated                                   | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                             | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/
using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class NotesController : BaseApiController
    {
        private readonly INotesModule _notesModule;

        /// <summary>
        ///  Constructor
        /// </summary>
        /// <param name="notes"></param>
        public NotesController(INotesModule notes)
        {
            _notesModule = notes;
        }
        // GET: Notes
        #region Fetching and displaying the existing Notes
        /// <summary>
        /// Notes API Get method to fetch the existing respective notes
        /// </summary>
        /// <param name="bagTag"> Bagtag value as input parameter</param>
        /// <param name="notesValue">notes Value value as input parameter</param>
        /// <param name="notesUBLValue">notes Value value as input parameter</param>
        /// <param name="notesType">notesType value as input parameter</param>
        /// <returns>Json response</returns>
        [HttpGet]
        [Route("GetNotes/{notesValue=notesValue}/{notesType=notesType}/{notesUblValue=notesUblValue}")]
        public async Task<IHttpActionResult> Get(string notesValue, string notesType, string notesUblValue)
        {
            var result = await _notesModule.Fetch(notesValue, notesType, notesUblValue, SignedInUserId).ConfigureAwait(false);
            return Ok(result);
        }
        #endregion
        /// <summary>
        /// Notes API Delete method to delete the respective note
        /// </summary>
        /// <param name="noteId">NotesId value as input parameter</param>
        /// <param name="notesValue">notesValue value as input parameter</param>
        /// <param name="notesType">notesType value as input parameter</param>
        /// <returns>Json response</returns>
        #region Deleting respective Notes
        [HttpDelete]
        [Route("DeleteNotes/{noteId=noteId}/{notesValue=notesValue}/{notesType=notesType}")]
        public async Task<IHttpActionResult> Delete(int noteId, string notesValue, string notesType)
        {
            var result = await _notesModule.DeleteNotes(noteId, notesValue, notesType, SignedInUserId).ConfigureAwait(false);
            return Ok(result);
        }
        #endregion

        // POST: Notes/Create
        #region Saving the Created Notes
        /// <summary>
        /// Notes API Post method to save the newly created note
        /// </summary>
        /// <param name="notes">Notes Entity as input parameter</param>
        /// <returns>Json response</returns>
        [HttpPost]
        public async Task<IHttpActionResult> Post(NotesEntity notes)
        {
            notes.UserId = SignedInUserId;
            return Ok(await _notesModule.Save(notes).ConfigureAwait(false));
        }
        #endregion
    }

}
