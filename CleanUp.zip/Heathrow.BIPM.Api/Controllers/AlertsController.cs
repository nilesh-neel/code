﻿/****************************************************************************************************************
Class Name   : AlertsController.cs
Purpose      : Provides GET, PUT, POST for Alerts Entity
Created By   : Vaishnavi.R
Created Date : 04/Oct/2018
Version      : 1.0
History      :        
Modified By            | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Anupama Kumari(694315) | FDS requirement                           | 02/12/2019        |Included new method TopicForMeasure for hierarchical dropdown load
Vignesh(686552)        | CCAP issue                                | 02/05/2019        |CCAP issue wax fixed
Nilesh More(405285)    | Code Optimization                         | 01/13/2019        |Converted return from Json to ok
Vaishnavi.R(687417)    | Optimized get call                        | 01/29/2019        |Included routes and method for configure alert tab
Vaishnavi.R(687417)    | Load dropdown                             | 01/03/2019        |Bind dropdown values in get call
**********************************************************************************************************************************************************************/
using System.Web.Http;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using System.Threading.Tasks;
using Heathrow.BIPM.Utility.Constants;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class AlertsController : BaseApiController
    {
        private readonly IAlertsModule _alertModule;
        private readonly ILookupModule _lookupModule;

        /// <summary>
        /// Constructor implementation along with dependency injection
        /// </summary>
        /// <param name="alert"></param>
        /// <param name="lookup"></param>
        public AlertsController(IAlertsModule alert, ILookupModule lookup)
        {
            _alertModule = alert;
            _lookupModule = lookup;
        }

        /// <summary>
        /// This is used to retrieve records based on userid- admin or standard user
        /// </summary>
        /// <returns>Json data </returns>
        [HttpGet]
        [Route("GetAlert")]
        [Route("GetConfiguredAlert")]
        public async Task<IHttpActionResult> Get()
        {
            if (Request.RequestUri.ToString().Contains(MessageConstants.Configured))
            {
                return Ok(await _alertModule.GetConfiguredAlert(SignedInUserId).ConfigureAwait(false));
            }
            else
            {
                return Ok(await (_alertModule.GetAlerts(SignedInUserId)).ConfigureAwait(false));
            }

        }
        /// <summary>
        /// This is used to retrieve records based on userid- admin or standard user
        /// </summary>
        /// <returns>Json data </returns>
        [HttpGet]
        [Route("AlertNotification")]
        [Route("AlertCount")]
        public async Task<IHttpActionResult> GetAlertNotification()
        {
            if (Request.RequestUri.ToString().Contains(MessageConstants.AlertNotification))
            {
                return Ok(await(_alertModule.GetAlertNotification(SignedInUserId)).ConfigureAwait(false));
            }
            else
            {
                return Ok(await (_alertModule.GetAlertCount(SignedInUserId)).ConfigureAwait(false));
            }
            
        }

        /// <summary>
        /// This is used save an alert which is configured by admin
        /// </summary>
        /// <param name="alertDetails"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IHttpActionResult> Post([FromBody]Alerts alertDetails)
        {
            var message=MessageConstants.SaveFail;
           
            if (alertDetails != null)
            {
                 message = await _alertModule.InsertUpdate(alertDetails).ConfigureAwait(false);
            }         
            return Ok(message);
        }

        /// <summary>
        /// Updates specific alert or response of user
        /// </summary>
        /// <param name="alertDetails"></param>
        /// <returns></returns>
        [HttpPut]
        public async Task<IHttpActionResult> Put([FromBody]Alerts alertDetails)
        {
            if (alertDetails != null)
            {
                alertDetails.ModifiedBy = SignedInUserId;
                await _alertModule.InsertUpdate(alertDetails).ConfigureAwait(false);
            }
            return Ok(1);
        }

        /// <summary>
        /// This is used to retrieve records based on alertid and populate dropdown
        /// </summary>
        /// <param name="alertId"></param>
        /// <returns>Json data </returns>
        [HttpGet]
        [Route("AlertByID")]
        [Route("ConfigureAlertByID")]

        public async Task<IHttpActionResult> Get(int alertId)
        {

            Alerts alertItem = new Alerts();
            if (alertId != 0)
            {
                if (Request.RequestUri.ToString().Contains(MessageConstants.Configure))
                {

                    alertItem = await (_alertModule.GetConfiguredAlertById(SignedInUserId, alertId)).ConfigureAwait(false);
                                
                }
                else
                {
                  return  Ok(await (_alertModule.GetAlertsById(SignedInUserId, alertId)).ConfigureAwait(false));
                }

            }
            if (alertId == 0)
            {
                alertItem.CreatedBy = SignedInUserId;
            }
            alertItem.BagLocation = _lookupModule.BagLocationList;
            alertItem.BagOperationalArea = _lookupModule.BagOperationalAreaList;
            alertItem.BagOrganisation = _lookupModule.BagOrganisationList;
            alertItem.BagTopic = _lookupModule.BagTopicList;
            alertItem.BagFrequency = _lookupModule.BagFrequencyList;
            alertItem.BagMeasure = _lookupModule.BagMeasureList;
            alertItem.BagTimeWindow = _lookupModule.BagTimeWindowList;
            alertItem.BagThreshold = _lookupModule.BagThresholdList;
            alertItem.ModifiedBy = SignedInUserId;

            return Ok(alertItem);
        }
        /// <summary>
        /// This is used to return topic if measure is selected or vice versa
        /// </summary>
        /// <param name="selectedId"></param>
        /// <returns>Json data(Topic/Measure)</returns>
        [HttpGet]
        [Route("TopicByMeasure")]
        public async Task<IHttpActionResult> TopicForMeasure(string selectedId)
        {
            Alerts alertItem = new Alerts();
           
            if (selectedId != null)
            {
                alertItem = await(_alertModule.GetTopicForMeasure(selectedId)).ConfigureAwait(false);
            }
            return Ok(alertItem);
        }

        /// <summary>
        /// This is used to retrieve todays alert
        /// </summary>
        /// <returns>Json data </returns>
        [HttpGet]
        [Route("TodaysAlert")]
        public async Task<IHttpActionResult> TodaysAlert()
        {
            return Ok(await _alertModule.GetTodaysAlert(SignedInUserId).ConfigureAwait(false));
        }

    }
}
