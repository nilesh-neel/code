﻿/****************************************************************************************************************
Class Name   : pdfController.cs
Purpose      : Provides GET for Pdf Entity
Created By   : Vivekanandan 
Created Date : 04/Dec/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh               FDS Change                                  09/01/2019         update for reference errror in solution
****************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BIPM.Business.Interface;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class PdfController : BaseApiController
    {
        private readonly IPdfModule _pdfModule;

        public PdfController(IPdfModule pdfModule)
        {
            _pdfModule = pdfModule;
        }

        /// <summary>
        /// get the pdf for the menu id
        /// </summary>
        /// <param name="menuId"></param>
        /// <returns>pdf details as json</returns>
        [HttpGet]
        public async Task<IHttpActionResult> Get(int menuId)
        {
            return Ok(await _pdfModule.Getpdfmenu(menuId).ConfigureAwait(false));
        }
    }
}