﻿/****************************************************************************************************************
Class Name   : AlertsController.cs
Purpose      : Provides GET, PUT, POST, DELETE for Alerts Entity
Created By   : Vaishnavi 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh               FDS Change                                  13/02/2019          Powerbi Role updates from database
Nilesh               FDS Change                                  13/01/2019          Web Api response message handler
****************************************************************************************************************/
using System;
using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BIPM.Business.Interface;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class AuthApiController : BaseApiController
    {

        private readonly IBpmPowerBi _bpmPowerBi;
        public AuthApiController(IBpmPowerBi bpmPowerBi)
        {
            _bpmPowerBi = bpmPowerBi;
        }

        /// <summary>
        /// get the pbi token for the report type of menu id
        /// </summary>
        /// <param name="menuId"></param>
        /// <param name="reportType"></param>
        /// <returns></returns>
        [Route("PbiToken/{menuId=menuId}/{reportType=reportType}")]
        [HttpGet]
        public async Task<IHttpActionResult> GetPbiToken(int menuId, int reportType)
        {
            return Ok(await _bpmPowerBi.EmbedReportV2(Convert.ToInt32(menuId.Equals(0) ? 2 : menuId), reportType).ConfigureAwait(false));
        }

        [Route("RefreshReport/{reportType=reportType}")]
        public IHttpActionResult Get(int reportType)
        {
            return Ok(_bpmPowerBi.ReportLastRefreshDateTime(reportType));
        }

    }
}
