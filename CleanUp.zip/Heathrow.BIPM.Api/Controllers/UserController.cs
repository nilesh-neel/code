﻿/****************************************************************************************************************
Class Name   : UserController.cs
Purpose      : Maps the user to operational area and location
Created By   : Anupama Kumari 
Created Date : 10/March/2019
Version      : 1.0
History      :
Modified By | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Anupama             FDS Change                                    20/03/2019       Getting the user details already in database                    
****************************************************************************************************************/

using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using System.Threading.Tasks;
using System.Web.Http;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class UserController : BaseApiController
    {
        private readonly IUserMapModule _userMapModule;

        /// <summary>
        /// Constructor implementation along with dependency injection
        /// </summary>
        /// <param name="user"></param>
        public UserController(IUserMapModule user)
        {
            _userMapModule = user;
        }

        /// <summary>
        ///  Saving the user data for the Logged-in User
        /// </summary>
        /// <param name="userData"> user Entity as input parameter</param>
        /// <returns>Updated user as Json</returns>
        [HttpPost]
        public async Task<IHttpActionResult> Post(User userData)
        {
            userData.UserId = userData.UserId.ToLower();
            return Ok(await _userMapModule.UpdateOperationalAreaAndLocation(userData).ConfigureAwait(false));
        }

        /// <summary>
        /// Get the user details for the Logged-in User
        /// </summary>
        /// <param></param>
        /// <returns>user details as Json</returns>
        [HttpGet]
        [Route("GetUserDetails")]
        public async Task<IHttpActionResult> Get()
        {
            var result = await _userMapModule.Fetch(SignedInUserId).ConfigureAwait(false);
            return Ok(result);
        }

        /// <summary>
        /// Get the azure authenticated user details from db to validate.
        /// </summary>
        /// <param name="strEmail"></param>
        /// <returns></returns>
        [AllowAnonymous]
        [Route("ValidateUser/{strEmail=strEmail}")]
        [HttpGet]
        public async Task<IHttpActionResult> ValidateUser(string strEmail)
        {
            if (!string.IsNullOrEmpty(strEmail))
            {
                return Ok(await _userMapModule.Fetch(strEmail).ConfigureAwait(false));
            }
            return NotFound();
        }
    }
}