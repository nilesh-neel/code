﻿/****************************************************************************************************************
Class Name   : UserBagListController.cs
Purpose      : Provides GET, PUT, POST, DELETE for Baglist Entity
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetch/Remove/Save bagtags using user's EmailId instead of userId   | 05/Dec/2018       | Logic changed
Vignesh (686552)   | BagList Entitiy as param for Post method                           | 10/Dec/2018       | Entity properties added
Vignesh (686552)   | code cleanup and updated                                           | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                                     | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class UserBagListController : BaseApiController
    {
        private readonly IBagListModule _bagListModule;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="bagList"></param>
        /// <param name="userModule"></param>
        public UserBagListController(IBagListModule bagList)
        {
            _bagListModule = bagList;
        }

        /// <summary>
        /// Get the Existing BagTags and BagTags Count of the Logged-in User
        /// </summary>
        /// <param name="otherUserId"> Logged-in userId as input parameter</param>
        /// <returns>Existing Bagtags as Json</returns>
        [HttpGet]
        public async Task<IHttpActionResult> Get(string otherUserId)
        {
            string userId = (!string.IsNullOrEmpty(otherUserId)) ? otherUserId : SignedInUserId;
            var result = await _bagListModule.GetUserExistingbagtags(userId).ConfigureAwait(false);
            return Ok(result);
        }

        /// <summary>
        ///  Saving the Added BagTags selected by the Logged-in User
        /// </summary>
        /// <param name="bagData"> BagList Entity as input parameter</param>
        /// <returns>Updated bagtags as Json</returns>
        [HttpPost]
        public async Task<IHttpActionResult> Post(BagList bagData)
        {
            var result = await _bagListModule.SaveBagTags(bagData.BagTagsJson, SignedInUserId).ConfigureAwait(false);
            return Ok(result);
        }

        /// <summary>
        /// Deleting/Removing BagTags selected by the Logged-in User
        /// </summary>
        /// <param name="bagTagValue"> Selected bagtags as input parameter</param>
        /// <param name="userId">Logged-in userId as input parameter</param>
        /// <returns>Updated bagtags as Json</returns>
        [HttpDelete]
        public async Task<IHttpActionResult> Delete(string bagTagValue)
        {
            var result = await _bagListModule.RemoveBagTags(bagTagValue, SignedInUserId).ConfigureAwait(false);
            return Ok(result);
        }

    }
}
