﻿/****************************************************************************************************************
Class Name   : MenuController.cs 
Purpose      : In this controller we are loading the menu for the weg application.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh               FDS Change                                  31/01/2019         Security code update
Nilesh               FDS Change                                  14/01/2019         Exception handling and exception logging
****************************************************************************************************************/

using System.Web.Http;
using Heathrow.BIPM.Business.Interface;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class MenuController : BaseApiController
    {

        private readonly IMenuModule _menuModule;

        public MenuController(IMenuModule menuModule)
        {
            _menuModule = menuModule;
        }

        /// <summary>
        /// Get all the menu
        /// </summary>
        /// <param></param>
        /// <returns>menu details as json</returns>
        public IHttpActionResult Get()
        {
            return Ok(_menuModule.GetAllMenu());
        }
    }
}
