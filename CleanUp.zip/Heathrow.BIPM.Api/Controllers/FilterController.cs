﻿/****************************************************************************************************************
Class Name   : FilterController.cs
Purpose      : Provides GET, POST  for Filter API
Created By   : Kannan 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Kannan              FDS Change                                   05/02/2019        Administration level handling
Kannan              FDS Change                                   15/02/2019        Passing user Id to business level
Kannan              FDS Change                                   10/01/2019        Change in dropdown values
Anupama             FDS Change                                   01/03/2019        Change in Filter Mapping
****************************************************************************************************************/

using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using System.Threading.Tasks;
using System.Web.Http;

namespace Heathrow.BIPM.Api.Controllers
{
    /// <summary>
    ///  Filter API
    /// </summary>
    [RoutePrefix("api")]
    public class FilterController : BaseApiController
    {
        private readonly IFilterModule _filterModule;

        // GET: Filter

        /// <inheritdoc />
        /// <summary>
        /// Initialize filter object and implemented constructor injection 
        /// </summary>
        /// <param name="filter" />
        /// <param name="userModule"></param>
        public FilterController(IFilterModule filter)
        {
            _filterModule = filter;

        }

        /// <summary>
        ///  To save filter data 
        /// </summary>
        /// <param name="filterData"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IHttpActionResult> Post(FilterEntity filterData)
        {
            filterData.UserId = SignedInUserId;
            return Ok(await _filterModule.SaveFilter(filterData).ConfigureAwait(false));
        }

        /// <summary>
        ///  Get save filter data by menuId
        /// </summary>
        /// <param name="menuId"></param>
        /// <returns>filter details as json</returns>

        [HttpGet]
        public async Task<IHttpActionResult> Get(int menuId)
        {
            var result = await _filterModule.FilterByMenuId(menuId, SignedInUserId).ConfigureAwait(false);
            return Ok(result);
        }

        /// <summary>
        /// Get filter control data
        /// </summary>
        /// <returns>filter details as json</returns>

        [HttpGet]
        public async Task<IHttpActionResult> Get()
        {
            FilterControlEntity result = await _filterModule.FilterConfiguration().ConfigureAwait(false);

            return Ok(result);
        }

    }
}
