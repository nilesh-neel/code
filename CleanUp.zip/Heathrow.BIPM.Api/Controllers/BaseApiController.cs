﻿/****************************************************************************************************************
Class Name   : BaseApiController.cs
Purpose      : This is the base class for all the web api controller. this class will provide sign in user id and user profile details for all the module.
Created By   : Vaishnavi 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh               FDS Change                                  16/02/2019         Change related to Powerbi Responsive window 
Nilesh               FDS Change                                  14/01/2019         Exception handling and exception logging
****************************************************************************************************************/
using System.Web.Http;
using System.Security.Claims;

namespace Heathrow.BIPM.Api.Controllers
{
    [Authorize]
    [RoutePrefix("api")]
    public class BaseApiController : ApiController
    {
        public virtual string SignedInUserId => (ClaimsPrincipal.Current.FindFirst(ClaimTypes.Upn) == null) ? string.Empty : ClaimsPrincipal.Current.FindFirst(ClaimTypes.Upn).Value;
    }
}
