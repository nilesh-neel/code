﻿/****************************************************************************************************************
Class Name   : FavoritesController.cs
Purpose      : Provides GET, PUT, POST, DELETE for Menu Favorites Module Specific for the power bi.
Created By   : Nilesh 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh              FDS Change                              05/02/2019        Administration level handling
****************************************************************************************************************/
using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Api.Controllers
{
    [RoutePrefix("api")]
    public class FavoritesController : BaseApiController
    {
        private readonly IFavouriteModule _favoritesModule;
        public FavoritesController(IFavouriteModule fav)
        {
            _favoritesModule = fav;
        }

        /// <summary>
        /// Get the favourites for the signed in user
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IHttpActionResult> Get()
        {
            var result = await _favoritesModule.GetUserFavourites(SignedInUserId).ConfigureAwait(false);
            return Ok(result);
        }

        /// <summary>
        /// To save the favourites for the user
        /// </summary>
        /// <param name="favMenu"></param>
        /// <returns></returns>
        [HttpPost]
        //[ValidateModelState]
        public async Task<IHttpActionResult> Post(Favourites favMenu)
        {
            favMenu.UserId = SignedInUserId;
            return Ok(await _favoritesModule.Save(favMenu).ConfigureAwait(false));            
        }
    }
}
