﻿/****************************************************************************************************************
Class Name   : WebAppJsonResultUtility.cs 
Purpose      : Used to define standard response for the mvc api applications. 
Created By   : Nilesh More 
Created Date : 03/Dec/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Nilesh (405285)   | Add code for HttpStatusCode.Forbidden Check.
Nilesh (405285)   | Add code for the HttpStatusCode.InternalServerError.
Nilesh (405285)   | Set Standard response in ResponseMetadata format.
****************************************************************************************************************/

using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System;
using System.Net;

namespace Heathrow.BIPM.Api.Helper
{
    public class ResponseHelper : DelegatingHandler
    {
        /// <summary>
        /// Set the standard response for the application 
        /// </summary>
        /// <param name="request">request in the current context.</param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var response = await base.SendAsync(request, cancellationToken).ConfigureAwait(false);
            try
            {
                return GenerateResponse(request, response);
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// Validate and generate the response for the current request.
        /// </summary>
        /// <param name="request">Current request </param>
        /// <param name="response">Current Response</param>
        /// <returns></returns>
        private static HttpResponseMessage GenerateResponse(HttpRequestMessage request, HttpResponseMessage response)
        {
            if (response.StatusCode == HttpStatusCode.Forbidden)
            {
                return response;
            }
            DateTime dt = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond);
            response.TryGetContentValue(out object responseContent);
            var isValidResponse = ValidateResponse(request, response, responseContent);
            if (isValidResponse != null)
            {
                return isValidResponse;
            }
            return ResponseResult(request, response, responseContent, "");
        }

        private static HttpResponseMessage ValidateResponse(HttpRequestMessage request, HttpResponseMessage response, object responseContent)
        {
            if (responseContent == null)
            {
                return null;
            }
            HttpError httpError = responseContent as HttpError;
            if (response.StatusCode == HttpStatusCode.Forbidden)
            {
                return ResponseResult(request, response, httpError.Message, httpError.Message);
            }
            if (httpError != null)
            {
                return ResponseResult(request, response, responseContent, httpError.Message);
            }
            else if (!IsResponseValid(response))
            {
                return ResponseResult(request, response, response.Content, "");
            }
            else
            {
                ResponseMetadata excpMetadata = responseContent as ResponseMetadata;
                if (excpMetadata != null && excpMetadata.StatusCode == HttpStatusCode.InternalServerError)
                { 
                    return request.CreateResponse(((ObjectContent)response.Content).Value);
                }
                return null;
            }
        }

        public static HttpResponseMessage ResponseResult(HttpRequestMessage request, HttpResponseMessage response, object responseContent, string errorMess)
        {
            if (response == null)
            {
                return request.CreateResponse(new ResponseMetadata
                {
                    Version = "1.0",
                    StatusCode = HttpStatusCode.NotFound,
                    Result = null,
                    Timestamp = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond),
                    ErrorMessage = errorMess,
                    Size = (long)0
                });
            }
            else
            {

                return request.CreateResponse(response.StatusCode, new ResponseMetadata
                {
                    Version = "1.0",
                    StatusCode = response.StatusCode,
                    Result = responseContent,
                    Timestamp = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour,
                        DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond),
                    ErrorMessage = errorMess,
                    Size = responseContent?.ToString().Length ?? (long)0
                });
            }
        }
        private static bool IsResponseValid(HttpResponseMessage response)
        {
            if ((response != null) && (response.StatusCode == HttpStatusCode.OK))
            { 
                return true;
            }
            return false;
        }

    }
    public class ResponseMetadata
    {
        public string Version { get; set; }
        public HttpStatusCode StatusCode { get; set; }
        public string ErrorMessage { get; set; }
        public object Result { get; set; }
        public DateTime Timestamp { get; set; }
        public long? Size { get; set; }
    }
}
