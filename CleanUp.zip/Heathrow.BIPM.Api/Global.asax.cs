﻿using System;
using System.Web;

namespace Heathrow.BIPM.Api
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();

            if (!(exception is HttpException httpException))
            {
                return;
            }
            string action;

            switch (httpException.GetHttpCode())
            {
                case 404:
                    // page not found
                    action = "HttpError404";
                    break;
                case 500:
                    // server error
                    action = "HttpError500";
                    break;
                default:
                    action = "Error";
                    break;
            }

            // clear error on server
            Server.ClearError();
            Response.Redirect(FormattableString.Invariant($"~/Exception/{action}/?message={exception.Message}&debug={exception.InnerException}"));
        }
        protected void Application_EndRequest()
        {
            // removing excessive headers. They don't need to see this.
            Response.Headers.Remove("X-AspNet-Version");
        }

    }
}
