﻿/****************************************************************************************************************
Class Name   : ExceptionHandler.cs 
Purpose      : This file is used to handle the Exceptions globally across the application in web Api and track those exceptions in the Azure Appinsights .......
Created By   : Vignesh AshokKumar 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Nilesh (405285)   | Add code to Get the sign in user from Claim Identity.
****************************************************************************************************************/

using System;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using Heathrow.BIPM.Utility.Common;
using System.Web.Http.ExceptionHandling;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http.Results;
using Heathrow.BIPM.Api.Helper;

namespace Heathrow.BIPM.Api.App_Start
{
    /// <summary>
    /// Application level exception and loggin handle in this class
    /// </summary>
    public sealed class ExceptionAndLogHandlers : IExceptionHandler, IExceptionLogger
    {
        /// <summary>
        /// Handle all the exception event in the application
        /// </summary>
        /// <param name="context">Current Context</param>
        /// <param name="cancellationToken">Cancellation Token</param>
        /// <returns></returns>
        public Task HandleAsync(ExceptionHandlerContext context, CancellationToken cancellationToken)
        {
            if (context == null)
            {
                return null;
            }
            else
            {
                var objErrorResponse = new ResponseMetadata
                {
                    Version = "1.0",
                    StatusCode = HttpStatusCode.InternalServerError,
                    Result = "",
                    Timestamp = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour,
                        DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond),
                    ErrorMessage = context.Exception.Message,
                    Size = 0
                };

                context.Result = new ResponseMessageResult(context.Request.CreateResponse(objErrorResponse));
                return Task.CompletedTask;
            }
        }
        /// <summary>
        /// Handle all the exception logging in application.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task LogAsync(ExceptionLoggerContext context, CancellationToken cancellationToken)
        {
            if (context == null)
            {
                return null;
            }
            else
            {
                var objectIdentifier = Convert.ToString(ClaimsPrincipal.Current.FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier"), CultureInfo.CurrentCulture);
                var userId = Convert.ToString(ClaimsPrincipal.Current.FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier"), CultureInfo.CurrentCulture);

                var SignedInUserId =
                    Convert.ToString(ClaimsPrincipal.Current
                                         .FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier")
                                         .Value ?? ClaimsPrincipal.Current
                                         .FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier").Value,
                        CultureInfo.CurrentCulture);


                if (!string.IsNullOrEmpty(objectIdentifier))
                {
                    LogUtility.LogException(context.Exception, SignedInUserId);
                }
                return Task.FromResult(0);
            }
        }
    }
}