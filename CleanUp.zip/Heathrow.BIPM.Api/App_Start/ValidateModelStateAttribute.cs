﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using Heathrow.BIPM.Api.Helper;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace Heathrow.BIPM.Api.App_Start
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Enum | AttributeTargets.Interface |AttributeTargets.Delegate)]
    public sealed class ValidateModelStateAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            if (actionContext != null && actionContext.ModelState.IsValid)
            {
                List<string> addError = actionContext.ModelState.Values.SelectMany(v => v.Errors)
                     .Select(validationError => validationError.ErrorMessage).ToList();

                var result = new ResponseMetadata
                {
                    Version = "1.0",
                    StatusCode = HttpStatusCode.Forbidden,
                    Result = "",
                    Timestamp = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour,
                        DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond),
                    ErrorMessage = string.Join("\n", addError),
                    Size = 0
                };

                actionContext.Response = new HttpResponseMessage(HttpStatusCode.Forbidden)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(result, new JsonSerializerSettings
                    {
                        ContractResolver = new CamelCasePropertyNamesContractResolver()
                    }), Encoding.UTF8, "application/json")
                };
            }
            else
            {
                return;
            }
        }


    }

}