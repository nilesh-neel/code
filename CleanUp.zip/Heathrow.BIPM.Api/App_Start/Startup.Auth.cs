﻿/****************************************************************************************************************
Class Name   : Startup.cs 
Purpose      : Used as Owin Startup class to implements authentication and authorization in Application. 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using Heathrow.BIPM.Core.Entity;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.ActiveDirectory;
using Owin;

namespace Heathrow.BIPM.Api
{
    public partial class Startup
    {
        /// <summary>
        /// In this method application validate the user credential against azure ad with OWIN middleware using OpenIdConnect authentication option.
        /// </summary>
        /// <param name="app"></param>
        public static void ConfigureAuth(IAppBuilder app)
        {
            app.UseWindowsAzureActiveDirectoryBearerAuthentication(
                 new WindowsAzureActiveDirectoryBearerAuthenticationOptions
                 {
                     Tenant = AzureAdConfig.AzureAdTenant,
                     AuthenticationMode = AuthenticationMode.Active,
                     TokenValidationParameters = new TokenValidationParameters
                     {
                         ValidAudience = AzureAdConfig.WebApiResourceId,
                     }
                     // = new JwtSecurityTokenHandler()
                 });
        }
    }
}