﻿/****************************************************************************************************************
Class Name   : WebApiConfig.cs
Purpose      : This files containg the all web api configuration like Attribute routing, default routing, custome response handdler..
Created By   : Nilesh
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Nilesh (405285)   | Add code to return the web api response in json camel case format.
Nilesh (405285)   | Code update for to register the exception and loggin at application level  

****************************************************************************************************************/
using System.Linq;
using System.Net.Http.Formatting;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;
using Heathrow.BIPM.Api.App_Start;
using Heathrow.BIPM.Api.Helper;
using Newtonsoft.Json.Serialization;

namespace Heathrow.BIPM.Api
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            if (config == null)
            {
                return;
            }

            //Enable Attribut routing..
            config.MapHttpAttributeRoutes();

            // Configure Customer response Handdler.
            config.MessageHandlers.Add(new ResponseHelper());

            // Web API routes
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            // return the web api response in json camel case format.
            var jsonFormatter = config.Formatters.OfType<JsonMediaTypeFormatter>().FirstOrDefault();
            if (jsonFormatter != null)
            {
                jsonFormatter.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                config.Formatters.Clear();
                config.Formatters.Add(jsonFormatter);
            }

            // Global Custom Expection Handler
            config.Services.Replace(typeof(IExceptionHandler), new ExceptionAndLogHandlers());
            // Global Custom Log Handler
            config.Services.Replace(typeof(IExceptionLogger), new ExceptionAndLogHandlers());
        }
    }
}
