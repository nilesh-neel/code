﻿/****************************************************************************************************************
Class Name   : NotesController.cs
Purpose      : Provides GET, PUT, POST, DELETE for Notes Entity
Created By   : Vignesh AshokKumar  
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Web.Http.ExceptionHandling;
using Unity;
using Unity.Lifetime;
using Heathrow.BIPM.Api.App_Start;
using Heathrow.BIPM.Business.Helper;


namespace Heathrow.BIPM.Api
{
    public class ApiBootstrap
    {
        private ApiBootstrap()
        {
        }

        public static IUnityContainer BuildUnityContainer()
        {
            var container = new UnityContainer();

            container.AddNewExtension<ChildDependencyExtension>();
            container.BindInSingletonScope<IExceptionHandler, ExceptionAndLogHandlers>();
            container.BindInSingletonScope<IExceptionLogger, ExceptionAndLogHandlers>();
            return container;
        }
    }

    public static class UnityIocExtensions
    {
        internal static void BindInSingletonScope<T1, T2>(this IUnityContainer container) where T2 : T1
        {
            container.RegisterType<T1, T2>(new ContainerControlledLifetimeManager());
        }
    }
}