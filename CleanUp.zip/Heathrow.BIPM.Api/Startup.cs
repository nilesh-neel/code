/****************************************************************************************************************
Class Name   : Startup.cs 
Purpose      : Used as Owin Startup class to implements authentication and authorization in Application. 
Created By   : Nilesh 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Cors;
using System.Web.Http;
using Heathrow.BIPM.Api;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Utility.Constants;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using Owin;
using Unity.Interception.Utilities;

[assembly: OwinStartup(typeof(Startup))]
namespace Heathrow.BIPM.Api
{

    public partial class Startup
    {
        private Startup()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="app"></param>
        public static void Configuration(IAppBuilder app)
        {
            HttpConfiguration config = new HttpConfiguration()
            {
                DependencyResolver = new Unity.WebApi.UnityDependencyResolver(ApiBootstrap.BuildUnityContainer())
            };
            WebApiConfig.Register(config);
            ConfigureAuth(app);

            var corsPolicy = new CorsPolicy
            {
                PreflightMaxAge = 21600,
                SupportsCredentials = true,
                Origins = { AzureAdConfig.AadAuthorityUri.ToString().TrimEnd('/'),
                    AzureAdConfig.RedirectUrl.ToString().TrimEnd('/'),
                    AzureAdConfig.WebApiUrl.ToString().TrimEnd('/')

                }
            };

            MessageConstants.CrosHeaders.ForEach(d => corsPolicy.Headers.Add(d));
            MessageConstants.CrosMethods.ForEach(d => corsPolicy.Methods.Add(d));

            var corsOptions = new CorsOptions
            {
                PolicyProvider = new CorsPolicyProvider
                {
                    PolicyResolver = context => Task.FromResult(corsPolicy)
                }
            };

            //Configuring�X-Content-Type-Options
            app.UseXContentTypeOptions();
            //Configuring�X-Frame�-�Options
            app.UseXfo(options => options.Deny());
            //Configuring�Strict-Transport�-�Security
            app.UseHsts(options => options.MaxAge(days: 1).IncludeSubdomains());
            //Configuring�X-XSS�-�Protection
            app.UseXXssProtection(options => options.EnabledWithBlockMode());
            //Configuring�X-Download-Options
            app.UseXDownloadOptions();
            //Redirect�validation
            app.UseRedirectValidation(options => options.AllowedDestinations(AzureAdConfig.RedirectUrl.ToString(), AzureAdConfig.WebApiUrl.ToString()).AllowSameHostRedirectsToHttps());
            app.UseCors(corsOptions);
            app.UseWebApi(config);
        }
    }
}