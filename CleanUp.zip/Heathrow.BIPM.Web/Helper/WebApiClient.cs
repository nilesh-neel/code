﻿/****************************************************************************************************************
Class Name   : ExceptionHandling.cs 
Purpose      : This file is used to handle the Exceptions globally across the application in Web project and track those exceptions in the Azure Appinsights .......
Created By   : Vignesh AshokKumar 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using System.Security.Claims;
using System.Net;
using System.Text;
using System.Net.Http;
using System.Web.Script.Serialization;
using System.Net.Http.Headers;
using System.Globalization;
using Newtonsoft.Json;
using Heathrow.BIPM.Utility.Common;

namespace Heathrow.BIPM.Web.Helper
{

    public static class WebApiClient
    {
        public static async Task<ResponseMetadata> GetResponseContent(string apiPattern, HttpMethod methodType,
            object requestData, string contentType)
        {
            try
            {
                if (string.IsNullOrEmpty(contentType))
                {
                    contentType = "application/json";
                }
                HttpClient client = new HttpClient();
                string fullPath = AzureAdConfig.WebApiUrl.ToString() + apiPattern;
                HttpRequestMessage request = new HttpRequestMessage(methodType, fullPath);
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", await TokenUtility.GetAccessTokenAsync(AzureAdConfig.WebApiResourceId, false).ConfigureAwait(false));
                if (methodType == HttpMethod.Post || methodType == HttpMethod.Put)
                {
                    request.Content = new StringContent(
                        new JavaScriptSerializer().Serialize(requestData), Encoding.UTF8, "application/json");
                }

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(contentType));

                HttpResponseMessage response = await client.SendAsync(request).ConfigureAwait(false);

                // If successful, Microsoft Graph returns a 200 OK status code and the photo's binary data. If no photo exists, returns 404 Not Found.
                string result = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                return JsonConvert.DeserializeObject<ResponseMetadata>(result);
            }
            catch (Exception ex)
            {
                var userId =
                    Convert.ToString(ClaimsPrincipal.Current
                                         .FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier")
                                         .Value ?? ClaimsPrincipal.Current
                                         .FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier")
                                         .Value, CultureInfo.CurrentCulture);

                LogUtility.LogException(ex, userId);

                return new ResponseMetadata
                {
                    version = "1.0",
                    statusCode = HttpStatusCode.InternalServerError,
                    result = "",
                    timestamp = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour,
                        DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond),
                    errorMessage = ex.Message,
                    size = 0
                };

            }
        }


        public static async Task<ResponseMetadata> GetAnonymousApiContent(string apiPattern, HttpMethod methodType, object requestData, string contentType)
        {
            try
            {
                if (string.IsNullOrEmpty(contentType))
                {
                    contentType = "application/json";
                }
                HttpClient client = new HttpClient();
                string fullPath = AzureAdConfig.WebApiUrl.ToString() + apiPattern;
                HttpRequestMessage request = new HttpRequestMessage(methodType, fullPath);
                if (methodType == HttpMethod.Post || methodType == HttpMethod.Put)
                {
                    request.Content = new StringContent(
                        new JavaScriptSerializer().Serialize(requestData), Encoding.UTF8, "application/json");
                }

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(contentType));

                HttpResponseMessage response = await client.SendAsync(request).ConfigureAwait(false);

                // If successful, Microsoft Graph returns a 200 OK status code and the photo's binary data. If no photo exists, returns 404 Not Found.
                string result = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                return JsonConvert.DeserializeObject<ResponseMetadata>(result);
            }
            catch (Exception ex)
            {
                var userId =
                    Convert.ToString(ClaimsPrincipal.Current
                                         .FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier")
                                         .Value ?? ClaimsPrincipal.Current
                                         .FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier")
                                         .Value, CultureInfo.CurrentCulture);

                LogUtility.LogException(ex, userId);

                return new ResponseMetadata
                {
                    version = "1.0",
                    statusCode = HttpStatusCode.InternalServerError,
                    result = "",
                    timestamp = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour,
                        DateTime.Now.Minute, DateTime.Now.Second, DateTime.Now.Millisecond),
                    errorMessage = ex.Message,
                    size = 0
                };

            }
        }


    }

    public class ResponseMetadata
    {
        public string version { get; set; }
        public HttpStatusCode statusCode { get; set; }
        public string errorMessage { get; set; }
        public object result { get; set; }
        public DateTime timestamp { get; set; }
        public long? size { get; set; }
    }

}