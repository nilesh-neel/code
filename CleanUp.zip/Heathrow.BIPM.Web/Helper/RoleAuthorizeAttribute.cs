﻿/****************************************************************************************************************
Class Name   : RoleAuthorizeAttribute.cs 
Purpose      : To check log in user authentication with role and if the user is authenticated, but we ended up here, it means that
//           : the user is not in a role that's allowed to use the controller being called  
Created By   : Nilesh More 
Created Date : 04/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System;
using System.Web.Mvc;

namespace Heathrow.BIPM.Web.Infrastructure
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public sealed class RoleAuthorizeAttribute : AuthorizeAttribute
    {
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (filterContext!=null)
            {
                // If the user is authenticated, but we ended up here, it means that
                // the user is not in a role that's allowed to use the controller being called
                if (filterContext.HttpContext.User.Identity.IsAuthenticated)
                { 
                    filterContext.HttpContext.Response.RedirectToRoute("Registration/RegistrationPage");
                }
                else
                { 
                    filterContext.Result = new HttpUnauthorizedResult();
                }
            }
        }
    }
}