﻿/****************************************************************************************************************
Class Name   : ExceptionHandling.cs 
Purpose      : This file is used to handle the Exceptions globally across the application in Web project and track those exceptions in the Azure Appinsights .......
Created By   : Vignesh AshokKumar 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Web.Mvc;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.Helper;
using Heathrow.BIPM.Web.ViewModel;
using Unity;
using Unity.Lifetime;
using Unity.Mvc5;

namespace Heathrow.BIPM.Web
{
    public sealed class Bootstrap
    {
        private Bootstrap()
        {

        }

        public static void Initialise()
        {
            var container = BuildUnityContainer();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }

        internal static IUnityContainer BuildUnityContainer()
        {
            var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // Database context, one per request, ensure it is disposed

            //Bind the various domain model services and repositories that e.g. our controllers require         

            container.BindInRequestScope<IMapper<FavouritesVM, Favourites>, FavouriteMapping>();
            //container.BindInRequestScope<IMapper<RegistrationVM, Registration>, RegistrationMapping>();
            container.BindInRequestScope<IMapper<NotificationVM, Notification>, NotificationMapping>();

            container.BindInRequestScope<IMapper<AlertVM, Alerts>, AlertMapping>();

            container.BindInRequestScope<IMapper<LookupVM, Lookup>, LookupMapping>();
            container.BindInRequestScope<IMapper<PowerBiVM, PowerBiEmbedConfig>, PowerBiVMMapping>();
            return container;
        }

    }
    public static class UnityIocExtensions
    {
        internal static void BindInRequestScope<T1, T2>(this IUnityContainer container) where T2 : T1
        {
            container.RegisterType<T1, T2>(new HierarchicalLifetimeManager());
        }
    }

}