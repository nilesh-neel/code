﻿/****************************************************************************************************************
Class Name   : Startup.cs 
Purpose      : In This class we use Owin Middleware to sent all initial configuration of OAUTH2, to trigger the
             : Azure authentication.  
Created By   : Nilesh More 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web;
using Heathrow.BIPM.Core.Entity;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.Notifications;
using Microsoft.Owin.Security.OpenIdConnect;
using Owin;
using Heathrow.BIPM.Utility.Common;
using System.IdentityModel.Claims;
using System.Net;
using Heathrow.BIPM.Utility.Constants;
using Microsoft.Identity.Client;
using System.Net.Http;
using Heathrow.BIPM.Web.Helper;
using Newtonsoft.Json;
using Heathrow.BIPM.Web.ViewModel;

namespace Heathrow.BIPM.Web
{
    public partial class Startup
    {
        private string _currentUserEmail = string.Empty;
        /// <summary>
        /// In this method application validate the user credential against azure ad with OWIN middleware using OpenIdConnect authentication option.
        /// </summary>
        /// <param name="app">Object Of Owin App builder inject By Owin Startup dll.</param>

        public void ConfigureAuth(IAppBuilder app)
        {
            // Enable the application to use a cookie to store information for the signed in user 
            // and to use a cookie to temporarily store information about a user logging in with a third party login provider 
            app.SetDefaultSignInAsAuthenticationType(CookieAuthenticationDefaults.AuthenticationType);
            app.UseCookieAuthentication(GetCookieAuthenticationOptions());
            app.UseOpenIdConnectAuthentication(
                new OpenIdConnectAuthenticationOptions
                {
                    ClientId = AzureAdConfig.ClientId,
                    Authority = AzureAdConfig.AadAuthorityUri.ToString(),
                    UseTokenLifetime = false,
                    RedirectUri = AzureAdConfig.RedirectUrl.ToString(),
                    TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = false,
                    },
                    Notifications = new OpenIdConnectAuthenticationNotifications
                    {
                        AuthorizationCodeReceived = OnAuthorizationCodeReceivedAsync,
                        AuthenticationFailed = OnAuthenticationFailedAsync,
                        RedirectToIdentityProvider = OnRedirectToIdentityProvider,
                        SecurityTokenValidated = OnSecurityTokenValidated,
                    }
                });
        }


        /// <summary>
        /// Configure the sign in cookie like Ites Name, Security, Expiration etc..
        /// </summary>
        /// <returns></returns>
        private static CookieAuthenticationOptions GetCookieAuthenticationOptions()
        {
            var options = new CookieAuthenticationOptions
            {
                CookieHttpOnly = true,
                CookieSecure = CookieSecureOption.Always,
                CookieName = MessageConstants.OwinCookieName,
                SlidingExpiration = false,
                // ExpireTimeSpan = TimeSpan.FromMinutes(AzureAdConfig.SessionAndCookieTimeOut),// set cookies timeout 
                Provider = new CookieAuthenticationProvider
                {
                    OnResponseSignIn = ctx =>
                    {
                        ctx.Properties.IsPersistent = true;
                        var ticks = ctx.Options.SystemClock.UtcNow.AddMinutes(AzureAdConfig.SessionAndCookieTimeOut).UtcTicks;
                        ctx.Properties.Dictionary.Add("absolute", ticks.ToString());
                    }
                }

            };
            return options;
        }

        /// <summary>
        /// Method will redirect the request to authr provider like azure login page or logout page
        /// </summary>
        /// <param name="context">Context is object of Owin Security Curent Context/Requests </param>
        /// <returns></returns>
        private static Task OnRedirectToIdentityProvider(RedirectToIdentityProviderNotification<OpenIdConnectMessage, OpenIdConnectAuthenticationOptions> context)
        {
            switch (context.ProtocolMessage.RequestType)
            {
                case OpenIdConnectRequestType.Authentication:
                {
                    var redirectUri = context.ProtocolMessage.CreateAuthenticationRequestUrl();
                    context.OwinContext.Response.Redirect(redirectUri);
                    context.HandleResponse();
                    break;
                }
                case OpenIdConnectRequestType.Logout:
                {
                    var redirectUri = context.ProtocolMessage.CreateLogoutRequestUrl();
                    //replace this to move directly on logout page insted of open pick up account to logout
                    context.OwinContext.Response.Redirect(redirectUri.Replace("/v2.0/", "/"));
                    context.HandleResponse();
                    break;
                }
                case OpenIdConnectRequestType.Token:
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
            return Task.FromResult(0);
        }

        /// <summary>
        /// On Successfully authentication use will redirect here, to acuqire the token from authrize code and save the toekn in cache.
        /// </summary>
        /// <param name="notification">this is the current Owing object with response from the azure autharization/claim details.</param>
        /// <returns></returns>
        private async Task OnAuthorizationCodeReceivedAsync(AuthorizationCodeReceivedNotification notification)
        {
            try
            {
                var httpContext = notification.OwinContext.Environment["System.Web.HttpContextBase"] as HttpContextBase;
                string signedInUserId = notification.AuthenticationTicket.Identity.FindFirst(ClaimTypes.NameIdentifier).Value;

                TokenCache userTokenCache = new KsSessionTokenCacheUtility(signedInUserId, httpContext).GetMsalCacheInstance();
                ConfidentialClientApplication cc = new ConfidentialClientApplication(AzureAdConfig.ClientId, AzureAdConfig.RedirectUrl.ToString(),
                    new ClientCredential(AzureAdConfig.ClientSecret), userTokenCache, null);
                notification.AuthenticationTicket.Properties.AllowRefresh = true;
                AuthenticationResult result = await cc.AcquireTokenByAuthorizationCodeAsync(notification.Code, new[] { "user.readbasic.all" }).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                const string message = "OnAuthorizationCodeReceivedAsync threw an exception";
                LogUtility.LogException(ex, _currentUserEmail);
                notification.HandleResponse();
                notification.Response.Redirect(FormattableString.Invariant($"/Exception/StartUpError?message={message}&exception={ex.Source}"));
            }
        }

        /// <summary>
        /// If any exception occure while validation or generating the autharization code /access token this methoe will be trigger to handle the exception.
        /// </summary>
        /// <param name="notification"></param>
        /// <returns></returns>
        private static Task OnAuthenticationFailedAsync(AuthenticationFailedNotification<OpenIdConnectMessage,
            OpenIdConnectAuthenticationOptions> notification)
        {
            notification.HandleResponse();

            if (notification.Exception.GetType().Name == "UnauthorizedAccessException")
            {
                string redirect = FormattableString.Invariant($"/Exception/StartUpError?statusCode=401&message=Un-Authorized Access&exception={new UnauthorizedAccessException()}");
                notification.Response.Redirect(redirect);
            }
            else
            {
                string redirect = FormattableString.Invariant($"/Exception/StartUpError?statusCode=500&message={notification.Exception.Message}&exception={notification.Exception}");
                notification.Response.Redirect(redirect);
            }

            return Task.FromResult(0);
        }

        private Task OnSecurityTokenValidated(
            SecurityTokenValidatedNotification<OpenIdConnectMessage, OpenIdConnectAuthenticationOptions> context)
        {
            _currentUserEmail = context.AuthenticationTicket.Identity.FindFirst("preferred_username").Value;
            using (var client = new HttpClient())
            {
                var response = client.GetAsync(AzureAdConfig.WebApiUrl.ToString() + "api/ValidateUser?strEmail=" + _currentUserEmail.ToString()).Result;
                if (!response.IsSuccessStatusCode)
                {
                    throw new UnauthorizedAccessException("registrationRequired");
                }
                var result = response.Content.ReadAsStringAsync().Result;
                var registration = JsonConvert.DeserializeObject<ResponseMetadata>(result);
                if (registration.statusCode != HttpStatusCode.OK || registration.result == null ||
                    ((Newtonsoft.Json.Linq.JArray) registration.result).Count <= 0)
                {
                    throw new UnauthorizedAccessException("registrationRequired");
                }
                string json = JsonConvert.SerializeObject(registration.result);
                if (string.IsNullOrEmpty(json))
                {
                    throw new UnauthorizedAccessException("registrationRequired");
                }
                var objDbUser = JsonConvert.DeserializeObject<IList<UserVM>>(json);
                var displayName = context.AuthenticationTicket.Identity.FindFirst("name").Value;
                var userRole = context.AuthenticationTicket.Identity
                    .FindFirst("http://schemas.microsoft.com/ws/2008/06/identity/claims/role").Value;

                var objuser = new AzureAdUser
                {
                    Id = objDbUser[0].userId,
                    Name = displayName.Length <= 6
                        ? displayName
                        : displayName.Substring(0, 6) + "...",
                    DisplayName = displayName,
                    Email = _currentUserEmail,
                    //Phone = objDbUser[0].phoneNumber,
                    Organization = objDbUser[0].organization,
                    Role = userRole,
                    //Locations = (IEnumerable<Lookup>)objDbUser[0].location,
                    //JobRoles = (IEnumerable<Lookup>)objDbUser[0].location,
                    Avatar = null
                };

                SessionUtility.Set(SessionConstants.LoggedUser, objuser);
            }
            return Task.FromResult(0);
        }
    }
}