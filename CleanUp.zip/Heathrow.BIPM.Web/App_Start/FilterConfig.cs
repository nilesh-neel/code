﻿/****************************************************************************************************************
Class Name   : ExceptionHandling.cs 
Purpose      : This file is used to handle the Exceptions globally across the application in Web project and track those exceptions in the Azure Appinsights .......
Created By   : Vignesh AshokKumar 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Web.Mvc;
using Heathrow.BIPM.Web.Filters;

namespace Heathrow.BIPM.Web
{
    public class FilterConfig
    {
        private FilterConfig()
        {

        }
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new ExceptionHandlingAttribute());//exception Handling
            filters.Add(new SessionExpireFilterAttribute());//session null check..
        }
    }
}