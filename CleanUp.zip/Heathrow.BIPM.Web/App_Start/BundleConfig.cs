﻿/****************************************************************************************************************
Class Name   : ExceptionHandling.cs 
Purpose      : This file is used to handle the Exceptions globally across the application in Web project and track those exceptions in the Azure Appinsights .......
Created By   : Vignesh AshokKumar 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Web.Optimization;

namespace Heathrow.BIPM.Web
{
    public static class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at https://modernizr.com to pick only the tests you need.

            if (bundles == null) return;
            bundles.Add(new Bundle("~/bundles/vendor").Include(
                "~/Scripts/vendor/jquery-3.3.1.min.js",
                "~/Scripts/vendor/jquery-ui.min.js",
                "~/Scripts/vendor/bootstrap.min.js",
                "~/Scripts/plugins/es-shim.min.js",
                "~/Scripts/vendor/powerbi/powerbi.min.js",
                "~/Scripts/vendor/powerbi/powerBIApp.js",
                //"~/Scripts/vendor/axios.min.js",
                "~/Scripts/plugins/jquery.fullscreen-min.js",
                "~/Scripts/plugins/lodash.min.js",
                "~/Scripts/vendor/quagga/adapter-latest.js",
                "~/Scripts/vendor/quagga/quagga.min.js",
                "~/Scripts/plugins/jquery.dataTables.min.js",
                "~/Scripts/plugins/moment.min.js",

                "~/Scripts/plugins/jquery.unobtrusive-ajax.min.js",
                "~/Scripts/plugins/daterangepicker.js",
                "~/Scripts/plugins/bootstrap-multiselect.js",
                "~/Scripts/plugins/ion.rangeSlider.min.js",
                "~/Scripts/plugins/comboBox.js",
                "~/Scripts/plugins/jquery.scrollbar.min.js",
                "~/Scripts/plugins/jquery.cookie.js",
                "~/Scripts/plugins/script.js"
            ));

            bundles.Add(new Bundle("~/bundles/appJS").IncludeDirectory(
                "~/Scripts/App/", "*.js", true));

            bundles.Add(new Bundle("~/bundles/notif").Include(
                //"~/Scripts/jquery.unobtrusive-ajax.js",             
                "~/Scripts/App/common/editForm.js",
                "~/Scripts/plugins/jquery.validate.min.js",
                "~/Scripts/plugins/jquery.validate.unobtrusive.min.js"
            ));

            bundles.Add(new StyleBundle("~/bundles/Content").Include(
                "~/Content/bootstrap.min.css",
                "~/Content/jquery-ui.min.css",
                "~/Content/bootstrap-theme.css",
                "~/Content/bootstrap-theme.min.css",
                //"~/Content/bootstrap.css",
                "~/Content/jquery.dataTables.min.css",
                "~/Content/daterangepicker.css",
                "~/Content/ion.rangeSlider.css",
                "~/Content/bootstrap-multiselect.css",
                "~/Content/jquery.scrollbar.css",
                "~/Content/skin2.css",
                "~/Content/barcodescan.css",
                "~/Content/baglist.css",
                "~/Content/custome.css",
                "~/Content/style.css"
            ));

#if DEBUG
            BundleTable.EnableOptimizations = false;
#else
                                    BundleTable.EnableOptimizations = true;
#endif
        }
    }
}