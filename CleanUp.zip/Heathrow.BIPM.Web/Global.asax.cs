﻿

using Heathrow.BIPM.Web.Controllers;
using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Heathrow.BIPM.Web
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            MvcHandler.DisableMvcResponseHeader = true;
            // add for the registration page ValidateAntiForgery token,
            System.Web.Helpers.AntiForgeryConfig.UniqueClaimTypeIdentifier = System.Security.Claims.ClaimTypes.NameIdentifier;
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();

            var routeData = new RouteData();
            routeData.Values.Add("controller", "Exception");
            routeData.Values.Add("action", "Error");
            routeData.Values.Add("exception", exception);



            if (exception.GetType() == typeof(HttpException))
            {
                routeData.Values.Add("statusCode", ((HttpException)exception).GetHttpCode());
            }
            else
            {
                routeData.Values.Add("statusCode", 500);
            }

            Response.TrySkipIisCustomErrors = true;
            IController controller = new ExceptionController();
            controller.Execute(new RequestContext(new HttpContextWrapper(Context), routeData));
            Response.End();

        }

        protected void Application_EndRequest()
        {
            if (Context.Items["AjaxPermissionDenied"] is bool)
            {
                Context.Response.StatusCode = 401;
                Context.Response.End();
            }
        }
    }
}
