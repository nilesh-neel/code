﻿/****************************************************************************************************************
Class Name   : ExceptionHandling.cs 
Purpose      : This file is used to handle the Exceptions globally across the application in Web project and track those exceptions in the Azure Appinsights .......
Created By   : Vignesh AshokKumar 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BIPM.Utility.Common;
using System;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Heathrow.BIPM.Web.Filters
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Enum | AttributeTargets.Interface | AttributeTargets.Delegate)]
    public sealed class ExceptionHandlingAttribute : HandleErrorAttribute
    {
        public override void OnException(ExceptionContext filterContext)
        {
            base.OnException(filterContext);

            filterContext.ExceptionHandled = true;
            filterContext.HttpContext.Session.RemoveAll();
            //set this to true so that IIS 7 does not use its own error pages
            filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;

            LogUtility.LogException(filterContext.Exception, (ClaimsPrincipal.Current.FindFirst(ClaimTypes.Upn) != null) ?
                ClaimsPrincipal.Current.FindFirst(ClaimTypes.Upn).Value :
                ClaimsPrincipal.Current.FindFirst("preferred_username").Value);

            int statusCode = 500;
            if (filterContext.Exception is HttpException exception)
            {
                statusCode = exception.GetHttpCode();
            }
            filterContext.Result = new RedirectToRouteResult(
                new RouteValueDictionary
                {
                    {"controller", "Exception"},
                    {"action", "Error"},
                    {"statusCode", statusCode},
                    { "message", "Internal Server Error.."},
                    { "exception",new Exception("Unhandled error occurred")}
                });
        }
    }


}