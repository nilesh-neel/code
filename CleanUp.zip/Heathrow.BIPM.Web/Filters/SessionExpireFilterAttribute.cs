﻿using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Utility.Constants;
using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Heathrow.BIPM.Web.Filters
{
    [AttributeUsage(AttributeTargets.Method, Inherited = true, AllowMultiple = false)]
    public class CheckSessionTimeOutAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(System.Web.Mvc.ActionExecutingContext filterContext)
        {
            var context = filterContext.HttpContext;
            if (context.Session != null)
            {
                if (context.Session.IsNewSession)
                {
                    string sessionCookie = context.Request.Headers["Cookie"];
                    if ((sessionCookie != null) && (sessionCookie.IndexOf("ASP.NET_SessionId") >= 0))
                    {
                        //  FormsAuthentication.SignOut();
                        string redirectTo = "~/Account/SingIn";
                        if (!string.IsNullOrEmpty(context.Request.RawUrl))
                        {
                            redirectTo = string.Format("~/Home/Login?ReturnUrl={0}",
                                HttpUtility.UrlEncode(context.Request.RawUrl));
                        }

                        filterContext.HttpContext.Response.Redirect(redirectTo, true);
                    }
                }
            }

            base.OnActionExecuting(filterContext);
        }
    }


    [AttributeUsage(AttributeTargets.Method, Inherited = true, AllowMultiple = false)]
    public class CheckSessionOutAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var context = filterContext.HttpContext;
            if (context.Session != null)
            {
                if (context.Session.IsNewSession)
                {
                    string sessionCookie = context.Request.Headers["Cookie"];

                    if ((sessionCookie != null) && (sessionCookie.IndexOf("ASP.NET_SessionId") >= 0))
                    {
                        //FormsAuthentication.SignOut();
                        string redirectTo = "~/Account/Login";
                        if (!string.IsNullOrEmpty(context.Request.RawUrl))
                        {
                            redirectTo = string.Format("~/Account/Login?ReturnUrl={0}",
                                HttpUtility.UrlEncode(context.Request.RawUrl));
                        }

                    }
                }
            }

            base.OnActionExecuting(filterContext);
        }
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
    public class SessionExpireFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            HttpContext ctx = HttpContext.Current;
            string controllerName = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
            string actionName = filterContext.ActionDescriptor.ActionName;

            if (ctx.Session.IsNewSession && !controllerName.Equals("Exception") && !controllerName.Equals("Account"))
            {
                // If the browser session or authentication session has expired...
                if (ctx.Session[SessionConstants.LoggedUser] == null || ctx.Session.IsNewSession)
                {

                    if (filterContext.HttpContext.Request.IsAjaxRequest())
                    {

                        // For AJAX requests, we're overriding the returned JSON result with a simple string,

                        // indicating to the calling JavaScript code that a redirect should be performed.

                        // filterContext.Result = new JsonResult { Data = "_Logon_" };

                        filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary
                        {
                            {"Controller", "Account"},
                            {"Action", "SignIn"}

                        });
                    }
                    else
                    {
                        filterContext.HttpContext.Session.Clear();
                        filterContext.HttpContext.Session.RemoveAll();
                        filterContext.HttpContext.Session.Abandon();
                        filterContext.HttpContext.Response.AddHeader("Cache-control", "no-store, must-revalidate, private, no-cache");
                        filterContext.HttpContext.Response.AddHeader("Pragma", "no-cache");
                        filterContext.HttpContext.Response.AddHeader("Expires", "0");
                        filterContext.HttpContext.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
                        filterContext.HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                        filterContext.HttpContext.Response.Cache.SetNoStore();
                        //ctx.Request.GetOwinContext().Authentication.SignOut();
                        filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary
                        {
                            {"Controller", "Account"},
                            {"Action", "SignIn"}

                        });
                    }
                }
                else
                {
                    HttpContext.Current.Session.Timeout = AzureAdConfig.SessionAndCookieTimeOut;
                }
            }
            base.OnActionExecuting(filterContext);
        }
    }
}