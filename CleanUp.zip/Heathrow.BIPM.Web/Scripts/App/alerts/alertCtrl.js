﻿//----------------------------------------------------------------------
//Class Name   : Alert Controller
//Purpose      : This is used to handle all jquery click event related with Alert CRUD method.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By  :      | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Vignesh(686552)     | CCAP                                      |  02/07/2019       | CCAP issue fix
//Vaishnavi.R(687417) | FDS requirement                           |  11/27/2018       | Included Alert Icon functionality                                                                                       
//--------------------------------------------------------------------------------------------------------------------

(function ($) {
    'use strict';
    $(document).ready(function () {
        var alert = new Alert();
        var configTab = new TabConfig(true, false, false, false);
        $(".alerts").click(alertIcon);

        $('.settingsIcon').click(SettingsController);
        $('.setting').click(SettingsController);
        $('#viewAllBtn').click(SettingsController);

        $('#congigureNewAlertBtn').click(newAlert);
        $('#configureBackBtn').click(AlertBack);

        $('#tabs a[href="#todaysAlerts"]').click(todaysAlert);
        $('#tabs a[href="#alertSettings"]').click(myAlertSettings);
        $('#tabs a[href="#configureAlerts"]').click(configureAlert);
     
        /**
       // Closes row expansion when control is moved from one tab to another
          */
        function closeExpansion() {
            $('.details').hide();
            var me = $('.showDetailsActive :last');
            var nTr = $($('#cancelBtn')[0]).closest('div').closest('tr').prev();
            var otable = $('.showDetailsActive').closest('table').dataTable();
            var prevClickedIcon = '.Show_details';
            otable.fnClose(nTr);
            $(me).closest("tr").find("td").toggleClass("showDetailsActive");
            $(me).removeClass("clickedIcons");
            $(me).toggleClass("customBorderSmall");
            $(me).next().toggleClass("clickedIcons");
            $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
        }
        /**
         // Used to load last five triggered alert in chronological order
            */
        function alertIcon() {
            event.preventDefault();
            event.stopPropagation();
            var alert = new Alert();
            alert.AlertCount();
            alert.AlertIcon();
            $(this).children(".spanNotification").css("display", "none");
            $(this).toggleClass("alertsClicked");
            $(".alertPopup").toggle();
            $(".settingsLogout").hide();
        }
        /**
         // Used to load landing page on click of settings icon
            */
        function SettingsController() {
            if (!window.location.href.includes("Alerts")) {
                window.location.href = baseUrl + '/Alerts/Index/';
                Menu.prototype.LinkingEmbedToPbi.call(this, 46);
                $('a[href="#todaysAlerts"]').trigger('click');
            }
            else {
                $('a[href="#alerts"]').click();
            }

        }
        /**
         // Click event for configure new alert form 
            */
        function newAlert() {
            Menu.prototype.LinkingEmbedToPbi.call(this, 46);
            configTab.NewConfigurationButtonClick();
        }
        /**
       // Click event for back button
          */
        function AlertBack() {
            Menu.prototype.LinkingEmbedToPbi.call(this, 46);
            configTab.BackButtonClick();
        }
         /**
       // Click event for todays alert tab
          */
        function todaysAlert() {
            alert.LoadAlertsLandingPage();

        }
         /**
       // Click event for my alert settings
          */
        function myAlertSettings() {
            closeExpansion();
            alert.BindMyAlertsSettings();
        }
        /**
       // Click event for my configure alert
          */
        function configureAlert() {
            $('#congigureNewAlertBtn').text('Configure New Alert');
            $('#congigureNewAlertBtn').css('display', 'block');
            $('.configureAlertForm').css('display', 'none');
            $('.dataTables_paginate').css('display', 'block');
            closeExpansion();
            alert.BindConfigureAlerts();
        }
      


    });
})(jQuery);