﻿//----------------------------------------------------------------------
//Class Name   : Alert
//Purpose      : This is used for binding all configured/triggerd alerts available and update its corresponding response
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By  :      | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Vaishnavi.R(687417) | FDS requirement                           |  12/06/2018       | Included Alert Icon functionality   
//--------------------------------------------------------------------------------------------------------------------

//To Display alert count and marquee notification every fifteen minutes
$(document).ready(function () {
    var alert = new Alert();
    var notifications = new Notifications();
    $('.alertnotif').css("display", "none");
    setInterval(function () {
        alert.AlertCount();
        notifications.ScrollingNotifications();
    }, 900000);
});
var Alert = (function () {
    var alertHtml = '';
    'use strict';
    var service;
    var alertData = {};
    var alertNotificationData = {};
    var todaysAlertData = {};
    /****
     * Creates a new Alert object.
     * @constructor
     *
     */
    Alert = function () {
        alertHtml = '';
        $('#loading').hide();     
    };
    /****
     * This  method use to load default Landing page for the alert, notification, report and assign home page module
     */
    Alert.prototype.LoadAlertsLandingPage = function () {
        $('#dvPowerBiEmbed').hide();
        $('#viewContainer').show();
        this.BindTodayAlerts();     
    };
    /****
     *  This  method use to bind data to the Todays Alert Tab
     *  */
    Alert.prototype.BindTodayAlerts = function () {
        service = new Service('api/TodaysAlert/');
        service.getApi()
            .then(function (resp) {
                todaysAlertData = _.map(resp, function (x) {
                    return {
                        AlertId: x.alertId,
                        Message: x.message,
                        Title: x.title,
                        DateAndTime: moment(x.createdDate).format("HH:mm"),
                        MandatoryOptional: x.mandatory,
                        Response: '<p class="IconsStyles"><span class="' + (x.responseType === 1 ? 'Tick_mark_Fill' : 'Tick_mark_Fill_white') + '"></span> <span class="' + ((x.mandatory===0)?(x.responseType === 2 ? 'ignore_red_fill' : 'ignore_white_fill'):'') + '"></span> <span class="' + (x.responseType === 3 ? 'blank_out_yellow_fill' : 'blank_out_white_fill') + '"></span> </p>',
                        ResponseID: x.responseType,
                        TodaysLocation: x.todaysLocation,
                        Topic: x.topic,
                        View: '<span class="Show_details  defaultIcons"></span>'
                    };
                });

                var column = [
                    { "data": 'Message', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Title' },
                    { "data": 'DateAndTime' },
                    { "data": 'Response' },
                    { "data": 'Topic', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'TodaysLocation', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'View' }
                ];
                 todaysAlertData = _.filter(todaysAlertData, function (o) { return o.ResponseID !== 3; });
                var grid = new CustomGrid('#todaysAlertTable', todaysAlertData, column, true);
                grid.CreateGrid(true);
                Alert.prototype.Response.call();
            });
    };
    /****
     *  This  method use to bind data to the My Alerts Settings Tab
     *  */
    Alert.prototype.BindMyAlertsSettings = function () {
        service = new Service('api/GetAlert/');
        service.getApi()
            .then(function (resp) {
                alertData = _.map(resp, function (x) {
                    return {
                        AlertId: x.alertId,
                        Description: x.description,
                        Title: x.title,
                        Topic: x.topic,
                        Location: x.location,
                        Measure: x.measure,
                        Threshold: x.threshold,
                        ThresholdValue: x.thresholdValue,
                        IsConfigureEmail: x.isConfigureEmail,
                        IsSubscribe: x.isSubscribe,
                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile,
                        IsSnooze: x.isSnooze,
                        Subscribe: x.isSubscribe ? '<label class="container"  class="textLabel"><input type="checkbox" class="gridSub' + x.alertId + '"checked="checked" data-error="*Mandatory Field" ><span class="checkmark" id="gridSub"></span></label>' : '<label class="container"  class="textLabel"><input type="checkbox" class="gridSub' + x.alertId +'"data-error="*Mandatory Field" ><span class="checkmark" id="gridSub"></span></label>',                       
                        Snooze: x.isSnooze? '<label class="container" class="textLabel"><input type="checkbox" class="gridSnooze' + x.alertId + '"checked="checked" data-error="*Mandatory Field"><span class="checkmark" id="gridSnooze"></span></label>' : '<label class="container" class="textLabel"><input type="checkbox" class="gridSnooze' + x.alertId +'"data-error="*Mandatory Field"><span class="checkmark" id="gridSnooze"></span></label>',
                        Email: x.isConfigureEmail?(x.isEmail ? '<label class="container"  class="textLabel"><input type="checkbox"  checked="checked" class="gridEmail' + x.alertId + '"data-error="*Mandatory Field" ><span class="checkmark" id="gridEmail" ></span></label>' : '<label class="container"  class="textLabel"><input type="checkbox" class="gridEmail' + x.alertId + '"data-error="*Mandatory Field" ><span class="checkmark" id="gridEmail" ></span></label>'): '<label class= "container"  class= "textLabel" > <input type="checkbox" class="gridEmail' + x.alertId +'" data-error="*Mandatory Field" disabled ><span class="checkmark" id="gridEmail" ></span></label>',
                        Mobile: x.isMobile ? '<label class="container"  class="textLabel"><input type="checkbox" checked="checked"  class="gridMobile" data-error="*Mandatory Field" disabled ><span class="checkmark"  id="gridMobile" ></span></label>' : '<label class="container"  class="textLabel"><input type="checkbox"  class="gridMobile" data-error="*Mandatory Field" disabled ><span class="checkmark" id="gridMobile"></span></label>',
                        MandatoryOptional: x.mandatoryOptional === 1 ?'Mandatory' : 'Optional',
                        View: '<span class="Show_details  defaultIcons"></span>',
                        Edit: ' <span class="Edit  defaultIcons"></span>'
                    };
                });

                var column = [
                    { "data": 'AlertId', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Title' },
                    { "data": 'Topic', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Location', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Subscribe' },
                    { "data": 'Snooze' },
                    { "data": 'Email' },
                    { "data": 'Mobile' },
                    { "data": 'View' },
                    { "data": 'Edit' }
                ];

                var grid = new CustomGrid('#alertSettingTable', alertData, column, false, true);
                grid.CreateGrid(true);
            
                _.forEach(_.filter(alertData, function (o) { return o.MandatoryOptional === 'Mandatory'; }), function (value, key) {
                    $('.gridEmail' + value.AlertId).attr('disabled', 'true');
                   // $('.gridSnooze' + value.AlertId).attr('disabled', 'true');
                    $('.gridSub' + value.AlertId).attr('disabled', 'true');
                });
                _.forEach(_.filter(alertData, function (o) { return o.IsSubscribe === false; }), function (value, key) {
                    $('.gridSnooze' + value.AlertId).attr('disabled', 'true');           
                });
                Alert.prototype.MyAlertSettingsResponse.call();                
            });
    };
    /****
     *  This  method use to bind data to the Configure Alert Tab
     *  */
    Alert.prototype.BindConfigureAlerts = function () {
        service = new Service('api/GetConfiguredAlert/');
        service.getApi()
            .then(function (resp) {
                alertConfiguredData = _.map(resp, function (x) {
                    return {
                        AlertId: x.alertId,
                        Description: x.description,
                        Title: x.title,
                        Topic: x.topic,
                        Location: x.location,
                        Measure: x.measure,
                        Threshold: x.threshold,
                        ThresholdValue: x.thresholdValue,
                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile,
                        Disable: x.disableAlert,
                        ResponseID: x.responseType,
                        Organisation: x.organization,
                        OperationalArea: x.operationalArea,
                        Frequency: x.frequency,
                        TimeWindow: x.timeWindow === 1 ? 'Operational' : 'Non Operational',
                        StartDate: moment(x.startDate).format("DD/MM/YYYY"),
                        EndDate: moment(x.endDate).format("DD/MM/YYYY"),
                        CreatedBy: x.createdBy,
                        Created: moment(x.createdDate).format("DD/MM/YYYY"),
                        ModifiedBy: x.modifiedBy,
                        ModifiedDate: moment(x.modifiedDate).format("DD/MM/YYYY"),
                        MandatoryOptional: x.mandatoryOptional === 1 ? 'Mandatory' : 'Optional',
                        View: '<span class="Show_details  defaultIcons"></span>',
                        Edit: ' <span class="Edit  defaultIcons"></span>'
                    };
                });
        var column = [
            { "data": 'AlertId' },
            { "data": 'Title', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
            { "data": 'Topic', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
            { "data": 'Location', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
            { "data": 'StartDate' },
            { "data": 'EndDate' },
            { "data": 'ModifiedDate' },
            { "data": 'ModifiedBy' },
            { "data": 'View' },
            { "data": 'Edit' }
        ];
                var grid = new CustomGrid('#configureAlertsTable', alertConfiguredData, column, true, true);
                grid.CreateGrid(true);
          });
    };
    /****
     *  This  method use to get Alert Count for bell icon
     *  */
    Alert.prototype.AlertCount = function () {
        service = new Service('api/AlertCount/');
        service.getApi()
            .then(function (resp) {
                if (resp > 0) {
                    $('.alertnotif').css("display", "block");
                    (resp < 10) ? (resp = "0" + resp) : resp;
                    $('.alertnotif').html(resp);
                    $('#alertCount').html(resp);
                }
                else {
                    $('.alertnotif').css("display", "none");
                    $('#alertCount').css("display", "none");
                }
            });
    };
    /****
     *  This  method use to bind latest five triggered alerts in chronological order
     *  */
    Alert.prototype.AlertIcon = function () {
        alertHtml = '';
        service = new Service('api/AlertNotification/');
        service.getApi()
            .then(function (resp) {
                alertNotificationData = _.map(resp, function (x) {
                    return {
                        AlertId: x.alertId,
                        Message: x.message,
                        Time: moment(x.time).fromNow(),
                        AlertTime: x.time,
                        Response: '<p class="IconsStyles"><span class="' + (x.responseType === 1 ? 'Tick_mark_Fill' : 'Tick_mark_Fill_white') + '"></span> <span class="' + ((x.mandatory === 0) ? (x.responseType === 2 ? 'ignore_red_fill' : 'ignore_white_fill') : '') + '"></span> <span class="' + (x.responseType === 3 ? 'blank_out_yellow_fill' : 'blank_out_white_fill') + '"></span> </p>',
                        ResponseID: x.responseType
                    };
                });

                if (alertNotificationData.length > 5) {
                    for (i = 0; i < 5; i++) {
                        alertHtml += '<li><p>' + alertNotificationData[i]['Message'] + '<p hidden>' + alertNotificationData[i]['AlertId'] + '</p></p>';
                        alertHtml += alertNotificationData[i]['Response'];
                        alertHtml += '<p> <span id="statusTime">' + alertNotificationData[i]['Time'] + '</span> </p></li>';
                    }
                }
                else {
                    for (i = 0; i < alertNotificationData.length ; i++) {
                        alertHtml += '<li><p>' + alertNotificationData[i]['Message'] + '<p hidden>' + alertNotificationData[i]['AlertId'] + '</p></p>';
                        alertHtml += alertNotificationData[i]['Response'];
                        alertHtml += '<p> <span id="statusTime">' + alertNotificationData[i]['Time'] + '</span> </p></li>';
                    }
                }
               
                $('.alertList').html(alertHtml);
                Alert.prototype.Response.call();
            });
    };
    /****
     *  This  method use to bind user response(acknowldge/ignore/snooze) for today's alerts and alert icon
     *  */
    Alert.prototype.Response = function () {
        var aData = [];   
        $('.IconsStyles').one('click', function (e) {
            //check response is from today's alert table
            if (e.target.parentElement.parentElement.tagName === 'TD') {
                var oTable = $(this).parents('table').dataTable();
                var nTr = $(this).parents('tr')[0];
                var gridData = oTable.fnGetData(nTr);
                aData['AlertId'] = gridData['AlertId'];
                aData['title'] = 'gridResponse';
            }
            else {
                aData['AlertId'] = e.target.parentElement.parentElement.childNodes[1].innerText;
                aData['title'] = 'IconResponse';
            }
          //condition to check there is no previous user response
            if (e.currentTarget.children[0].className.indexOf("white") > -1 && (e.currentTarget.children[2].className.indexOf("white") > -1) && ((e.currentTarget.children[1].className.indexOf("white") > -1) || e.currentTarget.children[1].className==='') )
            {
                switch (e.target.className) {

                    case "Tick_mark_Fill_white": e.target.className = "Tick_mark_Fill";
                        e.currentTarget.children[1].className = "ignore_white_fill";
                        e.currentTarget.children[2].className = "blank_out_white_fill";
                        aData['responseType'] = 1;
                        break;
                    case "ignore_white_fill": e.target.className = "ignore_red_fill";
                        e.currentTarget.children[0].className = "Tick_mark_Fill_white";
                        e.currentTarget.children[2].className = "blank_out_white_fill";
                        aData['responseType'] = 2;
                        break;
                    case "blank_out_white_fill": e.target.className = "blank_out_yellow_fill";
                        e.currentTarget.children[0].className = "Tick_mark_Fill_white";
                        e.currentTarget.children[1].className = "ignore_white_fill";
                        aData['responseType'] = 3;
                        break;
                    default:
                        break;
                }
            }
            if (aData['responseType'] > 0) {
                Alert.prototype.UpdateResponse(aData);
            }
        });

    };
    /****
     *  This  method use to bind and update user response(Subscribe/Snooze/Email) for my alert settings
     *  */
    Alert.prototype.MyAlertSettingsResponse = function () {
        var aData = [];
        $("input[type='checkbox']").click(function (e) {
            var oTable = $(this).parents('table').dataTable();
            var nTr = $(this).parents('tr')[0];
            var gridData = oTable.fnGetData(nTr);
            aData['responseType'] = 4;
            aData['title'] = 'Response';
            aData['isScreen'] = gridData['IsScreen'];
            aData['isSubscribe'] = gridData['IsSubscribe'];
            aData['isEmail'] = gridData['IsEmail'];
            aData['isSnooze'] = gridData['IsSnooze'];
            aData['AlertId'] = gridData['AlertId'];
            aData['ModifiedBy'] = gridData['ModifiedBy'];
            if (gridData['MandatoryOptional'] === 'Optional') {
                switch (e.currentTarget.className) {
                    case "gridSub" + gridData['AlertId']: (aData['isSubscribe'] === true) ? aData['isSubscribe'] = false : aData['isSubscribe'] = true;
                        if (aData['isSubscribe'] === true) {
                            $('.gridSnooze' + gridData['AlertId']).attr("disabled", false);
                            if (gridData['IsConfigureEmail'] === true) {
                                $('.gridEmail' + gridData['AlertId']).attr("disabled", false);
                                $('.gridEmail' + gridData['AlertId']).prop("checked", true);
                                aData['isEmail'] = true;
                            }
                        }
                        else {
                            $('.gridSnooze' + gridData['AlertId']).attr("disabled", true);
                            $('.gridEmail' + gridData['AlertId']).attr("disabled", true);
                            $('.gridEmail' + gridData['AlertId']).prop("checked", false);
                            aData['isSnooze'] = false;
                            aData['isEmail'] = false;
                        }

                       // (aData['isSubscribe'] === true) ? $('.gridSnooze' + gridData['AlertId']).attr("disabled", false) : ($('.gridSnooze' + gridData['AlertId']).attr("disabled", true), aData['isSnooze'] = false);
                       // (aData['isSubscribe'] === true && gridData['IsConfigureEmail'] === true) ? ($('.gridEmail' + gridData['AlertId']).attr("disabled", false), $('.gridEmail' + gridData['AlertId']).prop("checked", true), aData['isEmail'] = true) : $('.gridEmail' + gridData['AlertId']).prop("checked", false);
                        break;
                    case "gridEmail" + gridData['AlertId']: (aData['isEmail'] === true) ? aData['isEmail'] = false : aData['isEmail'] = true;
                        break;
                    //case "gridSnooze" + gridData['AlertId']: (aData['isSnooze'] === false) ? aData['isSnooze'] = true : aData['isSnooze'] = false;                                                                 
                    //  break;
                }
            }
            if (aData['isSubscribe'] === true) {
                switch (e.currentTarget.className) {
                    case "gridSnooze" + gridData['AlertId']: (aData['isSnooze'] === false) ? aData['isSnooze'] = true : aData['isSnooze'] = false;
                        break;
                }
            }
            Alert.prototype.UpdateResponse(aData);
        });
       
        $(".container").click(function (e) {
            var oTable = $(this).parents('table').dataTable();
            var nTr = $(this).parents('tr')[0];
            var gridData = oTable.fnGetData(nTr);
            if (gridData['MandatoryOptional'] === 'Mandatory' && (e.currentTarget.children[1].id === 'gridSub' || e.currentTarget.children[1].id === 'gridEmail'))
            {
                Utility.alertMessage("Mandatory Alerts cannot be modified", "warningMsg");
            }
           /* else if (e.currentTarget.children[0].disabled && e.currentTarget.children[1].id === 'gridSnooze') {
                Utility.alertMessage("Alert is not subscribed", "warningMsg");
            }*/
        });
    };
    /**
    // User response from Today's alert or alert icon is updated in database
    * @param {string} aData json data object with user response(acknowledge/ignore/snooze) from today's alert tab or alert icon
    */
    Alert.prototype.UpdateResponse = function (aData) {
        var alertVM = {};
        alertVM.ResponseType = aData['responseType'];
        alertVM.AlertId = aData['AlertId'];
        alertVM.Title = aData['title'];
        alertVM.IsSubscribe = aData['isSubscribe'];
        alertVM.IsEmail = aData['isEmail'];
        alertVM.IsOnScreen = aData['isScreen'];
        alertVM.IsSnooze = aData['isSnooze'];
        var service = new Service('api/Alerts', 'application/json; charset=utf-8', 'json', alertVM);
        service.putApi().done(function () {
            if (aData['title'] === 'gridResponse') {
                Alert.prototype.BindTodayAlerts.call();
                Alert.prototype.AlertCount.call();
            }
            else if (aData['title'] === 'IconResponse') {
                var count = $('.alertnotif').html();
                count--;
                (count < 10) ? (count = "0" + count) : count;
                alertHtml = '';
                Alert.prototype.AlertCount.call();
                Alert.prototype.AlertIcon.call();
                Alert.prototype.BindTodayAlerts.call();
            }
            else if (aData['title'] === 'Response'){
                Alert.prototype.BindMyAlertsSettings();
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        });
    };
    return Alert;
})();
