﻿//----------------------------------------------------------------------
//Class Name   : Search
//Purpose      : Search js use to search the bagtags,flight number,passenger surname.
//Created By   : P Kannan
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Anupama               FDS Change                                  12/03/2019         Change realted to messages
//Anupama               FDS Change                                  12/01/2019         change related to the search results based on search terms
//----------------------------------------------------------------------

var Search = (function () {
    'use strict';
    var searchEntity = [];
    var searchText;
    Search = function () { };
    var searchPrefix = '';
    var prefix;

    var searchCategory = Utility.SearchType;

     /**
    // Assign the type of search to search result on the basis of values in session storage.
    * @param {string} searchData json data object with search result for the search term.
    * @returns {string} searchData with the columnvalue which is the searchPrefix.
    */
    Search.prototype.assignValuesToEntity = function (searchData) {
        searchPrefix = Utility.GetStoredData('searchPrefix');
        searchEntity = Utility.GetStoredData('searchCriteria');
        searchData.ColumnValue = (searchPrefix === 'F') ? [searchEntity] : searchEntity.split(",");
        return searchData;
    };

    /**
    // calls the service method for the search result of the search term and also creates the breadcrumb for the respective result
    */
    Search.prototype.getBagListData = function () {
        var result = [];
        var service = new Service('api/Search?query=' + Utility.GetStoredData('searchCriteria') + '&searchType=' + Utility.GetStoredData('searchPrefix'), 'application/html; charset=utf-8', 'json', null);
        service.getApi()
            .done(function (resp) {
                var searchResult = resp;
                Search.prototype.createBreadCrumb.call(this, searchResult.menuId);
                searchResult = Search.prototype.assignValuesToEntity.call(this, searchResult);
                result.push(searchResult);
               Utility.SetStoredData('URLId', searchResult);
                var dashboardPowerBiApi = new PowerBIAPP();
                dashboardPowerBiApi.searchFilterApi(result, searchPrefix);
                $('#txtSearch').val(Utility.GetStoredData('searchCriteria'));
                $(".loader").css("display", "none");
                Utility.RemoveStoredData('searchCriteria');
                Utility.RemoveStoredData('searchPrefix');

            }).fail(function (jqXHR, textStatus, errorThrown) {
                Utility.alertMessage("Error occured while searching criteria.", "errorMsg");
            });
    };


    /**
    // Validates the search term entered and gives warning message if validation fails.
    * @param {string} param individual string entered for search.
    */
    Search.prototype.validateText = function (param) {

        if (!_.isEmpty(param)) {
            var searchValue = Search.prototype.validatationType.call(this, param);
            if (_.isNil(searchValue) && prefix !== searchValue) {

                if (prefix === searchCategory.FlightNumber) {
                    Utility.alertMessage('Search by Flight number only.Combination of search will be not allowed.', 'warningMsg');
                }
                else if (prefix === searchCategory.BagTag) {
                    Utility.alertMessage('Search by Bag Tag only.Combination of search will be not allowed.', 'warningMsg');
                    return;
                }
                else if (prefix === searchCategory.PassegerName) {
                    Utility.alertMessage('Search by Passeger Name only.Combination of search will be not allowed.', 'warningMsg');
                }
                else if (prefix === searchCategory.InvalidBagtag) {
                    Utility.alertMessage('Search by valid bagtag.The bagtag minimum should be 6 character.', 'warningMsg');
                }
                else if (prefix === searchCategory.InValid) {
                    Utility.alertMessage('Please enter valid Search criteria.', 'errorMsg');
                }
            }
        }
    };

    /**
    // passes each item of the array of search term entered for validation.
    * @param {string[]} source array of strings entered for search.
    */
    Search.prototype.searchValidation = function (source) {

        for (var i = 0; i < source.length; i++) {

            Search.prototype.validateText.call(this, source[i]);
        }

    };

    /**
    // Finds the type of search term(bagtag,flight no. or passenger name) and assigns the values to prefix ans searchPrefix.
    * @param {string} parameter individual string entered for search.
    * @returns {int} type of search
    */
    Search.prototype.validatationType = function (parameter) {

        var result = Utility.SearchConfigValidation(parameter);

        if (result === searchCategory.FlightNumber) {
            prefix = (_.isNil(prefix)) ? searchCategory.FlightNumber : prefix;
            searchPrefix = "F";
            return searchCategory.FlightNumber;
        } else if (result === searchCategory.BagTag) {
            prefix = (_.isNil(prefix)) ? searchCategory.BagTag : prefix;
            searchPrefix = "B";
            return searchCategory.BagTag;
        } else if (result === searchCategory.BagTag) {
            prefix = (_.isNil(prefix)) ? searchCategory.PassegerName : prefix;
            searchPrefix = "N";
            return searchCategory.PassegerName;
        }
        else {
            prefix = (result === searchCategory.InvalidBagtag) ? searchCategory.InvalidBagtag : searchCategory.InValid;
            searchPrefix = null;
            return 0;
        }
    };

    /**
    // Creates the breadcrumb for the respective search result.
    * @param {int} menuId menu id for the type of search result.
    */
    Search.prototype.createBreadCrumb = function (menuId) {
        $(".breadcrumb li").remove();
        $(".verticalNavigation li").remove();

        var searchHeader = '';

        if (Utility.ReportName.FlightDetailsInBound === menuId) {
            searchHeader = 'FLIGHT DETAILS - INBOUND';
        }
        else {
            searchHeader = Utility.ReportName.FlightDetailsOutBound === menuId ? 'FLIGHT DETAILS - OUTBOUND' : 'Bag Search List';
        }

        $(".breadcrumb").append("<li class='active'><a href='#'>" + searchHeader + "</a></li>");
        $(".verticalNavigation").append("<li class='active'><a href='#'>" + searchHeader + "</a></li>");
    };

    $("#searchbtn,#searchMobile").on("click", searchValue);

    
    // takes the input from search textbox and assigns the search prefix and search term to session storage.    
    function searchValue() {
        searchText = [];
        prefix = null;
        $(".loader").css("display", "block");
        var param = $('#txtSearch').val().split(",").filter(function (index) { return index; });
        if (_.isEmpty(param)) {
            $(".breadcrumb li").remove();
            $(".verticalNavigation li").remove();
            var paramNew = $('#mobileSearchInputBox').val().split(",").filter(function (index) { return index; });
            $.each(paramNew, function (key, val) {
                searchText.push(val);
            });
        }
        else {
            $.each(param, function (key, val) {
                searchText.push(val);
            });
        }
        if (_.isEmpty(param) && _.isEmpty(paramNew)) {
            Utility.alertMessage('Search criteria is not available. Please enter the search text', 'warningMsg');
             return;
        }

        if (searchText.length > 5) {
            Utility.alertMessage('Search will allow maximum  5 Bag Tags or Passanger', 'warningMsg');
            return;
        }
        else {

            Search.prototype.searchValidation.call(this, searchText);
            if (searchPrefix === 'F' && searchText.length > 1) {
                Utility.alertMessage('Screen can display only one Flight Number at a time.', 'warningMsg');
                $(".loader").css("display", "none");
                return;
            }
            var inputText = (searchPrefix === 'B' || searchPrefix === 'F') ? searchText.toString() : searchText;
           Utility.SetStoredData('searchCriteria', inputText);
           Utility.SetStoredData('searchPrefix', searchPrefix);
            inputText = searchPrefix === 'F' ? inputText : '';

            if (!_.isNil(searchPrefix)) {
                if (searchPrefix === 'F') {
                   Utility.SetStoredData('URLId', 6);
                }
               Utility.SetStoredData('URLId', 18);
                if (window.location.href.split("/")[3] !== "") {
                    window.location.replace(window.location.origin);
                } else {
                    $('#txtSearch').val(Utility.GetStoredData('searchCriteria'));
                    Search.prototype.getBagListData.call();
                }
            }
        }
    }

    // validate input parameter
    $("#txtSearch,#mobileSearchInputBox").on("keyup", function searchInputKeyup(e) {
        // KeyCode For comma is 188
        if (e.keyCode === 188) {
            var paramValue = $("#txtSearch").val().split(",").filter(function (index) { return index; });
            if (!_.isEmpty(paramValue)) {
                var index = paramValue.length - 1;
                Search.prototype.validateText.call(this, paramValue[index]);
            }
            else {
                var paramValueNew = $("#mobileSearchInputBox").val().split(",").filter(function (index) { return index; });
                var indexNew = paramValueNew.length - 1;
                Search.prototype.validateText.call(this, paramValueNew[indexNew]);
            }
            if (!_.isEmpty(paramValue) && !_.isEmpty(paramValueNew)) {
                Utility.alertMessage("You have not entered valid search criteria.", "warningMsg");
            }
        }
    });
       

    //initiates search on enter button press
    $('#txtSearch,#mobileSearchInputBox').on('keypress', function searchEnterButton(event) {
        if (event.keyCode === 13) {
            searchValue();
        }
        else {
            Utility.SpecialCharacterValidation(event);
        }
    });
       
    $('#txtSearch,#mobileSearchInputBox').bind('paste', removeAlphaChars);

    // Handle special characters start
    function removeAlphaChars() {
        var self = $(this);
        setTimeout(function () {
            var initVal = self.val(),
                outputVal = initVal.replace(/[^a-zA-Z0-9,]/g, "");
            if (initVal !== outputVal) {
                self.val(outputVal);
            }
        });
    }
    //End Handle special characters

    return Search;

})();