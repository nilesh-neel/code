﻿//----------------------------------------------------------------------
//File Name    : share.js
//Purpose      : share.js is used to share reports in web app.
//Created By   : Vignesh
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------
(function () {
    'use strict';
    var service;
    var shareUrl = '';
    $(document).ready(function () {

        $("#ddlAudienceGrp").combobox({
            select: function (event, ui) {
                var SelectedGrpID = $('option:selected', this).val();
                LoadGrpRecipients(SelectedGrpID);
            }
        });
    });

    /**
    // To open and close the Share Panel on share icon click and cancel click
    */
    $('.share,#sharePanelCancel').click(function shareClick(event) {
        event.stopPropagation();

        if ($("#notesDiv").is(":visible") || $("#filterPanel").is(":visible")) {
            Utility.ClosePanel();
        }

        if (!$("#sharePanel").is(":visible")) {
            LoadAudienceGrp();
            $(".combobox").combobox();
            $(".custom-combobox-input ").attr("placeholder", "Select");

            var filterResult = filterUrl;

            //To construct the Share Url only on share icon click
            if (!_.isNil(filterResult)) {
                shareUrlFormation(filterResult);
            }
            else {
                shareUrl = location.href.replace("#", "").trim();
                $(".urlTxt").text(shareUrl);
            }
        }

        $("#sharePanel").toggle();
        $(".share").toggleClass("clickedIcons");
        $(".share").toggleClass("customBorderSmall");
    });



    /**
   // To close the Share Panel on cancel button click
   */
    $(".cancel").click(cancelClick);

    function cancelClick() {
        if ($(this).parents(".sideNavBar")) {
            $(this).parents(".sideNavBar").css("display", "none");
        }

    }

    /**
    // To generate and display the share report Url in share panel
    */
    var LoadShareUrl = function () {
        var urlId = Utility.GetStoredData('URLId');
        var rptName = Utility.GetStoredData('RptName');
        var noteData = { menuId: urlId, rptname: rptName };

        service = new Service('api/Share?menuId=' + urlId + '&rptname=' + rptName, 'application/json; charset=utf-8', 'json', null);
        service.getApi()
            .done(function (response) {
                if (!_.isNil(response) && response.length > 0) {
                    $(".urlTxt").text(shareUrl);
                }
            }).fail(function (jqXHR, textStatus, errorThrown) {
                Utility.alertMessage("Error while shareUrl formation.", "errorMsg");
            });
    };

    /**
    // To get audience group names from Api
    */
    var LoadAudienceGrp = function () {
        var noteData = {};

        service = new Service('api/Share', 'application/json; charset=utf-8', 'json', null);
        service.getApi()
            .done(function (response) {
                if (!_.isNil(response) && response.length > 0) {
                    GetAudienceGrpData(response);
                }
            }).fail(function (jqXHR, textStatus, errorThrown) {
                Utility.alertMessage("Error while fetching Audience group.", "errorMsg");
            });
    };

    /**
    // Binding Audience Group dropdown values in share panel
    * @param {string} response json data object with audience group data.
    */
    var GetAudienceGrpData = function (response) {
        var option = '';
        for (var i = 0; i < response.length; i++) {
            option += '<option value="' + response[i].groupId + '">' + response[i].groupName + '</option>';
        }
        $('#ddlAudienceGrp').empty();
        $('#ddlAudienceGrp').append(option);
    };

    /**
   // To get recipients names from Api
    * @param {string} SelectedGrpID The Id of the selected audience group
   */
    var LoadGrpRecipients = function (SelectedGrpID) {

        service = new Service('api/Share?groupId=' + SelectedGrpID, 'application/json; charset=utf-8', 'json', null);
        service.getApi()
            .done(function (response) {
                if (!_.isNil(response) && response.length > 0) {
                    GetGrpRecipients(response);
                }
                else {
                    Utility.ClearMultiDropDown('#ddlGrpRecipients');
                }
            }).fail(function (jqXHR, textStatus, errorThrown) {
                Utility.alertMessage("Error while fetching Recipients.", "errorMsg");
            });
    };

    /**
    // Binding recipients values to the dropdown in share panel
    * @param {string} response json data object with recipients data.
    */
    var GetGrpRecipients = function (response) {
        var recipientsList = [];

        for (var i = 0; i < response.length; i++) {
            recipientsList.push(
                {
                    label: response[i].recipientName,
                    value: response[i].recipientId
                });
        }

        Utility.bindMultiDropDown('#ddlGrpRecipients', [recipientsList]);
    };

    /**
    // To close the Share Panel on cancel button click
    */
    $("#sharePanelCancel").click(shareCancelClick);

    function shareCancelClick() {
        $("#sharePanel").css("display", "none");
    }

    /**
    // To send Email to selected recipients on submit button click in share panel
    */
    $("#shareSave").click(shareSaveClick);

    function shareSaveClick() {

        // To get the selected value
        var selectedUsers = $("#ddlGrpRecipients option:selected").toArray().map(function (item) { return [item.value]; }).join(',');
        var displayselectedusers = $("#ddlGrpRecipients option:selected").toArray().map(function (item) { return [item.text]; }).join(',');
        $('#RecipientSelectedNames').text(displayselectedusers);

        if (!_.isEmpty(selectedUsers)) {
            var ReportUrl = $(".urlTxt").text();
            var Recipients = { selectedRecipients: selectedUsers, pattern: ReportUrl, reportName: Utility.GetStoredData('RptName') };

            service = new Service('/Share/SendMail', 'application/json; charset=utf-8', 'json', Recipients);
            service.save()
                .then(function (response) {
                    if (!_.isNil(response)) {
                        Utility.alertMessage("Report Url shared via Email Successfully.", "successMsg");
                    }
                }).fail(function (jqXHR, textStatus, errorThrown) {
                    Utility.alertMessage("Error while sending Email.", "errorMsg");
                });
        }
    }

    /**
    // Share report url formation
    * @param {string} filterResult the filter result
    */
    var shareUrlFormation = function (filterResult) {
        // For constructing the filter part in share url --- start
        var filtersApplied = "";
        shareUrl = '';

        if (filterResult.length > 0) {
            for (var i = 0; i < filterResult.length; i++) {
                var childValue = "";
                if (filterResult[i].columnValue && filterResult[i].columnValue.length) {
                    for (var j = 0; j < filterResult[i].columnValue.length; j++) {
                        childValue += filterResult[i].columnValue[j] + ',';
                    }
                    childValue = childValue.substr(0, childValue.length - 1);
                }
                filtersApplied += filterResult[i].tableName + "\\" + filterResult[i].columnName + "\\" + filterResult[i].operator + "\\" + childValue + "&";
            }
            filtersApplied = filtersApplied.substr(0, filtersApplied.length - 1);
            shareUrl = location.href.replace("#", "").trim() + "?reporttype=" + Utility.GetDateForOperationalOrBusinessReport() + "&calledreportid=" + Utility.GetStoredData('URLId') + "&" + filtersApplied;
        }
        else { shareUrl = location.href.replace("#", "").trim() + "?reporttype=" + Utility.GetDateForOperationalOrBusinessReport() + "&calledreportid=" + Utility.GetStoredData('URLId');}
        $(".urlTxt").text(shareUrl);
        $("#hrefUrl").text($(".urlTxt").text());

        // For constructing the Share Url to share the report via Email -- End
    };

    $("#hrefUrl").click(function (e) {
        e.preventDefault();
        window.open(this.text);
    });


})(jQuery);




