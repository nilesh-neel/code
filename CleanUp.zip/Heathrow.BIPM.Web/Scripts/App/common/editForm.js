﻿//----------------------------------------------------------------------
//Class Name   : editForm
//Purpose      : This is edit form js file use to capture edit events of forms.
//Created By   : Vaishnavi.R
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Anupam(694315)        FDS Change                                  12/01/2019         Modified the on success method with different messages in different scenarios
//Anupama(694315)       FDS Change                                  12 / 01 / 2019         Code for change in dropdown values of measure name based on topic and vise versa                 
//----------------------------------------------------------------------

$(function () {
    $(".combobox").combobox();
    singleDrpDown();

    $('.multiSelectComponent').multiselect({
        enableFiltering: true,
        buttonWidth: '100%',
        filterPlaceholder: 'Search for something...',
        nonSelectedText: 'Select'
    });
    $('.multiselect-container').addClass('scrollbar-inner');
    $('.scrollbar-inner').scrollbar();
    $('ul.multiselect-container').removeClass('dropdown-menu');

    //show all items tooltip
    $(".multiselectCombo button").removeAttr('title');
    $(".multiselectCombo button b").attr("data-toggle", "tooltip");
    $(".multiselectCombo button b").attr("data-original-title", "Show All Items");
    $(".multiselectCombo button b").tooltip();
    $(".formCalendarIcon").daterangepicker({   
        singleDatePicker: true,
        showDropdowns: true     
    });
});

//Min date of end date as start date
$('.startDate').on('apply.daterangepicker', function (ev, picker) {
            $(".endDate").daterangepicker({
                showDropdowns: true,
                singleDatePicker: true,
                minDate: (picker.startDate.format('MM/DD/YYYY'))
            });
    });


$('input,textarea,combobox,select,multiSelectComponent').change(inputChange);

/****
     * This  method use to Disable save button until mandatory fields are filled
     */
function inputChange() {
    var isValid = true;
    $('input,textarea,combobox,select,multiSelectComponent').filter('[required]:visible').each(function () {

        if (($(this).val() === '') || _.isEmpty($(this).val())) {
            isValid = false;
        }
    });

    if (isValid) {
        $('.submitBtn').prop('disabled', false);
    } else {
        $('.submitBtn').prop('disabled', true);
    }
}

/****
     * This  method use to handle success event of form submission
     * @param {string} response related json response from related form 
     */
function OnSuccess(response) {
    if (response === "Alert saved successfully for EditAlertForm") {
        Utility.alertMessage("Alert settings updated successfully", "successMsg");
        $("#tabs a[href='#alertSettings']").click();
    }
    else if (response === "Alert saved successfully for configureAlert") {
        Utility.alertMessage("Alert updated successfully", "successMsg");
        $("#tabs a[href='#configureAlerts']").click();
    }
    else if (response === "Alert saved successfully") {

        Utility.alertMessage("Alert configured successfully", "successMsg");
    }
    else if (response === "Notification saved successfully for myNotificationSettingForm") {
        Utility.alertMessage("Notification settings updated successfully", "successMsg");
        $("#tabs a[href='#notificationSettings']").click();
    }
    else if (response === "Notification saved successfully for configureNotificationForm") {
        Utility.alertMessage("Notification updated successfully", "successMsg");
        $("#tabs a[href='#configureNotifications']").click();
    }
    else if (response === "Notification saved successfully") {
        Utility.alertMessage("Notification setup successfully.", "successMsg");
    }
    else {
        Utility.alertMessage(response, "errorMsgMsg");
    }

}
/****
     * This  method use to handle failure event of form submission   
     */
function OnFailure() {
    Utility.alertMessage("Some Error occured while processing your request.", "errorMsg");
}

$("#cancelBtn").click(function cancelButtonClick(event) {
    $("#cancelBtnPopup").modal('show');  
    $('#editCancel').click(function () {
    $("#cancelBtnPopup").modal('hide');  
    closeExpansion(event);
    });

    
});


$('#isSubscribe').change(function () {
    if ($(this).is(":checked")) {
        //Snooze is enabled
        $(this).parent().closest('tr').next('tr').find('input[type=checkbox]').attr("disabled", false);
        
        //OnScreen checked and disabled
        $(this).parent().closest('tr').next('tr').next('tr').find('input#isOnScreen').prop('checked', true);
        $(this).parent().closest('tr').next('tr').next('tr').find('input#isOnScreen').attr("disabled", true);

        //Email checked 
        if ($('#configureEmail').val()) {
            $(this).parent().closest('tr').next('tr').next('tr').find('input#isEmail').attr("disabled", false);
            $(this).parent().closest('tr').next('tr').next('tr').find('input#isEmail').prop('checked', true);
        }
    }
    else {
        //Snooze is unchecked and disabled
        $(this).parent().closest('tr').next('tr').find('input[type=checkbox]').prop('checked', false);
        $(this).parent().closest('tr').next('tr').find('input[type=checkbox]').attr("disabled", true);
        //OnScreen is unchecked and disabled
        $(this).parent().closest('tr').next('tr').next('tr').find('input#isOnScreen').prop('checked', false);
        $(this).parent().closest('tr').next('tr').next('tr').find('input#isOnScreen').attr("disabled", true);
        //Email unchecked and disabled
        $(this).parent().closest('tr').next('tr').next('tr').find('input#isEmail').prop('checked', false);
        $(this).parent().closest('tr').next('tr').next('tr').find('input#isEmail').attr("disabled", true);
    }
});

/****
     * This  method use to close the expanded row  
     */
function closeExpansion() {
    $('.details').hide();
    var me = $('.showDetailsActive :last');
    var nTr = $($('#cancelBtn')[0]).closest('div').closest('tr').prev();
    var otable = $('.showDetailsActive').closest('table').dataTable();
    var prevClickedIcon = '.Show_details';
    otable.fnClose(nTr);
    $(me).closest("tr").find("td").toggleClass("showDetailsActive");
    $(me).removeClass("clickedIcons");
    $(me).toggleClass("customBorderSmall");
    $(me).next().toggleClass("clickedIcons");
    $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
}
/****
     * This  method use to load related topic on measure change  
     */
function MeasureChange() {
    var selectedId = $("#drpAudience").val() + "_MeasureChange";
    var option = '';
    service = new Service('api/TopicByMeasure?selectedId=' + selectedId);
    service.getApi()
        .then(function (resp) {
            var value = "";
            //var id = 0;
            $('#drpRecipients').empty();
            for (var i = 0; i < resp.bagTopic.length; i++) {
                option += '<option value="' + resp.bagTopic[i].rowId + '">' + resp.bagTopic[i].lookupTypeName + '</option>';
                value = resp.bagTopic[0].lookupTypeName;
                //id = resp.bagTopic[0].rowId;
            }
            Utility.SetValuesToDropDown('#drpRecipients',value);
            debugger;
            $('#drpRecipients').append(option);
        });
}

/****
     * This method handles select event of drop down 
     */
var singleDrpDown = function () {
    $('.combobox').combobox(
        {           
            select: function () {
                var selectedDropdownId = $(this).closest('select').attr('id');
                var mandatory = $(this).closest('select')[0].value;
                if (selectedDropdownId === "drpAudience") {
                    MeasureChange();
                }
                else if (selectedDropdownId === "drpRecipients") {
                    TopicChange();
                }
              /*  else if (mandatory === "1") {
                    $('input#isOnScreen').attr("disabled", true);
                    $('input#isOnScreen').prop('checked', true);
                }
                else if (mandatory === "0") {
                    $('input#isOnScreen').attr("disabled", true);
                    $('input#isOnScreen').prop('checked', true);
                }*/
            }
        });
};
/****
     * This method is called on click of cancel button in form 
     * @param {object} oForm form object from where cancel is clicked
     */
function cancelClick(oForm) {
    $("#cancelBtnPopup").modal('show');

    //if yes to discard changes is clicked
    $('#editCancel').click(function () {
    $("#cancelBtnPopup").modal('hide');
  /*  var bagMeasure = [];
    var bagTopic = [];
    bagMeasure = bagMeasuresArray;
    bagTopic = bagToipcArray;
    var option = '';
    var optionNew = '';
    $('#drpAudience').empty();
    $("#drpRecipients").empty();
    for (var i = 0; i < bagMeasure.length; i++) {
        option += '<option value="' + bagMeasure[i].rowId + '">' + bagMeasure[i].lookupTypeName + '</option>';
    }
    $('#drpAudience').append(option);

    for (var j = 0; j < bagTopic.length; j++) {
        optionNew += '<option value="' + bagTopic[j].rowId + '">' + bagTopic[j].lookupTypeName + '</option>';
    }
        $('#drpRecipients').append(optionNew);
   */
        //if cancel is clicked in new alert form
        if (oForm.id === "newAlert") {
         
            $('#congigureNewAlertBtn').trigger('click');
        }
        else {
            $('#configureNewNotificationBtn').trigger('click');
        }

       // oForm.reset();
        return false;
    });
}

/****
     * This method used to load topic on measure change 
     */
function TopicChange() {
    var selectedId = $("#drpRecipients").val() + "_TopicChange";
    var option = '';
    service = new Service('api/TopicByMeasure?selectedId=' + selectedId);
    service.getApi()
        .then(function (resp) {
            var value = "";
            //var id = 0;
            $('#drpAudience').empty();
            option = "<option value='' disabled selected>Select</option>";
            for (var i = 0; i < resp.bagMeasure.length; i++) {
                if (i === 0) {
                    option += '<option selected="selected" value="' + resp.bagMeasure[i].rowId + '">' + resp.bagMeasure[i].lookupTypeName + '</option>';
                }
                else {
                    option += '<option value="' + resp.bagMeasure[i].rowId + '">' + resp.bagMeasure[i].lookupTypeName + '</option>';
                }
                    value = resp.bagMeasure[0].lookupTypeName;                
            }
            Utility.SetValuesToDropDown('#drpAudience',value);
            $('#drpAudience').append(option);

        });
}




/****
     * Row expansion Template Show Details
     * @param {object} oTable selected table
     * @param {object} nTr The table row to 'open'
     * @returns {string} html to load in row expansion
     */
function fnFormatNotification(oTable, nTr) {
    var aData;
    var sOut;
    //Row expansion  for notification Table
    if (oTable['0'].id === 'todaysNotificationTable') {
        aData = oTable.fnGetData(nTr);
        sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Notification:</td><td>' + aData['Description'] + '</td></tr>';
        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['Locations'] + '</td></tr>';
        sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" id="viewScreen" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" id="viewEmail" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="viewMobile" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
        sOut += '</table>';
    }

    if (oTable['0'].id === 'notificationSettingsTable') {
        aData = oTable.fnGetData(nTr);
        sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Notification Id:</td><td>' + aData['NotificationId'] + '</td></tr>';
        sOut += '<tr><td>Notification:</td><td>' + aData['Description'] + '</td></tr>';
        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['Locations'] + '</td></tr>';
        sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">Application<input type="checkbox" id="viewScreen" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" id="viewEmail" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="viewMobile" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';
        sOut += '</table>';
    }
    else if (oTable['0'].id === 'ConfigureNotificationTable') {
        aData = oTable.fnGetData(nTr);
        sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Notification Id:</td><td>' + aData['NotificationId'] + '</td></tr>';
        sOut += '<tr><td>Notification:</td><td>' + aData['Description'] + '</td></tr>';
        sOut += '<tr><td>Organisation:</td><td>' + aData['Organisation'] + '</td></tr>';
        sOut += '<tr><td>Operational Area:</td><td>' + aData['OperationalArea'] + '</td></tr>';
        sOut += '<tr><td>Additional Information URL:</td><td><a href="' + aData['Additional'] + '"target="_blank" rel="noopener">Help URL</td></tr>';

        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['Locations'] + '</td></tr>';
        sOut += '<tr><td>Start Date:</td><td>' + aData['Start'] + '</td></tr>';
        sOut += '<tr><td>End Date:</td><td>' + aData['End'] + '</td></tr>';
        sOut += '<tr><td>Disable Notification</td><td><label for"Disable" class="textLabel panelCheckBox"><input type="checkbox" id="disable" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';

        sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">Application<input type="checkbox" id="viewScreen" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" id="viewEmail" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="viewMobile" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';
        sOut += '<tr><td>Created By:</td><td>' + aData['CreatedBy'] + '</td></tr>';
        sOut += '<tr><td>Created:</td><td>' + aData['Created'] + '</td></tr>';
        sOut += '<tr><td>Modified By:</td><td>' + aData['ModifiedBy'] + '</td></tr>';
        sOut += '<tr><td>Modified:</td><td>' + aData['Modified'] + '</td></tr>';
        sOut += '</table>';
    }
    //Row expansion for alert Table
    else if (oTable['0'].id === 'todaysAlertTable') {
        aData = oTable.fnGetData(nTr);
        sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Message:</td><td>' + aData['Message'] + '</td></tr>';
        sOut += '<tr><td>Title:</td><td>' + aData['Title'] + '</td></tr>';
        sOut += '<tr><td>Time:</td><td>' + aData['DateAndTime'] + '</td></tr>';
        sOut += '<tr><td>Response:</td><td><p class="IconsStyles"><span class="' + ((aData['ResponseID'] === 1) ? 'Tick_mark_Fill' : 'Tick_mark_Fill_white') + '"></span> <span class="' + ((aData['MandatoryOptional'] === 0) ? (aData['ResponseID'] === 2 ? 'ignore_red_fill' : 'ignore_white_fill') : '') + '"></span> <span class="' + ((aData['ResponseID'] === 3) ? 'blank_out_yellow_fill' : 'blank_out_white_fill') + '"></span> </p></td></tr>';
        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['TodaysLocation'] + '</td></tr>';
        sOut += '</table>';
    }
    else if (oTable['0'].id === 'alertSettingTable') {
        aData = oTable.fnGetData(nTr);

        sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Alert ID:</td><td>' + aData['AlertId'] + '</td></tr>';
        sOut += '<tr><td>Measure Name:</td><td>' + aData['Measure'] + '</td></tr>';
        sOut += '<tr><td>Title:</td><td>' + aData['Title'] + '</td></tr>';
        sOut += '<tr><td>Description:</td><td>' + aData['Description'] + '</td></tr>';
        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['Location'] + '</td></tr>';
        sOut += '<tr><td>Threshold:</td><td>' + aData['Threshold'] + '</td></tr>';
        sOut += '<tr><td>Threshold Value:</td><td>' + aData['ThresholdValue'] + '</td></tr>';
        sOut += '<tr><td>Mandatory/Optional:</td><td>' + aData['MandatoryOptional'] + '</td></tr>';
        sOut += '<tr><td>Snooze:</td><td><label class="container" class="textLabel"><input type="checkbox" id="viewSnooze" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td ></tr >';
       // sOut += '<tr><td>Snooze:</td><td>' + aData['Snooze'] + '</td></tr>';
        sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" id="viewScreen" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" id="viewEmail" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="viewMobile" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';

        sOut += '</table>';
    }
    else if (oTable['0'].id === 'configureAlertsTable') {
        aData = oTable.fnGetData(nTr);

        sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Alert ID:</td><td>' + aData['AlertId'] + '</td></tr>';
        sOut += '<tr><td>Measure Name:</td><td>' + aData['Measure'] + '</td></tr>';
        sOut += '<tr><td>Title:</td><td>' + aData['Title'] + '</td></tr>';
        sOut += '<tr><td>Organisation:</td><td>' + aData['Organisation'] + '</td></tr>';
        sOut += '<tr><td>Operational Area:</td><td>' + aData['OperationalArea'] + '</td></tr>';


        sOut += '<tr><td>Description:</td><td>' + aData['Description'] + '</td></tr>';
        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['Location'] + '</td></tr>';
        sOut += '<tr><td>Threshold:</td><td>' + aData['Threshold'] + '</td></tr>';
        sOut += '<tr><td>Threshold Value:</td><td>' + aData['ThresholdValue'] + '</td></tr>';

        sOut += '<tr><td>Frequency:</td><td>' + aData['Frequency'] + '</td></tr>';
        sOut += '<tr><td>Time Window:</td><td>' + aData['TimeWindow'] + '</td></tr>';
        sOut += '<tr><td>Mandatory/Optional:</td><td>' + aData['MandatoryOptional'] + '</td></tr>';
        sOut += '<tr><td>Start Date</td><td>' + aData['StartDate'] + '</td></tr>';
        sOut += '<tr><td>End Date</td><td>' + aData['EndDate'] + '</td></tr>';

        sOut += '<tr><td>Disable Alert</td><td><label for"Disable" class="textLabel panelCheckBox"><input type="checkbox" id="disable" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';

        sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" id="viewScreen" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" id="viewEmail" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="viewMobile" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';
        sOut += '<tr><td>Created By</td><td>' + aData['CreatedBy'] + '</td></tr>';
        sOut += '<tr><td>Created</td><td>' + aData['Created'] + '</td></tr>';
        sOut += '<tr><td>Modified By</td><td>' + aData['ModifiedBy'] + '</td></tr>';
        sOut += '<tr><td>Modified</td><td>' + aData['ModifiedDate'] + '</td></tr>';
        sOut += '<tr></tr>';
        sOut += '</table>';
    }

    return sOut;
}

/****
     *Row expansion Template Edit Details
     * @param {object} oTable selected table
     * @param {object} nTr The table row to 'open'
     * @returns {string} div tag to load form
     */
function fnFormatEdit(oTable, nTr) {
    return '<div name=editForm id=load' + $(nTr).find("td:first").text() + '></div>';
}



