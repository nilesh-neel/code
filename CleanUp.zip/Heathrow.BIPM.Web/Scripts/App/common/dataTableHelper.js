﻿//----------------------------------------------------------------------
//Class Name   : CustomGrid
//Purpose      : This is Custome Grid Class js file use to create the default JqData Table object with common css and other.
//               mandantory features like order enable/disable paginate etc...
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By  :     | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Vaishnavi.R (687417)|  Function implementation                  | 10/01/2018        |Functionality Implementation
//----------------------------------------------------------------------

$(document).ready(function () {
    //Row expansion for view
    $('table').on('click', '.Show_details', function rowExpansionView() {
        var nTr = $(this).parents('tr')[0];
        $(this).closest('table').find('tr.show_row').removeClass('show_row');
        $(nTr).addClass('show_row');
        var me = this;
        var Edit = '.Edit';
        var oTable = $(this).parents('table').dataTable();
        var aData = oTable.fnGetData(nTr);
        var grid = new CustomGrid();
        grid.RowExp(nTr, Edit, oTable, me, fnFormatNotification);
        $("#viewEmail").prop('checked', aData['IsEmail']);
        $("#viewMobile").prop('checked', aData['IsMobile']);
        $("#disable").prop('checked', aData['Disable']);

        $("#viewSub").prop('checked', aData['IsSubscribe']);
        $("#viewScreen").prop('checked', aData['IsScreen']);
        $("#viewSnooze").prop('checked', aData['IsSnooze']);
        $("#verticalTabs").height($(".zeroStyling:last-child").height());//to calculate the height if verticalTabs

    });
    //Row expansion for edit
    $('table').on('click', '.Edit', function rowExpansionEdit() {
        var nTr = $(this).parents('tr')[0];
        var me = this;
        var Show_details = '.Show_details';
        var tableName = $(this).closest('table').attr('id');
        $(this).closest('table').find('tr.show_row').removeClass('show_row');
        $(nTr).addClass('show_row');
        var path = '';
        var oTable = $(this).parents('table').dataTable();
        var aData = oTable.fnGetData(nTr);
        var grid = new CustomGrid();


       /* if (aData['MandatoryOptional'] === 'Mandatory' && tableName === 'alertSettingTable') {
            Utility.alertMessage("Mandatory alert cannot be modified", "warningMsg");
        }
        else*/ if (aData['CreatedBy'] !== $('#userEmail').text().toLowerCase() && (tableName === 'configureAlertsTable' )) {
            Utility.alertMessage("Your organisation is not allowed to modify this Alert", "warningMsg");
        }
        else if (aData['CreatedBy'] !== $('#userEmail').text().toLowerCase() && tableName === 'ConfigureNotificationTable' ) {
            Utility.alertMessage("Your organization is not allowed to modify this Notification", "warningMsg");
        }
        else if (tableName === 'alertSettingTable') {
            grid.RowExp(nTr, Show_details, oTable, me, fnFormatEdit);
            id = aData['AlertId'];
            path = baseUrl + '/Alerts/AlertSetting/' + id;
        }
        else if (tableName === 'configureAlertsTable') {
            grid.RowExp(nTr, Show_details, oTable, me, fnFormatEdit);
            id = aData['AlertId'];
            path = baseUrl + '/Alerts/Edit/' + id;
        }
        else if (tableName === 'notificationSettingsTable') {
            grid.RowExp(nTr, Show_details, oTable, me, fnFormatEdit);
            id = aData['NotificationId'];
            path = baseUrl + '/Notifications/NotificationSetting?notificationId=' + id;
        }
        else if (tableName === 'ConfigureNotificationTable') {
            grid.RowExp(nTr, Show_details, oTable, me, fnFormatEdit);
            id = aData['NotificationId'];
            path = baseUrl + '/Notifications/Edit?notificationId=' + id;
        }

        if (oTable.fnIsOpen(nTr)) {
            $.ajax({
                url: path,
                dataType: 'html',
                success: function (html) {
                    $('#load' + $(nTr).find("td:first").text()).html(html);
                }
            });
        }
        $("#verticalTabs").height($(".zeroStyling:last-child").height());//to calculate the height if verticalTabs

    });
});

var CustomGrid = (function () {
    'use strict';

    /****
   * Creates a new Alert object.
   * @constructor
   * @param {string} tableDiv pass the div id to configure the table.
   * @param {object} tableData pass the data to bind the table.
   * @param {object} tableColumn pass the number of column to bind the JqData Table
   * @param {bool} showDetails pass boolean value to show view detils button
   * @param {bool} allowEdit pass boolean value to show edit detils button
   */
    CustomGrid = function (tableDiv, tableData, tableColumn, showDetails, allowEdit) {
        this.GridDivName = tableDiv;
        this.Data = tableData;
        this.Column = tableColumn;
        this.AllowShow = _.isNull(showDetails) || _.isUndefined(showDetails) ? false : true;
        this.AllowEdit = _.isNull(allowEdit) || _.isUndefined(allowEdit) ? false : true;
        this.resp = true;
    };
        /****
     *  This  method use to create grid
     *  */
    CustomGrid.prototype.CreateGrid = function () {
        var numberOfRows = window.innerHeight - ($(".header").innerHeight() + $(".navPosition").innerHeight() + $(".notificationWrapper").outerHeight() + $('#tabs').outerHeight() + $(this.GridDivName + ' th').innerHeight() + 60);//for datatables pagination
        numberOfRows = Math.round(numberOfRows / ($(this.GridDivName + ' th').innerHeight()));// on load styles are not applied for 'th' so not calculating properly 
        $(this.GridDivName).dataTable({

            "sProcessing": true,
            "data": this.Data,
            "columns": this.Column,
            "pagingType": 'full_numbers',

            "iDisplayLength": numberOfRows,
            "ordering": true,
            "info": false,
            "bLengthChange": false,
            "bAutoWidth": false,
            "searching": false,
            "responsive": true,
            "oLanguage": {
                "sProcessing": "DataTables is currently busy",

                "oPaginate": {
                    "sFirst": 'First',
                    "sNext": '<img class="Next" src="" />',
                    "sPrevious": '<img class="Previous" src="" />',
                    "sLast": 'Last'
                }
            },
            "fnDrawCallback": function (oSettings) {
                $('span.Show_details').closest('td').addClass('showdetailsTDstyle');
                $('span.Edit').closest('td').addClass('showdetailsTDstyle');
                $('table tr td label.container').closest('td').addClass('tableCheckmarkStyleOveride');

            },
            "bDestroy": true,
            "bStateSave": true,
            "aoColumnDefs": [{
                "bSortable": false,
                "aTargets": ['nosort']
            }]
            //"fnStateSave": function (oSettings, data) {
            //    localStorage.setItem('offersDataTables', JSON.stringify(data));
            //},
            //"fnStateLoad": function (oSettings) {
            //    return JSON.parse(localStorage.getItem('offersDataTables'));
            //}

        });

        if ($(".notificationWrapper").css("display") === "none") {
            $(".dataTables_wrapper .dataTables_paginate").css("padding-bottom", "0px");
        }
        /* $('.checkmark').on('click', function (e) {
             debugger;
             Utility.alertMessage("Please click on edit to modify", "warningMsg");
         });*/
    };
     /****
     *  This method is called on click of view or edit in table for row expansion
     *  @param {object} nTr The table row to 'open'
     *  @param {object} prevClickedIcon  selection of previous icon (view/edit)
     *  @param {object} otable selected table
     *  @param {object} me selected icon (view/edit)
     *  @param {object} tempName function name that implements the HTML to put into the row
     *  */
    CustomGrid.prototype.RowExp = function (nTr, prevClickedIcon, otable, me, tempName) {
        otable.api().rows().every(function () {
            //&& !$(this.node()).hasClass('show_row')
            if (otable.fnIsOpen(this) && !($(this.node()).hasClass('show_row'))) {
                console.log(this.node());
                console.log(nTr);
                console.log($(nTr));
                otable.fnClose(this);
                // $(this.node()).removeClass('show_row')
                // $(this.node()).removeClass();
                $(this.node()).find("td").removeClass("showDetailsActive");
                $(this.node()).find("td span.clickedIcons").removeClass("clickedIcons").removeClass('customBorderSmall');
            }
        });
        // if ( !otable.fnIsOpen(nTr) )
        // {
        if ($(nTr).find(prevClickedIcon).hasClass('customBorderSmall')) {
            $(nTr).find(prevClickedIcon).closest("tr").find("td").toggleClass("showDetailsActive");
            $(nTr).find(prevClickedIcon).next().toggleClass("clickedIcons");
            $(nTr).find(prevClickedIcon).toggleClass("customBorderSmall");
            $(nTr).find(prevClickedIcon).closest("td").find("span").removeClass("clickedIcons");
            otable.fnClose(nTr);

        }
        if (otable.fnIsOpen(nTr)) {
            /* This row is already open - close it */
            // $(nTr).removeClass('show_row');
            otable.fnClose(nTr);
            $(me).closest("tr").find("td").toggleClass("showDetailsActive");
            $(me).removeClass("clickedIcons");
            $(me).toggleClass("customBorderSmall");
            $(me).next().toggleClass("clickedIcons");
            $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
            // $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
        }
        else {
            /* Open this row */
            // $(nTr).addClass('show_row');
            $(me).closest("tr").find("td").toggleClass("showDetailsActive");
            $(me).addClass("clickedIcons");
            $(me).next().toggleClass("clickedIcons");
            $(me).toggleClass("customBorderSmall");
            $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
            otable.fnOpen(nTr, tempName(otable, nTr), 'details');

            //$("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
        }
        //}
    };

     /****
      *  This method is used to append text with ellipsis at the last
      * @param {int} cutoff Denotes the length of text to be displayed
      * @returns {data} Updated string with ellipsis appended to the substring
      *  */
    CustomGrid.prototype.Ellipsis = function (cutoff) {
        return function (data, type, row) {
            return data.length > cutoff ? data.substr(0, cutoff) + '…' : data;
        };
    };

    /****
      *  This method is used to return comma separated text
      * @param {int} listToSplit List to be comma separated
      * @returns {data} Updated comma separated string
      *  */
    CustomGrid.prototype.CommaSeperatedString = function (listToSplit) {
        return _.chain(listToSplit).filter({ isSelected: true }).map(function (d) { return d.name; }).join(', ').value();
    };

    return CustomGrid;
})();