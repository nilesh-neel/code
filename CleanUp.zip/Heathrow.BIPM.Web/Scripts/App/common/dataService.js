﻿//----------------------------------------------------------------------
//Class Name   : Service
//Purpose      : This is Data Service js file use to connect with the server side api/controller call.
//               Whit this ajax call we can achive promise in javascripts.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------


var Service = (function ($) {

    var fileAttribute = window.location.origin;
    var apiUrl = $('#hdnApiUrl').val().trim();

    /**
     * Creates a new Service object.
     * @constructor
     * @param {string} url the controller or api url
     * @param {string} contentType the ajax call content Type like(application/json Or application/html) or api url
     * @param {string} dataType the type of data conatin in ajax request.
     * @param {object} data the data to send to serve for the post call
     * @param {Array}  callArray the execute multiple ajax call.
     */
    Service = function (url, contentType, dataType, data, callArray) {
        $('#loading').show();
        this.requestURL = url;
        this.requestContentType = _.isNull(contentType) || _.isUndefined(contentType) ? 'application/json; charset=utf-8' : contentType;
        this.requestDataType = _.isNull(dataType) || _.isUndefined(dataType) ? 'json' : dataType;
        this.requestData = _.isNull(data) || _.isUndefined(data) ? null : data;
        this.requestMultipleCall = callArray;

        this.config = {
            url: url,
            contentType: _.isNull(contentType) || _.isUndefined(contentType) ? 'application/json; charset=utf-8' : contentType,
            data: _.isNull(data) || _.isUndefined(data) ? null : JSON.stringify(data),
            type: "",
            dataType: _.isNull(dataType) || _.isUndefined(dataType) ? 'json' : dataType,
            crossDomain: true
        };

    };


    Service.prototype.AsyncCall = function (configData) {

        $.ajax(configData).done(function (jqXHR, textStatus, err) {
            deffer.resolve(jqXHR, textStatus, err);
        }).fail(function (jqXHR, textStatus, err) {
            deffer.reject(jqXHR, textStatus, err);
        });
    };


    /**
    // ajax authentication call only.
    * @param {string} authToken the token is authenticated
    * @returns {object} return the promise state(Resolve/reject).
    */
    Service.prototype.authenticate = function (authToken) {
        var deffer = $.Deferred();
        $.ajax({
            url: this.requestURL,
            type: 'POST',
            contentType: this.requestContentType,
            dataType: 'json',
            beforeSend: function (request) {
                request.setRequestHeader('AuthToken', authToken);
            },
            'success': function (data) {
                deffer.resolve(data);
            },
            'error': function (error) {
                deffer.reject(error);
            }
        });

        return deffer.promise();
    };


    /**
    // ajax get call only.
    * @returns {object} return the promise state(Resolve/reject).
    */
    Service.prototype.get = function () {
        $('#loading').show();
        var deffer = $.Deferred();
        $.ajax({
            url: this.requestURL,
            data: this.requestData,
            type: 'GET',
            crossDomain: true
        }).done(function (jqXHR, textStatus, err) {
            $('#loading').hide();
            deffer.resolve(jqXHR, textStatus, err);
        }).fail(function (data) {
            $('#loading').hide();
            deffer.reject(jqXHR, textStatus, err);
            if (data.errorMessage) {
                Utility.alertMessage('There was a problem in get request: ' + data.errorMessage, 'errorMsg');
            }
            Utility.alertMessage('There was a problem in the request : Please try again.', 'errorMsg');
        });
        return deffer.promise();
    };

    /**
    // ajax get call only.
    * @returns {object} return the promise state(Resolve/reject).
    */
    Service.prototype.getApi = function () {
        $('#loading').show();
        var deffer = $.Deferred();
        var ajaxOption = this.config;
        Service.prototype.webApiAccessToken.call(this).then(
            function (resp) {
                delete ajaxOption['contentType'];
                ajaxOption.url = apiUrl + ajaxOption.url;
                ajaxOption.beforeSend = function (request) {
                    request.setRequestHeader('Authorization', 'Bearer ' + resp.token);
                };
                ajaxOption.type = 'GET';
                $.ajax(ajaxOption).done(function (jqXHR, textStatus, err) {
                    $('#loading').hide();
                    if (jqXHR.statusCode === 200) {
                        deffer.resolve(jqXHR.result);
                    } else {
                        deffer.reject(jqXHR, textStatus, err);
                        Utility.alertMessage('There was a problem in the request : ' + JSON.stringify(jqXHR.errorMessage), 'errorMsg');
                    }
                }).fail(function (jqXHR, textStatus, err) {
                    deffer.reject(jqXHR, textStatus, err);
                    $('#loading').hide();
                    Utility.alertMessage('There was a problem in get request: ' + JSON.stringify(jqXHR.errorMessage), 'errorMsg');
                });
            });
        return deffer.promise();
    };

    /**
    // ajax save call to save data, make sure send data in the body of the request.
    * @returns {object} return the promise state(Resolve/reject).
    */
    Service.prototype.save = function () {
        $('#loading').show();
        var deffer = $.Deferred();
        $.ajax({
            url: this.requestURL,
            contentType: this.requestContentType,
            data: JSON.stringify(this.requestData),
            type: 'POST',
            dataType: this.dataType,
            crossDomain: true
        }).done(function (jqXHR, textStatus, err) {
            deffer.resolve(jqXHR, textStatus, err);
            $('#loading').hide();
        }).fail(function (jqXHR, textStatus, err) {
            deffer.reject(jqXHR, textStatus, err);
            $('#loading').hide();
            if (data.errorMessage) {
                Utility.alertMessage('There was a problem while saving error is: ' + data.errorMessage, 'errorMsg');
            }
            Utility.alertMessage('There was a problem in save request : Please try again.', 'errorMsg');
        });
        return deffer.promise();
    };

    /**
    // ajax save call to save data, make sure send data in the body of the request.
    * @returns {object} return the promise state(Resolve/reject).
    */
    Service.prototype.postApi = function () {
        $('#loading').show();
        var deffer = $.Deferred();
        var ajaxOption = this.config;
        Service.prototype.webApiAccessToken().then(
            function (resp) {
                ajaxOption.url = apiUrl + ajaxOption.url;
                ajaxOption.beforeSend = function (request) {
                    request.setRequestHeader('Authorization', 'Bearer ' + resp.token);
                };
                ajaxOption.type = 'POST';
                $.ajax(ajaxOption).done(function (jqXHR, textStatus, err) {
                    if (jqXHR.statusCode === 200) {
                        deffer.resolve(jqXHR.result);
                    } else {
                        deffer.reject(jqXHR, textStatus, err);
                        Utility.alertMessage('There was a problem in the request : ' + jqXHR.result, 'errorMsg');
                    }
                    $('#loading').hide();
                }).fail(function (jqXHR, textStatus, err) {
                    if (textStatus === 'error') {
                        deffer.reject(jqXHR, textStatus, err);
                        Utility.alertMessage('There was a problem while saving: ' + jqXHR.responseJSON.errorMessage, 'errorMsg');
                    } else {
                        deffer.reject(jqXHR, textStatus, err);
                        Utility.alertMessage('There was a problem while saving: ' + jqXHR.responseJSON.message, 'errorMsg');
                    }
                    $('#loading').hide();
                });
            });
        return deffer.promise();
    };


    /**
    // ajax put call to update data,  make sure URL contain the id to update the record.
    * @returns {object} return the promise state(Resolve/reject).
    */
    Service.prototype.update = function () {
        $('#loading').show();
        var deffer = $.Deferred();

        $.ajax({
            url: this.requestURL,
            contentType: this.requestContentType,
            data: this.requestData,
            type: 'PUT',
            crossDomain: true
        }).done(function (jqXHR, textStatus, err) {
            deffer.resolve(jqXHR, textStatus, err);
            $('#loading').hide();
        }).fail(function (jqXHR, textStatus, err) {
            deffer.reject(jqXHR, textStatus, err);
            if (data.errorMessage) {
                Utility.alertMessage('There was a problem while updating data => error is: ' + data.errorMessage, 'errorMsg');
            }
            Utility.alertMessage('There was a problem in update request : Please try again.', 'errorMsg');
            $('#loading').hide();
        });

        return deffer.promise();
    };

    /**
   // ajax put call to update data,  make sure URL contain the id to update the record.
   * @returns {object} return the promise state(Resolve/reject).
   */
    Service.prototype.putApi = function () {
        $('#loading').show();
        var deffer = $.Deferred();
        var ajaxOption = this.config;
        Service.prototype.webApiAccessToken().then(
            function (resp) {
                ajaxOption.url = apiUrl + ajaxOption.url;
                ajaxOption.beforeSend = function (request) {
                    request.setRequestHeader('Authorization', 'Bearer ' + resp.token);
                };
                ajaxOption.type = 'PUT';
                ajaxOption.dataType = 'json';
                $.ajax(ajaxOption).done(function (jqXHR, textStatus, err) {
                    if (jqXHR.statusCode === 200) {
                        deffer.resolve(jqXHR.result);
                    } else {
                        deffer.reject(jqXHR, textStatus, err);
                        Utility.alertMessage('There was a problem in the request : ' + jqXHR.result, 'errorMsg');
                    }
                    $('#loading').hide();
                }).fail(function (jqXHR, textStatus, err) {
                    deffer.reject(jqXHR, textStatus, err);
                    Utility.alertMessage('There was a problem in get request: ' + err.message, 'errorMsg');
                    $('#loading').hide();
                });
            });
        return deffer.promise();
    };

    /**
    // ajax delete call to delete data, make sure URL contain the id to delete the record.
    * @returns {object} return the promise state(Resolve/reject).
    */
    Service.prototype.delete = function () {
        $('#loading').show();
        var deffer = $.Deferred();
        $.ajax({
            url: this.requestURL,
            contentType: this.requestContentType,
            data: this.requestData,
            type: 'DELETE',
            crossDomain: true
        }).done(function (jqXHR, textStatus, err) {
            deffer.resolve(jqXHR, textStatus, err);
            $('#loading').hide();
        }).fail(function (jqXHR, textStatus, err) {
            deffer.reject(jqXHR, textStatus, err);
            if (data.errorMessage) {
                Utility.alertMessage('There was a problem while deleting data => error is: ' + data.errorMessage, 'errorMsg');
            }
            Utility.alertMessage('There was a problem in delete request : Please try again.', 'errorMsg');
            $('#loading').hide();
        });

        return deffer.promise();
    };

    /**
   // ajax delete call to delete data, make sure URL contain the id to delete the record.
   * @returns {object} return the promise state(Resolve/reject).
   */
    Service.prototype.deleteApi = function () {
        $('#loading').show();
        var deffer = $.Deferred();
        var ajaxOption = this.config;
        Service.prototype.webApiAccessToken().then(
            function (resp) {
                ajaxOption.url = apiUrl + ajaxOption.url;
                ajaxOption.beforeSend = function (request) {
                    request.setRequestHeader('Authorization', 'Bearer ' + resp.token);
                };
                ajaxOption.type = 'DELETE';
                ajaxOption.dataType = 'json';
                $.ajax(ajaxOption).done(function (jqXHR, textStatus, err) {
                    if (jqXHR.statusCode === 200) {
                        deffer.resolve(jqXHR.result);
                    } else {
                        deffer.reject(jqXHR, textStatus, err);
                        Utility.alertMessage('There was a problem in the request : ' + jqXHR.result, 'errorMsg');
                    }
                    $('#loading').hide();
                }).fail(function (jqXHR, textStatus, err) {
                    deffer.reject(jqXHR, textStatus, err);
                    Utility.alertMessage('There was a problem in get request: ' + err.message, 'errorMsg');
                    $('#loading').hide();
                });
            });
        return deffer.promise();
    };

    /**
   // get the access token from web api
   * @returns {object} return the promise state(Resolve/reject).
   */
    Service.prototype.webApiAccessToken = function () {
        $('#loading').show();
        var deffer = $.Deferred();
        $.ajax({
            url: fileAttribute + '/Auth/Token',
            type: 'GET'
        }).done(function (jqXHR, textStatus, err) {
            deffer.resolve(jqXHR, textStatus, err);
            $('#loading').hide();
        }).fail(function (data) {
            //if (data.errorMessage) {
            //    Utility.alertMessage('There was a problem to genetate token data => error is: ' + deffer.resolve(data).errorMessage, 'errorMsg');
            //}
            //Utility.alertMessage('There was a problem in token request : Please try again.', 'errorMsg');
            deffer.reject(data);
            $('#loading').hide();
            Utility.ClearStoredData();
            window.location.href = '/Account/InValidToken';
        });

        return deffer.promise();
    };

    //handle multiple calls
    Service.prototype.getMultipleCall = function () {
        var promises = this.requestMultipleCall;
        return $.when.apply($, promises);
    };
    return Service;
})(jQuery);