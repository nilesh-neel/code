﻿//----------------------------------------------------------------------
//Class Name   : Utility
//Purpose      : This is Utility js file use to define globally used functions and variables.//               
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Anupama               FDS Change                                  10/02/2019         code for updating the default value of dropdown
//Anupama               FDS Change                                  15/01/2019         Enum for Report type
//----------------------------------------------------------------------

'use strict';
var filterConfigValues;
var filterUrl;
var notesValue = null;
var notesType;
var notesUblValue = null;
var notesCountVal;
var hasSingleDate = false;
var isSearchClicked = false;
var isFilterInheritance = false;
var isApplyClicked = false;
var filterDate = '';
var isDropdownValChanged = false;
var documentClicked = true;
var ksStorage = sessionStorage;

var Utility =
{

    //This will add values to the dropdown list
    addValuesToDropDown: function (dropDown, values) {
        $.each(values, function (key, property) {
            $(dropDown).append($('<option></option>').attr('value', property.ID).text(property.Name));
        });
    },

    //update values to dropdown
    SetValuesToDropDown: function (dropDown, value) {
        var controlSelector = dropDown + ' + span';
        $(controlSelector).first('input').children('input').val(value);
    },
    //update values to dropdown
    SetValuesToSingleDropDown: function (dropDown, value) {
        var controlSelector = dropDown + ' + span';
        var displayText = _.filter($(dropDown)[0].options, function (o) { return o.value === value; })
        if (displayText.length > 0) {
            $(controlSelector).children('input').val(displayText[0].text);
        }
    },

    //bind values to multiselect dropdown
    bindMultiDropDown: function (dropDown, values) {
        if (!_.isNil(values[0])) {
            $(dropDown).multiselect('dataprovider', values[0]);
            var selectconfig = {
                enableFiltering: true,
                includeSelectAllOption: false,
                maxHeight: 200,
                buttonWidth: '100%',
                enableCaseInsensitiveFiltering: true,
                nonSelectedText: 'All'
            };
            $(dropDown).multiselect('setOptions', selectconfig);
            $(dropDown).multiselect('rebuild');
        }
    },
    //clear multiselect dropdown
    ClearMultiDropDown: function (dropDown) {
        $(dropDown).multiselect().empty();
        var selectconfig = {
            maxHeight: 200,
            buttonWidth: '100%',
            nonSelectedText: 'Select'
        };
        $(dropDown).multiselect('setOptions', selectconfig);
        $(dropDown).multiselect('rebuild');
    },

    //add values to multiselect dropdown
    addValuesToMultiSelectDropDown: function (dropDown, selectedvalues) {
        if (!_.isNil(selectedvalues)) {
            var selectedOptions = selectedvalues.split(",");
            $(dropDown).val(selectedOptions);
            $(dropDown).multiselect('rebuild');
        }
    },

    //special character validation
    SpecialCharacterValidation: function (event) {
        var regex = new RegExp('^[a-zA-Z0-9,]+$');
        var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
        if (!regex.test(key)) {
            event.preventDefault();
            return false;
        }
    },

    //close panel
    ClosePanel: function () {
        if ($("#sharePanel").is(":visible") || $("#filterPanel").is(":visible") || $("#notesDiv").is(":visible")) {
            if ($("#filterPanel").is(":visible")) {
                $("#filterPanel").toggle();
                $(".filter").toggleClass("clickedIcons");
                $(".filter").toggleClass("customBorderSmall");
            }

            if ($("#notesDiv").is(":visible")) {
                $("#notesDiv").toggle();
                $(".notes").toggleClass("clickedIcons");
                $(".notes").toggleClass("customBorderSmall");
            }
            if ($("#sharePanel").is(":visible")) {
                $("#sharePanel").toggle();
                $(".share").toggleClass("clickedIcons");
                $(".share").toggleClass("customBorderSmall");
            }
        }

        if ($(".settingsLogout").is(":visible")) {
            $(".settingsLogout").toggle();
        }
    },

    //click of message
    alertMessage: function (msg, msgType) {
        var refMessage = $('.refreshMessage');
        var dvMessage = $('#dvAlertMsg');

        refMessage.show();
        dvMessage.show();

        var len = msg.length;

        if (len >= 75) {
            dvMessage.text(msg.substring(0, 80) + "...");
            dvMessage.on("mouseover", function dvMessageHover(e) {
                $(this).css('cursor', 'pointer');
                $(this).stop(true /*, false implied */).fadeIn(0);
            });

            dvMessage.on("click", function dvMessageClick(e) {
                refMessage.hide();
                dvMessage.hide();

                $("#messageModalCenter").modal('show');
                $("#messageModalLongTitle").text(msg);
            });
        }
        else {
            dvMessage.text(msg);
            dvMessage.on("mouseover", function dvMessageMouseOver(e) {
                $(this).stop(true /*, false implied */).fadeIn(0);
            });
        }

        refMessage.on("mouseover", function refMessageMouseOver(e) {
            $(this).stop(true /*, false implied */).fadeIn(0);
        });

        refMessage.on("mouseleave", function refMessageMouseLeave(e) {
            Utility.HideMessage(this);
        });

        dvMessage.on("mouseleave", function dvMessageMouseLeave(e) {
            Utility.HideMessage(this);
        });

        refMessage.removeClass();
        refMessage.addClass('refreshMessage ' + msgType);

    },
    HideMessage: function (element) {
        $('.refreshMessage').fadeOut(8000, function () {
            $(this).hide();
        });
        $('#dvAlertMsg').fadeOut(8000, function () {
            $(this).hide();
        });
    },

    //get type of report
    GetDateForOperationalOrBusinessReport: function () {
        //today date
        var d = new Date();
        var currentDate = d.getMonth() + 1 + "/" + d.getDate() + "/" + d.getFullYear();
        var reportDate = null;
        if ($("#headerDate").val().indexOf('-') > -1) {
            reportDate = $("#headerDate").val().split('-')[1];
        } else {
            reportDate = $("#headerDate").val();
        }
        reportDate = reportDate.trim();

        //changing the format of report type date to  mm/dd/yyyy
        //since it is string use valueOf
        var arrReportDate = reportDate.valueOf().split("/");
        var selectedDate = arrReportDate[1] + "/" + arrReportDate[0] + "/" + arrReportDate[2];

        // changing to date object for comparision
        var currentDateVal = new Date(currentDate);
        var reportDateVal = new Date(selectedDate);
        if (Date.parse(reportDateVal) < Date.parse(currentDateVal)) {
            //Business report
            return 2;
        } else {
            //Operationl report
            return 1;
        }
    },

    ReportName:
    {
        Favourite: 1, Home: 2, BagDetails: 4, BagListInBound: 42, BagListOutBound: 43, FlightDetailsInBound: 6, FlightDetailsOutBound: 7, VOLSMR: 14, ADPDBD: 24,
        ADPDBDLocal: 44, ADPDBDTransfer: 45, ADPSMR: 25, ADPDLR: 26, BJPDBD: 27, BJPSMR: 28, BJPDLR: 29, NLBDBD: 35, NLBSMR: 36, NLBDLR: 37, DDPDBD: 32,
        DDPSMR: 33, DDPDLR: 34, BagListGeneral: 18, BagListNLBA: 19, BTRInBound: 20,
        BTROutBound: 21, BSMSMR: 15, ITTDBD: 30, ITTDLR: 31, MDRSMR: 38, MDRDLR: 39, ARRDBDNext: 22, ARRDBD: 23
    },
    ControlName:
    {
        RelationalTimeband: 3, PaxSurname: 4, BagTag: 5, NotLoadedCategory: 6, NotLoadedSubCategory: 7, OutboundFlight: 8, OutboundAircraft: 9, Destination: 10,
        OutboundAirline: 11, OutboundHandler: 12, OutboundTerminal: 13, InboundFlight: 14, InboundAirline: 15, InboundAircraft: 16, Origin: 17, InboundHandler: 18,
        InboundTerminal: 19, LastSeenLocation: 20, BagStatus: 21, BagType: 22, ShortConnect: 23, OOGBags: 24, SeenAfterChox: 25, ShowDeletedBags: 26, ShowMissedBRS: 27,
        ShowDelBSMs: 28, ShowMyBagList: 29, Route: 30, ProcessArea: 31, BaggageSystem: 32, RouteStartEndTime: 33, InboundITO: 34, InTarget: 35, FailedThenMissed: 36,
        SeenAtStart: 37, SeenAtEnd: 38, NotLoadedFailedInSystem: 39, MDStatusLocation: 40, LateBSM: 41
    },
    SearchType:
    {
        FlightNumber: 1,
        BagTag: 2,
        PassegerName: 3,
        InvalidBagtag: 4,
        InValid: 5
    },

    //check on session data
    SessionDataNullCheck: function (paramName, storageType, paramValue) {
        if (sessionStorage) {
            if (storageType === Utility.SessionStorageType.Get) {
                return !_.isNil(Utility.GetStoredData(paramName)) ? Utility.GetStoredData(paramName) : null;
            }
            else if (storageType === Utility.SessionStorageType.Set) {
                Utility.SetStoredData(paramName, paramValue);
            }
        }
    },

    SessionStorageType:
    {
        Get: 1,
        Set: 2
    },
    //show/hide of notes icon
    ShowNotesIcon: function (isEnable, isPinEnable) {
        if (isEnable) {
            $("#dvNotesIcon").addClass('defaultIcons notes');
            $("#xsNote").addClass('spanNotification');
            $("#dvNotesIcon,#xsNote").removeClass('noteDisable');
        }
        else {
            $("#dvNotesIcon").removeClass('defaultIcons notes');
            $("#xsNote").removeClass('spanNotification');
            $("#dvNotesIcon,#xsNote").addClass('noteDisable');
        }
        this.ShowFilterIcon(isPinEnable);
    },

    //show/hide of filter icon
    ShowFilterIcon: function (hasFilter) {
        if (hasFilter) {
            $("#btnReset,#pinIcon,pinIconLink").removeClass('hidden');
        }
        else {
            $("#btnReset,#pinIcon,pinIconLink").addClass('hidden');
            $(".filter").removeClass("disabledIcons");
        }
    },

    //date format of report
    ReportDateFormat: function () {
        var reportDate = [];
        var dateForFilter = [];
        var dateVal = (!_.isEmpty(filterDate) && isFilterInheritance) ? filterDate : $("#headerDate").val().trim();
        if ($("#headerDate").val().indexOf('-') > -1) {
            reportDate = $("#headerDate").val().split('-');
        }
        else { reportDate.push($("#headerDate").val()); }
        for (var i = 0; i < reportDate.length; i++) {
            dateForFilter.push(reportDate[i].trim().split("/").reverse().join("-") + "T00:00:00");
        }
        return dateForFilter;
    },
    ReportColumnName:
    {
        BagDetails: 'BagItemID',
        InboundFlight: 'InboundAircraftMovementIdentificationID',
        OutboundFlight: 'OutboundAircraftMovementIdentificationID',
        InboundFlightNumber: 'InboundAirlineFlightNumber',
        OutboundFlightNumber: 'OutboundAirlineFlightNumber',
        BagTag: 'TagNumber',
        Date: 'Date'
    },

    FilterDefaultValue:
    {
        None: 'Identified',
        No: 'N',
        All: 'Y AND N'
    },

    SearchDataPrefix:
    {
        FlightNumber: "F",
        BagTag: "B",
        PassegerName: "N"
    },
    DateOperator:
    {
        GreaterThanEqual: 'GreaterThanOrEqual',
        LessthanEqual: 'LessThanOrEqual',
        Equal: 'eq',
        LogicalAnd: 'And',
        LogicalOr: 'Or'
    },

    //show the filtered data
    ShowFilterDate: function (menuItemId, isMultiDate, isMenuClik) {
        if (menuItemId > 0) {

            var report = this.ReportName;
            switch (menuItemId) {
                case report.BagListInBound: case report.BagListOutBound: case report.FlightDetailsInBound: case report.BagDetails:
                case report.FlightDetailsOutBound: case report.BTRInBound: case report.BTROutBound: case report.ADPDBD:
                case report.ADPDBDLocal: case report.ADPDBDTransfer: case report.NLBDBD: case report.ARRDBDNext: case report.ARRDBD:
                    singleDateSelector(isMenuClik);
                    break;
                default:
                    multipleDatesSelector(isMultiDate, isMenuClik);
                    break;
            }
        }
    },

    //apply date filter
    ApplyDateFilter: function (filterData, filterList) {
        var dateRow = [];
        var dateVal = Utility.ReportDateFormat();

        if (dateVal.length === 1) {
            dateRow = { tableName: filterData.tableName, columnName: filterData.columnName, columnValue: [dateVal[0]], operator: filterData.operator };
            filterList.push(dateRow);
        }
        else {
            for (var j = 0; j < dateVal.length; j++) {
                dateRow = {
                    tableName: filterData.tableName, columnName: filterData.columnName,
                    operator: (j === 0) ? 'gt' : 'le', columnValue: [dateVal[j]]
                };
                filterList.push(dateRow);
            }
        }

        return filterList;
    },

    //show the hide menu icon
    showHideMenuIcon: function () {
        $(".hambergerDiv,.favorite, .searchDiv, #lnkbtnMyBagList").attr("style", "display: none !important");
    },
    SearchConfigValidation: function (parameter) {
        var flightRegex = new RegExp(/^(([A-Za-z]{1,3})|([A-Za-z]\d)|(\d[A-Za-z]))(\d{1,4})([A-Za-z]?)$/);
        var bagtagRegex = new RegExp(/^\d{6,10}$/);
        var passengerRegex = new RegExp(/^([a-zA-Z]{2,30})+$/);
        var numericRegex = new RegExp(/^\d{1,5}$/);

        if (flightRegex.test(parameter)) {
            return this.SearchType.FlightNumber;
        }
        else if (bagtagRegex.test(parameter)) {
            return this.SearchType.BagTag;
        }
        else if (passengerRegex.test(parameter)) {
            return this.SearchType.PassegerName;
        }
        else {
            if (numericRegex.test(parameter)) {
                return 0;
            }
        }
    },

    GetStoredData: function (key) {
        return ksStorage.getItem(key);
    },
    SetStoredData: function (key, value) {
        ksStorage.setItem(key, value);
    },
    RemoveStoredData: function (key) {
        ksStorage.removeItem(key);
    },
    ClearStoredData: function (key) {
        ksStorage.clear();
    }


};