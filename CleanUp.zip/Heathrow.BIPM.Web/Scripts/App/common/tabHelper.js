﻿//----------------------------------------------------------------------
//Class Name   : TabConfig
//Purpose      : Purpose of this file to configure the default tab behaviour in Alert/Notifications Module's.
//               mandantory features like order enable/disable paginate etc...
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By :       | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Vaishnavi.R (687417)|  Function implementation                  | 10/01/2018        |Functionality Implementation
//----------------------------------------------------------------------

var TabConfig = (function () {
    'use strict';

    /****
   * Creates a new Alert object.
   * @constructor
   * @param {string} configForAlert pass the div id to configure the alert tab.
   * @param {string} configForNotify pass the div id to configure the notification tab
   * @param {string} configForReport pass the div id to configure the report tab
   * @param {string} configForAssignHome pass the div id to configure the assign home page tab
   *
   */
    TabConfig = function (configForAlert, configForNotify, configForReport, configForAssignHome) {
        this.AlertTab = _.isNull(configForAlert) || _.isUndefined(configForAlert) ? false : true;
        this.NotificationTab = _.isNull(configForNotify) || _.isUndefined(configForNotify) ? false : true;
        this.ReportTab = _.isNull(configForReport) || _.isUndefined(configForReport) ? false : true;
        this.AssignHomeTab = _.isNull(configForAssignHome) || _.isUndefined(configForAssignHome) ? false : true;
    };

     /****
     * This  method used to load alert/notification configuration form on click of new alert/new notification
     */
    TabConfig.prototype.NewConfigurationButtonClick = function () {
        $("#dvDateselection").hide();
        var configDiv = _.lowerCase($('.tab-content .tab-pane.active.in').attr('id'));
        if (_.includes(configDiv, 'alert')) {
            $("#alertSettingTable_wrapper,#configureAlertsTable_wrapper,#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display', 'none');
            $('#congigureNewAlertBtn').css('display', 'none');

            $('.configurueTab').css('display', 'block');
            $('#configureBackBtn').css('display', 'block');
            $('.configureAlertForm').css('display', 'block');
            $.ajax({
                url: baseUrl + '/Alerts/NewAlert',
                dataType: 'html',
                success: function (html) {
                    $('.configureAlertForm').html(html);
                }
            });       
            $('#congigureNewAlertBtn').text('Configure New Alert');
        } else if (_.includes(configDiv, 'notification')) {
            $('#tabs ul li').css('display', 'none');
            $('.configureNotificationTab ').css('display', 'block');
            $('.ConfigureNotificationTable_wrapper').css('display', 'none');
            $("#ConfigureNotificationTable_wrapper").css('display', 'none');
            $('.configureBtnNotification').css('display', 'block');
            $('.configureBtnNotification button').css('display', 'none');
            $('#configureBackNotificationBtn').css('display', 'block');
            $('.configureNotificationForm').css('display', 'block');
            $.ajax({
                url: baseUrl + '/Notifications/NewNotification',
                dataType: 'html',
                success: function (html) {
                    $('.configureNotificationForm').html(html);
                }
            });
        }
    };
      /****
     * This  method handles back button click event from configure new alert/ configure new notification
     */

    TabConfig.prototype.BackButtonClick = function () {
        $("#dvDateselection").hide();
        $(".favorite,.filter,.share,.print").addClass("disabledIcons");
        var configDiv = _.lowerCase($('.tab-content .tab-pane.active.in').attr('id'));

        if (_.includes(configDiv, 'alert')) {
            $('#tabs ul li').css('display', 'none');
            $('.alertTabs').css('display', 'block');
            $('.configureBtn').css('display', 'block');
            $('.configureBtn button,.configureAlertForm').css('display', 'none');
            $("#tabs a[href='#alertSettings'] , #tabs a[href='#todaysAlerts']").css('display', 'block');
            $("#configureAlertsTable_wrapper").show();
            $("#tabs a[href='#configureAlerts']").click();

        } else if (_.includes(configDiv, 'notification')) {
            $('#tabs ul li').css('display', 'none');
            $('.notificationTabs').css('display', 'block');
            $('.configureBtnNotification').css('display', 'block');
            $('.configureBtnNotification button,.configureNotificationForm').css('display', 'none');
            $("#ConfigureNotificationTable_wrapper").show();
            $("#tabs a[href='#configureNotifications']").click();
        }
    };
    return TabConfig;
})();