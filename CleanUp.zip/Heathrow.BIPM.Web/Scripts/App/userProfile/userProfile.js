﻿//----------------------------------------------------------------------
//Class Name   : UserProfile
//Purpose      : egt the login in user details profile photo, email organization etc..
//Created By   : Anupama Kumari
//Created Date : 01/March/2019
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Anupama               FDS Change                                  12/03/2019         Change related to the dropdown values being saved for the user
//Anupama               FDS Change                                  12/03/2019         Change related to getting the saved values in dropdown
//----------------------------------------------------------------------
$(document).ready(function () {
    var firstName = $('#userFullName').text().split(' ');
    var intials = firstName[0].replace(/(\r\n|\n|\r)/gm, "").charAt(0) + firstName[1].replace(/(\r\n|\n|\r)/gm, "").charAt(0);
    $("#profileImage").html(intials).addClass('cspUserPic');

    //on click of user image
    $('.user.pull-right').on('click', imageClick);

    function imageClick() {
        var firstName = $('#userFullName').text().split(' ');
        var intials = firstName[0].replace(/(\r\n|\n|\r)/gm, "").charAt(0) + firstName[1].replace(/(\r\n|\n|\r)/gm, "").charAt(0);
        $("#profileImage2").html(intials).addClass('cspUserPic2');
        //UserProfile.prototype.OperationalArea.call();
        //UserProfile.prototype.Location.call();
        UserProfile.prototype.GetUserDetails.call();
    }
});

// map the user to selected operational area and location
function mapUserToOperationAreaLocation() {
    var selectedUserOperationalAreaId = $("#userOperationalArea :selected").val();
    var selectedUserOperationalAreaText = $("#userOperationalArea :selected").text();
    var selectedUserLocationId = $("#userLocation :selected").val();
    var selectedUserLocationText = $("#userLocation :selected").text();
    var loggedUserId = $('#userId').val();
    var userData = {};
    var lookupData = {};
    var lookupDataNew = {};
    userData.UserId = loggedUserId;

    if (selectedUserOperationalAreaId !== null) {
        lookupData.RowId = selectedUserOperationalAreaId;
        lookupData.LookupTypeName = selectedUserOperationalAreaText;
        userData.OperationalArea = lookupData;
    }

    if (selectedUserLocationId !== null) {
        lookupDataNew.RowId = selectedUserLocationId;
        lookupDataNew.LookupTypeName = selectedUserLocationText;
        userData.Location = lookupDataNew;
    }

    service = new Service('api/User', 'application/json; charset=utf-8', 'json', userData);
    service.postApi()
        .done(function () {
            return false;
        }).fail(function (jqXHR, textStatus, errorThrown) {
            console.log(jqXHR, textStatus, errorThrown);
        });
}
var originalOperationalArea = "";
var originalLocation = "";
var UserProfile = (function () {

    var service =
        /****
        * Creates a new UserProfile object.
        * @constructor
        *
        */
        UserProfile = function () {


        };

    /**
    // set photo of the user
    */
    UserProfile.prototype.photo = function () {
        service = new Service('dashboard/photo');
        $.when(service.get()
            .then(function (resp) {
                $("#imgUserThumbnail").attr('src', 'data:image/png;base64,' + resp).addClass('cspUserPic');
                $("#imgUser").attr('src', 'data:image/png;base64,' + resp).addClass('profPicMain');
            }));
    };

    /**
    // get user's location and operational area details
    */
    UserProfile.prototype.GetUserDetails = function () {
        var dataToSend = [];
        if ($('#userOperationalArea')[0].options.length === 0 || $('#userLocation')[0].options.length === 0) {
            service = new Service('api/GetUserDetails');
            $.when(service.getApi()
                .then(function (resp) {
                    for (i = 0; i < resp.length; i++) {
                        var userOperationalAreaText = resp[i].operationalArea.lookupTypeName;
                        var userLocationText = resp[i].location.lookupTypeName;
                        dataToSend.push(userOperationalAreaText, userLocationText);
                    }
                    fillOperationalArea(dataToSend[0]);
                    fillLocation(dataToSend[1]);
                }));
        }
    };

    //fill the operational area dropdown
    function fillOperationalArea(operationalAreaText) {
        var option = '';
        $('#userOperationalArea').append(option);
        service = new Service('api/UserProfile/0');
        $.when(service.getApi()
            .then(function (resp) {
                var value = "";
                for (i = 0; i < resp.bagOperationalArea.length; i++) {
                    value = resp.bagOperationalArea[0].lookupTypeName;
                    option += '<option value="' + resp.bagOperationalArea[i].rowId + '">' + resp.bagOperationalArea[i].lookupTypeName + '</option>';
                }
                if (operationalAreaText !== null || operationalAreaText !== "") {
                    originalOperationalArea = operationalAreaText;
                    Utility.SetValuesToDropDown('#userOperationalArea', operationalAreaText);
                }
                else {
                    originalOperationalArea = value;
                    Utility.SetValuesToDropDown('#userOperationalArea', value);
                }
                $('#userOperationalArea').append(option);
            }));

        $('.combobox').combobox(
            {
                select: function () {
                    isDropdownValChanged = true;
                    documentClicked = false;
                }
            });

    }

    //fill the location dropdown
    function fillLocation(userLocationText) {
        var option = '';
        service = new Service('api/UserProfile/0');
        $.when(service.getApi()
            .then(function (resp) {
                var value = "";
                $('#userLocation').append(option);
                for (i = 0; i < resp.bagLocation.length; i++) {
                    value = resp.bagLocation[0].lookupTypeName;
                    option += '<option value="' + resp.bagLocation[i].rowId + '">' + resp.bagLocation[i].lookupTypeName + '</option>';
                }
                if (userLocationText !== null || userLocationText !== "") {
                    originalLocation = userLocationText;
                    Utility.SetValuesToDropDown('#userLocation', userLocationText);
                }
                else {
                    originalLocation = value;
                    Utility.SetValuesToDropDown('#userLocation', value);
                }
                $('#userLocation').append(option);
            }));

        $('.combobox').combobox(
            {
                select: function () {
                    isDropdownValChanged = true;
                    documentClicked = false;
                }
            });

    }
    return UserProfile;
})();