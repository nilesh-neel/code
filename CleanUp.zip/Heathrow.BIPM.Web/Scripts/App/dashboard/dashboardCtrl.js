﻿//----------------------------------------------------------------------
//Class Name   : Menu
//Purpose      : Dashboard Controller file use to load first default power bi dashboard/report.
//               Whit this ajax call we can achive promise in javascripts.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function (powerbi) {
    'use strict';
    var dashboardPowerBiApi;
    $(document).ready(function () {

        var currentId = _.parseInt(_.isNil(Utility.GetStoredData('URLId')) ? 0 : Utility.GetStoredData('URLId'));
        var intervalId;
        //routing for the alerts and notification, search click, my bag list and default power bi report embed.
        if (window.location.pathname === '/Alerts/Index' || window.location.pathname === '/Alerts/Index/') {
            Utility.RemoveStoredData('BreadCrumb');
            $(".breadcrumb li").remove();
            $(".verticalNavigation li").remove();
            $(".breadcrumb").append("<li class='active'><a href='#' id=46>Alerts</a></li>");
            $(".verticalNavigation").append("<li class='active'><a href='#' id=46>Alerts</a></li>");
            Menu.prototype.LinkingEmbedToPbi.call(this, 46);
            $('#loading').hide();
        }
        else if (!_.isNil(Utility.GetStoredData('searchCriteria')) || !_.isNil(Utility.GetStoredData('searchPrefix'))) {
            Utility.RemoveStoredData('BreadCrumb');
            $(".breadcrumb li").remove();
            $(".verticalNavigation li").remove();
            $(".breadcrumb").append("<li class='active'><a href='#' id=51>Bag Search List</a></li>");
            $(".verticalNavigation").append("<li class='active'><a href='#' id=51>Bag Search List</a></li>");
            Search.prototype.getBagListData.call();
        }
        else if (Utility.GetStoredData('URLId') === "47") {
            Utility.RemoveStoredData('BreadCrumb');
            $(".breadcrumb li").remove();
            $(".verticalNavigation li").remove();
            $(".breadcrumb").append("<li class='active'><a href='#' id=47>My Bag List</a></li>");
            $(".verticalNavigation").append("<li class='active'><a href='#' id=47>My Bag List</a></li>");
            Menu.prototype.LinkingEmbedToPbi.call(this, 47);
            $("#lnkbtnMyBagList").trigger("click");
        }
        else {
            var breadCrumb = Utility.GetStoredData('BreadCrumb');
            if (!_.isNil(breadCrumb)) {
                $(".breadcrumb li").remove();
                $(".verticalNavigation li").remove();
                $(".breadcrumb").append(breadCrumb);
                $(".verticalNavigation").append(breadCrumb);

                $('.breadcrumb a,.verticalNavigation li a').off('click').on('click', function (event) {
                    Menu.prototype.BreadCrumbsORMenuClick.call(this, event.target);
                });

            }
            if (currentId === 18) {
                $('#btnAddBagtags').show();
            }
            if (_.isNil($('#hdnUrlValues').val())) {
                 dashboardPowerBiApi = new PowerBIAPP();
                dashboardPowerBiApi.embedPowerBIApi(null, 0);
                Menu.prototype.LinkingEmbedToPbi.call(this, (_.isNil(currentId) || currentId === 0) ? 2 : currentId);
                if (currentId === 18) {
                    $('#btnAddBagtags').show();
                }
            }
        }

        /***
        //ToDo:
        *The demo refresh rate(15 Second)set for the testing purpose.It may be crash with actual power bi report refresh call.
       */
        $('#spnAutoUpdate').on('click', autoUpdate);

        function autoUpdate() {
            var self = $(this);
            if (self.data('update') === true) {

                var powerBiUrl = Utility.GetStoredData('autoRefURL');

                intervalId = setInterval(function () {
                    console.log('Interval 15 seconds call..');
                    if (!_.isNull(powerBiUrl)) {
                        dashboardPowerBiApi = new PowerBIAPP();
                        dashboardPowerBiApi.embedPowerBIApi(null, 0);

                    } else {
                        dashboardPowerBiApi.refreshReport();
                    }
                    // $('#divDate').html(moment().format(' DD/MM/YYYY, hh:mm:ss'));
                }, 15000);
                self.data('update', false);
            } else {
                console.log('Interval 15 seconds call clear..');
                clearInterval(intervalId);
                self.data('update', true);
            }
        }

        $('.print').on('click', printFunction);

        function printFunction() {
            Utility.ClosePanel();
            dashboardPowerBiApi = new PowerBIAPP();
            dashboardPowerBiApi.printReport();
        }

        $('#headerDate').off('change').on('change', headerDateChange);

        function headerDateChange() {

            $('#headerDate').off('apply.daterangepicker').on('apply.daterangepicker', function (ev, picker) {
                filterDate = '';
                filterDate = (isFilterInheritance) ? $("#headerDate").val() : '';
                var oPowerBiApi = new PowerBIAPP();
                oPowerBiApi.embedPowerBIApi(null, 0);
            });
        }

        $('.homeLinkIcon').on('click', homeClick);

        function homeClick(event) {
            Utility.SetStoredData('URLId', 2);
            $('.favorite').removeClass('favorites');
            Menu.prototype.BreadCrumbsORMenuClick.call(event.target);
        };

        $('#iconRefresh').on('click', PowerBIAPP.prototype.ReportLastRefreshDateTime);


    });
    $(document).ready(function () {

        $(document).ajaxStart(function () {
            $('#loading').show();
            if (window.location.pathname === '/Alerts/Index') {
                $('#loading').hide();
            }
        });
        $(document).ajaxStop(function () {
            $('#loading').hide();
            if (window.location.pathname === '/Alerts/Index') {
                $('#loading').hide();
            }
        });
        $(document).ajaxError(function (xhr, props) {
            $('#loading').hide();
            if (props.status === 401) {
                window.location.href = '@Url.Action("Account","SignIn")';
            }
            if (window.location.pathname === '/Alerts/Index') {
                $('#loading').hide();
            }
        });
    });

})(window.powerbi);