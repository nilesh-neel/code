﻿//----------------------------------------------------------------------
//Class Name   : Menu
//Purpose      : Menu Class file use to bind the left side menu.
//               Whit this ajax call we can achive promise in javascripts.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------


var Menu = (function () {
    var menuItemId = 0;
    /****
    * Creates a new Menu object.
    * @constructor
    *
    */
    Menu = function () { };

    /**
    /* fetch the menu data from database and bind to menu div..
    */
    Menu.prototype.bindMenu = function () {
        var service = new Service('api/menu');
        $.when(service.getApi())
            .then(function (menuData, favData) {
                if (_.isNil(menuData)) {
                    return;
                }
                Utility.SetStoredData('menuList', JSON.stringify(menuData));

                var parentMenu = _.takeWhile(menuData, function (o) { return o.parentId === 0; });
                var menuHtml = '';
                for (var i = 0; i < parentMenu.length; i++) {

                    var childList = _.filter(menuData, { parentId: parentMenu[i].menuId });
                    if (_.isEmpty(childList)) {
                        menuHtml += '<li id="' + parentMenu[i].menuId + '"class="subDropdown"  data-embedReport="true" data-placement="right" data-isMenu="true" data-toggle="tooltip" title="' +
                            parentMenu[i].tooltip + '"><span class="' + parentMenu[i].cssIcon + '"></span></li>';

                    } else {
                        var childhtml = '';
                        _.forEach(childList,
                            function (child) {
                                childhtml += '<a data-toggle="tooltip" data-placement="right"  data-isMenu="true" data-embedReport="true"  title="' +
                                    child.tooltip + '"id="' + child.menuId + '" href="#">' + child.description + '</a>';
                            }) +
                            '</li>';
                        //bind the sublevel menu
                        menuHtml += '<li id="' + parentMenu[i].menuId + '" title="' + parentMenu[i].tooltip +
                            '"class="subDropdown" data-toggle="tooltip"  data-embedReport="false" data-isMenu="true" data-placement="right"><span class="' + parentMenu[i].cssIcon +
                            '"></span><div class="dropdown-content">' + childhtml +
                            '</div></li>';
                    }
                }

                $('.menu').html(menuHtml);

                //Side by side menu
                if ($(".hamburgerSideBar").height() < $(".menu li").innerHeight() * $(".menu li").length) {
                    listPopulation($(".menu li"));                  
                } 
                Favourites.prototype.GetFavourites.call(this);
                Menu.prototype.autoRefresh.call();

                /*Menu is generating dynamically, Hence, menu hover event should be add after menu construction.*/
                Menu.prototype.createBreadCrumbs.call();


            }).catch(function (jqXHR, textStatus, err) {
                Utility.alertMessage(jqXHR.message, 'errorMsg');
            });

    };

    //ToDo: manage the menu for the multilevel..
    Menu.prototype.bindChildMenu = function (childMenuList) {
        var childhtml = '';
        _.forEach(childMenuList,
            function (child) {
                childhtml += '<a id="' +
                    child.menuId +
                    '"data-isreport="' +
                    child.IsReport +
                    '"data-powerbiurl="' +
                    child.url +
                    '"data-powerbiOperUrl="' +
                    child.operationalUrl +
                    '"data-powerbiBussUrl="' +
                    child.businessUrl +
                    '" href="#">' +
                    child.description +
                    '</a>';
            }) +
            '</li>';
        return '<li class="subDropdown"><span class="' +
            parentMenu[i].cssIcon +
            '"></span><div class="dropdown-content">' +
            childhtml +
            '</div></li>';
    };

    /**
    / auto refresh the power bi report.This method fetch the value from the localSession.
    */
    Menu.prototype.autoRefresh = function () {

        $('.dropdown-content a, verticalNavigation a').off('click').on('click',
            function (event) {
                var self = $(this);
                currentId = parseInt(self[0].id);
                $(".menu li.subDropdown .dropdown-content").css("display", "none");

                if (event.target.id !== "verticalBreadCrumb") {
                    $(".verticalNavigation").hide();
                }
                $(".dropdown-content").css("display", "none");
                //Menu.prototype.LinkingEmbedToPbi.call(this, currentId);
                Menu.prototype.BreadCrumbsORMenuClick.call(event.target);

                // $('#homeNavigationBar').toggleClass('active');
            });
    };

    Menu.prototype.BreadCrumbsORMenuClick = function (e) {
        $("#txtSearch").val('');
        menuItemId = (_.isNil(e)) ? parseInt($(this)[0].id) : parseInt(e.id);
        var currAddress = window.location.href;
        menuItemId = parseInt(menuItemId);
        if (_.isNaN(menuItemId)) {
            return;
        }

        //Load Date calender based on the report type
        Utility.ShowFilterDate(menuItemId, false, !_.isNil($(this).data('ismenu')));

        var isNewReport = Utility.SessionDataNullCheck('isNewReport', Utility.SessionStorageType.Get);

        if (currAddress.split("/")[3] !== "" && currAddress.split("/")[3] !== '#' && !isNewReport) {
            Utility.SetStoredData('URLId', menuItemId);
            window.location.replace(window.location.origin);
        } else {
            Utility.SetStoredData('URLId', menuItemId);
            Utility.RemoveStoredData('FilterConfig');
            Utility.ClosePanel();

            //check the for favorite menu
            Favourites.prototype.markFavouritesCss.call(this, menuItemId);

            // Display the Add/Remove Baglist buttons only for Baglist screen -- start
            // ID of Baglist screen
            if (menuItemId === Utility.ReportName.BagListGeneral) {
                $("#btnAddBagtags").show();
                $("#btnRemoveBagtags").hide();
                $("#dvOtherUserMyBagList").hide();
            } else {
                $("#dvDateselection").show();
                $("#btnAddBagtags").hide();
                $("#btnRemoveBagtags").hide();
                $("#dvOtherUserMyBagList").hide();
            }

            // Display the Add/Remove Baglist buttons only for Baglist screen -- End
            var menuListObject = JSON.parse(Utility.GetStoredData('menuList'));
            var currentMenuObject = _.filter(menuListObject, ['menuId', menuItemId])[0];

            $(document).attr("title", "Kestrel - " + _.toUpper(currentMenuObject.tooltip));

            var currentBreadCrumb = "";
            var breadCrumb = Utility.GetStoredData('BreadCrumb');

            if (!_.isNaN(breadCrumb) && currentMenuObject.isMultiLevel === false) {
                currentBreadCrumb = "<li class='active'><a href='#' id=" +
                    currentMenuObject.menuId +
                    ">" +
                    _.toUpper(currentMenuObject.breadCrumb) +
                    "</a></li>";
            } else {
                var parentData = _.filter(menuListObject,
                    ['parentId', currentMenuObject.parentId]);

                _.each(parentData, function (b) {
                    if (b.menuId === menuItemId) {
                        currentBreadCrumb += "<li class='active'><a href='#' id=" +
                            b.menuId +
                            ">" +
                            _.toUpper(b.breadCrumb) +
                            "</a></li>";
                    } else {
                        currentBreadCrumb += "<li><a href='#' id=" +
                            b.menuId +
                            ">" +
                            _.toUpper(b.breadCrumb) +
                            "</a></li>";
                    }
                });
            }
            $(".breadcrumb li").remove();
            $(".verticalNavigation li").remove();
            $(".breadcrumb").append(currentBreadCrumb);
            $(".verticalNavigation").append(currentBreadCrumb);
            Utility.SetStoredData('BreadCrumb', currentBreadCrumb);

            var oPowerBiApi = new PowerBIAPP();
            oPowerBiApi.embedPowerBIApi(null, 0);
            
            Menu.prototype.LinkingEmbedToPbi.call(this, menuItemId);
            $('#date').html(moment().format('DD/MM/YYYY, hh:mm'));

            $(".menu li.subDropdown .dropdown-content").css("display", "none");
            $("#homeNavigationBar").removeClass("active");
            $('.hamburgerSideBar').removeClass('SideBarActive');
            $(".hamburger").removeClass("clickedIcons").addClass("defaultIcons");
            $(".hambergerDiv").removeClass("hambergerActive");
        }
    };

    Menu.prototype.createBreadCrumbs = function () {

        $('ul.menu li').hover(function (e) {
            $(".menu li.subDropdown .dropdown-content a").css("display", "none");
            $(e.target).find('span').addClass("clickedIcons").removeClass("defaultIcons");
            $(e.currentTarget).find('span').addClass("clickedIcons").removeClass("defaultIcons");
            $(e.target).tooltip("show");
        }, function (e) {
            jQuery(this).find('span').removeClass("clickedIcons").addClass("defaultIcons");
            $(e.currentTarget).find('span').removeClass("clickedIcons").addClass("defaultIcons");
        });

        $('.dropdown-content a').hover(function () {
            $(e.target).find('span').toggleClass("clickedIcons").toggleClass("defaultIcons");
            $(e.target).tooltip("show");

        });

        /****vertical tabs hover***/

        jQuery('#verticalTabs li').click(function () {
            jQuery('#verticalTabs li').find('span:first-child').removeClass("clickedIcons").addClass("defaultIcons");
            jQuery(this).find('span:first-child').toggleClass("clickedIcons").toggleClass("defaultIcons");
        });


        $(".menu li.subDropdown .dropdown-content a,.menu li:not(.subDropdown)").on('click', function () {
            $("#homeNavigationBar").removeClass("active");
        });


        /***breadcrumbs***/
        $(".menu li.subDropdown,.menu li:not(.subDropdown)").on("click", function (e) {
            // will not trigger document ready and it will close dropdown-content
            e.stopPropagation();
            $(".menu li").tooltip("destroy");
            $(".menu li.subDropdown .dropdown-content").css("display", "none");
            $(this).find(".dropdown-content").css("display", "block");
            $(this).find(".dropdown-content a").css("display", "block");
            $(e.target).tooltip("show");

            var currentId = '';
            var embedReport = false;
            var currentBreadCrumb = "";

            if (!_.isEmpty(e.target.id)) {
                currentId = parseInt(e.target.id);
                embedReport = $(e.target).data('embedreport');
            } else {
                currentId = parseInt(e.currentTarget.id);
                embedReport = $(e.currentTarget).data('embedreport');
            }

            if (!_.isNaN(currentId) && currentId === 1) {
                return;
            }

            var menuListObject = JSON.parse(Utility.GetStoredData('menuList'));
            var currentMenuObject = _.filter(menuListObject, ['menuId', currentId])[0];

            if (!_.isNaN(currentId) && currentMenuObject.isMultiLevel === false) {
                currentBreadCrumb = "<li class='active'><a href='#' id=" +
                    currentMenuObject.menuId +
                    ">" +
                    _.toUpper(currentMenuObject.breadCrumb) +
                    "</a></li>";
            } else {
                var parentData = _.filter(menuListObject,
                    ['parentId', embedReport ? currentMenuObject.parentId : currentMenuObject.menuId]);

                _.each(parentData, function (b) {
                    if (b.menuId === currentId) {
                        currentBreadCrumb += "<li class='active'><a href='#' id=" +
                            b.menuId +
                            ">" +
                            _.toUpper(b.breadCrumb) +
                            "</a></li>";
                    } else {
                        currentBreadCrumb += "<li><a href='#' id=" +
                            b.menuId +
                            ">" +
                            _.toUpper(b.breadCrumb) +
                            "</a></li>";
                    }
                });
            }

            if (!_.isNaN(currentId) && embedReport === true) {
                $(".breadcrumb li").remove();
                $(".verticalNavigation li").remove();
                $(".breadcrumb").append(currentBreadCrumb);
                $(".verticalNavigation").append(currentBreadCrumb);
                Utility.SetStoredData('BreadCrumb', currentBreadCrumb);
                Utility.SetStoredData('RptName', currentMenuObject.breadCrumb);

                if (currentMenuObject.parentId === 0 &&
                    currentMenuObject.isMultiLevel === false &&
                    embedReport === true) {
                    Menu.prototype.BreadCrumbsORMenuClick.call(this, e.currentTarget);
                }

                isFilterInheritance = false;
                isApplyClicked = false;
                Utility.RemoveStoredData('InheritedValues');
            }
            else {
                isFilterInheritance = false;
                Utility.RemoveStoredData('InheritedValues');
            }

            $('body').on('click', '.breadcrumb li a,.verticalNavigation li a', bodyBreadcrumbClick);

            $('ul.breadcrumb li').click(function () {
                $(this).addClass('active').siblings().removeClass('active');
            });

            $('.disabledIcons').hover(function (e) { e.preventDefault(); });
        });

    };

    function bodyBreadcrumbClick() {
        if (!_.isEmpty(this.id) && parseInt(this.id) !== menuItemId) {
            if (menuItemId === Utility.ReportName.ADPDBD || menuItemId === Utility.ReportName.ADPSMR ||
                menuItemId === Utility.ReportName.ADPDLR || menuItemId === Utility.ReportName.NLBDBD ||
                menuItemId === Utility.ReportName.NLBSMR || menuItemId === Utility.ReportName.NLBDLR) {
                isFilterInheritance = true;
                filterDate = '';
                filterDate = $("#headerDate").val();
            }
            Menu.prototype.BreadCrumbsORMenuClick.call(this, null);
        }
    }
    Menu.prototype.LinkingEmbedToPbi = function (menuId) {

        var setReportType = Utility.GetDateForOperationalOrBusinessReport();
        Utility.ShowFilterDate(menuId, false, false);

        var menuValues = Utility.SessionDataNullCheck('MenuId', Utility.SessionStorageType.Get);
        if (!_.isNil(menuValues)) { Utility.RemoveStoredData('MenuId'); }

        switch (parseInt(menuId)) {
            case 17:
                window.location.href = baseUrl + '/Alerts/Index/';
                Menu.prototype.LinkingEmbedToPbi.call(this, 46);
                $('a[href="#todaysAlerts"]').trigger('click');
                break;
            case 46:
                $(".favorite,.filter,.print,.share").addClass("disabledIcons");
                $(".dateDiv").attr("style", "display: none");
                $(".txtMarginLastRefresh").hide();
                $('.refresh,.fullScreen').attr("style", "display: none !important");
                $(".addMBLDiv").show();
                Utility.ShowNotesIcon(false, true);
                break;
            case 2:
                $(".favorite,.filter,.print,.share").addClass("disabledIcons");
                $(".dateDiv").attr("style", "display: none");
                $(".txtMarginLastRefresh").hide();
                $('.refresh,.fullScreen').attr("style", "display: block !important");
                $(".addMBLDiv").show();
                Utility.ShowNotesIcon(false, true);
                break;
            case 4:
                $('.favorite').removeClass("disabledIcons");
                $(".filter,.print,.share").removeClass("disabledIcons");
                $(".dateDiv").attr("style", "display: block");
                $(".txtMarginLastRefresh").show();
                $('.refresh,.fullScreen').attr("style", "display:  inline-block !important");
                $(".addMBLDiv").show();
                Utility.ShowNotesIcon(true, false);

                break;
            //IB Flights  || OB Flights and Bag Details
            case 6:
            case 7:
                $(".filter,.print,.share").removeClass("disabledIcons");
                $(".dateDiv").attr("style", "display: block");
                $(".txtMarginLastRefresh").show();
                $('.refresh,.fullScreen').attr("style", "display:  inline-block !important");
                $(".addMBLDiv").show();
                $('.favorite').addClass("disabledIcons");
                Utility.ShowNotesIcon(true, false);
                break;
            //My Bag List 47
            case 47:
                $(".favorite,.filter,.print,.share").addClass("disabledIcons");
                $(".txtMarginLastRefresh").hide();
                $(".dateDiv,.notes").attr("style", "display: none");
                $('.refresh,.fullScreen').css("display", "none !important");
                $(".addMBLDiv").hide();
                $(".removeMBLDiv").show();
                Utility.ShowNotesIcon(false, true);
                break;
            default:
                $(".favorite,.filter,.print,.share").removeClass("disabledIcons");
                $(".dateDiv").attr("style", "display: block");
                $(".txtMarginLastRefresh").show();
                $('.refresh,.fullScreen').css("display", "block !important");
                $(".addMBLDiv").show();
                Utility.ShowNotesIcon(false, true);
                break;
        }


        if (setReportType === 2 || parseInt(menuId) === 46 || parseInt(menuId) === 47) {
            $('.refresh').css("display", "none !important");
            $('.refresh').addClass("disabledIcons");
            $(".txtMarginLastRefresh").hide();
        }
        /****PBI Operational ****/
        else {
            switch (parseInt(menuId)) {
                case 4:
                    Utility.ShowNotesIcon(true, false);
                    $('.print').addClass("disabledIcons");
                    break;
                case 6:
                case 7:
                    $('.refresh').css("display", "none !important");
                    $('.refresh').addClass("disabledIcons");
                    $(".txtMarginLastRefresh").hide();
                    break;
                default:
                    $('.refresh').css("display", "block !important");
                    $('.refresh').removeClass("disabledIcons");
                    $(".txtMarginLastRefresh").show();
            }
        }
    };

    Menu.prototype.setEmbedIcon = function (isEnable) {
        $(".favorite,.filter,.print,.share").addClass("disabledIcons");
        $(".txtMarginLastRefresh").hide();
        $(".dateDiv,.notes").attr("style", "display: none");
        $('.refresh,.fullScreen').css("display", "none !important");
        $(".addMBLDiv").hide();
        $(".removeMBLDiv").show();
        Utility.ShowNotesIcon(false, true);
    };

    function listPopulation(menuList) {
        var startPoint = 0;
        var Endpoint = 0;
        var numberOFElements = Math.round($(".hamburgerSideBar").height() / $(".menu li").innerHeight()) - 1;
        var menuSlidingCount = Math.round($(".menu li").innerHeight() * $(menuList).length / $(".hamburgerSideBar").height());
        Endpoint = numberOFElements;
        $("#homeNavigationBar").empty();
        for (var i = 0; i <= menuSlidingCount; i++) {
            var ul = document.createElement('ul');
            var menu = $(menuList).slice(startPoint, Endpoint);
            $(ul).addClass('menu');
            $.each(menu, function (key, value) {
                ul.append(menu[key]);
            });
            $("#homeNavigationBar").append(ul);
            startPoint = Endpoint
            Endpoint = numberOFElements + startPoint;
        }
        $(".menu").height($(".hamburgerSideBar").height());
        $(".hamburgerSideBar").hide();
    }

    return Menu;
})();
