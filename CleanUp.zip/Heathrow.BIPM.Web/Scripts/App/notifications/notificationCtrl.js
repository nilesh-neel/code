﻿//----------------------------------------------------------------------
//Class Name   : Notification controller
//Purpose      : This is used to handle all jquery click event related with Notification CRUD method.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By  :     | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Vaishnavi.R (687417)|  Function implementation                  | 10/01/2018        |Functionality Implementation                                                                       
//----------------------------------------------------------------------

(function ($) {
    'use strict';
    $(document).ready(function () {
        var notifications = new Notifications();
        var configTab = new TabConfig(false, true, false, false);

        $("#viewAllLink").click(viewAll);
        $('#notification').click(todaysNotification);

        $('#configureNewNotificationBtn').click(newNotification);
        $("#configureBackNotificationBtn").click(notificationBack);

        $('#tabs a[href="#todaysNotifications"]').click(todaysNotification);

        $('#tabs a[href="#notificationSettings"]').click(myNotificaitonSettings);
        $('#tabs a[href="#configureNotifications"]').click(configureNotification);


        /**
       // Click event of view all in marquee text
          */
        function viewAll() {
            if (!window.location.href.includes("Alerts")) {
                window.location.href = baseUrl + '/Alerts/Index/';
                Menu.prototype.LinkingEmbedToPbi.call(this, 46);
            }
            $('a[href="#notification"]').click();
            function calNotifSettingsTab() {
                $('#tabs a[href="#todaysNotifications"]').trigger('click');
                setTimeout(calNotifSettingsTab, 200);
            }
        }
 
        /**
        // Click event for configure new notification form 
           */
        function newNotification() {
            configTab.NewConfigurationButtonClick();
            $('#configureNotificationBackBtn').css('display', 'block');
        }
        /**
       // Click event for back button
          */
        function notificationBack() {
            Menu.prototype.LinkingEmbedToPbi.call(this, 50);
            configTab.BackButtonClick();
        }

        /**
     // Click event for todays notification tab
      */
        function todaysNotification() {
            closeExpansion();
            notifications.LoadNotificationLandingPage();
        }
        /**
      // Click event for my notification settings
         */
        function myNotificaitonSettings() {
            $('#congigureNewAlertBtn').text('Configure New Notification');
            closeExpansion();
            notifications.BindMyNotificationSettings();
        }
        /**
       // Click event for my configure notification
          */
        function configureNotification() {
            $('.configureBtn').css('display', 'none');
            $('.configureNotificationForm').css('display', 'none');
            $('.configureBtn button').css('display', 'none');

            $('.configureBtnNotification').css('display', 'block');
            $('.configureBtnNotification button').css('display', 'none');
            $('#configureNewNotificationBtn').css('display', 'block');
            closeExpansion();
            notifications.BindConfigureNotifications();
        }
    });
})(jQuery);
