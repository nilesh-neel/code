﻿//----------------------------------------------------------------------
//Class Name   : Notifications
//Purpose      : This is used for binding all configured notifications available and update its corresponding response
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By  :      | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Vaishnavi.R (687417)|  Function implementation                  | 10/01/2018        |Functionality Implementation
//--------------------------------------------------------------------------------------------------------------------

var Notifications = (function () {

    'use strict';
    var notificationData = {};
    var service;
    Notifications = function () {
        $('#loading').hide();
    };


  /****
     * This  method use to load default Landing page for notification
     */
    Notifications.prototype.LoadNotificationLandingPage = function () {
        $('#dvPowerBiEmbed').hide();
        $('#viewContainer').show();
        this.BindTodayNotification();
    };
     /* This  method use to bind the Todays Notification Tab
            *  */
    Notifications.prototype.BindTodayNotification = function () {

        service = new Service('api/Notification');
        service.getApi()
            .then(function (resp) {
                notificationData = _.map(resp, function (x) {
                    return {
                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile,
                        Description: x.description + ' <a href="' + x.additionalInformation + '" target="_blank" rel="noopener">' + x.additionalInformation+'</a>',
                        Time: moment(x.dateAndTime).format("YYYY-MM-DD HH:mm:ss"),
                        Topic: x.topic,
                        Locations: x.location,
                        Disable: x.disableNotification,
                        View: '<span class="Show_details  defaultIcons"></span>'
                    };
                });
                var todaysData = _.filter(notificationData, function (o) { return o.Disable === false; });


                var column = [
                    { "data": "Description", "render": CustomGrid.prototype.Ellipsis.call(this, 50), "width": "300px" },
                    { "data": "Topic", "render": CustomGrid.prototype.Ellipsis.call(this, 15)},
                    { "data": "Locations", "render": CustomGrid.prototype.Ellipsis.call(this, 50), "width": "300px" },
                    { "data": "Time", "width": "250px"},
                    { "data": "View"}
                ];
                var grid = new CustomGrid('#todaysNotificationTable', todaysData, column, true);
                grid.CreateGrid(true);
            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + err + " " + textStatus);
            });
    };


    /* This  method use to bind the My Notification Settings Tab
            *  */
    Notifications.prototype.BindMyNotificationSettings = function () {
        service = new Service('api/Notification');
        service.getApi()
            .then(function (resp) {
                notificationData = _.map(resp, function (x) {
                    return {

                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile,
                        NotificationId: x.notificationId,
                        Description: x.description,
                        Time: moment(x.dateAndTime).format("YYYY-MM-DD HH:mm:ss"),
                        Topic: x.topic,
                        Locations: x.location,
                        Disable: x.disableNotification,
                        View: '<span class="Show_details  defaultIcons"></span>',
                        Edit: ' <span class="Edit  defaultIcons"></span>'
                    };
                });
                var myNotificationData = _.filter(notificationData, function (o) { return o.Disable === false; });
                var column = [
                    { "data": "NotificationId"},
                    { "data": "Description", "render": CustomGrid.prototype.Ellipsis.call(this, 50)},
                    { "data": "Topic", "render": CustomGrid.prototype.Ellipsis.call(this, 15)},
                    { "data": "Locations", "render": CustomGrid.prototype.Ellipsis.call(this, 50)},
                    { "data": 'View'},
                    { "data": 'Edit'}
                ];
                var grid = new CustomGrid('#notificationSettingsTable', myNotificationData, column, true, true);
                grid.CreateGrid(false, true);
            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + err + " " + textStatus);
            });

    };
    /* This  method use to bind the Configure Notifications Tab
            *  */
    Notifications.prototype.BindConfigureNotifications = function () {
        service = new Service('api/Notification');
        service.getApi()
            .then(function (resp) {
                notificationData = _.map(resp, function (x) {
                    return {

                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile,
                        NotificationId: x.notificationId,
                        Description: x.description,
                        Time: moment(x.dateAndTime).format("YYYY-MM-DD HH:mm:ss"),
                        Topic: x.topic,
                        Locations: x.location,
                        View: '<span class="Show_details  defaultIcons"></span>',
                        Edit: ' <span class="Edit  defaultIcons"></span>',

                        Start: moment(x.startDate).format("DD/MM/YYYY"),
                        End: moment(x.endDate).format("DD/MM/YYYY"),
                        DisableNotification: x.disableNotification ? '<td><label class="container"  class="textLabel"><input type="checkbox" id="disableNotification" checked data-error="*Mandatory Field"><span class="checkmark" id="disableNotification"></span></label></td>' : '<td><label class="container"  class="textLabel"><input type="checkbox" id="disableNotification"  data-error="*Mandatory Field"><span class="checkmark" id="disableNotification"></span></label></td>',
                        Created: moment(x.dateAndTime).format("MM/DD/YYYY"),
                        CreatedBy: x.createdBy,
                        Modified: moment(x.modifiedDate).format("MM/DD/YYYY"),
                        ModifiedBy: x.modifiedBy,
                        Disable: x.disableNotification,
                        Additional: x.additionalInformation,
                        Organisation: x.organisation,
                        OperationalArea: x.operationalArea

                    };
                });
                var column = [
                    { "data": "NotificationId"},
                    { "data": "Description", "render": CustomGrid.prototype.Ellipsis.call(this, 50) },
                    { "data": "Topic", "render": CustomGrid.prototype.Ellipsis.call(this, 15)},
                    { "data": "Locations", "render": CustomGrid.prototype.Ellipsis.call(this, 50) },
                    { "data": "Start"},
                    { "data": "End"},
                    { "data": "DisableNotification"},
                    { "data": "Modified"},
                    { "data": "ModifiedBy"},
                    { "data": 'View'},
                    { "data": 'Edit'}
                ];

                var grid = new CustomGrid('#ConfigureNotificationTable', notificationData, column, true, true);
                grid.CreateGrid(false, true);
                Notifications.prototype.BindNotificationResponse.call();
            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + err + " " + textStatus);
            });
    };
    /* This  method use to bind the marquee notification
            *  */
    Notifications.prototype.ScrollingNotifications = function () {
        var notificationHtml = '';
        var notificationDetails = {};
        service = new Service('api/ScrollingNotification/');
        service.getApi()
            .then(function (resp) {
                notificationDetails = _.map(resp, function (x) {
                    return {
                        Description: x.description,
                        HelpURL: x.additionalInformation
                       
                    };
                });

                notificationHtml += '<marquee><ul>';
                for (var i = 0; i < notificationDetails.length; i++) {
                    notificationHtml += '<li>' + notificationDetails[i]['Description'] + ' <a href="' + notificationDetails[i]['HelpURL'] + '" target="_blank" rel="noopener">Help URL</a>';
                    notificationHtml += '</li>';
                }
                notificationHtml += '</ul></marquee>';
                $('.marqDiv').html(notificationHtml);
            });
    };

    /* This  method use to bind the User Response (disable notification) in Configure Notification
            *  */
    Notifications.prototype.BindNotificationResponse = function () {
        $("input[type='checkbox']").click(function (e) {
            var oTable = $(this).parents('table').dataTable();
            var nTr = $(this).parents('tr')[0];
            var gridData = oTable.fnGetData(nTr);
            var notificationVM = {};
            notificationVM.ResponseType = 5;
            notificationVM.AlertId = gridData['NotificationId'];
            notificationVM.Title = 'Response';
            notificationVM.IsSnooze = gridData['Disable'];
            var service = new Service('api/Alerts', 'application/json; charset=utf-8', 'json', notificationVM);
            service.putApi().done(function () {
                Notifications.prototype.BindConfigureNotifications.call();
            }).fail(function (jqXHR, textStatus, errorThrown) {
                alert(errorThrown);
            });
        });
    };
    return Notifications;

})();

