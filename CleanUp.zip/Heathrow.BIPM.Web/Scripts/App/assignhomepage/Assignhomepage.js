﻿//----------------------------------------------------------------------
//File Name    : AssignHomepage.js
//Purpose      : AssignHomepage.js is used to assign Homescreen to users in web app.
//Created By   : Vignesh
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------
(function ($) {
    'use strict';

    var service;
    var homePageList;



    /**
    // AssignHomePage button click event
    */
    $("#assignHomePage").click(assignHomepage);

    function assignHomepage() {
        var HomePagesCount = '';
        service = new Service('api/AssignHomePage', 'application/json; charset=utf-8', 'json');
        service.getApi()
            .done(function (resp) {
                if (resp !== null && resp.length > 0) {
                    var tempHtml = undefined;
                    tempHtml = $('#dvLoadHomeDashboards').empty();
                    //homePageList = resp.split(';');
                    homePageList = resp;
                    HomePagesCount = resp.length;
                    for (var i = 0; i < resp.length; i++) {
                        tempHtml = $('#dvLoadHomeDashboards').append('<div class="row"> <div class="col-md-3 col-sm-3 col-xs-3 margin">' + resp[i].displayName.toString() +
                            '</div> <div class="dropdown col-md-4 col-sm-4 col-xs-4 form-group"><div class="ui-widget form-group comboStylings" data-toggle="tooltip" data-placement="top" title="Show All Items"> <select id=groupCtrl' + i + ' class="combobox form-control comboSelect" > <option value="">select</option> </select> </div> </div> <div class="dropdown col-md-4 col-sm-4 col-xs-4 form-group"> <div class="multiselectCombo"> <select id="ddlAssignGrpRecipients' + i + '" class="multiSelectComponent form-control"  multiple="multiple"> </select> </div> </div> </div>');
                    }
                    LoadUserGrp();

                    $(".combobox").combobox();
                    $(".custom-combobox-input ").attr("placeholder", "Select");

                    singleDrpDown();
                    multiSelectFnCall();

                    //For Scroll Bar
                    $('.ms-options > ul').addClass('scrollbar-inner');
                    $('.scrollbar-inner').scrollbar();

                }
            }).fail(function (jqXHR, textStatus, errorThrown) {
                Utility.alertMessage("Error while fetching Dashboards list from Workspace.", "errorMsg");
            });

        //Get the User Group dropdown values
        var LoadUserGrp = function () {
            var LoggedinUserId = 1;
            var LoggedinuserEmailId = 'Admin@abc.com';
            service = new Service('api/AssignHomePage?userEmailId=' + LoggedinuserEmailId + '&userId=' + LoggedinUserId, 'application/json; charset=utf-8', 'json');
            service.getApi()
                .done(function (response) {
                    if (response !== null && response.length > 0) {
                        GetAudienceGrpData(response);
                    }
                }).fail(function (jqXHR, textStatus, errorThrown) {
                });
        };

        //Load the User Group dropdown values
        var GetAudienceGrpData = function (response) {
            var option = '';
            for (var i = 0; i < response.length; i++) {
                option += '<option value="' + response[i].userGroupId + '">' + response[i].description + '</option>';
            }
            for (var j = 0; j < HomePagesCount; j++) {
                $('#groupCtrl' + j).append(option);
            }
        };

        //Get the Recipients dropdown values
        var LoadGrpRecipients = function (selectedGrpID, controlId) {
            var selectedUserGrpID = { Usergrpid: selectedGrpID };
            service = new Service('api/AssignHomePage?userGroupId=' + selectedGrpID, 'application/json; charset=utf-8', 'json');
            service.getApi()
                .done(function (response) {
                    if (response !== null && response.length > 0) {
                        GetGrpRecipients(response, controlId);
                    }
                }).fail(function (jqXHR, textStatus, errorThrown) {
                });
        };


        //Load the Recipients dropdown values
        var GetGrpRecipients = function (response, controlId) {
            var recipientsList = [];
            // Available recipients to be checked-in
            //var selectedRecipients = '';

            for (var i = 0; i < response.length; i++) {

                recipientsList.push(
                    {
                        label: response[i].userFirstName,
                        value: response[i].userEmail
                    });
                // Available recipients to be checked-in
                //if (response[i].homepage !== null) {
                //    selectedRecipients += response[i].userEmail + ',';
                //}
            }
            Utility.bindMultiDropDown('#ddlAssignGrpRecipients' + controlId, [recipientsList]);
            // Available recipients to be checked-in
            //if (selectedRecipients.length > 1) {
            //    Utility.addValuesToMultiSelectDropDown('#ddlAssignGrpRecipients' + controlId, selectedRecipients.substring(0, selectedRecipients.length - 1).toString());
            //}
        };

        //SelectedIndex changed for User group dropdown
        var singleDrpDown = function () {
            $('.combobox').combobox(
                {
                    select: function () {
                        var selectedGrpID = $(this).val();
                        var controlId = $(this)[0].id.replace("groupCtrl", "");
                        LoadGrpRecipients(selectedGrpID, controlId);

                    }
                });
        };

        function multiSelectFnCall() {
            $('.multiSelectComponent').multiselect({
                enableFiltering: true,
                buttonWidth: '100%',
                filterPlaceholder: 'Search for something...',
                nonSelectedText: 'Select'
            });
            $('.multiselect-container').addClass('scrollbar-inner');
            $('.scrollbar-inner').scrollbar();
            $('ul.multiselect-container').removeClass('dropdown-menu');

            //show all items tooltip 
            $(".multiselectCombo button").removeAttr('title');
            $(".multiselectCombo button b").attr("data-toggle", "tooltip");
            $(".multiselectCombo button b").attr("data-original-title", "Show All Items");
            $(".multiselectCombo button b").tooltip();
        }

    }

    /**
  // AssignCancel button click event
  */
    $("#btnAssignCancel").off('click').on('click', assignHomepage);
   

    /**
  // AssignSubmit button click event
  */
    $('#btnAssignSubmit').off('click').on('click', submitHomepage);

    function submitHomepage() {

        var homeXml = '';
        var duplicateUsers = '';

        var assignHomePage = {
            "userGroupId": 0,
            "description": null,
            "userId": 0,
            "userEmail": null,
            "userFirstName": null,
            "homepage": null,
            "usersHomePage": []
        };

        for (var i = 0; i < homePageList.length; i++) {

            var groupId = $('#groupCtrl' + i + ' :selected').val();
            var selectedUsers = $("#ddlAssignGrpRecipients" + i + " option:selected").toArray().map(optionSelected).join(',');
            duplicateUsers += selectedUsers !== "" ? selectedUsers + "," : selectedUsers;
            if (selectedUsers !== "") {
                var users = selectedUsers.split(',');

                for (var j = 0; j < users.length; j++) {

                    var userHomePage = {
                        "pageName": homePageList[i].displayName.toString(),
                        "userId": users[j].toString(),
                        "groupId": groupId,
                        "reportId": homePageList[i].id.toString(),
                    };
                    assignHomePage.usersHomePage.push(userHomePage);
                }
            }
        }

        //Check for Duplicate Users -- start
        var duplicateUsersArr = duplicateUsers.trim(',').split(",");
        var usersArray = duplicateUsersArr.sort();

        for (var a = 0; a < usersArray.length - 1; a++) {
            if (usersArray[a + 1] === usersArray[a]) {
                Utility.alertMessage("You are trying to assign HomePage to the already assigned User.", "warningMsg");
                return false;
            }
        }
        //Check for Duplicate Users -- End

        function optionSelected(item) {
            return [item.value];
        }

        var service = new Service('api/AssignHomePage', 'application/json; charset=utf-8', 'json', assignHomePage);
        $.when(service.postApi()).then(function (resp) {
            Utility.alertMessage("Assign Home Page details saved successfully.", "successMsg");
            return false;
        }).fail(function (jqXHR, textStatus, errorThrown) {
            Utility.alertMessage("Error while saving AssigHomePage details.", "errorMsg");
        });
    }


})(jQuery);