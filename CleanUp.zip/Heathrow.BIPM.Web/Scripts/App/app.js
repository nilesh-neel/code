﻿//----------------------------------------------------------------------
//Class Name   : Service
//Purpose      : This is Data Service js file use to connect with the server side api/controller call.
//               Whit this ajax call we can achive promise in javascripts.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function ($) {
    'use strict';
    // add this global variable for the base web api url.
    window.baseUrl = window.location.origin;
    var service;
    var DEFAULT_URL;
    $('.homeLinkIcon, #homeIcon').on('click', homeClick);

    function homeClick() {
        Utility.SetStoredData('URLId', "2");
        var currAddress = window.location.href;
        if (currAddress.split("/")[3] !== "" && currAddress.split("/")[3] !== '#') {
            window.location.replace(window.location.origin);
        } else {
            Utility.RemoveStoredData('BreadCrumb');
            $(".breadcrumb li").remove();
            $(".verticalNavigation li").remove();
            var dashboardPowerBiApi = new PowerBIAPP();
            dashboardPowerBiApi.embedPowerBIApi(null, 0);
            Menu.prototype.LinkingEmbedToPbi.call(this, 2);
            $('#btnAddBagtags').hide();
            $('#dvOtherUserMyBagList').hide();
            $('#btnRemoveBagtags').hide();
        }
    }

    $(document).ready(function () {
        //var axios = require('axios');
        //var Promise = require('es6-promise').Promise;
        //first bind the menu then call powerbi API.


        var objMenu = new Menu();
        objMenu.bindMenu();
        $('.setting').on('click', function SettingsController() {
            Menu.prototype.LinkingEmbedToPbi.call(this, 46);
            window.location.href = baseUrl + '/Alerts/Index/';

        });
        var notifications = new Notifications();
        notifications.ScrollingNotifications();
        var alert = new Alert();
        alert.AlertCount();
        var currAddress = window.location.href;
        if (currAddress.split("/")[3] === "Alerts") {
            alert.LoadAlertsLandingPage();
        }
    });

    //on window resize
    $(window).resize(function windowResize() {
        PowerBIAPP.prototype.SetPbiContainerHeight.call(this, false);
    });

    //on click of logout button
    $('#btnLogout').on('click', logoutClick);

    function logoutClick() {
        Utility.ClearStoredData();
        window.location.href = '/Account/SignOut';
    }

    //pdf viewer
    $('.defaultIcons.help').on('click', defaultIconClick);

    function defaultIconClick() {
        var menuId = Utility.GetStoredData('URLId');

        service = new Service('api/Pdf?MenuId=' + menuId);
        service.getApi()
            .done(function (resp) {
                if (resp) {
                    var pdfName = resp[0].pdfName;
                    var pageNo = resp[0].pageNo;

                    var win = window.open('../../Help/viewer.html#page=' + pageNo + '&pdfname=' + pdfName, 'PdfViewer', 'location=0,width=1200,height=800');
                    win.blur();
                }
            });
    }

    $('.defaultIcons.minimize').click(defaultIconMinimize);

    function defaultIconMinimize() {

        if ($('#divUserBagLst').css('display') === 'block') {
            $('#divUserBagLst').toggleClass('widget-fullscreen');
            $('#divUserBagLst').toggleClass('fullscreen-widget-active');
        }
        else {
            $('#dvPowerBiEmbed').toggleClass('widget-fullscreen');
            $('#dvPowerBiEmbed').toggleClass('fullscreen-widget-active');
        }
    }

})(window.jQuery);