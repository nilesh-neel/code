﻿//----------------------------------------------------------------------
//Class Name   : Notes
//Purpose      : This is used for binding all configured/triggerd alerts available and update its corresponding response
//Created By   : Kannan.P
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By  :    | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//                                                                                     
//--------------------------------------------------------------------------------------------------------------------

var Notes = (function () {
    'use strict';
    var notesCount = 0;
    var service;
    var notesId = 0;
    Notes = function () { };
    var notesDesc;

        /**
    // This method to save the notes when the user press enter.
    */
    $('#notesMenu').bind('keyup', function notesKeyup(event) {
        if (event.keyCode === 13) {
            settingsController();
        }
    });    


        /**
    // This method to open and close the Notes Panel on notes icon click and cancel click
    */
    $('#dvNotesIcon').off('click').on('click', notesIconClick);

    function notesIconClick() {

        if ($("#sharePanel").is(":visible") || $("#filterPanel").is(":visible"))
            Utility.ClosePanel();

        if (!$("#notesDiv").is(":visible")) {

            // Get the NotesId of the Deleted Notes
            $('body').on('click', '.delete', function (event) {
                $("#notesDeletePopup").modal('show');

                $('#notesDialogBtn').on('click', function () {
                    service = new Service('api/DeleteNotes/' + event.currentTarget.id + '/' + notesValue + '/' + notesType);
                    service.deleteApi()
                        .done(function (response) {
                            if (!_.isNil(response)) {
                                $('.updatedNotesDetails').empty();
                                Notes.prototype.CreateDynamicNotes.call(this, response);
                                $("#notesDeletePopup").modal('hide');
                                Utility.alertMessage("Notes deletd successfully.", "successMsg");
                            }

                        }).fail(function () {
                            Utility.alertMessage("Error while deleting Notes.", "errorMsg");
                        });
                });
            });
            $('#notesSave').on('click', settingsController);
        }
    }


            /**
    // This method constructing notes values to save into database. 
    */
    function settingsController() {
        if (Notes.prototype.Validation.call()) {
            var noteUserAccess = $('#Ispublic').is(':checked') ? 1 : 0;

            var notes = {
                NotesId: notesId,
                NoteDescription: notesDesc,
                IsPublic: noteUserAccess,
                NotesType: notesType,
                UblValue: notesUblValue,
                NotesValue: notesValue
            };

            service = new Service('api/Notes', 'application/json; charset=utf-8', 'json', notes);
            service.postApi()
                .done(function (response) {
                    if (!_.isNil(response)) {
                        $('.updatedNotesDetails').empty();
                        Notes.prototype.CreateDynamicNotes.call(this, response);
                        Utility.alertMessage("Notes saved successfully.", "successMsg");
                        $('#Notedesc').val('');
                    }

                }).fail(function () {
                    Utility.alertMessage("Error while saving Notes.", "errorMsg");
                });
        }
    }
     /****
     *This method is used to fetch existing notes 
     */
    Notes.prototype.FetchNotes = function () {
        service = new Service('api/GetNotes/' + notesValue + '/' + notesType + '/' + notesUblValue);
        service.getApi()
            .done(function (response) {
                if (!_.isNil(response)) {
                    notesCount = parseInt(response.length);
                    notesCountVal = notesCount;
                    $("#lblNotescount").text(notesCount);
                    $(".spanNotification").css("display", (notesCount === 0) ? "none" : "block");
                    Notes.prototype.CreateDynamicNotes.call(this, response);
                }

            }).fail(function () {
                Utility.alertMessage("Error while fetching Notes.", "errorMsg");
            });
    };
     /****
     *This method is used to bind existing notes into notes panel
     * @param {object} result notes fetched to be loaded
     */
    Notes.prototype.CreateDynamicNotes = function (result) {
        var tempHtml;
        if (result !== null && result.length > 0) {
            tempHtml = $('#dvMainNotes').empty();
            notesCount = parseInt(result.length);
            notesCountVal = notesCount;

            $("#lblNotescount").text(notesCount);
            for (var i = 0; i < result.length; i++) {
                if (result[i].noteDescription.length > 0) {
                    var ispublic = (result[i].isPublic === 1) ? 'Public' : 'Private';

                    if (result[i].noteDescription.length > 80)
                        tempHtml = $('#dvMainNotes').append('<div class="updatedNotesDetails"> <div class="details">  <div class= " pull-left userName" > <span>' + result[i].userFirstName + '&nbsp;' + result[i].userLastName + '</span></div > <div class="pull-right dateAndTime"><span>' + result[i].createdDate + '&nbsp;' + ispublic + ' </span></div> </div> <br/> <div class="row pull-left">  <div> <label class="text more"> ' + result[i].noteDescription + '</label></div> <div id=' + result[i].notesId + ' class="defaultIcons delete row pull-left"></div></div></div> </div></div>');
                    else
                        tempHtml = $('#dvMainNotes').append('<div class="updatedNotesDetails"> <div class="details">  <div class= " pull-left userName" > <span>' + result[i].userFirstName + '&nbsp;' + result[i].userLastName + '</span></div > <div class="pull-right dateAndTime"><span>' + result[i].createdDate + '&nbsp;' + ispublic + ' </span></div> </div> <br/> <div class="row pull-left">  <div> <label class="text"> ' + result[i].noteDescription + '</label></div> <div id=' + result[i].notesId + ' class="defaultIcons delete row pull-left"></div></div></div> </div></div>');
                }
            }
            $('#Ispublic')[0].checked = false;
           
        }
    };
    /****
     *This method is used to validate the entered text in notes
     * @returns {boolean} returns true if entered text is valid else false 
     */
    Notes.prototype.Validation = function () {

        notesDesc = $('#Notedesc').val().trim();

        if (_.isEmpty(notesDesc)) {
            Utility.alertMessage("Please enter the notes description to save.", "warningMsg");
            return false;
        }
        else if (_.isNil(notesValue)) {
            var urlId = Utility.SessionDataNullCheck('URLId', Utility.SessionStorageType.Get);
            var errorMsg = (parseInt(urlId) === Utility.ReportName.BagDetails) ? 'bagtag' : 'flight number'
            Utility.alertMessage("Please provide the " + errorMsg + " details to save the notes.", "warningMsg");
            return false;
        }

        return true;
    };

        /****
     *This method is used to validate the entered text in notes
     * @returns {boolean} returns true if entered text is valid else false 
     */
    /**note script**/
    $('#dvNotesIcon').click(function notesClick(event) {
        event.stopPropagation();
        $(this).children(".spanNotification").css("display", "none");
        $("#notesDiv").toggle();
        $(".notes").toggleClass("clickedIcons");
        $(".notes").toggleClass("customBorderSmall");
    });

    // To handle the cancel click events
    $("#notesCancel").click(notesCancelClick);
    function notesCancelClick() {
        $('#Notedesc').val('');
        if ($(this).parents(".sideNavBar")) {
            $(this).parents(".sideNavBar").css("display", "none");
            $(".updatedNotesDetails").empty();
            $(".spanNotification").css("display", (notesCount === 0) ? "none" : "block");
        }
    }

    /**note script Ends**/

    return Notes;

})();