﻿//----------------------------------------------------------------------
//Class Name   : Favourites
//Purpose      : This is file use to call Favourites CRUD method.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var Favourites = (function () {

    /****
     * Creates a new Favourites object.
     * @constructor
     *
     */
    Favourites = function () { };
    /**
  // on click of favourite icon call this method to save favourite url/menu
  */
    Favourites.prototype.saveFavourites = function () {
        var favData = {
            "favouriteId": 0,
            "userId": null,
            "favouriteLink": {
                "menuId": Utility.GetStoredData('URLId'),
                "description": null,
                "operationalUrl": Utility.GetStoredData('autoRefURL'),
                "businessUrl": null,
                "organization": null,
                "parentId": 0,
                "orderId": 0,
                "cssIcon": null,
                "isReport": false,
                "tooltip": null,
                "favouritesDescription": null
            }
        };


        var service = new Service('api/Favorites', 'application/json; charset=utf-8', 'json', favData);
        $.when(service.postApi()).then(function (favMenu) {
            var childhtml = '';
            _.forEach(favMenu,
                function (child) {
                    childhtml += '<a id="' +
                        child.favouriteLink.menuId +
                        '"data-isreport="' +
                        child.favouriteLink.isReport +
                        '"data-powerbiurl="' +
                        child.favouriteLink.operationalUrl +
                        '" href=#>' +
                        child.favouriteLink.description +
                        '</a>';
                });
            var favMenuHtml =
                '<span class="defaultIcons favourite"><span class="subDropdownIcon defaultIcons "></span></span><div class="dropdown-content">' +
                childhtml +
                '</div>';

            $('.menu li').has('span.defaultIcons.favourite').html(favMenuHtml);
            //bind the click event post html updated
            //$('.defaultIcons, .favorite').on('click', function () {
            //    Favourites.prototype.saveFavourites.call(this);
            //});
            //update the session variable value after post call.
            Utility.SetStoredData('favMenu', JSON.stringify(favMenu));
            Menu.prototype.autoRefresh.call();
            Favourites.prototype.GetFavourites.call()
            Utility.alertMessage("Save successfully.", "successMsg");
        }).fail(function (jqXHR, textStatus, errorThrown) {
            Utility.alertMessage("Error while saving Favorites: " + jqXHR.responseJSON.errorMessage, "errorMsg");
        });
    };

    /**
    // set the Favourite CSS
    * @param {int} menuItemID menu id currently active
    */
    Favourites.prototype.markFavouritesCss = function (menuItemID) {
        var favMenuList = JSON.parse(Utility.GetStoredData('favMenu'));
        if (!_.isNil(favMenuList) && favMenuList.length > 0) {
            var favMenu = _.find(favMenuList, function (k) { return k.favouriteLink.menuId === parseInt(menuItemID); });
            if (!_.isNil(favMenu)) {
                $('.favorite').addClass('favorites');
            } else {
                $('.favorite').removeClass('favorites');
            }
        } else {
            $('.favorite').removeClass('favorites');
        }
    };

    /**
    // gat the Favourites for logged in user
    */
    Favourites.prototype.GetFavourites = function () {
        Utility.RemoveStoredData('favMenu');
        var service = new Service('api/Favorites', 'application/json; charset=utf-8', 'json');
        $.when(service.getApi()).then(function (favMenu) {
            Utility.SetStoredData('favMenu', JSON.stringify(favMenu));
            var childhtml = '';
            _.forEach(favMenu,
                function (child) {
                    childhtml += '<a id="' +
                        child.favouriteLink.menuId +
                        '"data-isreport="' +
                        child.favouriteLink.isReport +
                        '"data-powerbiurl="' +
                        child.favouriteLink.operationalUrl +
                        '" href=#>' +
                        child.favouriteLink.description +
                        '</a>';
                });
            var favMenuHtml =
                '<span class="defaultIcons favourite"></span><div class="dropdown-content">' +
                childhtml +
                '</div>';

            $('.menu li').has('span.defaultIcons.favourite').html(favMenuHtml);
            Favourites.prototype.markFavouritesCss.call(this, Utility.GetStoredData('URLId'));
            Menu.prototype.autoRefresh.call();
        }).fail(function (jqXHR, textStatus, errorThrown) {
            Utility.alertMessage("Error while save Favourites.", "errorMsg");
        });
    };
    return Favourites;
})();