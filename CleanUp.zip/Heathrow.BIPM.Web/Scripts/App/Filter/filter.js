﻿//----------------------------------------------------------------------
//Class Name   : Service
//Purpose      : This is Filter Class js file use for the all bind configuration available in filter module.
//Created By   : Kannan.P
//Created Date : 20/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Kannan                FDS Change                                  12/03/2019         Change related to Loading filters
//Anupama               FDS Change                                  12/01/2019         Change related to applying date filter in report
//Anupama               FDS Change                                  12/01/2019         Change related to filter controls display order
//----------------------------------------------------------------------
var Filter = (function () {
    'use strict';
    var userFilterselection = [];
    var filterId = 0;
    var filterResult = [];
    var filterVM = {};
    var filterConfig = [];
    var isFilterConfiguration = false;
    var hasEmbeddedLinks = false;
    var controlName = Utility.ControlName;

    Filter = function () { };

    /**
    // on change of value in single dropdown pin state change is called.
    */
    Filter.prototype.singleDrpDownEventHandler = function () {

        $('.combobox').combobox(
            {
                select: function () {
                    Filter.prototype.ApplyPinState.call();
                }
            });
    };

    /**
    // on change of value in multiple dropdown pin state change is called.
    */
    Filter.prototype.multipleDropDownHandler = function () {

        $("select[multiple]").change(function () {
            Filter.prototype.ApplyPinState.call();
        });

    };

    /**
    // if the new value is not same same as previous value pin state is changed.
    * @param {string} currentValue the value currently entered.
    * @param {string} previousValue the value already stored
    */
    Filter.prototype.EnablePinState = function (currentValue, previousValue) {

        if (currentValue !== previousValue && filterId > 0) {
            Filter.prototype.ApplyPinState.call();
        }
    };

    /**
    // change the pin state.
    */
    Filter.prototype.ApplyPinState = function () {
        if ($('.pinclicked').is(":visible")) {
            $('#pinIcon').toggleClass("Pin");
            $('#pinIcon').toggleClass("pinclicked");
        }
    };

    /**
    // set time slice for the control for the from and to range
    * @param {string} controlField the field name.
    * @param {string} fromValue from value
    * @param {string} toValue to value
    */
    Filter.prototype.setTimeSlicer = function (controlField, fromValue, toValue) {

        $(controlField).ionRangeSlider({
            type: "double",
            min: 0,
            max: 24,
            from: 6,
            step: 2,
            from_shadow: true,
            to: 24,
            to_shadow: true,
            grid: true,
            grid_snap: true,
            postfix: ".00"

        });
        if (fromValue > 0 && toValue > fromValue) {
            var slider = $(controlField).data("ionRangeSlider");
            slider.reset();
            slider.update({
                from: fromValue,
                to: toValue
            });
        }
    };

    /**
    // loads the filter configuration for the report
    * @param {string[]} filterSelection the field name array.
    * @param {string} filterControlData the filter result returned for report
    */
    Filter.prototype.LoadFilterConfiguration = function (filterSelection, filterControlData) {
        filterConfig = [];
        filterConfig = filterSelection;
        filterResult = filterControlData;
        if (!_.isEmpty(filterConfig.pbiMappingList)) {
            isFilterConfiguration = (filterConfig.filterItemSelection.length > 0);
            var isNewReportStatus = (!_.isNil(Utility.SessionDataNullCheck('isNewReport', Utility.SessionStorageType.Get)));
            hasEmbeddedLinks = isNewReportStatus;
            for (var i = 0; i < filterConfig.pbiMappingList.length; i++) {

                Filter.prototype.filterControlsShowHide.call(this, filterConfig.pbiMappingList[i].controlMappingId, filterConfig.pbiMappingList[i].columnName, isNewReportStatus);
            }
        }
        if (isFilterConfiguration && !isFilterInheritance) {
            filterId = filterConfig.filterId;
            if ($('.Pin').is(":visible")) {
                $('#pinIcon').toggleClass("Pin");
                $('#pinIcon').toggleClass("pinclicked");
            }
        }
        else {
            Filter.prototype.ApplyPinState.call();
        }
    };

    /**
    // checks the display order for the controls according to the menu id
    * @param {string} menuId the menu id for report loaded.
    */
    Filter.prototype.filterControlDisplayOrder = function (menuId) {
        var reportType = Utility.ReportName;
        switch (menuId) {
            case reportType.BTRInBound:
            case reportType.BTROutBound:
                Filter.prototype.BTRControlDisplay.call(this, reportType.BTRInBound === menuId);
                break;
            case reportType.BagListInBound:
            case reportType.BagListOutBound:
                Filter.prototype.BTRControlDisplay.call(this, reportType.BagListInBound === menuId);
                break;
            case reportType.BagListGeneral:
                Filter.prototype.BagListControlDisplay.call(this, true, false);
                break;
            case reportType.BagListNLBA:
                Filter.prototype.BagListControlDisplay.call(this, false, true);
                break;
            case reportType.BagDetails:
                $("#dvMain > #dvBagTag");
                break;
            case reportType.FlightDetailsInBound:
            case reportType.FlightDetailsOutBound:
                (reportType.FlightDetailsInBound === menuId) ? $("#dvMain > #dvInbndFlight") : $("#dvMain > #dvOutbndFlight");
                break;
            case reportType.ADPDBD:
                Filter.prototype.ADPControlDisplay.call(this, true, false);
                break;
            case reportType.ADPSMR:
                Filter.prototype.ADPControlDisplay.call(this, false, true);
                break;
            case reportType.ADPDLR:
                Filter.prototype.ADPControlDisplay.call(this, false, false);
                break;
            case reportType.BJPSMR:
            case reportType.BJPDLR:
                Filter.prototype.BJPControlDisplay.call(this, reportType.BJPSMR === menuId);
                break;
            case reportType.DDPDBD:
                Filter.prototype.DDPControlDisplay.call(this, true);
                break;
            case reportType.DDPSMR:
            case reportType.DDPDLR:
                Filter.prototype.DDPControlDisplay.call(this, false);
                break;
            case reportType.BSMSMR:
                Filter.prototype.BSMSMRControlDisplay.call();
                break;
            case reportType.ITTDLR:
                Filter.prototype.ITTDLRControlDisplay.call();
                break;
            case reportType.MDRSMR:
            case reportType.MDRDLR:
                Filter.prototype.MDRControlDisplay.call(this, reportType.MDRDLR === menuId);
                break;
            case reportType.NLBDBD:
                Filter.prototype.NLBControlDisplay.call(this, true, false);
                break;
            case reportType.NLBSMR:
                Filter.prototype.NLBControlDisplay.call(this, false, true);
                break;
            case reportType.NLBDLR:
                Filter.prototype.NLBControlDisplay.call(this, false, false);
                break;
            case reportType.ARRDBDNext:
            case reportType.ARRDBD:
                Filter.prototype.ARRControlDisplay.call();
                break;
            case reportType.VOLSMR:
                $("#dvMain > #dvOutbndFlight").after($("#dvOutbndAirline"));
                $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
                $("#dvMain > #dvOutbndHandler").after($("#dvOutbndTerminal"));
                break;
            default:
                break;
        }
    };

    /**
    // filter control order for BagList reports
    * @param {boolean} isBagGen if it is a baglist general report.
    * @param {boolean} isBagNLB if it is a baglist NLB report
    */
    Filter.prototype.BagListControlDisplay = function (isBagGen, isBagNLB) {
        $("#dvMain > #dvMultiDate").after($("#dvBagTag"));
        if (isBagGen) {
            $("#dvMain > #dvBagTag").after($("#dvPaxName"));
            $("#dvMain > #dvPaxName").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvDestination"));
            $("#dvMain > #dvDestination").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvInbndFlight"));
            $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndAircraft"));
            $("#dvMain > #dvInbndAircraft").after($("#dvOrigin"));
            $("#dvMain > #dvOrigin").after($("#dvInbndhandler"));
            $("#dvMain > #dvInbndhandler").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvLastLocation"));
            $("#dvMain > #dvLastLocation").after($("#dvBagStatus"));
            $("#dvMain > #dvBagStatus").after($("#dvBagType"));
            $("#dvMain > #dvBagType").after($("#dvShortConnect"));
            $("#dvMain > #dvShortConnect").after($("#dvOOGBags"));
            $("#dvMain > #dvOOGBags").after($("#dvchox"));
            $("#dvMain > #dvchox").after($("#dvDeleteBags"));
            $("#dvMain > #dvDeleteBags").after($("#dvBRSonly"));
            $("#dvMain > #dvBRSonly").after($("#dvBagList"));
            $("#dvMain > #dvBagList").after($("#dvLateBSM"));
        }
        if (isBagNLB) {
            $("#dvMain > #dvBagTag").after($("#dvNotLoaded"));
            $("#dvMain > #dvNotLoaded").after($("#dvNotLoadedSub"));
            $("#dvMain > #dvNotLoadedSub").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvInbndFlight"));
            $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndhandler"));
            $("#dvMain > #dvInbndhandler").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvLastLocation"));
            $("#dvMain > #dvLastLocation").after($("#dvBagType"));
            $("#dvMain > #dvBagType").after($("#dvShortConnect"));
            $("#dvMain > #dvShortConnect").after($("#dvchox"));
            $("#dvMain > #dvchox").after($("#dvDelBSM"));
            $("#dvMain > #dvDelBSM").after($("#dvOOGBags"));
            $("#dvMain > #dvOOGBags").after($("#dvRoute"));
            $("#dvMain > #dvRoute").after($("#dvProcessArea"));
            $("#dvMain > #dvProcessArea").after($("#dvBaggageSystem"));
        }
    };

    /**
   // filter control order for BagListInbound/Outbound reports
   * @param {boolean} isBagInbnd if it is a baglist Inbound report.
   * @param {boolean} isBagOutbnd if it is a baglist Outbound report
   */
    Filter.prototype.BagListInboundControl = function (isBagInbnd, isBagOutbnd) {
        $("#dvMain > #dvMultiDate").after($("#dvBagTag"));
        if (isBagInbnd) {
            $("#dvMain > #dvBagTag").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvInbndFlight"));
            $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndAircraft"));
            $("#dvMain > #dvInbndAircraft").after($("#dvInbndhandler"));
            $("#dvMain > #dvInbndhandler").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvLastLocation"));
            $("#dvMain > #dvLastLocation").after($("#dvBagStatus"));
            $("#dvMain > #dvBagStatus").after($("#dvBagType"));
            $("#dvMain > #dvBagType").after($("#dvShortConnect"));
            $("#dvMain > #dvShortConnect").after($("#dvOOGBags"));
            $("#dvMain > #dvOOGBags").after($("#dvDeleteBags"));
            $("#dvMain > #dvDeleteBags").after($("#dvBagList"));
        }
        if (isBagOutbnd) {
            $("#dvMain > #dvBagTag").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvOutbndAircraft"));
            $("#dvMain > #dvOutbndAircraft").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvInbndFlight"));
            $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvLastLocation"));
            $("#dvMain > #dvLastLocation").after($("#dvBagStatus"));
            $("#dvMain > #dvBagStatus").after($("#dvBagType"));
            $("#dvMain > #dvBagType").after($("#dvShortConnect"));
            $("#dvMain > #dvShortConnect").after($("#dvOOGBags"));
            $("#dvMain > #dvOOGBags").after($("#dvchox"));
            $("#dvMain > #dvchox").after($("#dvDeleteBags"));
            $("#dvMain > #dvDeleteBags").after($("#dvBagList"));
        }
    };

    /**
    // filter control order for BagList reports
    * @param {boolean} isBagGnr if it is a baglist general report.
    * @param {boolean} isBagNlb if it is a baglist NLB report
    */
    Filter.prototype.BagListControlDisplay = function (isBagGnr, isBagNlb) {
        $("#dvMain > #dvMultiDate").after($("#dvBagTag"));

        if (isBagGnr) {
            $("#dvMain > #dvBagTag").after($("#dvPaxName"));
            $("#dvMain > #dvPaxName").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvDestination"));
            $("#dvMain > #dvDestination").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvInbndFlight"));
            $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndAircraft"));
            $("#dvMain > #dvInbndAircraft").after($("#dvOrigin"));
            $("#dvMain > #dvOrigin").after($("#dvInbndhandler"));
            $("#dvMain > #dvInbndhandler").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvLastLocation"));
            $("#dvMain > #dvLastLocation").after($("#dvBagStatus"));
            $("#dvMain > #dvBagStatus").after($("#dvBagType"));
            $("#dvMain > #dvBagType").after($("#dvShortConnect"));
            $("#dvMain > #dvShortConnect").after($("#dvOOGBags"));
            $("#dvMain > #dvOOGBags").after($("#dvchox"));
            $("#dvMain > #dvchox").after($("#dvDeleteBags"));
            $("#dvMain > #dvDeleteBags").after($("#dvBRSonly"));
            $("#dvMain > #dvBRSonly").after($("#dvBagList"));
            $("#dvMain > #dvBagList").after($("#dvLateBSM"));
        }
        if (isBagNlb) {
            $("#dvMain > #dvBagTag").after($("#dvNotLoaded"));
            $("#dvMain > #dvNotLoaded").after($("#dvNotLoadedSub"));
            $("#dvMain > #dvNotLoadedSub").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvInbndFlight"));
            $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndhandler"));
            $("#dvMain > #dvInbndhandler").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvLastLocation"));
            $("#dvMain > #dvLastLocation").after($("#dvBagType"));
            $("#dvMain > #dvBagType").after($("#dvShortConnect"));
            $("#dvMain > #dvShortConnect").after($("#dvchox"));
            $("#dvMain > #dvchox").after($("#dvDelBSM"));
            $("#dvMain > #dvDelBSM").after($("#dvBagList"));
            $("#dvMain > #dvBagList").after($("#dvRoute"));
            $("#dvMain > #dvRoute").after($("#dvProcessArea"));
            $("#dvMain > #dvProcessArea").after($("#dvBaggageSystem"));
        }
    };

    /**
    // filter control order for BTR reports
    * @param {boolean} isInbndOrder if it is a Inbound order.
    */
    Filter.prototype.BTRControlDisplay = function (isInbndOrder) {
        $("#dvMain > #dvMultiDate").after($("#dvTimeBand"));
        $("#dvMain > #dvTimeBand").after($("#dvBagStatus"));

        if (isInbndOrder) {
            $("#dvMain > #dvBagStatus").after($("#dvInbndhandler"));
            $("#dvMain > #dvInbndhandler").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvInbndAircraft"));
        }
        else {
            $("#dvMain > #dvBagStatus").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvOutbndAircraft"));
        }
    };

    /**
    // filter control order for ADP reports
    * @param {boolean} isAdpDbd if it is a Inbound order.
    * @param {boolean} isAdpSmr if it is a Outbound order
    */
    Filter.prototype.ADPControlDisplay = function (isAdpDbd, isAdpSmr) {
        if (isAdpDbd) {
            $("#dvMain > #dvSingleDate").after($("#dvInbndhandler"));
            $("#dvMain > #dvInbndhandler").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvInbndFlight"));
        }
        else {
            (isAdpSmr) ? $("#dvMain > #dvSingleDate").after($("#dvInbndhandler")) : $("#dvMain > #dvMultiDate").after($("#dvInbndhandler"));
            $("#dvMain > #dvInbndhandler").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvInbndFlight"));
            $("#dvMain > #dvInbndFlight").after($("#dvInbndAircraft"));
            $("#dvMain > #dvInbndAircraft").after($("#dvOrigin"));
        }
    };

    /**
    // filter control order for BJP reports
    * @param {boolean} isBjpSmr if it is bjp summary.
    */
    Filter.prototype.BJPControlDisplay = function (isBjpSmr) {

        $("#dvMain > #dvMultiDate").after($("#dvInbndTerminal"));
        $("#dvMain > #dvInbndTerminal").after($("#dvOutbndTerminal"));
        if (isBjpSmr) {
            $("#dvMain > #dvOutbndTerminal").after($("#dvRoute"));
            $("#dvMain > #dvRoute").after($("#dvBaggageSystem"));
            $("#dvMain > #dvBaggageSystem").after($("#dvProcessArea"));
            $("#dvMain > #dvProcessArea").after($("#dvOOGBags"));
        }
        else {
            $("#dvMain > #dvOutbndTerminal").after($("#dvRouteStartTime"));
            $("#dvMain > #dvRouteStartTime").after($("#dvBaggageSystem"));
            $("#dvMain > #dvBaggageSystem").after($("#dvProcessArea"));
            $("#dvMain > #dvProcessArea").after($("#dvFailedSystem"));
            $("#dvMain > #dvFailedSystem").after($("#dvOOGBags"));
        }
    };

    /**
    // filter control order for DDP reports
    * @param {boolean} isDdpDbd if it is DDP dashboard.
    */
    Filter.prototype.DDPControlDisplay = function (isDdpDbd) {

        if (isDdpDbd) {
            $("#dvMain > #dvSingleDate").after($("#dvTimeBand"));
            $("#dvMain > #dvTimeBand").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvOutbndTerminal"));
        }
        else {
            $("#dvMain > #dvMultiDate").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvOutbndAircraft"));
        }
    };

    /**
    // filter control order for BSM report
    */
    Filter.prototype.BSMSMRControlDisplay = function () {
        $("#dvMain > #dvMultiDate").after($("#dvInbndFlight"));
        $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
        $("#dvMain > #dvInbndAirline").after($("#dvInbndhandler"));
        $("#dvMain > #dvInbndhandler").after($("#dvOutbndFlight"));
        $("#dvMain > #dvOutbndFlight").after($("#dvOutbndAirline"));
        $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
    };

    /**
    // filter control order for ITT report
    */
    Filter.prototype.ITTDLRControlDisplay = function () {
        $("#dvMain > #dvMultiDate").after($("#dvInbndTerminal"));
        $("#dvMain > #dvInbndTerminal").after($("#dvOutbndTerminal"));
        $("#dvMain > #dvOutbndTerminal").after($("#dvInbndhandler"));
        $("#dvMain > #dvInbndhandler").after($("#dvInbndAirline"));
        $("#dvMain > #dvInbndAirline").after($("#dvOutbndAirline"));
        $("#dvMain > #dvOutbndAirline").after($("#dvAtStart"));
        $("#dvMain > #dvAtStart").after($("#dvAtEnd"));
        $("#dvMain > #dvAtEnd").after($("#dvInbndITO"));
        $("#dvMain > #dvInbndITO").after($("#dvInTarget"));
        $("#dvMain > #dvInTarget").after($("#dvFailedMissed"));
    };

    /**
    // filter control order for MDR reports
    * @param {boolean} isMdrDlr if it is MDR detail.
    */
    Filter.prototype.MDRControlDisplay = function (isMdrDlr) {
        $("#dvMain > #dvMultiDate").after($("#dvInbndTerminal"));
        $("#dvMain > #dvInbndTerminal").after($("#dvInbndAirline"));
        $("#dvMain > #dvInbndAirline").after($("#dvInbndhandler"));
        $("#dvMain > #dvInbndhandler").after($("#dvOutbndTerminal"));
        $("#dvMain > #dvOutbndTerminal").after($("#dvOutbndAirline"));
        $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
        (isMdrDlr) ? $("#dvMain > #dvOutbndAirline").after($("#dvMDStatus")) : $("#dvMain > #dvOutbndAirline").after($("#dvLastLocation"));
    };

    /**
    // filter control order for ARR reports
    */
    Filter.prototype.ARRControlDisplay = function () {
        $("#dvMain > #dvSingleDate").after($("#dvInbndFlight"));
        $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
        $("#dvMain > #dvInbndAirline").after($("#dvOrigin"));
        $("#dvMain > #dvOrigin").after($("#dvInbndhandler"));
        $("#dvMain > #dvInbndhandler").after($("#dvInbndTerminal"));
    };

    /**
    // filter control order for NLB reports
    * @param {boolean} isNlbDbd if it is NLB dashboard.
    * @param {boolean} isNlbSmr if it is NLB summary.
    */
    Filter.prototype.NLBControlDisplay = function (isNlbDbd, isNlbSmr) {
        if (isNlbDbd) {
            $("#dvMain > #dvSingleDate").after($("#dvTimeBand"));
            $("#dvMain > #dvTimeBand").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvInbndFlight"));
            $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
        }
        else {
            $("#dvMain > #dvMultiDate").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvInbndFlight"));
            $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
            if (isNlbSmr) {
                $("#dvMain > #dvInbndAirline").after($("#dvInbndTerminal"));
            }
            else {
                $("#dvMain > #dvInbndAirline").after($("#dvInbndhandler"));
                $("#dvMain > #dvInbndhandler").after($("#dvInbndTerminal"));
            }
        }
    };

    /**
    // saves the filter configuration on click of pin icon
    * @param {int} menuId menu id which is currently active
    */
    Filter.prototype.saveFilterConfiguration = function (menuId) {
        userFilterselection = [];
        if (!_.isNil(filterConfig.pbiMappingList)) {

            for (var i = 0; i < filterConfig.pbiMappingList.length; i++) {
                Filter.prototype.assignValuesToFilterVM.call(this, filterConfig.pbiMappingList[i], true);
            }

            if (!_.isEmpty(userFilterselection)) {
                filterVM.FilterId = filterId;
                filterVM.MenuId = menuId;
                filterVM.FilterItemSelection = userFilterselection;
                var service = new Service('api/Filter', 'application/json; charset=utf-8', 'json', filterVM);
                service.postApi().done(function () {
                    if ($(".Pin").is(":visible")) {
                        $('#pinIcon').toggleClass("Pin");
                        $('#pinIcon').toggleClass("pinclicked");
                    }
                    Utility.alertMessage("Filter configuration saved successfully.", "successMsg");
                }).fail(function () {
                    Utility.alertMessage("Error occured while saving Filter configuration.", "errorMsg");
                });
            }
        }
    };

    //// #region ShowHideFilterControl
    /**
    // hides/shows the filter controls
    * @param {int} controlId control id of filter
    * @param {string} columnName name of the column of report
    * @param {boolean} reportStatus status of the report
    */
    Filter.prototype.filterControlsShowHide = function (controlId, columnName, reportStatus) {
        var datasource = [];
        if (isFilterConfiguration || reportStatus) {

            datasource = Filter.prototype.filterValueContruction.call(this, controlId, columnName, reportStatus);
        }
        switch (controlId) {
            case controlName.RelationalTimeband:
                $("#dvTimeBand").removeClass('hidden');
                $('#minsBefore').val('30');
                $('#minsAfter').val('240');
                break;
            case controlName.PaxSurname:
                $("#dvPaxName").removeClass('hidden');
                $('#txtPaxName').val('');
                if (datasource.length > 0) {
                    $("#txtPaxName").val(datasource[0].columnValue.toString());
                }
                break;
            case controlName.BagTag:
                $("#dvBagTag").removeClass('hidden');
                $('#txtBagTag').val('');
                if (datasource.length > 0) {
                    $("#txtBagTag").val(datasource[0].columnValue.toString());
                }
                break;
            case controlName.NotLoadedCategory:
                $("#dvNotLoaded").removeClass('hidden');
                Utility.bindMultiDropDown('#selectNotLoaded', [filterResult.notLoadedCategoryList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectNotLoaded', datasource[0].columnValue.toString());
                }
                break;
            case controlName.NotLoadedSubCategory:
                $("#dvNotLoadedSub").removeClass('hidden');
                Utility.bindMultiDropDown('#selectNotLoadedSub', [filterResult.notLoadedSubCategoryList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectNotLoadedSub', datasource[0].columnValue.toString());
                }
                break;
            case controlName.OutboundFlight:
                $("#dvOutbndFlight").removeClass('hidden');
                $('#txtOutbndFlight').val('');
                if (!_.isEmpty(datasource)) {
                    $("#txtOutbndFlight").val(datasource[0].columnValue.toString());
                    Utility.RemoveStoredData('OutbndFlight');
                    Utility.SetStoredData('OutbndFlight', datasource[0].columnValue.toString());
                }
                break;
            case controlName.OutboundAircraft:
                $("#dvOutbndAircraft").removeClass('hidden');
                Utility.bindMultiDropDown('#selectOutbndAircraft', [filterResult.outboundAircraftList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectOutbndAircraft', datasource[0].columnValue.toString());
                }
                break;
            case controlName.Destination:
                $("#dvDestination").removeClass('hidden');
                Utility.bindMultiDropDown('#selectDestination', [filterResult.destinationList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectDestination', datasource[0].columnValue.toString());
                }
                break;
            case controlName.OutboundAirline:
                $("#dvOutbndAirline").removeClass('hidden');
                Utility.bindMultiDropDown('#selectOutbndAirline', [filterResult.outboundAirlineList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectOutbndAirline', datasource[0].columnValue.toString());
                }
                break;
            case controlName.OutboundHandler:
                $("#dvOutbndHandler").removeClass('hidden');
                Utility.bindMultiDropDown('#selectOutbndHandler', [filterResult.outboundHandlerList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectOutbndHandler', datasource[0].columnValue.toString());
                }
                break;
            case controlName.OutboundTerminal:
                $("#dvOutbndTerminal").removeClass('hidden');
                Utility.bindMultiDropDown('#selectOutbndTerminal', [filterResult.outboundTerminalList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectOutbndTerminal', datasource[0].columnValue.toString());
                }
                break;
            case controlName.InboundFlight:
                $("#dvInbndFlight").removeClass('hidden');
                $('#txtInbndFlight').val('');
                if (datasource.length > 0) {
                    $("#txtInbndFlight").val(datasource[0].columnValue.toString());
                    Utility.RemoveStoredData('InbndFlight');
                    Utility.SetStoredData('InbndFlight', datasource[0].columnValue.toString());
                }
                break;
            case controlName.InboundAirline:
                $("#dvInbndAirline").removeClass('hidden');
                Utility.bindMultiDropDown('#selectInbndAirline', [filterResult.outboundAirlineList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectInbndAirline', datasource[0].columnValue.toString());
                }
                break;
            case controlName.InboundAircraft:
                $("#dvInbndAircraft").removeClass('hidden');
                Utility.bindMultiDropDown('#selectInbndAircraft', [filterResult.outboundAircraftList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectInbndAircraft', datasource[0].columnValue.toString());
                }
                break;
            case controlName.Origin:
                $("#dvOrigin").removeClass('hidden');
                Utility.bindMultiDropDown('#selectOrigin', [filterResult.destinationList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectOrigin', datasource[0].columnValue.toString());
                }
                break;
            case controlName.InboundHandler:
                $("#dvInbndhandler").removeClass('hidden');
                Utility.bindMultiDropDown('#selectInbndhandler', [filterResult.outboundHandlerList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectInbndhandler', datasource[0].columnValue.toString());
                }
                break;
            case controlName.InboundTerminal:
                $("#dvInbndTerminal").removeClass('hidden');
                Utility.bindMultiDropDown('#selectInbndTerminal', [filterResult.outboundTerminalList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectInbndTerminal', datasource[0].columnValue.toString());
                }
                break;
            case controlName.LastSeenLocation:
                $("#dvLastLocation").removeClass('hidden');
                Utility.bindMultiDropDown('#selectLastLocation', [filterResult.lastSeenLocationList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectLastLocation', datasource[0].columnValue.toString());
                }
                break;
            case controlName.BagStatus:
                $("#dvBagStatus").removeClass('hidden');
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectBagStatus', datasource[0].columnValue.toString());
                }
                break;
            case controlName.BagType:
                $("#dvBagType").removeClass('hidden');
                if (datasource.length > 0) { Utility.SetValuesToSingleDropDown("#selectBagType", datasource[0].columnValue[0]); }
                break;
            case controlName.ShortConnect:
                $("#dvShortConnect").removeClass('hidden');
                if (datasource.length > 0) {
                    Utility.SetValuesToSingleDropDown("#selectShortConnect", datasource[0].columnValue[0]);
                }
                break;
            case controlName.OOGBags:
                $("#dvOOGBags").removeClass('hidden');
                if (datasource.length > 0) {
                    Utility.SetValuesToSingleDropDown("#selectOOGBags", datasource[0].columnValue[0]);
                }
                break;
            case controlName.SeenAfterChox:
                $("#dvchox").removeClass('hidden');
                if (datasource.length > 0) { Utility.SetValuesToSingleDropDown("#selectchox", datasource[0].columnValue[0]); }
                break;
            case controlName.ShowDeletedBags:
                $("#dvDeleteBags").removeClass('hidden');
                if (datasource.length > 0) { Utility.SetValuesToSingleDropDown("#selectDeleteBags", datasource[0].columnValue[0]); }
                else {
                    $("#selectDeleteBags + span").children('input').val($("#selectDeleteBags option:first").text());
                }
                break;
            case controlName.ShowMissedBRS:
                $("#dvBRSonly").removeClass('hidden');
                if (datasource.length > 0) { Utility.SetValuesToSingleDropDown("#selectBRSonly", datasource[0].columnValue[0]); }
                else {
                    $("#selectBRSonly + span").children('input').val($("#selectBRSonly option:first").text());
                }
                break;
            case controlName.ShowDelBSMs:
                $("#dvDelBSM").removeClass('hidden');
                if (datasource.length > 0) { Utility.SetValuesToSingleDropDown("#selectDelBSM", datasource[0].columnValue[0]); }
                else {
                    $("#selectDelBSM + span").children('input').val($("#selectDelBSM option:first").text());
                }

                break;
            case controlName.ShowMyBagList:
                $("#ShowMyBagList").removeClass('hidden');
                if (datasource.length > 0) { Utility.SetValuesToSingleDropDown("#selectBagList", datasource[0].columnValue[0]); }
                break;
            case controlName.Route:
                $("#dvRoute").removeClass('hidden');
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectRoute', datasource[0].columnValue.toString());
                }
                break;
            case controlName.ProcessArea:
                $("#dvProcessArea").removeClass('hidden');
                Utility.bindMultiDropDown('#selectProcessArea', [filterResult.lastSeenLocationList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectProcessArea', datasource[0].columnValue.toString());
                }
                break;
            case controlName.BaggageSystem:
                $("#dvBaggageSystem").removeClass('hidden');
                Utility.bindMultiDropDown('#selectBaggageSystem', [filterResult.baggageSystemList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectBaggageSystem', datasource[0].columnValue.toString());
                }
                break;
            case controlName.RouteStartEndTime:
                $("#dvRouteStartTime").removeClass('hidden');
                Filter.prototype.setTimeSlicer.call(this, '#txtRouteStartTime', 6, 24);
                if (datasource.length > 0) {
                    var filterVal = datasource[0].columnValue.split(":");
                    Filter.prototype.setTimeSlicer.call(this, '#txtRouteStartTime', parseInt(filterVal[0]), parseInt(filterVal[1]));
                    Utility.SetStoredData('routeStartTime', datasource[0].columnValue);
                }
                break;
            case controlName.InboundITO:
                $("#dvInbndITO").removeClass('hidden');
                Utility.addValuesToDropDown('#selectInbndITO', [filterResult.lastSeenLocationList]);
                if (datasource.length > 0) { $("#selectInbndITO + span").children('input').val(datasource[0].columnValue[0]); }
                break;
            case controlName.InTarget:
                $("#dvInTarget").removeClass('hidden');
                if (datasource.length > 0) { $("#selectInTarget + span").children('input').val(datasource[0].columnValue[0]); }
                break;
            case controlName.FailedThenMissed:
                $("#dvFailedMissed").removeClass('hidden');
                if (datasource.length > 0) { $("#selectFailedMissed + span").children('input').val(datasource[0].columnValue[0]); }
                break;
            case controlName.SeenAtStart:
                $("#dvAtStart").removeClass('hidden');
                Utility.bindMultiDropDown('#selectAtStart', [filterResult.lastSeenLocationList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectAtStart', datasource[0].columnValue.toString());
                }
                break;
            case controlName.SeenAtEnd:
                $("#dvAtEnd").removeClass('hidden');
                Utility.bindMultiDropDown('#selectAtEnd', [filterResult.lastSeenLocationList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectAtEnd', datasource[0].columnValue.toString());
                }
                break;
            case controlName.NotLoadedFailedInSystem:
                $("#dvFailedSystem").removeClass('hidden');
                Utility.bindMultiDropDown('#selectFailedSystem', [filterResult.lastSeenLocationList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectFailedSystem', datasource[0].columnValue.toString());
                }
                break;
            case controlName.MDStatusLocation:
                $("#dvMDStatus").removeClass('hidden');
                Utility.bindMultiDropDown('#selectMDStatus', [filterResult.lastSeenLocationList]);
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectMDStatus', datasource[0].columnValue.toString());
                }
                break;
            case controlName.LateBSM:
                $("#dvLateBSM").removeClass('hidden');
                if (datasource.length > 0) {
                    Utility.addValuesToMultiSelectDropDown('#selectLateBSM', datasource[0].columnValue.toString());
                }
                break;
            default:
                break;
        }
    }
    //// #endregion

    /**
// assign values to filter
* @param {string[]} columnName columnnamne of filter mappings
* @param {boolean} reportStatus if new report or existing report
* @param {int} controlId filter control id 
*/
    Filter.prototype.filterValueContruction = function (controlId, columnName, reportStatus) {
        var filterParameter = [];
        var filterDatasource = [];
        if (reportStatus && controlId > 2) {
            var urlValues = Utility.SessionDataNullCheck('URLParamValues', Utility.SessionStorageType.Get);
            filterParameter = JSON.parse(urlValues);
            var column = Utility.ReportColumnName;
            if (Utility.ControlName.BagTag === controlId || Utility.ControlName.InboundFlight === controlId ||
                Utility.ControlName.OutboundFlight === controlId) {
                filterDatasource = _.filter(filterParameter, function (o) {
                    return o.columnName === column.BagTag || o.columnName === column.InboundFlightNumber
                        || o.columnName === column.OutboundFlightNumber
                });
            }
            else {
                filterDatasource = _.filter(filterParameter, function (o) { return o.columnName === columnName });
            }
        }
        else {
            filterDatasource = _.filter(filterConfig.filterItemSelection, function (o) { return o.controlMappingId === controlId; });
        }
        return filterDatasource;
    }


    /**
    // assign values to filter
    * @param {string[]} mappingList list of filter mappings
    * @param {boolean} isSaveFilter if filter is saved
    */
    Filter.prototype.assignValuesToFilterVM = function (mappingList, isSaveFilter) {
        var controlVal = [];
        switch (mappingList.controlMappingId) {
            case 1:
            case 2:
                if (!isSaveFilter) {
                    controlVal = Utility.ReportDateFormat();
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.RelationalTimeband:
                if (!isSaveFilter) {
                    var startTime = parseInt($('#minsBefore').val().trim());
                    var endTime = parseInt($('#minsAfter').val().trim());

                    ////UTC timezone.
                    //controlVal.push(moment.utc(moment.utc().hours(), 'hh:mm:ss').subtract(startTime, 'minutes').format('hh:mm:ss'));
                    //controlVal.push(moment.utc(moment.utc().hours(), 'hh:mm:ss').add(endTime, 'minutes').format('hh:mm:ss'));

                    ///get current date and adding start time and end time   local TimeZone.
                    startTime = moment().format('YYYY-MM-DD') + " " + moment(moment()).subtract(startTime, 'minutes').format('hh:mm:ss');
                    endTime = moment().format('YYYY-MM-DD') + " " + moment(moment()).subtract(startTime, 'minutes').format('hh:mm:ss');
                    controlVal.push(startTime);
                    controlVal.push(endTime);
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.PaxSurname:
                if (!isSaveFilter) {
                    controlVal = $("#txtPaxName").val().split(",").filter(function (index) { return index; });
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.BagTag:
                if (!isSaveFilter) {
                    controlVal = $("#txtBagTag").val().split(",").filter(function (index) { return index; });
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.NotLoadedCategory:
                controlVal = $("#selectNotLoaded").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.NotLoadedSubCategory:
                controlVal = $("#selectNotLoadedSub").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.OutboundFlight:
                controlVal = $("#txtOutbndFlight").val().trim();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.OutboundAircraft:
                controlVal = $("#selectOutbndAircraft").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.Destination:
                controlVal = $("#selectDestination").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.OutboundAirline:
                controlVal = $("#selectOutbndAirline").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.OutboundHandler:
                controlVal = $("#selectOutbndHandler").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.OutboundTerminal:
                controlVal = $("#selectOutbndTerminal").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.InboundFlight:
                controlVal = $("#txtInbndFlight").val().trim();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.InboundAirline:
                controlVal = $("#selectInbndAirline").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.InboundAircraft:
                controlVal = $("#selectInbndAircraft").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.Origin:
                controlVal = $("#selectOrigin").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.InboundHandler:
                controlVal = $("#selectInbndhandler").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.InboundTerminal:
                controlVal = $("#selectInbndTerminal").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.LastSeenLocation:
                controlVal = $("#selectLastLocation").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.BagStatus:
                if (!($("#selectBagStatus option:selected").val() === $("#selectBagStatus option:first").val())) {
                    controlVal = $("#selectBagStatus").val();
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.BagType:
                if (!($("#selectBagType + span").children('input').val() === $("#selectBagType option:first").val())) {
                    controlVal = $("#selectBagType + span").children('input').val();
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.ShortConnect:
                if (isSaveFilter) {
                    controlVal = !($("#selectShortConnect option:selected").val() === $("#selectShortConnect option:first").val()) ? $("#selectShortConnect option:selected").val() : '';
                }
                else { controlVal = Utility.FilterDefaultValue.All; }
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.OOGBags:
                if (!($("#selectOOGBags option:selected").val() === $("#selectOOGBags option:first").val())) {
                    controlVal = $("#selectOOGBags option:selected").val();
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.SeenAfterChox:
                if (!($("#selectchox option:selected").val() === $("#selectchox option:first").val())) {
                    controlVal = $("#selectchox option:selected").val();
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.ShowDeletedBags:
                if (isSaveFilter) {
                    controlVal = !($("#selectDeleteBags option:selected").val() === $("#selectDeleteBags option:first").val()) ? $("#selectDeleteBags option:selected").val() : '';
                }
                else { controlVal = Utility.FilterDefaultValue.No; }
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.ShowMissedBRS:
                if (isSaveFilter) {
                    controlVal = !($("#selectBRSonly option:selected").val() === $("#selectBRSonly option:first").val()) ? $("#selectBRSonly option:selected").val() : '';
                }
                else { controlVal = Utility.FilterDefaultValue.No; }
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.ShowDelBSMs:
                if (isSaveFilter) {
                    controlVal = !($("#selectDelBSM option:selected").val() === $("#selectDelBSM option:first").val()) ? $("#selectDelBSM option:selected").val() : '';
                }
                else { controlVal = Utility.FilterDefaultValue.No; }
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.ShowMyBagList:
                if (!($("#selectBagList option:selected").val() === $("#selectBagList option:first").val())) {
                    controlVal = $("#selectBagList option:selected").val();
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.Route:
                controlVal = $("#selectRoute").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.ProcessArea:
                controlVal = $("#selectProcessArea").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.BaggageSystem:
                controlVal = $("#selectBaggageSystem").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.RouteStartEndTime:
                controlVal = $("#txtRouteStartTime").val().trim();
                controlVal = controlVal.replace(";", ":");
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.InboundITO:
                controlVal = $('#selectInbndITO  + span').children('input')[0].value;
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.InTarget:
                if (!($("#selectInTarget + span").children('input').val() === $("#selectInTarget option:first").val())) {
                    controlVal = $("#selectInTarget + span").children('input').val();
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.FailedThenMissed:
                if (!($("#selectFailedMissed + span").children('input').val() === $("#selectFailedMissed option:first").val())) {
                    controlVal = $("#selectFailedMissed + span").children('input').val();
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.SeenAtStart:
                controlVal = $("#selectAtStart").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.SeenAtEnd:
                controlVal = $("#selectAtEnd").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.NotLoadedFailedInSystem:
                if (!($("#selectFailedSystem + span").children('input').val() === $("#selectFailedSystem option:first").val())) {
                    controlVal = $("#selectFailedSystem + span").children('input').val();
                    Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                }
                break;
            case controlName.MDStatusLocation:
                controlVal = $("#selectMDStatus").val();
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            case controlName.LateBSM:
                if (isSaveFilter) {
                    controlVal = !($("#selectLateBSM option:selected").val() === $("#selectLateBSM option:first").val()) ? $("#selectLateBSM").val() : '';
                }
                else { controlVal = [Utility.FilterDefaultValue.None]; }
                Filter.prototype.FilterValueConstruction.call(this, controlVal, mappingList);
                break;
            default:
                break;
        }
    };

    /**
    // assign values to filter controls before loading
    * @param {string[]} controlValue list of filter mappings
    * @param {string} PBImappingData mapping data available for the report
    */
    Filter.prototype.FilterValueConstruction = function (controlValue, PBImappingData) {

        if (!_.isEmpty(controlValue)) {

            var inputVal = [];

            switch (PBImappingData.controlMappingId) {
                case 1:
                case 2:
                    for (var i = 0; i < controlValue.length; i++) {
                        inputVal = {
                            tableName: PBImappingData.tableName, columnName: PBImappingData.columnName, columnValue: [controlValue[i]],
                            operator: (i === 0) ? 'gt' : 'le', controlMappingId: PBImappingData.controlMappingId
                        };
                        userFilterselection.push(inputVal);
                    }
                    break;
                default:
                    switch (PBImappingData.controlMappingId) {
                        case controlName.InboundFlight: case controlName.OutboundFlight:
                            if (hasEmbeddedLinks) {
                                var columnName = (PBImappingData.controlMappingId === controlName.InboundFlight) ? Utility.ReportColumnName.InboundFlightNumber : Utility.ReportColumnName.OutboundFlightNumber;
                                inputVal = { tableName: PBImappingData.tableName, columnName: columnName, columnValue: [controlValue], operator: PBImappingData.operator, controlMappingId: PBImappingData.controlMappingId };
                            }
                            else {
                                inputVal = { tableName: PBImappingData.tableName, columnName: PBImappingData.columnName, columnValue: [controlValue], operator: PBImappingData.operator, controlMappingId: PBImappingData.controlMappingId };
                            }

                            break;
                        case  controlName.BagType: case controlName.ShortConnect: case controlName.OOGBags:
                        case controlName.SeenAfterChox: case controlName.ShowDeletedBags: case controlName.ShowMissedBRS: case controlName.ShowDelBSMs: case controlName.ShowMyBagList:
                        case controlName.RouteStartEndTime: case controlName.InboundITO: case controlName.InTarget: case controlName.FailedThenMissed: case controlName.NotLoadedFailedInSystem:
                            inputVal = { tableName: PBImappingData.tableName, columnName: PBImappingData.columnName, columnValue: [controlValue], operator: PBImappingData.operator, controlMappingId: PBImappingData.controlMappingId };
                            break;
                        default:
                            inputVal = { tableName: PBImappingData.tableName, columnName: PBImappingData.columnName, columnValue: controlValue, operator: PBImappingData.operator, controlMappingId: PBImappingData.controlMappingId };
                            break;
                    }
                    userFilterselection.push(inputVal);
                    break;
            }
        }

    };

    /**
    // apply mapping values to filter controls
    * @param {string[]} mappingList list of filter mappings
    * @returns {string[]} userFilterselection the list of filters selected by user
    */
    Filter.prototype.applyFilterMappingValues = function (mappingList) {
        if (!_.isNil(mappingList)) {
            userFilterselection = [];
            for (var i = 0; i < mappingList.length; i++) {
                Filter.prototype.assignValuesToFilterVM.call(this, mappingList[i], false);
            }
            return userFilterselection;
        }
    };

    return Filter;

})();