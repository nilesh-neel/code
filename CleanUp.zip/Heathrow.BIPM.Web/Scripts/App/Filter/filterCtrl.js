﻿//----------------------------------------------------------------------
//Class Name   : Filter Controller
//Purpose      : This is file use to handel all jquery click event related with Filter Save filter  method.
//Created By   : Kannan
//Created Date : 18/oct/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function ($) {
    'use strict';
    var isNewReportOpen = false;
    var filterVM = {};
    var filterConfig = [];
    var filter = new Filter();
   // var dashboardPowerBiApi = new PowerBIAPP();
    var menuItemId = 0;
    $(document).ready(function () {
        filter.singleDrpDownEventHandler();
        filter.multipleDropDownHandler();
       
        var configData = (Utility.GetStoredData('FilterData') !== null) ? JSON.parse(Utility.GetStoredData('FilterData')) : null;
        if (configData === null) {
            var service = new Service('api/Filter', 'application/json; charset=utf-8', 'json', null);
            service.getApi()
                .done(function (resp) {
                    if (resp !== "null") {
                        var controlResult = resp;
                        Utility.RemoveStoredData("FilterData");
                        Utility.SetStoredData('FilterData', JSON.stringify(controlResult));
                    }
                });
        }
    });

    //apply filter on click of enter
    $('#dvMain').bind('keyup', function applyOnEnter(event) {
        if (event.keyCode === 13) {
            applyFilter();
        }
    });

    //onchange of value change the pin state
    $('#txtInbndFlight').on('change', inbndFlightTextChange);
    function inbndFlightTextChange() {
        filter.EnablePinState(this.value, Utility.GetStoredData('InbndFlight'));
    }

    //onchange of value change the pin state
    $('#txtOutbndFlight').on('change', outbndFlightTextChange);
    function outbndFlightTextChange() {
        filter.EnablePinState(this.value, Utility.GetStoredData('OutbndFlight'));
    }

    //onchange of value change the pin state
    $('#txtRouteStartTime').on('change', roteTimeChange);

    function roteTimeChange() {
        filter.EnablePinState(this.value, Utility.GetStoredData('routeStartTime'));
    }

    //special character validation on keypress
    $('#txtInbndFlight').on('keypress', function specialCharacterValidation(event) {
        Utility.SpecialCharacterValidation(event);
    });
    //special character validation on keypress
    $('#txtOutbndFlight').on('keypress', function specialCharacterValidation(event) {
        Utility.SpecialCharacterValidation(event);
    });
    //special character validation on keypress
    $('#txtBagTag').on('keypress', function specialCharacterValidation(event) {
        Utility.SpecialCharacterValidation(event);
    });
    //special character validation on keypress
    $('#txtPaxName').on('keypress', function specialCharacterValidation(event) {
        Utility.SpecialCharacterValidation(event);
    });
    //special character validation on keypress
    $('#txtTimeBand').on('keypress', function specialCharacterValidation(event) {
        Utility.SpecialCharacterValidation(event);
    });

    //show filter panel on click of filter icon 
    $('.filter').click(filterIconClick);

    function filterIconClick() {
        //close the other panel if it is opened.
        if ($("#sharePanel").is(":visible") || $("#notesDiv").is(":visible")) {
            Utility.ClosePanel();
        }
        $("#filterPanel").toggle();
        $(".filter").toggleClass("clickedIcons");
        $(".filter").toggleClass("customBorderSmall");

        $("#dvMain").hide();
        var report = Utility.ReportName;
        isNewReportOpen = !_.isNil(Utility.SessionDataNullCheck('isNewReport', Utility.SessionStorageType.Get));
        var id = Utility.SessionDataNullCheck('URLId', Utility.SessionStorageType.Get);
        var previousId = Utility.SessionDataNullCheck('MenuId', Utility.SessionStorageType.Get);
        menuItemId = !_.isNil(id) ? parseInt(id) : 0;
        var previousMenuId = !_.isNil(previousId) ? parseInt(previousId) : 0;

        if ($("#filterPanel").is(":visible")) {
            if (menuItemId !== 0 && menuItemId !== previousMenuId || isNewReportOpen) {
                $('.filterCtrl').addClass('hidden');
                var result = !_.isNil(Utility.GetStoredData('FilterData')) ? Utility.GetStoredData('FilterData') : null;
                var filterResult = JSON.parse(result);
                if (!_.isNil(filterResult)) {
                    Utility.RemoveStoredData('MenuId');
                    Utility.SetStoredData('MenuId', menuItemId);
                    var urlData = Utility.SessionDataNullCheck('URLFilterData', Utility.SessionStorageType.Get);

                    if ((isNewReportOpen) && !_.isNil(urlData)) {
                        filterConfig = JSON.parse(urlData);
                    }
                    else {
                        filterConfig = filterConfigValues;
                        var filterInherited = Utility.SessionDataNullCheck('InheritedValues', Utility.SessionStorageType.Get);
                        if (!_.isNil(filterInherited)) {
                            filterInherited = JSON.parse(filterInherited);
                            filterConfig.filterItemSelection = filterInherited;
                            hasSingleDate = _.isMatch(report.ADPDBD === menuItemId || report.ADPDBDLocal === menuItemId ||
                                report.ADPDBDTransfer === menuItemId || report.NLBDBD === menuItemId)
                        }
                        if (_.isNil(filterConfig)) {
                            Utility.ShowFilterIcon(false);
                            return;
                        }
                        Utility.ShowFilterIcon(true);
                    }
                    filter.filterControlDisplayOrder(menuItemId);
                    filter.LoadFilterConfiguration(filterConfig, filterResult);
                    $("#dvMain").show();
                }
            }
            else {
                if (menuItemId === 0 || previousMenuId === 0) {
                    $('.filterCtrl').addClass('hidden');
                    $("#dvMain").hide();
                }
                else {
                    $("#dvMain").show();
                }
            }
        }
    }

    //apply filter on click of apply button
    $('#btnApply').on('click', applyFilter);

    function applyFilter() {
        try {
           // $('#loading').show();
            if (!_.isEmpty(filterConfig.pbiMappingList)) {
                var userFilterselection = [];
                isApplyClicked = true;
                userFilterselection = filter.applyFilterMappingValues(filterConfig.pbiMappingList);

                if (userFilterselection.length > 0) {
                    var dashboardPowerBiApi = new PowerBIAPP();
                    dashboardPowerBiApi.applyFilterToReport(userFilterselection, true);

                    if (!isNewReportOpen) {
                        filterVM.FilterItemSelection = userFilterselection;
                        filterUrl = [];
                        filterUrl = filterVM.FilterItemSelection;
                        filterInheritance(filterVM.FilterItemSelection);
                    }
                }
            }

            //$('#loading').hide();
        } catch (e) {
           // $('#loading').hide();
        }
    }

    //check inherited values and set in session storage
    var filterInheritance = function (filterValues) {

        var filterReport = Utility.ReportName;
        switch (menuItemId) {
            case filterReport.ADPDBD:
            case filterReport.ADPSMR:
            case filterReport.ADPDLR:
            case filterReport.NLBDBD:
            case filterReport.NLBSMR:
            case filterReport.NLBDLR:
                Utility.RemoveStoredData('InheritedValues');
                Utility.SetStoredData('InheritedValues', JSON.stringify(filterValues));
                isFilterInheritance = true;
                break;
            default:
                Utility.RemoveStoredData('InheritedValues');
               // isFilterInheritance = false;
                filterDate = '';
                break;
        }
    };

    /* Pin Icon functionality in filters panel start

    //save filter configuration on click of pin icon
    */
    $('#pinIcon').click(pinIconClick);

    function pinIconClick() {
        if ($(".Pin").is(":visible")) {
            filter.saveFilterConfiguration(menuItemId);
        }
    }

    //on hover of pin icon
    $('#pinIconLink').hover(pinIconHover);

    function pinIconHover(event) {
        $(this).removeClass('hovered-content');
        if ($('#pinIcon').hasClass("pinclicked")) {
            $('#pinIconLink').tooltip('hide');
            $(this).addClass('hovered-content');
        }
    }

    /* Pin Icon functionality in filters panel end */
    $('#btnReset').click(resetClick);

    function resetClick() {

        $(".filterCtrl").find("input[type=text]").val('');

        // clear multi select dropdown
        $(".filterCtrl").find('select[multiple]').multiselect("clearSelection");
        $(".filterCtrl").find('select[multiple]').multiselect('refresh');

        // Clear the Not loaded Sub category values
        Utility.ClearMultiDropDown('#selectNotLoadedSub');

        // default value selection for multiple select
        $('#selectBagStatus').val('NotLoaded').multiselect();
        $('#selectBagStatus').multiselect('rebuild');

        $('#selectLateBSM').val('Identified').multiselect();
        $('#selectLateBSM').multiselect('rebuild');

        $('#selectRoute').val('0').multiselect();
        $('#selectRoute').multiselect('rebuild');

        //Clear Single select dropdown value
        $('#selectBagType + span').children('input').val($("#selectBagType option:first").text());
        $('#selectShortConnect + span').children('input').val($("#selectShortConnect option:first").text());
        $("#selectOOGBags + span").children('input').val($("#selectOOGBags option:first").text());
        $("#selectchox + span").children('input').val($("#selectchox option:first").text());
        $("#selectDeleteBags + span").children('input').val($("#selectDeleteBags option:first").text());
        $("#selectBRSonly + span").children('input').val($("#selectBRSonly option:first").text());
        $("#selectDelBSM + span").children('input').val($("#selectDelBSM option:first").text());
        $("#selectBagList + span").children('input').val($("#selectBagList option:first").text());
        $("#selectInTarget + span").children('input').val($("#selectInTarget option:first").text());
        $("#selectFailedMissed + span").children('input').val($("#selectFailedMissed option:first").text());
        $("#selectFailedSystem + span").children('input').val($("#selectFailedSystem option:first").text());

        $('#minsBefore').val('30');
        $('#minsAfter').val('240');

        filter.setTimeSlicer('#txtRouteStartTime', 6, 24);

        filter.ApplyPinState();

        if (isFilterInheritance && isApplyClicked) {
            Utility.RemoveStoredData('InheritedValues');
            filterDate = '';
        }

        // Get a reference to the embedded report HTML element
        var powerBiContainer = $('#embedContainer')[0];

        // Get a reference to the embedded report.

        var report = powerbi.get(powerBiContainer);

        report.getPages().then(function (pages) {
            _.forEach(pages, function (p) {
                if (p.isActive) {
                    p.removeFilters().then(function (filter) {
                        // report.refresh();
                    }).catch(function (errors) {
                        Utility.alertMessage("Invalid filter definition" + JSON.stringify(errors), "errorMsg");
                    });
                }
            });
        });
    }

    /* daterangePicker for single calender*/
    $("#headerDate").daterangepicker({

        singleDatePicker: true,
        showDropdowns: true

    });
})(jQuery);