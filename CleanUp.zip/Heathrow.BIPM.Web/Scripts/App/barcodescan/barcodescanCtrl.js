﻿//----------------------------------------------------------------------
//Class Name   : Barcode Scan
//Purpose      : This is Barcode Scan Class js file use for the all scan the bag tag barcode with device camera
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function () {
    'use strict';


    var lastResult = [];
    $('.scan,.scanMobile').on('click', scanClick);

    function scanClick() {
        $('#livestream_scanner').modal('show');
        var barcode = new BarcodeScan();
        barcode.init();
    }

    Quagga.onProcessed(function (result) {
        var drawingCtx = Quagga.canvas.ctx.overlay,
            drawingCanvas = Quagga.canvas.dom.overlay;

        if (result) {
            if (result.boxes) {
                drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
                result.boxes.filter(function (box) {
                    return box !== result.box;
                }).forEach(function (box) {
                    Quagga.ImageDebug.drawPath(box, { x: 0, y: 1 }, drawingCtx, { color: "green", lineWidth: 2 });
                });
            }

            if (result.box) {
                Quagga.ImageDebug.drawPath(result.box, { x: 0, y: 1 }, drawingCtx, { color: "#00F", lineWidth: 2 });
            }

            if (result.codeResult && result.codeResult.code) {
                Quagga.ImageDebug.drawPath(result.line, { x: 'x', y: 'y' }, drawingCtx, { color: 'red', lineWidth: 3 });
            }
        }
    });


    //if not initialized
    if (Quagga.initialized === undefined) {
        Quagga.onDetected(function (result) {
            var lastCode = result.codeResult.code;
            lastResult.push(lastCode);
            if (lastResult.length >= 20) {
                var code = orderByOccurrence(lastResult)[0];
                lastResult = [];

                if (!_.isNil(code) && code.length >= 10) {
                    //$('#txtSearch').val(code);
                    //$('#mobileSearchInputBox').val(code);

                    $('#mobileSearchInputBox').val(function (i, val) {
                        return val + (val ? ', ' : '') + code;
                    });

                    $('#txtSearch').val(function (i, val) {
                        return val + (val ? ', ' : '') + code;
                    });


                    $('#livestream_scanner').modal('hide');
                }
            }
        });
    }

    //oder according to the occurance
    function orderByOccurrence(arr) {
        var counts = {};
        arr.forEach(function (value) {
            if (!counts[value]) {
                counts[value] = 0;
            }
            counts[value]++;
        });

        return Object.keys(counts).filter(function (a, i) {
            if (counts[a] >= 3) {
                return Object.keys(counts)[i];
            }
        });


    }

})();