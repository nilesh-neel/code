﻿//----------------------------------------------------------------------
//Class Name   : Barcode Scan
//Purpose      : This is Barcode Scan Class js file use for the all scan the bag tag barcode with device camera
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var BarcodeScan = (function () {

    'use strict';

    this.state = {
        inputStream: {
            type: "LiveStream",
            constraints: {
                width: { min: 640 },
                height: { min: 480 },
                facingMode: "environment",
                aspectRatio: { min: 1, max: 2 }
            }
        },
        locator: {
            patchSize: "medium",
            halfSample: true
        },
        numOfWorkers: 2,
        frequency: 10,
        decoder: {
            readers: [
                {
                    format: "i2of5_reader",
                    config: {}
                }
            ]
        },
        locate: true
    };
    var lastResult = null;

    /**
    // initiates the scanner
    */
    BarcodeScan.prototype.init = function () {
        var self = this;

        Quagga.init(self.state, function (err) {
            if (err) {
                $('#dvScanError').text(err);
            }

            BarcodeScan.prototype.initCameraSelection.call(this);
            BarcodeScan.prototype.checkCapabilities.call(this);
            Quagga.initialized = true;
            Quagga.start();
        });
    };

    /**
    // initiates the camera selection
    * @returns {string[]} video devices
    */
    BarcodeScan.prototype.initCameraSelection = function () {
        var streamLabel = Quagga.CameraAccess.getActiveStreamLabel();

        return Quagga.CameraAccess.enumerateVideoDevices()
            .then(function (devices) {
                function pruneText(text) {
                    return text.length > 30 ? text.substr(0, 30) : text;
                }

                var $deviceSelection = document.getElementById("ddlCamera");
                while ($deviceSelection.firstChild) {
                    $deviceSelection.removeChild($deviceSelection.firstChild);
                }
                devices.forEach(function (device) {
                    var $option = document.createElement("option");
                    $option.value = device.deviceId || device.id;
                    $option.appendChild(
                        document.createTextNode(pruneText(device.label || device.deviceId || device.id)));
                    $option.selected = streamLabel === device.label;
                    $deviceSelection.appendChild($option);
                });
            });
    };

    /**
    // checks the capabilities of the camera
    */
    BarcodeScan.prototype.checkCapabilities = function () {
        var track = Quagga.CameraAccess.getActiveTrack();
        var capabilities = {};
        if (typeof track.getCapabilities === 'function') {
            capabilities = track.getCapabilities();
        }
        BarcodeScan.prototype.applySettingsVisibility.call(this, 'zoom', capabilities.zoom);
        BarcodeScan.prototype.applySettingsVisibility.call(this, 'torch', capabilities.torch);
    };

    /**
    // applies the settings according to capability
    * @param {string} setting the setting needed
    * @param {boolean} capability the capability of camera
    */
    BarcodeScan.prototype.applySettingsVisibility = function (setting, capability) {
        // depending on type of capability
        if (typeof capability === 'boolean') {
            var node = document.querySelector('input[name="settings_' + setting + '"]');
            if (node) {
                node.parentNode.style.display = capability ? 'block' : 'none';
            }
            return;
        }
        if (window.MediaSettingsRange && capability instanceof window.MediaSettingsRange) {
            var node2 = document.querySelector('select[name="settings_' + setting + '"]');
            if (node2) {
                BarcodeScan.prototype.updateOptionsForMediaRange.call(this, node2, capability);
                node2.parentNode.style.display = 'block';
            }
            return;
        }
    };

    /**
    // updates the options for media
    * @param {string} node the node for which modification is done
    * @param {string[]} range the range of options
    */
    BarcodeScan.prototype.updateOptionsForMediaRange = function (node, range) {
       // console.log('updateOptionsForMediaRange', node, range);
        var NUM_STEPS = 6;
        var stepSize = (range.max - range.min) / NUM_STEPS;
        var option;
        var value;
        while (node.firstChild) {
            node.removeChild(node.firstChild);
        }
        for (var i = 0; i <= NUM_STEPS; i++) {
            value = range.min + (stepSize * i);
            option = document.createElement('option');
            option.value = value;
            option.innerHTML = value;
            node.appendChild(option);
        }
    };


});