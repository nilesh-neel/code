﻿//----------------------------------------------------------------------
//File Name    : bagList.js
//Purpose      : bagList.js is used to add/remove bagtags from Baglist/MyBaglist in web app.
//Created By   : Vignesh
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var BagList = (function () {

    'use strict';

    var service;
    /****
     * Creates a new BagList object.
     * @constructor
     *
     */
    BagList = function () {

    };

    /**
    // Add Bagtags button click event
    * @returns {boolean} false if any error message is shown
    */
    BagList.prototype.AddBagTags = function () {

        var bagtags = Utility.GetStoredData('SelectedbagtagsList');
        var SelectedbagtagsCnt = _.toNumber(Utility.GetStoredData('SelectedbagtagsCnt'));
        var ExistingbagtagCnt = _.toNumber($("#lblMybagListcount").text());
        var Existingbagtags = Utility.GetStoredData('ExistingBagtags').length > 0 ? Utility.GetStoredData('ExistingBagtags').replace("'", "") : "";
        var totalbagtagCnt = ExistingbagtagCnt + SelectedbagtagsCnt;
        var selectedBagtagsArr = bagtags.split(",");
        var ExistingbagtagsArr = Existingbagtags.split(",");

        for (var i = 0; i < selectedBagtagsArr.length; i++) {
            if (ExistingbagtagsArr.includes(selectedBagtagsArr[i])) {
                Utility.alertMessage("You are trying to add bag tags that are already present in your My Bag List.", "warningMsg");
                return false;

            }
        }

        if (totalbagtagCnt > 100) {
            Utility.alertMessage("My Bag List has exceeded its capacity (100 Bag Tags). Remove Bag Tag’s and try again.", "warningMsg");
            return false;
        }
        else {
            bagtags = Existingbagtags.length > 0 ? Existingbagtags + ',' + bagtags : bagtags;
            var bagtagsJson = '[{"TableName":"BagItemListFact","ColumnName":"TagNumber","ColumnValue":["' + bagtags.trim(',') + '"]}]';
            var bagData = { BagtagsJson: bagtagsJson };

            service = new Service('api/UserBagList', 'application/json; charset=utf-8', 'json', bagData);
            service.postApi()
                .done(function (resp) {
                    var result = JSON.parse(resp);
                    var existingtags = result[0] !== null ? result[0].ColumnValue.toString() : "";
                    var existingtagsArr = existingtags.split(",");
                    var existingtagsCnt = _.toNumber(existingtagsArr.length);
                    $("#lblMybagListcount").text(existingtagsCnt);
                    Utility.SetStoredData('ExistingBagtags', existingtags);
                    Utility.alertMessage("Bagtags added successfully.", "successMsg");
                }).fail(function (jqXHR, textStatus, errorThrown) {
                    Utility.alertMessage("Error while adding BagTags.", "errorMsg");
                });
        }


    };

    /**
    // Remove Bagtags button click event
    * @returns {boolean} false if any error message is shown
    */
    BagList.prototype.RemoveBagTags = function () {
        var Existingbagtags = Utility.GetStoredData('ExistingBagtags').length > 0 ? Utility.GetStoredData('ExistingBagtags').replace("'", "") : "";
        var bagtags = Utility.GetStoredData('SelectedbagtagsList');
        var RemoveSelectedbagtagsCnt = Utility.GetStoredData('SelectedbagtagsCnt');
        if (RemoveSelectedbagtagsCnt < 1) {
            $('#dvAlertMsg').text('Select atleast one BagTag to remove.');
            Utility.alertMessage("Select atleast one BagTag to remove.", "warningMsg");
            return false;
        }
        else {
            var selectedBagtagsArr = bagtags.split(",");
            var ExistingbagtagsArr = Existingbagtags.split(",");
            ExistingbagtagsArr = $.grep(ExistingbagtagsArr, function (value) {
                return $.inArray(value, selectedBagtagsArr) < 0;
            });

            var Remainingbagtagscount = _.toNumber(ExistingbagtagsArr.length);

            var Remainingbagtags = ExistingbagtagsArr.toString();

            var bagtagsJson = '[{"TableName":"BagItemListFact","ColumnName":"TagNumber","ColumnValue":["' + Remainingbagtags.trim(',') + '"]}]';

            service = new Service('api/UserBagList?bagTagValue=' + bagtagsJson, 'application/json; charset=utf-8', 'json', null);
            service.deleteApi()
                .done(function (resp) {
                    var result = JSON.parse(resp);
                    var existingtagsCnt = 0;
                    if (result[0] !== null && result[0].ColumnValue.toString() !== "") {
                        var existingtags = result[0].ColumnValue.toString();
                        var existingtagsArr = existingtags.split(",");
                        existingtagsCnt = _.toNumber(existingtagsArr.length) > 0 ? _.toNumber(existingtagsArr.length) : 0;
                    }
                    $("#lblMybagListcount").text(existingtagsCnt);
                    Utility.alertMessage("Bagtags removed successfully.", "successMsg");
                    var selectedUserID = '';
                    //To refresh and load both Operational and Historic report in separete Divs after removing bagtags
                    //BagList.prototype.LoadMyBaglistOprtnlHistrcDivs.call(this, selectedUserID);
                    //Report Refresh Start
                    var LoggedinUserEmailId = '';
                    service = new Service('api/UserBagList?otherUserId=' + LoggedinUserEmailId, 'application/json; charset=utf-8', 'json', null);
                    $.when(service.getApi())
                        .then(function (resp) {
                            if (resp !== "") {
                                var result = JSON.parse(resp);
                                var existingtags = result[0] !== null ? result[0].ColumnValue.toString() : "";
                                var existingtagsArr = existingtags.split(",");
                                var existingtagsCnt = _.toNumber(existingtagsArr.length) > 0 ? _.toNumber(existingtagsArr.length) : 0;
                                Utility.SetStoredData('ExistingBagtags', existingtags);
                                Utility.RemoveStoredData('myBagList');
                                // For Operational Report -- Embedding
                                var embeddiv1 = 'dvMyBagListOprtnRpt';

                                var dashboardPowerBiApi1 = new PowerBIAPP();
                                dashboardPowerBiApi1.bagListPowerBiReport(existingtags, 1, embeddiv1,1);

                                // For Historic Report -- Embedding
                                var embeddiv2 = 'dvMyBagListHistRpt';

                                var dashboardPowerBiApi2 = new PowerBIAPP();
                                dashboardPowerBiApi1.bagListPowerBiReport(existingtags, 1, embeddiv2,1);
                            }
                            else {
                                Utility.alertMessage("No Bagtags available for the User ID", "warningMsg");
                            }
                        }).fail(function (jqXHR, textStatus, errorThrown) {
                            Utility.alertMessage("Error occured while fetching BagTags.", "errorMsg");
                        });
                    //Report Refresh End

                }).fail(function (jqXHR, textStatus, errorThrown) {
                    Utility.alertMessage("Error while removing BagTags.", "errorMsg");
                });
        }
    };

    /**
    // Load Bagtags count
    * @param {string} selectedUserID Logged-in user's Email Id.
    */
    BagList.prototype.LoadBagtagCnt = function (selectedUserID) {

        // To get the Logged in user's Existing Bagtags along with count
        service = new Service('api/UserBagList?otherUserId=' + selectedUserID, 'application/json; charset=utf-8', 'json', null);
        service.getApi()
            .done(function (resp) {
                if (resp !== "") {
                    var result = JSON.parse(resp);
                    var existingtags = result[0] !== null ? result[0].ColumnValue.toString() : "";
                    var existingtagsArr = existingtags.split(",");
                    var existingtagsCnt = _.toNumber(existingtagsArr.length) > 1 ? _.toNumber(existingtagsArr.length) : 0;
                    $("#lblMybagListcount").text(existingtagsCnt);
                    Utility.SetStoredData('ExistingBagtags', existingtags);
                }
                else {
                    var bagtagCnt = 0;
                    $("#lblMybagListcount").text(bagtagCnt);
                    Utility.SetStoredData('ExistingBagtags', "");
                }

            }).fail(function (jqXHR, textStatus, errorThrown) {
                Utility.alertMessage("Error occured while fetching BagTags.", "errorMsg");
            });
    };

    /**
    // This method is to load the MyBaglist with both operationl and Historic Divs Report for logged in user and to view other selected user's MyBaglist
    * @param {string} LoggedinUserEmailId Logged-in user's Email Id.
    */
    BagList.prototype.LoadMyBaglistOprtnlHistrcDivs = function (LoggedinUserEmailId) {
        service = new Service('api/UserBagList?otherUserId=' + LoggedinUserEmailId, 'application/json; charset=utf-8', 'json', null);
        $.when(service.getApi())
            .then(function (resp) {
                if (resp !== "") {
                    var result = JSON.parse(resp);
                    var existingtags = result[0] !== null ? result[0].ColumnValue.toString() : "";
                    var existingtagsArr = existingtags.split(",");
                    var existingtagsCnt = _.toNumber(existingtagsArr.length) > 1 ? _.toNumber(existingtagsArr.length) : 0;
                    Utility.SetStoredData('ExistingBagtags', existingtags);
                    Utility.RemoveStoredData('myBagList');
                    // For Operational Report -- Embedding
                    var embeddiv1 = 'dvMyBagListOprtnRpt';

                    var dashboardPowerBiApi1 = new PowerBIAPP();
                    dashboardPowerBiApi1.bagListPowerBiReport(existingtags, 1, embeddiv1,0);

                    // For Historic Report -- Embedding
                    var embeddiv2 = 'dvMyBagListHistRpt';

                    var dashboardPowerBiApi2 = new PowerBIAPP();
                    dashboardPowerBiApi2.bagListPowerBiReport(existingtags, 2, embeddiv2,0);
                }
                else {
                    Utility.alertMessage("No Bagtags available for the User ID", "warningMsg");
                }
            }).fail(function (jqXHR, textStatus, errorThrown) {
                Utility.alertMessage("Error occured while fetching BagTags.", "errorMsg");
            });
    };

    return BagList;
})();