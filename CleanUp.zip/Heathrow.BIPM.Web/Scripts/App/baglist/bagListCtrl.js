﻿//----------------------------------------------------------------------
//File Name    : bagListCtrl.js
//Purpose      : bagListCtrl.js is used to add/remove bagtags from Baglist/MyBaglist in web app.
//Created By   : Vignesh
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function () {
    'use strict';

    $(document).ready(function () {
        var bagList = new BagList();
        var selectedUserID = '';
        bagList.LoadBagtagCnt(selectedUserID);

        /**
        // Add Bagtags button click event
        */
        $("#btnAddBagtags").off('click').on('click', addBagtags);

        function addBagtags() {
            if (_.toNumber(Utility.GetStoredData('SelectedbagtagsCnt')) > 0) {
                bagList.AddBagTags();
            }
            else {
                Utility.alertMessage("Please select atleast one bagtag to add to My Bag List.", "warningMsg");
                return false;
            }

        }

        /**
        // Remove Bagtags button click event
        */
        $("#btnRemoveBagtags").off('click').on('click', removeBagtags);

        function removeBagtags() {
            var selectedBagtagsCnt = _.toNumber(Utility.GetStoredData('SelectedbagtagsCntRpt1')) + _.toNumber(Utility.GetStoredData('SelectedbagtagsCntRpt2'));
            Utility.SetStoredData('SelectedbagtagsCnt', selectedBagtagsCnt);
            if (selectedBagtagsCnt > 0) {
                // Append both Report selected bagtags by user
                var selectedbagtagsRpt1 = Utility.GetStoredData('SelectedbagtagsListRpt1') !== null ? Utility.GetStoredData('SelectedbagtagsListRpt1') : "";
                var selectedbagtagsRpt2 = Utility.GetStoredData('SelectedbagtagsListRpt2') !== null ? Utility.GetStoredData('SelectedbagtagsListRpt2') : "";
                var selectedbagtags = selectedbagtagsRpt1 + "," + selectedbagtagsRpt2;
                selectedbagtags = selectedbagtags.trim(',');
                var uniquebagtags = selectedbagtags.split(',').filter(function (item, i, allItems) {
                    return i === allItems.indexOf(item);
                }).join(',');
                Utility.RemoveStoredData("SelectedbagtagsList");
                Utility.SetStoredData('SelectedbagtagsList', uniquebagtags);
                bagList.RemoveBagTags();
                Utility.RemoveStoredData("SelectedbagtagsList");
                Utility.RemoveStoredData("SelectedbagtagsCnt");
            }
            else {
                Utility.alertMessage("Please select atleast one bagtag to remove from My Bag List.", "warningMsg");
                return false;
            }
        }

        /**
        // MyBaglist link click event
        */
        $('#lnkbtnMyBagList').off('click').on('click', lnkMyBaglist);

        function lnkMyBaglist() {
            Utility.ClosePanel();
            $('#divUserBagLst').hide();
            $('#divUserBagLst').css('display', 'none');
            var currentBreadCrumb = "<li class='active'><a href='#' id=47>My Bag List</a></li>";
            $('#tbOtherUserBaglist').val('');
            $(".breadcrumb li").remove();
            $(".verticalNavigation li").remove();
            $(".breadcrumb").append(currentBreadCrumb);
            Utility.SetStoredData('BreadCrumb', currentBreadCrumb);

            $(".verticalNavigation").append(currentBreadCrumb);

            //routing to default dashboard index for the report embed
            if (window.location.href.split("/")[3] !== "") {
                Utility.SetStoredData('myBagList', true);
                window.location.replace(window.location.origin);
            }
            $("#btnAddBagtags").hide();
            $("#dvDateselection").hide();
            $("#btnRemoveBagtags").show();
            $("#dvOtherUserMyBagList").show();

            //send call to icon enable /disable for the my bag list click
            Menu.prototype.LinkingEmbedToPbi.call(this, 47);

            var LoggedinUserID = '';
            //$("#divUserBagLst").show();
            //$("#divUserBagLst").css('display', 'block');
            $('#viewContainer').hide();
            $('#dvPowerBiEmbed').hide();
            $('#dvPowerBiEmbed').css('display', 'none');

            bagList.LoadMyBaglistOprtnlHistrcDivs(LoggedinUserID);
            Utility.SetStoredData('URLId', 47);
        }

        /**
        // View other user bagtags button click event
        */
        $('#btnViewOthersBaglist').off('click').on('click', viewOthersBaglist);

        function viewOthersBaglist() {
            $('#divUserBagLst').hide();
            $('#divUserBagLst').css('display', 'none');
            var selectedUserEmailId = $('#tbOtherUserBaglist').val();
            $("#btnRemoveBagtags").hide();
            if (selectedUserEmailId.trim().toLowerCase() === $('#userEmail')[0].textContent.trim().toLowerCase()) {
                Utility.alertMessage("Please enter another User ID to view", "warningMsg");
                return false;
            }
            else {
                bagList.LoadMyBaglistOprtnlHistrcDivs(selectedUserEmailId);
            }
        }

        //view other user's baglist on click of enter
        $('#dvOtherUserMyBagList').bind('keyup', function applyOnEnter(event) {
            if (event.keyCode === 13) {
                viewOthersBaglist();
            }
        });

        $('.defaultIcons.fullScreen').off('click').on('click', fullScreen);

        function fullScreen() {
            var reportElement = document.getElementById('userBagListContainer');
            $('#userBagListContainer').toggleClass('widget-fullscreen');
            $(".headerPosition").hide();
            $(".headerTopNav").hide();
            $(".border").hide();
            $(".dateStyling").hide();
            $(document).toggleFullScreen();
            $("#userBagListContainer").css("margin-top", 0);
        }

        $(document).bind('webkitfullscreenchange mozfullscreenchange fullscreenchange', browserFullscreen);

        function browserFullscreen(e) {
            var state = document.fullScreen || document.mozFullScreen || document.webkitIsFullScreen;
            var event = state ? 'FullscreenOn' : 'FullscreenOff';
            if (event === 'FullscreenOff') {
                $('#userBagListContainer').toggleClass('widget-fullscreen');
                $(".headerPosition").show();
                $(".headerTopNav").show();
                $(".border").show();
                $(".dateStyling").show();
                $("#userBagListContainer").css("margin-top", 0);
                $("#userBagListContainer").css("margin-top", $(".navBg").innerHeight() + $(".header").innerHeight());
                $(document).toggleFullScreen();

                //$("#userBagListContainer").css("margin-top", 0);
                // Escape key
                //if (e.keyCode === 27) {
                //$('#userBagListContainer').toggleClass('widget-fullscreen');
                //}
            }
        }

        /**
        //resize the div in mybaglist module.
        */
        $(".resize").resizable({
            resize: function () {
                var currentWidth = $(this).width();
                var ratio = parseInt(1280 / 450);
                var containerDiv = $(this)[0].id === "dvOprtnlRpt" ? "#dvMyBagListOprtnRpt" : "#dvMyBagListHistRpt";
                console.log(containerDiv);
                var pbiContainerOprtnHeight = parseInt(parseInt(currentWidth) / ratio);
                $(containerDiv).css("min-height", pbiContainerOprtnHeight);
            }
        });

    });
})();