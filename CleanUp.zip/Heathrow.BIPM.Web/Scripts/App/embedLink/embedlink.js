﻿//----------------------------------------------------------------------
//Class Name   : Service
//Purpose      : This is Embedded Links Class js file use for the all bind configuration available in filter module.
//Created By   : Kannan.P
//Created Date : 26/dec/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var EmbedLinks = (function () {
    'use strict';
    var paramList = [];
    var reportId = 0;
    var url;
    var filterValues = [];
    var reportType;
    var filterConfiguration = [];
    EmbedLinks = function () { };
    var reportName = Utility.ReportName;
    var isShareReport = false;
    var reportDate = null;
    var isEmbeddedLinks = false;


    // This method load report values if the user navigating via embedded links or share URL.  
    $(document).ready(function () {
        url = $('#hdnUrlValues').val();

        if (_.isNil(url)) { return; }

        $(".breadcrumb li").remove();
        $(".verticalNavigation li").remove();

        Utility.SetStoredData('isNewReport', true);
        var actualUrl = url;
        paramList = actualUrl.split('&');
        isEmbeddedLinks = true;
        if (paramList.length > 2) {
            reportId = parseInt(paramList[0]);
            Utility.RemoveStoredData("ReportId");
            Utility.SetStoredData('ReportId', reportId);
            reportType = parseInt(paramList[1]);
            Utility.showHideMenuIcon();
            notesType = (reportId === reportName.FlightDetailsInBound || reportId === reportName.FlightDetailsOutBound) ? 'F' : 'B';
            EmbedLinks.prototype.GetReportConfiguration.call();
        }
        else {
            reportId = (paramList.length > 0) ? parseInt(paramList[0]) : 0;
            EmbedLinks.prototype.CreateBreadCrumb.call();
            Utility.RemoveStoredData("URLParamValues");
            Utility.RemoveStoredData("ReportId");
            Utility.SetStoredData('ReportId', reportId);
            var dashboardPowerBiApi = new PowerBIAPP();
            dashboardPowerBiApi.embedPowerBIApi(null, reportId);
        }
    });

    /**
    // load filter parameters for embeded link reports
    *
    */
    EmbedLinks.prototype.LoadFilterParameter = function (paramList) {
        filterValues = EmbedLinks.prototype.GetAllUrlParams.call(this, paramList);
        Utility.RemoveStoredData("URLParamValues");
        Utility.SetStoredData('URLParamValues', JSON.stringify(filterValues));
        var dashboardPowerBiApi = new PowerBIAPP();
        dashboardPowerBiApi.embedPowerBIApi(filterValues, reportId);
    };

    /**
    // load PBI mapping configuration for the report
    */
    EmbedLinks.prototype.GetReportConfiguration = function () {

        if (reportId > 0) {
            var service = new Service('api/Filter?menuId=' + reportId,
                'application/json; charset=utf-8',
                'json',
                null);
            service.getApi()
                .done(function (resp) {
                    if (!_.isNil(resp)) {
                        filterConfiguration = resp;
                        Utility.RemoveStoredData("URLFilterData");
                        Utility.SetStoredData('URLFilterData', JSON.stringify(filterConfiguration));
                        EmbedLinks.prototype.CreateBreadCrumb.call();
                        EmbedLinks.prototype.LoadFilterParameter.call(this, paramList, reportId);
                    }
                }).fail(function () {
                    Utility.alertMessage("Error occured while loading bag list details", "errorMsg");
                });
        }

    };

    /**
    // get all filter parameters for embeded link reports
    * @param {string[]} parameterList list of filter mappings
    * @returns {string[]} filterconfiguration list of filter configurations saved
    */
    EmbedLinks.prototype.GetAllUrlParams = function (parameterList) {

        // we'll store the parameters here
        var filterMapping = {};
        var filterSelection = [];

        for (var i = 2; i < parameterList.length; i++) {
            // separate filter the values
            var filterObj = parameterList[i].split('\\');

            if (i <= 4) {
                isShareReport = _.isMatch(filterObj[1], Utility.ReportColumnName.Date);

                if (isShareReport) {
                    isEmbeddedLinks = false;
                    EmbedLinks.prototype.DateDisplay.call(this, filterObj);
                   
                }
                else {

                    if (!isEmbeddedLinks) {
                        $("#headerDate").val(reportDate);
                        Utility.ShowFilterDate(reportId, true, false);
                    }
                }
            }

           // if (!isShareReport)
           // Utility.showHideMenuIcon();

            if (reportId === reportName.BagDetails || reportId === reportName.FlightDetailsInBound
                || reportId === reportName.FlightDetailsOutBound) {
                if (i === 2 && !isShareReport) {
                    notesUblValue = filterObj[3];
                }
                else {
                    notesValue = filterObj[3];
                }
                EmbedLinks.prototype.NotesDisplay.call();
            }


            filterObj[3] = (Utility.ReportColumnName.BagDetails === filterObj[1] || Utility.ReportColumnName.InboundFlight === filterObj[1] ||
                Utility.ReportColumnName.OutboundFlight === filterObj[1]) ? parseInt(filterObj[3]) : filterObj[3];

            filterMapping = {
                tableName: filterObj[0], columnName: filterObj[1], operator: filterObj[2], columnValue: [filterObj[3]]
            };

            filterSelection.push(filterMapping);
        }
        return filterSelection;
    };

    /**
    // displays notes icon based on the report load
    */
    EmbedLinks.prototype.NotesDisplay = function () {

        if (reportId === reportName.BagDetails || reportId === reportName.FlightDetailsInBound
            || reportId === reportName.FlightDetailsOutBound) {
            var notes = new Notes();
            notes.FetchNotes();
            Utility.ShowNotesIcon(true, false);
        }
    };

        /**
    // This method is handled date display if the url having date values  
    */

    EmbedLinks.prototype.DateDisplay = function (filterObj) {
        var dateVal = [];
        var reportOperator;
        var selectedDate = '';
        dateVal = filterObj[3].replace('T00:00:00', '').split('-');
        reportOperator = filterObj[2];

        if (dateVal.length > 0) {
            selectedDate = dateVal[2] + "/" + dateVal[1] + "/" + dateVal[0];

            if (reportOperator === Utility.DateOperator.LessthanEqual) {
                reportDate = reportDate + '-' + selectedDate;
            }
            else { reportDate = selectedDate; }
        }
    };

    /**
    // creates breadcrumb for embeded link & share Url reports also
    */
    EmbedLinks.prototype.CreateBreadCrumb = function () {
        var currentBreadCrumb = "";
        var menuItem = JSON.parse(Utility.GetStoredData('menuList'));
        var mainMenu = _.filter(menuItem, function (o) { return o.menuId === reportId; });

        if (mainMenu.length > 0) {
            var childMenuList = _.filter(menuItem, function (o) { return o.parentId > 0 && o.parentId === mainMenu[0].parentId && o.isMultiLevel });
            $(document).attr("title", "Kestrel - " + _.toUpper(mainMenu[0].tooltip));

            if (childMenuList.length > 0) {
                for (var i = 0; i < childMenuList.length; i++) {
                   
                    if (childMenuList[i].orderId === 1 && childMenuList[i].menuId === reportId) {
                        currentBreadCrumb += "<li class='active'><a href='#' id=" + childMenuList[i].menuId + ">" + _.toUpper(childMenuList[i].tooltip) + "</a></li>";
                    }
                    else if (childMenuList[i].orderId === 1) {
                        currentBreadCrumb += "<li ><a href='#' id=" + childMenuList[i].menuId + ">" + _.toUpper(childMenuList[i].tooltip) + "</a></li>";
                    }
                    if (childMenuList[i].orderId === 2 && childMenuList[i].menuId === reportId) {
                        currentBreadCrumb += "<li class='active'><a href='#' id=" + childMenuList[i].menuId + ">" + _.toUpper(childMenuList[i].tooltip) + "</a></li>";
                    }
                    else if (childMenuList[i].orderId === 2) {
                        currentBreadCrumb += "<li><a href='#' id=" + childMenuList[i].menuId + ">" + _.toUpper(childMenuList[i].tooltip) + "</a></li>"
                    }
                    if (childMenuList[i].orderId === 3 && childMenuList[i].menuId === reportId) {
                        currentBreadCrumb += "<li class='active'><a href='#' id=" + childMenuList[i].menuId + ">" + _.toUpper(childMenuList[i].tooltip) + "</a></li>";
                    }
                    else if (childMenuList[i].orderId === 3) {
                        currentBreadCrumb += "<li ><a href='#' id=" + childMenuList[i].menuId + ">" + _.toUpper(childMenuList[i].tooltip) + "</a></li>";
                    }
                }
            }
            else {
                currentBreadCrumb += "<li class='active'> " + _.toUpper(mainMenu[0].tooltip) + " </li>";
            }
        }

        $(".breadcrumb li").remove();
        $(".verticalNavigation li").remove();

        $(".breadcrumb").append(currentBreadCrumb);
        $(".verticalNavigation").append(currentBreadCrumb);
    };

    return EmbedLinks;

})();



