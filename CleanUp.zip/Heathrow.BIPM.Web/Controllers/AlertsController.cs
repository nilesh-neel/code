﻿/****************************************************************************************************************
Class Name   : Alerts.cs 
Purpose      : Provides action Method for Alerts 
Created By   : Vaishnavi.R
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By            | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh(405285)         | CAST                                      |02/12/2019         | CAST Fix        
Gayathri Kannan(153661)| CCAP                                      |02/07/2019         | CCAP Fix
Anupama Kumari(694315)  | Validation                                |01/28/2019         | Server side validation included to post call
Vaishanvi.R(687417)    | API Implementation                        |01/16/2019         | Updated api implementation to bind with view model
Nilesh(405285)         | API implementation                        |12/29/2018         | Updated web methods with API call to fetch data                                
****************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.ViewModel;
using System.Net.Http;
using Heathrow.BIPM.Web.Helper;
using Newtonsoft.Json;
using System.Linq;
using Heathrow.BIPM.Utility.Constants;

namespace Heathrow.BIPM.Web.Controllers
{

    public class AlertsController : BaseController
    {

        private readonly IMapper<AlertVM, Alerts> _map;

        /// <summary>
        /// Constructor implementation with dependency injection
        /// </summary>
        /// <param name="map"></param>
        public AlertsController(IMapper<AlertVM, Alerts> map)
        {
            _map = map;
        }


        /// <summary>
        /// Loads the landing page view
        /// </summary>
        /// <returns>landingpage view</returns>
        public ActionResult Index()
        {
            return View(MessageConstants.LandingPage);
        }


        /// <summary>
        /// Dropdown data is loaded from the api and mapped to viewmodel
        /// </summary>
        /// <returns>Partial View for new alert</returns>
        public async Task<ActionResult> NewAlert()
        {
            var responseAlert = await WebApiClient.GetResponseContent(MessageConstants.AlertByID + 0, HttpMethod.Get, null, "").ConfigureAwait(false);
            string json = JsonConvert.SerializeObject(responseAlert.result);
            var result = JsonConvert.DeserializeObject<AlertVM>(json);
            result.isOnScreen = true;
            result.isEmail = true;
            result.createdDate = System.DateTime.Now;
            result.startDate = System.DateTime.Now;
            result.endDate = System.DateTime.Now;
            return PartialView(MessageConstants.NewAlert, result);
        }


        /// <summary>
        /// Loads record of corresponding id from api and is mapped to viewmodel- Standard User level
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Partial view to edit alert setting</returns>
        public async Task<ActionResult> AlertSetting(int id)
        {
            var responseAlert = await WebApiClient.GetResponseContent(MessageConstants.AlertByID + id, HttpMethod.Get, null, "").ConfigureAwait(false);
            string json = JsonConvert.SerializeObject(responseAlert.result);
            var result = JsonConvert.DeserializeObject<AlertVM>(json);
            
            return PartialView(MessageConstants.EditAlertSettings, result);            
        }

        /// <summary>
        /// Loads record of corresponding id from api and is mapped to viewmodel - Admin level configuration
        /// </summary>
        /// <param name="id"></param>
        /// <returns>Partial view to edit configure alert</returns>
        public async Task<ActionResult> Edit(int id)
        {

            var responseAlert = await WebApiClient.GetResponseContent(MessageConstants.ConfigureAlertByID + id, HttpMethod.Get, null, "").ConfigureAwait(false);
            string json = JsonConvert.SerializeObject(responseAlert.result);
            var result = JsonConvert.DeserializeObject<AlertVM>(json);
            
            return PartialView(MessageConstants.EditAlertConfigure, result);
        }

        /// <summary>
        /// Posts data to api 
        /// </summary>
        /// <param name="alertData"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> Edit(AlertVM alertData)
        {

            if (alertData != null && ModelState.IsValid)
            {
                if (alertData.startDate > alertData.endDate)
                {
                    return JsonSuccess(MessageConstants.StartDateGTEndDate);
                }
                else
                {
                    var result = await WebApiClient.GetResponseContent(MessageConstants.APIAlert, HttpMethod.Post, _map.MapTo(alertData), "").ConfigureAwait(false);
                    if (result.result.ToString() == MessageConstants.SaveFail)
                    {
                        return JsonSuccess(MessageConstants.AlertFail);
                    }
                    else
                    {
                        switch (alertData.measure)
                        {
                            case "EditAlertForm":
                                return JsonSuccess(MessageConstants.EditSuccess);

                            case "configureAlert":
                                return JsonSuccess(MessageConstants.ConfigureSuccess);
                            case "newAlert":
                                return JsonSuccess(MessageConstants.AlertSuccess);
                            default:
                                return JsonSuccess(result.result);
                        }
                    }
                }
            }
            else if (!ModelState.IsValid)
            {
                var message = "";
                foreach (var validationError in ModelState.Values.SelectMany(v => v.Errors))
                {
                    switch (message)
                    {
                        case "":
                            message = validationError.ErrorMessage;
                            break;
                        default:
                            message = message + "," + validationError.ErrorMessage;
                            break;
                    }
                }
                return JsonSuccess(message);
            }          
            else
            {
                return JsonSuccess(MessageConstants.AlertFail);
            }
        }


        /// <summary>
        /// Posts data to api 
        /// </summary>
        /// <param name="alertData"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> EditMyAlertSettings(AlertVM alertData)
        {
           if(alertData != null)
            {
              await WebApiClient.GetResponseContent(MessageConstants.APIAlert, HttpMethod.Put, _map.MapTo(alertData), "").ConfigureAwait(false);
              return JsonSuccess(MessageConstants.EditSuccess);        
            }
            else
            {
                return JsonSuccess(MessageConstants.AlertFail);
            }
        }

    }

}