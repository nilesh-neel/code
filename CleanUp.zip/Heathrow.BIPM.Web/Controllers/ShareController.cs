﻿/****************************************************************************************************************
Class Name   : ShareController.cs 
Purpose      : This is the share file in the application. To handle sharing of report URL to the selected Users...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetch organisation/recipients using logged-in user's EmailId instead of userId | 05/Dec/2018 | Logic changed
Vignesh (686552)   | code cleanup and updated                                                       | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                                                 | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System.Web.Mvc;
using System.Threading.Tasks;
using System;
using Heathrow.BIPM.Utility.Common;
using Heathrow.BIPM.Utility.Constants;
using System.Text;
using System.Net.Mail;
using System.Net.Mime;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Web.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public class ShareController : BaseController
    {
        public string HtmlString = string.Empty;
        
        /// <summary>
        /// Constructor
        /// </summary>
        public ShareController()
        {
        }

        #region Sending Email through Office365
        /// <summary>
        /// To Send the Report Url via Email to the selected Recipients
        /// </summary>
        /// <param name="selectedRecipients"> Selected Recipients as input parameter</param>
        /// <param name="url">Report Url as input parameter</param>
        /// <returns>Mail Response</returns>
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public async Task<ActionResult> SendMail(string selectedRecipients, string pattern, string reportName)
        {
            try
            {
                string reportLink = pattern.Replace(" ", "%20").ToString();
                var loggedinUser = SessionUtility.Get<AzureAdUser>(SessionConstants.LoggedUser).DisplayName;
                string htmlReportName = MessageConstants.reportNameStartTag + reportName != null ? reportName.Replace("-", "").Trim():"";
                string htmlReportLink = MessageConstants.reportLinkStartTag + reportLink.Trim() + MessageConstants.reportLinkMiddleTag + reportLink.Trim() + MessageConstants.reportLinkEndTag;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(MessageConstants.htmlStructureStart);
                stringBuilder.Append(loggedinUser);
                stringBuilder.Append(MessageConstants.htmlSharedWithYou);
                stringBuilder.Append(htmlReportName);
                stringBuilder.Append(MessageConstants.htmlReportAccess);
                stringBuilder.Append(htmlReportLink);
                stringBuilder.Append(MessageConstants.htmlStructureEnd);
                var alternateView = getEmbeddedImage(AppDomain.CurrentDomain.BaseDirectory + MessageConstants.kestrelLogoPath, stringBuilder);
                string mailBody = HtmlString;
                string mailSubject =reportName.Replace("-", "").Trim();
                if (!string.IsNullOrEmpty(selectedRecipients) && !string.IsNullOrEmpty(pattern))
                {
                    var Mailresponse = await Task.Run(() => MailUtility.SendMail(selectedRecipients, mailSubject, mailBody,alternateView)).ConfigureAwait(false); // Send Mail using Office365
                    return JsonSuccess(Mailresponse);
                }
                return JsonError(new Exception("Mail not Sent"));
            }
            catch (Exception ex)
            {
                JsonError(ex);
                return null;
            }

        }
        #endregion
        /// <summary>
        /// To Embed the kestrel Logo Image in the signature of Email 
        /// </summary>
        /// <param name="filePath">Filepath</param>
        /// <param name="stringBuilder">String Builder for Email body</param>
        /// <returns></returns>
        private AlternateView getEmbeddedImage(String filePath, StringBuilder stringBuilder)
        {
            LinkedResource res = new LinkedResource(filePath, MediaTypeNames.Image.Jpeg);
            res.ContentId = Guid.NewGuid().ToString();
            string imageTag = MessageConstants.imgStartTag + res.ContentId + MessageConstants.imgEndTag;
            stringBuilder.Append(imageTag);
            stringBuilder.Append(MessageConstants.htmlResponseMonitored);
            stringBuilder.Append(MessageConstants.htmlEndTag);
            HtmlString = stringBuilder.ToString();
            AlternateView alternateView = AlternateView.CreateAlternateViewFromString(HtmlString, null, MediaTypeNames.Text.Html);
            alternateView.LinkedResources.Add(res);
            return alternateView;
        }
    }
}