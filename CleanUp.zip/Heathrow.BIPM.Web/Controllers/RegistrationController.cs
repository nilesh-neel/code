﻿/****************************************************************************************************************
Class Name   : RegistrationController.cs 
Purpose      : Provides the Action Method for User Registration.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Web.Mvc;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.ViewModel;
using System.Threading.Tasks;
using Heathrow.BIPM.Web.Helper;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using Microsoft.Security.Application;
using Heathrow.BIPM.Utility.Common;
using Heathrow.BIPM.Utility.Constants;
using System.Net.Mail;
using System.Net.Mime;

namespace Heathrow.BIPM.Web.Controllers
{
    [AllowAnonymous]
    public class RegistrationController : Controller
    {
        private readonly IMapper<RegistrationVM, Registration> _map;

        public RegistrationController(IMapper<RegistrationVM, Registration> map)
        {
            _map = map;

        }


        /// <summary>
        /// This is used to load registration page
        /// </summary>
        /// <returns></returns>
        // GET: Registration/Create
        [HttpGet]
        public async Task<ActionResult> RegistrationPage(string strEmail)
        {
            ResponseMetadata registration = null;
            if (!string.IsNullOrEmpty(strEmail))
            {
                registration = await WebApiClient.GetAnonymousApiContent("api/Registration", HttpMethod.Get, null, "")
                    .ConfigureAwait(false);
            }
            else
            {
                registration = await WebApiClient.GetResponseContent("api/Registration", HttpMethod.Get, null, "")
                    .ConfigureAwait(false);
            }

            string json = JsonConvert.SerializeObject(registration.result);
            var result = JsonConvert.DeserializeObject<RegistrationVM>(json);
            return View(result);
        }

        // POST: Registration/Create
        /// <summary>
        /// Used to save registration request
        /// </summary>
        /// <param name="registration"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> RegistrationPage(RegistrationVM registration)
        {
            Sanitizer.GetSafeHtmlFragment(registration.AccessReason);
            if (!ModelState.IsValid)
            {
                return View(_map.MapTo(registration));
            }

            var emailid = await WebApiClient.GetResponseContent("api/Registration", HttpMethod.Post, _map.MapTo(registration), "").ConfigureAwait(false);
            if (emailid.statusCode == HttpStatusCode.OK)
            {
                string email = JsonConvert.SerializeObject(emailid.result);
                AlternateView alternateView = AlternateView.CreateAlternateViewFromString("", null, MediaTypeNames.Text.Html);
                var Mailresponse = await Task.Run(() => MailUtility.SendMail(email.Replace("\"", ""),
                  MessageConstants.RegistrationMessage, MessageConstants.RegistrationMessage, alternateView)).ConfigureAwait(false);
            }
            return new EmptyResult();
        }


    }
}