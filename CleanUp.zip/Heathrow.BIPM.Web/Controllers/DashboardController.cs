﻿/****************************************************************************************************************
Class Name   : DashboardController.cs 
Purpose      : Dashboard file use to set the user pic and get the token for the power bi reports.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Web.Mvc;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Utility.Common;
using Heathrow.BIPM.Utility.Constants;
using Newtonsoft.Json;
using User = Microsoft.Graph.User;

namespace Heathrow.BIPM.Web.Controllers
{
    public class DashboardController : BaseController
    {
        private string _queryString = string.Empty;

        /// <summary>
        /// Default landing page for the application after login.
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            // Signal OWIN to send an authorization request to Azure.
            if (!Request.IsAuthenticated)
            {
                RedirectToAction(MessageConstants.SignIn, MessageConstants.Account);
            }
            try
            {
                if (SessionUtility.Get<AzureAdUser>(SessionConstants.LoggedUser) == null)
                {
                    GetUserDetailsAsync();
                }

                if (Request.QueryString[MessageConstants.CalledReportId] != null)
                {
                    if (Request.QueryString.Count > 2)
                    {
                        var result = Request.QueryString[Request.QueryString.Count - 1].Split(',');

                        _queryString = Request.QueryString[MessageConstants.CalledReportId] + MessageConstants.Amber + Request.QueryString[MessageConstants.ReportType];

                        foreach (string t in result)
                        {
                            _queryString += MessageConstants.Amber + t;
                        }
                    }
                    else
                    {
                        _queryString = Request.QueryString[MessageConstants.CalledReportId] + MessageConstants.Amber + Request.QueryString[MessageConstants.ReportType];
                    }

                    ViewBag.ParamValue = _queryString;
                }
                if (Session[MessageConstants.Photo] == null)
                {
                    var pic = GetMyProfilePhoto();
                    SessionUtility.Set(SessionConstants.UserPhoto, !string.IsNullOrEmpty(pic) ? pic : string.Empty);
                    ViewBag.Avatar = SessionUtility.Get<string>(SessionConstants.UserPhoto);
                }
            }
            catch (Exception ex)
            {
                JsonError(ex);
            }

            if (Request.IsAjaxRequest())
            {
                return PartialView("_Index");
            }

            return View();
        }
        /// <summary>
        /// Get the login in user details from azure with MS graph api call.
        /// </summary>
        private void GetUserDetailsAsync()
        {
            //Microsoft.Graph.User graphUser = GetUserProfile();
            var displayName = ClaimsPrincipal.Current.FindFirst("name").Value;
            var email = ClaimsPrincipal.Current.FindFirst("preferred_username").Value;

            var objuser = new AzureAdUser
            {
                // Id = graphUser.Id,
                Name = displayName.Length <= 6
                    ? displayName
                    : displayName.Substring(0, 6) + "...",
                DisplayName = displayName,
                Email = email,
                Locations = null,// notification.BagLocation,
                JobRoles = null, //notification.BagOperationalArea,
                Phone = "",
                //Organization = graphUser.CompanyName,
                Role = ClaimsPrincipal.Current.FindFirst(ClaimTypes.Role) != null ? ClaimsPrincipal.Current.FindFirst(ClaimTypes.Role).Value : "",
                Avatar = null
            };

            SessionUtility.Set(SessionConstants.LoggedUser, objuser);
            ViewBag.LogInUser = objuser;
        }

        /// <summary>
        /// Get user profile details
        /// </summary>
        public User GetUserProfile()
        {
            string endpoint = MessageConstants.MsGraphApiUserDetailsEndpoint;
            var response = GetDataFromMsGraph(endpoint);
            if (response.IsSuccessStatusCode)
            {
                string userJson = response.Content.ReadAsStringAsync().Result;
                return JsonConvert.DeserializeObject<User>(userJson);
            }
            return null;
        }

        /// <summary>
        /// Get the profile photo of user.
        /// </summary>
        public string GetMyProfilePhoto()
        {
            string endpoint = MessageConstants.MsGraphApiUserPhotoEndpoint;
            var response = GetDataFromMsGraph(endpoint);
            if (response.IsSuccessStatusCode)
            {
                var result = response.Content.ReadAsStreamAsync().Result;
                return ConvertToBase64(result);
            }
            return null;
        }

        /// <summary>
        /// Get the login in user details from azure with MS graph api call.
        /// </summary>
        public static HttpResponseMessage GetDataFromMsGraph(string endpoint)
        {
            var result = TokenUtility.GetAccessTokenAsync(AzureAdConfig.MSGraphApiResourceId, false).Result;
            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, endpoint))
                {
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", result);
                    return client.SendAsync(request).Result;
                }
            }
        }

        //convert the datatype
        private static string ConvertToBase64(Stream stream)
        {
            byte[] bytes;
            stream.Seek(0, SeekOrigin.Begin);
            using (var memoryStream = new MemoryStream())
            {
                stream.CopyTo(memoryStream);
                bytes = memoryStream.ToArray();
            }

            return Convert.ToBase64String(bytes);
        }
    }
}