﻿/****************************************************************************************************************
Class Name   : NotificationsController.cs 
Purpose      :  To view/edit Today's Notification,My Notification Setting and Configure Notification
Created By   : Vaishnavi R
Created Date : 09/Oct/2018
Version      : 1.0
History      :
Modified By            | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Nilesh(405285)         | CAST                                      |02/12/2019         | CAST FIX   
Anupama Kumari(694315) | Validation                                |01/28/2019         | Server side validation included to post call
Vaishanvi.R(687417)    | API Implementation                        |01/16/2019         | Updated api implementation to bind with view model
Vignesh(686552)        | Warning                                   |01/11/2019         | Warning fix
Nilesh(405285)         | API implementation                        |12/29/2018         | Updated web methods with API call to fetch data     
****************************************************************************************************************/

using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.Helper;
using Heathrow.BIPM.Web.ViewModel;
using Newtonsoft.Json;
using System.Net;
using System.Linq;
using Heathrow.BIPM.Utility.Constants;

namespace Heathrow.BIPM.Web.Controllers
{
    public class NotificationsController : BaseController
    {
        private readonly IMapper<NotificationVM, Notification> _map;

        /// <summary>
        /// Constructor implementation with dependency injection
        /// </summary>
        public NotificationsController( IMapper<NotificationVM, Notification> map)
        {
            _map = map;
          
        }
        /// <summary>
        /// Loads the landing page view
        /// </summary>
        /// <returns>landingpage view</returns>
        public ActionResult Index()
        {
            return PartialView(MessageConstants.LandingPage);

        }
        //Configure New Notification
        /// <summary>           
        /// To create new notification
        /// </summary>        
        /// <returns>partial view for new notification</returns> 
        public async Task<ActionResult> NewNotification()
        {
            var responseNotification = await WebApiClient.GetResponseContent(MessageConstants.Api + 0, HttpMethod.Get, null, "").ConfigureAwait(false);
            string json = JsonConvert.SerializeObject(responseNotification.result);
            var result = JsonConvert.DeserializeObject<NotificationVM>(json);
          
            result.isConfigureOnScreen = true;
            result.createdDate = System.DateTime.Now;
            result.startDate = System.DateTime.Now;
            result.endDate = System.DateTime.Now;
            if (responseNotification.statusCode == HttpStatusCode.OK)
            {
                return PartialView(MessageConstants.NewNotification, result);
            }
            else
            {
                return new EmptyResult();
            }
        }

        /// <summary> 
        /// It gets record corresponding to selected id. 
        /// It populates dropdown from lookup table. 
        /// </summary> 
        /// <param name="notificationId">Notification id to obtain record</param>
        /// <returns>Partial View for My Notification Setting</returns> 
        public async Task<ActionResult> NotificationSetting(int notificationId)
        {
            var responseNotification = await WebApiClient.GetResponseContent(MessageConstants.Api + notificationId, HttpMethod.Get, null, "").ConfigureAwait(false);

            string json = JsonConvert.SerializeObject(responseNotification.result);
            var result = JsonConvert.DeserializeObject<NotificationVM>(json);
            if (responseNotification.statusCode == HttpStatusCode.OK)
            {

                return PartialView(MessageConstants.EditNotificationSetting, (result));
            }
            else
            {
                return new EmptyResult();
            }

        }
        //UPDATE
        /// <summary> 
        /// It gets record corresponding to selected id. 
        /// It populates dropdown from lookup table. 
        /// </summary> 
        /// <param name="notificationId"></param>
        /// <returns>Partial view for Configure Notification</returns> 
        public async Task<ActionResult> Edit(int notificationId)
        {
            var responseNotification = await WebApiClient.GetResponseContent(MessageConstants.Api + notificationId, HttpMethod.Get, null, "").ConfigureAwait(false);
            string json = JsonConvert.SerializeObject(responseNotification.result);
            var result = JsonConvert.DeserializeObject<NotificationVM>(json);
            if (responseNotification.statusCode == HttpStatusCode.OK)
            {
                return PartialView(MessageConstants.EditNotificationConfigure, result);
            }
            else
            {
                return new EmptyResult();
            }
        }

        /// <summary> 
        /// It gets data posted on click of save. 
        /// Obtained data is saved in database 
        /// </summary> 
        /// <param name="notification">ViewModel to save in database</param>
        /// <returns></returns> 
        [HttpPost]
        //[ChildActionOnly]
        public async Task<ActionResult> Edit(NotificationVM notification)
        {
            if (notification != null && ModelState.IsValid)
            {
               
                if (notification.startDate > notification.endDate)
                {
                    return JsonSuccess(MessageConstants.StartDateGTEndDate);
                }
                else
                {
                    var response = await WebApiClient.GetResponseContent(MessageConstants.ApiNotifications, HttpMethod.Post, _map.MapTo(notification), "").ConfigureAwait(false);
                    if (response.result.ToString() == MessageConstants.SaveFail)
                    {
                        return JsonSuccess(MessageConstants.NotificationFail);
                    }
                    else
                    {
                        switch (notification.measure)
                        {
                            case "myNotificationSettingForm":
                                return JsonSuccess(MessageConstants.NotificationSettingSuccess);

                            case "configureNotificationForm":
                                return JsonSuccess(MessageConstants.NotificationConfigureSuccess);
                            case "newNotificationForm":
                                return JsonSuccess(MessageConstants.NotificationSuccess);
                            default:
                                return JsonSuccess(MessageConstants.NotificationSuccess);
                        }
                    }
                }
            }
            else if (!ModelState.IsValid)
            {
                var message = "";
                foreach (var validationError in ModelState.Values.SelectMany(v => v.Errors))
                {
                    switch (message)
                    {
                        case "":
                            message = validationError.ErrorMessage;
                            break;
                        default:
                            message = message + "," + validationError.ErrorMessage;
                            break;
                    }
                }
                return JsonSuccess(message);
            }
            else
            {
                return JsonSuccess(MessageConstants.NotificationFail);
            }
        }



        /// <summary>
        /// Posts data to api 
        /// </summary>
        /// <param name="notificationData"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> EditMyNotificationSettings(NotificationVM notificationData)
        {

            if (notificationData != null)
            {
                await WebApiClient.GetResponseContent(MessageConstants.ApiNotifications, HttpMethod.Post, _map.MapTo(notificationData), "").ConfigureAwait(false);
                return JsonSuccess(MessageConstants.NotificationSettingSuccess);
            }
            else
            {
                return JsonSuccess(MessageConstants.NotificationFail);
            }
        }

    }
}

