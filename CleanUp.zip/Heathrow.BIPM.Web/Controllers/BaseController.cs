﻿/****************************************************************************************************************
Class Name   : BaseController.cs 
Purpose      : This authenticate each and every call/route/method before executing 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;
using Microsoft.Owin.Security.Cookies;
using Heathrow.BIPM.Web.Helper;
using System.Linq;
using Heathrow.BIPM.Web.Filters;
using Heathrow.BIPM.Utility.Constants;
using Heathrow.BIPM.Utility.Common;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.Web.Controllers
{
    //  [Authorize(Roles = "Administrators, SuperUsers, Approvers,StandardUser")]
    [Authorize]
    // [SessionExpireFilter]
    [ExceptionHandling]
    public abstract class BaseController : Controller
    {
        internal string SignedInUserId
        {
            get
            {
                if (Request.IsAuthenticated)
                {
                    return ClaimsPrincipal.Current.FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier").Value;
                }
                return "";
            }
        }

        //on action executing
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext == null) return;
            if (!Request.IsAuthenticated)
            {
                // The session has lost data. This happens often
                Request.GetOwinContext().Authentication.SignOut(CookieAuthenticationDefaults.AuthenticationType);
                filterContext.Result = RedirectToAction(MessageConstants.SignIn, MessageConstants.Account);
            }
            else
            {
                ViewBag.LogInUser = SessionUtility.Get<AzureAdUser>(SessionConstants.LoggedUser);
                ViewBag.Avatar = SessionUtility.Get<string>(SessionConstants.UserPhoto);
            }
            base.OnActionExecuting(filterContext);
        }

        #region "Standared json response to communicate with client"

        //get model state validation error
        protected JsonResultHelper JsonValidationError()
        {
            var result = new JsonResultHelper();

            foreach (var validationError in ModelState.Values.SelectMany(v => v.Errors))
            {
                result.AddError(validationError.ErrorMessage);
            }
            return result;
        }

        //add json error
        protected JsonResultHelper JsonError(Exception exception)
        {
            var result = new JsonResultHelper();
            if (exception != null)
            {
                var url = "http://schemas.microsoft.com/identity/claims/objectidentifier";
                LogUtility.LogException(exception, ClaimsPrincipal.Current.FindFirst(url).Value ?? ClaimsPrincipal.Current.FindFirst(ClaimTypes.Upn).Value);
                result.AddError(exception.Message);
            }

            return result;
        }

        //add json error
        protected JsonResultHelper JsonError(Exception exception, string errorMessage)
        {
            var result = new JsonResultHelper();
            if (exception != null)
            {
                var url = "http://schemas.microsoft.com/identity/claims/objectidentifier";
                LogUtility.LogException(exception, ClaimsPrincipal.Current.FindFirst(url).Value ?? ClaimsPrincipal.Current.FindFirst(ClaimTypes.Upn).Value);
                result.AddError(exception.Message);
            }
            else
            {
                result.AddError(errorMessage);
            }
            return result;
        }

        protected static JsonResultHelper<T> JsonSuccess<T>(T data)
        {
            return new JsonResultHelper<T> { Data = data };
        }
        #endregion
    }
}