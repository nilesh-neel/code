﻿/****************************************************************************************************************
Class Name   : ExceptionHandling.cs 
Purpose      : This file is used to handle the Exceptions globally across the application in Web project and track those exceptions in the Azure Appinsights .......
Created By   : Vignesh AshokKumar 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Utility.Common;
using Heathrow.BIPM.Utility.Constants;
using System;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Heathrow.BIPM.Web.Controllers
{
    public class AuthController : BaseController
    {
        // GET: Access Token from api
        public async Task<JsonResult> GetToken()
        {
            try
            {
                var result = await TokenUtility.GetAccessTokenAsync(AzureAdConfig.WebApiResourceId, false).ConfigureAwait(false);

                return !string.IsNullOrEmpty(result) ? JsonSuccess(new
                {
                    Token = result,
                    Url = AzureAdConfig.WebApiUrl
                }) : JsonError(new Exception("Error in token generation"));
            }
            catch (Exception ex)
            {
                return JsonError(ex);
            }
        }

        public async Task<ActionResult> Token()
        {
            try
            {
                if (string.IsNullOrEmpty(SignedInUserId))
                    RedirectToAction(MessageConstants.SignIn, MessageConstants.Account);


                var result = await TokenUtility.GetAccessTokenAsync(AzureAdConfig.WebApiResourceId, false)
                        .ConfigureAwait(false);

                return !string.IsNullOrEmpty(result)
                    ? JsonSuccess(new
                    {
                        Token = result,
                    })
                    : JsonError(new Exception("Error in token generation"));

            }
            catch (Exception ex)
            {
                return JsonError(ex);
            }
        }
    }
}