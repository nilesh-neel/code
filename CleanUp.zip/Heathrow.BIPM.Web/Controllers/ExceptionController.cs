﻿/****************************************************************************************************************
Class Name   : ExceptionController.cs 
Purpose      : Provides action Method for ExceptionHandling
Created By   : Vignesh 
Created Date : 04/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using Heathrow.BIPM.Utility.Constants;
using System;
using System.Web;
using System.Web.Mvc;

namespace Heathrow.BIPM.Web.Controllers
{
    [AllowAnonymous]
    public class ExceptionController : Controller
    {
        /// <summary>
        /// </summary>
        /// <param name="statusCode"></param>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <returns></returns>
        public ActionResult Error(int statusCode, string message, Exception exception)
        {
            if (statusCode == 401)
            {
                HttpContext.Session.Clear();
                HttpContext.Session.RemoveAll();
                HttpContext.Session.Abandon();
                HttpContext.Response.AddHeader("Cache-control", "no-store, must-revalidate, private, no-cache");
                HttpContext.Response.AddHeader("Pragma", "no-cache");
                HttpContext.Response.AddHeader("Expires", "0");
                HttpContext.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
                HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Response.Cache.SetNoStore();
            }
            Response.StatusCode = statusCode;

            return new FilePathResult(MessageConstants.FilePath, MessageConstants.ContentType);

        }

        /// <summary>
        /// Log Exception occured in owin startup files.
        /// </summary>
        /// <param name="statusCode"></param>
        /// <param name="message"></param>
        /// <param name="exception"></param>
        /// <returns></returns>
        public ActionResult StartUpError(int statusCode, string message, string exception)
        {
            /*
             401 – Unauthorized
            403 – Forbidden
            404 – Not Found
            405 – Method Not Allowed
            406 – Not Acceptable
            412 – Precondition Failed
            500 – Internal Server Error
            501 – Not Implemented
            502 – Bad Gateway
            */

            if (statusCode != 401) return new FilePathResult(MessageConstants.FilePath, MessageConstants.ContentType);
            HttpContext.Session.Clear();
            HttpContext.Session.RemoveAll();
            HttpContext.Session.Abandon();
            HttpContext.Response.AddHeader("Cache-control", "no-store, must-revalidate, private, no-cache");
            HttpContext.Response.AddHeader("Pragma", "no-cache");
            HttpContext.Response.AddHeader("Expires", "0");
            HttpContext.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Response.Cache.SetNoStore();

            return new FilePathResult(MessageConstants.FilePath, MessageConstants.ContentType);

        }
    }
}