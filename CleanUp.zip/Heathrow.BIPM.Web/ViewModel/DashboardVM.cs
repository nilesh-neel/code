﻿using System;

namespace Heathrow.BIPM.Web.ViewModel
{
    public class DashboardVM
    {
        public DashboardsVM[] Value { get; set; }
        public string AccessToken { get; set; }
    }

    public class DashboardsVM
    {
        public string Id { get; set; }
        public string DisplayName { get; set; }
        public Uri EmbedUrl { get; set; }
        public bool IsReadOnly { get; set; }
       

    }
}