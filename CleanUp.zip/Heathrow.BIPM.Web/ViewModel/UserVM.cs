﻿namespace Heathrow.BIPM.Web.ViewModel
{
    public class UserVM
    {
        public string userId { get; set; }
        //public IEnumerable<LookupVM> operationalArea { get; set; }
        //public IEnumerable<LookupVM> location { get; set; }
        public string userPhoto { get; set; }
        public string phoneNumber { get; set; }
        public string organization { get; set; }
        public string email { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public int roleId { get; set; }
        public string roleName { get; set; }
        public int organisationId { get; set; }
        public string organisationName { get; set; }
    }
}