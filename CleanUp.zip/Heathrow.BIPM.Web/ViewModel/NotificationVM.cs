﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.Helper;
using Heathrow.BIPM.Utility.Constants;

namespace Heathrow.BIPM.Web.ViewModel
{
    public class NotificationVM : DropDown
    {
        public DateTime dateAndTime { get; set; }

        public int notificationId { get; set; }
        [AllowHtml]
        public string additionalInformation { get; set; }

        public string requestFrom { get; set; }
    }
    public class NotificationMapping : IMapper<NotificationVM, Notification>
    {
        private readonly IMapper<LookupVM, Lookup> _lookupMap;
        public NotificationMapping(IMapper<LookupVM, Lookup> lookupMap)
        {
            _lookupMap = lookupMap;
        }
        public NotificationVM MapFrom(Notification input)
        {
            return BindCoreToViewModel(input);
        }
        public IEnumerable<NotificationVM> MapFrom(IEnumerable<Notification> input)
        {
            return input.Select(x => BindCoreToViewModel(x));
        }

        public Notification MapTo(NotificationVM input)
        {
            return BindViewModelToCore(input);
        }

        public IEnumerable<Notification> MapTo(IEnumerable<NotificationVM> input)
        {
            return input.Select(x => BindViewModelToCore(x));
        }

        private NotificationVM BindCoreToViewModel(Notification input)
        {

            return new NotificationVM()
            {
                /*    Location = string.Join(",", _input.Locations.ToArray()),*/
           /*     notificationId = input.NotificationId,
                description = input.Description,
                topic = input.Topic,
                createdBy = input.CreatedBy,
                disableNotification = input.DisableNotification,
                modifiedBy = input.ModifiedBy,
                organisation = input.Organisation,
                operationalArea = input.OperationalArea,

                isOnScreen = (input.AdditionalInformation == MessageConstants.Setting) ? input.IsOnScreen:input.IsConfigureOnScreen,
                isEmail = (input.AdditionalInformation== MessageConstants.Setting)?input.IsEmail:input.IsConfigureEmail,
                isMobile =  input.IsMobile,           
                selectedLocation = (List<int>)input.SelectedLocation,
                location = input.Location,
                startDate = input.StartDate,
                modifiedDate = input.ModifiedDate,
                endDate = input.EndDate,
                dateAndTime = input.DateAndTime,
                createdDate = input.CreatedDate,
                selectedTopic = input.SelectedTopic,
                selectedOrganisation = input.SelectedOrganisation,
                selectedOperationalArea = (List<int>)input.SelectedOperationalArea,
                additionalInformation = input.AdditionalInformation,
                bagTopic = _lookupMap.MapFrom(input.BagTopic),
                bagLocation = _lookupMap.MapFrom(input.BagLocation),
                bagOperationalArea = _lookupMap.MapFrom(input.BagOperationalArea),
                bagOrganisation = _lookupMap.MapFrom(input.BagOrganisation),
                */
            };
        }

        private static Notification BindViewModelToCore(NotificationVM input)
        {
            var notification = new Notification()
            {
                NotificationId = input.notificationId,
                Description = input.description,
                Topic = input.topic,
                CreatedBy = input.createdBy,
                DisableNotification = input.disableNotification,
                ModifiedBy = input.modifiedBy,


                StartDate = input.startDate,
                EndDate = input.endDate,
                ModifiedDate = input.modifiedDate,
                DateAndTime = input.dateAndTime,
                CreatedDate = input.createdDate,


                IsOnScreen = (input.additionalInformation == MessageConstants.Setting) ? input.isOnScreen : input.isConfigureOnScreen,
                IsEmail = (input.additionalInformation == MessageConstants.Setting) ? input.isEmail : input.isConfigureEmail,
      
                IsMobile = input.isMobile,

                //  SelectedLocation = input.selectedLocation.ToArray(),

                SelectedOrganisation = input.selectedOrganisation,
                //  SelectedOperationalArea = input.selectedOperationalArea,
                SelectedTopic = input.selectedTopic,
                AdditionalInformation = input.additionalInformation
            };
            if (input.selectedOperationalArea != null)
            {
                ((List<int>)notification.SelectedOperationalArea).AddRange(input.selectedOperationalArea);
            }

            if (input.selectedLocation != null)
            {
                ((List<int>)notification.SelectedLocation).AddRange(input.selectedLocation);
            }

            return notification;
        }
    }


}