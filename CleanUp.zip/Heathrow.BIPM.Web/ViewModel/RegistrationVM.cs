﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.Helper;

namespace Heathrow.BIPM.Web.ViewModel
{
    public class RegistrationVM
    {
        [Required(ErrorMessage = "*Mandatory Field")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "*Mandatory Field")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "*Mandatory Field")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "*Mandatory Field")]       
        public int SelectedOrganisation { get; set; }
        public int SelectedOperationalArea { get; set; }    
        public int SelectedLocation { get; set; }

        public IEnumerable<LookupVM> BagLocation { get; set; }
        public IEnumerable<LookupVM> BagOperationalArea { get; set; }
        public IEnumerable<LookupVM> BagOrganisation { get; set; }

        [Required(ErrorMessage = "*Mandatory Field")]
        [StringLength(140)]
        public string AccessReason { get; set; }
    }
   
    public class RegistrationMapping : IMapper<RegistrationVM, Registration>
    {
        private readonly IMapper<LookupVM, Lookup> _lookupMap;
        public RegistrationMapping(IMapper<LookupVM, Lookup> lookupMap)
        {
            _lookupMap = lookupMap;
        }
        public RegistrationVM MapFrom(Registration input)
        {
            return BindCoreToViewModel(input);
        }


        public IEnumerable<RegistrationVM> MapFrom(IEnumerable<Registration> input)
        {
            return input.Select(x => BindCoreToViewModel(x));
        }

        public Registration MapTo(RegistrationVM input)
        {
            return BindViewModelToCore(input);
        }

        public IEnumerable<Registration> MapTo(IEnumerable<RegistrationVM> input)
        {
            return input.Select(x => BindViewModelToCore(x));
        }


        private  RegistrationVM BindCoreToViewModel(Registration input)
        {
            return new RegistrationVM()
            {
                BagOperationalArea = _lookupMap.MapFrom(input.BagOperationalArea),
                BagLocation = _lookupMap.MapFrom(input.BagLocation),
                BagOrganisation = _lookupMap.MapFrom(input.BagOrganisation)
            };

        }
      
       


        private static Registration BindViewModelToCore(RegistrationVM input)
        {
            return new Registration()
            {
                FirstName = input.FirstName,
                LastName = input.LastName,
                Email = input.Email,
                SelectedOrganisation=input.SelectedOrganisation,
                SelectedLocation=input.SelectedLocation,
                SelectedOperationalArea = input.SelectedOperationalArea,               
                AccessReason = input.AccessReason
            };
        }
       

    }

   
 }