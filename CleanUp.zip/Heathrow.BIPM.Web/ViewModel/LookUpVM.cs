﻿using System.Collections.Generic;
using System.Linq;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.Helper;

namespace Heathrow.BIPM.Web.ViewModel
{
    public class LookupVM
    {
        public int rowId { get; set; }
        public string lookupTypeName { get; set; }
    }

    public class LookupMapping : IMapper<LookupVM, Lookup>
    {
        public LookupVM MapFrom(Lookup input)
        {
            return BindCoreToViewModel(input);
        }
        public IEnumerable<LookupVM> MapFrom(IEnumerable<Lookup> input)
        {
            return input.Select(x => BindCoreToViewModel(x));
        }

        public Lookup MapTo(LookupVM input)
        {
            return BindViewModelToCore(input);
        }

        public IEnumerable<Lookup> MapTo(IEnumerable<LookupVM> input)
        {
            return input.Select(x => BindViewModelToCore(x));
        }

        private static LookupVM BindCoreToViewModel(Lookup _input)
        {
            return new LookupVM()
            {

               
                lookupTypeName=_input.LookupTypeName,
                rowId=_input.RowId

            };
        }

        private static Lookup BindViewModelToCore(LookupVM _input)
        {
            return new Lookup()
            {
               
                RowId=_input.rowId,             
                LookupTypeName=_input.lookupTypeName
            };
        }
    }
}