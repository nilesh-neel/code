﻿using Heathrow.BIPM.Core.Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Heathrow.BIPM.Web.Helper;
using System.Web.Mvc;

namespace Heathrow.BIPM.Web.ViewModel
{
    public class AlertVM : DropDown
    {        
        public int alertId { get; set; }
        [Required(ErrorMessage = "Tiltle Required")]
        [AllowHtml]

        [MaxLength(50, ErrorMessage = "Title cannot be longer than 50 characters.")]
        public string title { get; set; }
        public string time { get; set; }
        [Required(ErrorMessage = "Threshold value Required")]
        [AllowHtml]
        [MaxLength(50, ErrorMessage = "Threshold cannot be longer than 50 characters.")]
        public string thresholdValue { get; set; }
        public int mandatoryOptional { get; set; }
        public int? responseType { get; set; }
        public string todaysLocation { get; set; }
    }


    public class DropDown
    {
        //selected index
        [Required(ErrorMessage = "Location Required")]
        public IEnumerable<int> selectedLocation { get; set;  }

        [Required(ErrorMessage = "Measure Required")]
        public int selectedMeasure { get; set; }
        [Required(ErrorMessage = "Operational Area Required")]
        public IEnumerable<int> selectedOperationalArea { get; set; }

        [Required(ErrorMessage = "Organisation Required")]
        public int selectedOrganisation { get; set; }

        public int selectedThreshold { get; set; }

        [Required(ErrorMessage = "Topic Required")]
        public int selectedTopic { get; set; }

        [Required(ErrorMessage = "Time Window Required")]
        public int selectedTimeWindow { get; set; }

        [Required(ErrorMessage = "Frequency Required")]
        public int selectedFrequency { get; set; }


        //prop for view


        public string location { get; set; }


        public string measure { get; set; }


        public string operationalArea { get; set; }


        public string organisation { get; set; }


        public string topic { get; set; }


        public string threshold { get; set; }


        public string frequency { get; set; }

        public int timewindow { get; set; }
        [AllowHtml]
        [Required(ErrorMessage = "Description Required")]
        public string description { get; set; }
        //audit
        public string createdBy { get; set; }
        [DataType(DataType.Date)]
        public DateTime createdDate { get; set; }

        public string modifiedBy { get; set; }
        [DataType(DataType.Date)]
        public DateTime modifiedDate { get; set; }

        [Required(ErrorMessage = "Start Date Required")]
        [DataType(DataType.Date)]
        public DateTime startDate { get; set; }

        [Required(ErrorMessage = "End Date Required")]
        [DataType(DataType.Date)]
        public DateTime endDate { get; set; }
        //checkbox
        public bool isSubscribe { get; set; }
        public bool isOnScreen { get; set; }
        public bool isEmail { get; set; }
        public bool isMobile { get; set; }
        public bool isSnooze { get; set; }
        public bool isConfigureEmail { get; set; }
        public bool isConfigureOnScreen { get; set; }
        [Required(ErrorMessage = "Disable Alert Required")]
        public bool disableAlert { get; set; }
        public bool disableNotification { get; set; }

        //dropdown
        public IEnumerable<LookupVM> bagLocation { get; set; }
        public IEnumerable<LookupVM> bagMeasure { get; set; }
        public IEnumerable<LookupVM> bagOperationalArea { get; set; }
        public IEnumerable<LookupVM> bagOrganisation { get; set; }
        public IEnumerable<LookupVM> bagTopic { get; set; }
        public IEnumerable<LookupVM> bagThreshold { get; set; }
        public IEnumerable<LookupVM> bagFrequency { get; set; }
        public IEnumerable<LookupVM> bagTimeWindow { get; set; }
    }

    public class AlertMapping : IMapper<AlertVM, Alerts>
    {


        private readonly IMapper<LookupVM, Lookup> _lookupMap;
        public AlertMapping(IMapper<LookupVM, Lookup> lookupMap)
        {
            _lookupMap = lookupMap;
        }

        public AlertVM MapFrom(Alerts input)
        {
            return BindCoreToViewModel(input);
        }
        public IEnumerable<AlertVM> MapFrom(IEnumerable<Alerts> input)
        {
            return input.Select(x => BindCoreToViewModel(x));
        }
        
        public Alerts MapTo(AlertVM input)
        {
            return BindViewModelToCore(input);
        }

        public IEnumerable<Alerts> MapTo(IEnumerable<AlertVM> input)
        {
            return input.Select(x => BindViewModelToCore(x));
        }

        private AlertVM BindCoreToViewModel(Alerts input)
        {
            return new AlertVM()
            {

            };
        }
        
        private static Alerts BindViewModelToCore(AlertVM input)
        {
            var alert = new Alerts()
            {

                AlertId = input.alertId,
                Title = input.title,
                Description = input.description,
                CreatedBy = input.createdBy,
                CreatedDate = input.createdDate,
                ThresholdValue = input.thresholdValue,
                MandatoryOptional = input.mandatoryOptional,
                ModifiedBy = input.modifiedBy,
                ModifiedDate = input.modifiedDate,
                StartDate = input.startDate,
                EndDate = input.endDate,
                Measure=input.measure,
                ResponseType = input.responseType,
                IsSubscribe = input.isSubscribe,
                IsEmail = input.isEmail,
                IsMobile = input.isMobile,
                IsOnScreen = input.isOnScreen,
                IsSnooze=input.isSnooze,
                DisableAlert = input.disableAlert,
                TimeWindow = input.timewindow,
                SelectedMeasure = input.selectedMeasure,
                SelectedOrganisation = input.selectedOrganisation,
                SelectedThreshold = input.selectedThreshold,
                SelectedTopic = input.selectedTopic,
                SelectedFrequency = input.selectedFrequency,
                SelectedTimeWindow = input.selectedTimeWindow
            };

            if (input.selectedLocation != null)
            {
                ((List<int>)alert.SelectedLocation).AddRange(input.selectedLocation);
            }
            if (input.selectedOperationalArea != null)
            {
                ((List<int>)alert.SelectedOperationalArea).AddRange(input.selectedOperationalArea);
            }
            return alert;
        }


    }
}

