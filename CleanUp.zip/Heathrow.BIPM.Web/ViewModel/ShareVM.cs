﻿using System.Collections.Generic;
using System.Linq;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.Helper;

namespace Heathrow.BIPM.Web.ViewModel
{
    public class ShareVM
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public string RecipientId { get; set; }
        public string RecipientName { get; set; }
        public IEnumerable<Share> ShareList { get; set; }
    }

    public class ShareMapping : IMapper<ShareVM, Share>
    {
        public ShareVM MapFrom(Share input)
        {
            if (input == null)
            {
                return null;
            }
            else
            {
                return new ShareVM()
                {
                    GroupId = input.GroupId,
                    GroupName = input.GroupName,
                    RecipientId = input.RecipientId,
                    RecipientName = input.RecipientName

                };
            }
        }


        public IEnumerable<ShareVM> MapFrom(IEnumerable<Share> input)
        {
            return input.Select(x => new ShareVM()
            {
                GroupId = x.GroupId,
                GroupName = x.GroupName,
                RecipientId = x.RecipientId,
                RecipientName = x.RecipientName
            });
        }

        public Share MapTo(ShareVM input)
        {
            if (input == null)
            {
                return null;
            }
            else
            {
                return new Share()
                {
                    GroupId = input.GroupId,
                    GroupName = input.GroupName,
                    RecipientId = input.RecipientId,
                    RecipientName = input.RecipientName

                };
            }
        }

        public IEnumerable<Share> MapTo(IEnumerable<ShareVM> input)
        {
            return input.Select(x => new Share()
            {
                GroupId=x.GroupId,
                GroupName=x.GroupName,
                RecipientId=x.RecipientId,
                RecipientName=x.RecipientName
            });
        }

    }
}