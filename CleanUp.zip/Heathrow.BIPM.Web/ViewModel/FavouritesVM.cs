﻿using System;
using System.Collections.Generic;
using System.Linq;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.Helper;

namespace Heathrow.BIPM.Web.ViewModel
{
    public class FavouritesVM
    {

        public int FavouriteId { get; set; }

        public string UserId { get; set; }
        //[Required]
        public string OperationalReportId { get; set; }
        public string Description { get; set; }
       // [Required]
        public int MenuId { get; set; }
        public bool IsReport { get; set; }
    }

    public class FavouriteMapping : IMapper<FavouritesVM, Favourites>
    {
        public FavouritesVM MapFrom(Favourites input)
        {
            return BindCoreToViewModel(input);
        }


        public IEnumerable<FavouritesVM> MapFrom(IEnumerable<Favourites> input)
        {
            return input.Select(x => BindCoreToViewModel(x));
        }

        public Favourites MapTo(FavouritesVM input)
        {
            return BindViewModelToCore(input);
        }

        public IEnumerable<Favourites> MapTo(IEnumerable<FavouritesVM> input)
        {
            return input.Select(x => BindViewModelToCore(x));
        }

        private static FavouritesVM BindCoreToViewModel(Favourites input)
        {
            return new FavouritesVM()
            {

                FavouriteId = input.FavouriteId,
                MenuId = input.FavouriteLink.MenuId,
                Description = input.FavouriteLink.Description,
                OperationalReportId = input.FavouriteLink.OperationalReportId,
                UserId = input.UserId,
                IsReport = input.FavouriteLink.IsReport
            };
        }

        private static Favourites BindViewModelToCore(FavouritesVM input)
        {
            return new Favourites()
            {

                FavouriteId = input.FavouriteId,
                UserId = input.UserId,
                FavouriteLink = new Menu()
                {
                    MenuId = input.MenuId,
                    Description = input.Description,
                    OperationalReportId = input.OperationalReportId,
                    IsReport = Convert.ToBoolean(input.IsReport)
                }
            };
        }
    }

}