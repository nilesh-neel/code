﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.Web.Helper;

namespace Heathrow.BIPM.Web.ViewModel
{
    public class MenuVM
    {
        [Required]
        public int MenuId { get; set; }
        public string ReportId { get; set; }

        public string OperationalReportId { get; set; }
        public string BusinessReportId { get; set; }
        public string Description { get; set; }

        public string CssIcon { get; set; }
        public int? ParentId { get; set; }
        public int? OrderId { get; set; }
        public bool IsReport { get; set; }
        public string Tooltip { get; set; }
        public string FavDesc { get; set; }
        public bool? IsVisible { get; set; }
    }

    public class MenuMapping : IMapper<MenuVM, Menu>
    {
        public MenuVM MapFrom(Menu input)
        {
            return BindCoreToViewModel(input);
        }

        public IEnumerable<MenuVM> MapFrom(IEnumerable<Menu> input)
        {
            return input.Select(x => BindCoreToViewModel(x));
        }

        public Menu MapTo(MenuVM input)
        {
            return BindViewModelToCore(input);
        }

        public IEnumerable<Menu> MapTo(IEnumerable<MenuVM> input)
        {
            return input.Select(x => BindViewModelToCore(x));
        }

        private static MenuVM BindCoreToViewModel(Menu input)
        {
            return new MenuVM()
            {
                MenuId = input.MenuId,
                Description = input.Description,
                ReportId = input.OperationalReportId,
                CssIcon = input.CssIcon,
                ParentId = input.ParentId,
                OrderId = input.OrderId,
                IsReport = input.IsReport,
                Tooltip = input.Tooltip,
                FavDesc = input.FavouritesDescription,
                BusinessReportId = input.BusinessReportId,
                OperationalReportId = input.OperationalReportId,
                IsVisible = input.IsVisible

            };
        }

        private static Menu BindViewModelToCore(MenuVM input)
        {
            return new Menu()
            {
                MenuId = input.MenuId,
                Description = input.Description,
                OperationalReportId = input.ReportId,
                CssIcon = input.CssIcon,
                ParentId = input.ParentId,
                OrderId = input.OrderId,
                IsReport = input.IsReport,
                Tooltip = input.Tooltip,
                FavouritesDescription = input.FavDesc,
                IsVisible = input.IsVisible
            };
        }
    }

}