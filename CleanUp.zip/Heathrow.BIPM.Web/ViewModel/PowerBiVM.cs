﻿using System.Collections.Generic;
using System;
using System.Linq;
using Heathrow.BIPM.Core.Entity;
using Microsoft.PowerBI.Api.V2.Models;
using Heathrow.BIPM.Web.Helper;

namespace Heathrow.BIPM.Web.ViewModel
{
    public class PowerBiVM
    {
        public string Id { get; set; }

        public Uri EmbedUrl { get; set; }

        public EmbedToken EmbedToken { get; set; }

        public bool? IsEffectiveIdentityRolesRequired { get; set; }

        public bool? IsEffectiveIdentityRequired { get; set; }

        public bool EnableRLS { get; set; }

        public string UserName { get; set; }

        public string Roles { get; set; }

        public string ErrorMessage { get; set; }
        public string PowerbiType { get; set; }
    }

    public class PowerBiVMMapping : IMapper<PowerBiVM, PowerBiEmbedConfig>
    {
        public PowerBiVM MapFrom(PowerBiEmbedConfig input)
        {
            return BindCoreToViewModel(input);
        }
        public IEnumerable<PowerBiVM> MapFrom(IEnumerable<PowerBiEmbedConfig> input)
        {
            return input.Select(x => BindCoreToViewModel(x));
        }

        public PowerBiEmbedConfig MapTo(PowerBiVM input)
        {
            return BindViewModelToCore(input);
        }

        public IEnumerable<PowerBiEmbedConfig> MapTo(IEnumerable<PowerBiVM> input)
        {
            return input.Select(x => BindViewModelToCore(x));
        }

        private static PowerBiVM BindCoreToViewModel(PowerBiEmbedConfig input)
        {
            return new PowerBiVM()
            {
                Id = input.Id,
                EmbedToken = input.EmbedToken as EmbedToken,
                EmbedUrl = input.EmbedUrl,
                EnableRLS = input.EnableRls,
                ErrorMessage = input.ErrorMessage,
                IsEffectiveIdentityRequired = input.IsEffectiveIdentityRequired,
                IsEffectiveIdentityRolesRequired = input.IsEffectiveIdentityRolesRequired,
                PowerbiType = input.PowerBIType,
                Roles = input.Roles,
                UserName = input.UserName
            };
        }

        private static PowerBiEmbedConfig BindViewModelToCore(PowerBiVM input)
        {
            return new PowerBiEmbedConfig()
            {
                Id = input.Id,
                EmbedUrl =input.EmbedUrl,
                ErrorMessage = input.ErrorMessage,
                IsEffectiveIdentityRolesRequired = input.IsEffectiveIdentityRolesRequired,
                UserName = input.UserName,
                PowerBIType = input.PowerbiType,
                Roles = input.Roles,
                EnableRls = input.EnableRLS,
                IsEffectiveIdentityRequired = input.IsEffectiveIdentityRequired,
                EmbedToken = input.EmbedToken
            };
        }
    }
}