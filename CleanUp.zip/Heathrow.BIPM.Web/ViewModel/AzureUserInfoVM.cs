﻿using System.Collections.Generic;

namespace Heathrow.BIPM.Web.ViewModel
{
    public class AzureUserInfoVM
    {
        public string OdataContext { get; set; }
        public string Id { get; set; }
        public IEnumerable<string> BusinessPhones { get; set; }
        public string DisplayName { get; set; }
        public string GivenName { get; set; }
        public string JobTitle { get; set; }
        public string Mail { get; set; }
        public object MobilePhone { get; set; }
        public object OfficeLocation { get; set; }
        public object PreferredLanguage { get; set; }
        public string Surname { get; set; }
        public string UserPrincipalName { get; set; }
    }
}