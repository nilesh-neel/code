using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class MenuRepositoryTests : BaseRepositoryTest
    {
        private MenuRepository _menuRepository;
        private string _userId = "xy@gmail.com";

        [TestInitialize]
        public void TestInitialize()
        {
            var fakeVWMenu = new VWMenu[]
            {
                    new VWMenu() {MenuDesc = "DAshboard", MenuId = 2,BreadCrumb = "BreadCrumb",CreatedDatetime = new System.DateTime(), CreatedUser="apan1", CssIcon="icon",IsMultiLevel = true,IsVisible = true, OrderId = null, ParentId = null,ReportName = "apan1", Tooltip = "tooltip",UpdatedDatetime = new System.DateTime(),UpdateUser = "apan1",Favourites= "favour"}
            };

            var spMock = SetupReturn(new spFetchReportDetails_Result()
            {
                MenuId = 2,
                FilterType = "2"
            });

            var mockDbObj = new Mock<BaggageDbContext>("constructor");


            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.VWMenu).ReturnsDbSet(fakeVWMenu);
                dbMock.Setup(b => b.spFetchReportDetails(_userId)).Returns(() => spMock.Object);
            });

            RegisterResettableType<IMenu>(() => mock =>
            {
                mock.Setup(s => s.GetAllMenu());
                mock.Setup(s => s.GetReportDetails(_userId));
            });

            _menuRepository = Container.Resolve<MenuRepository>();

        }



        [TestCleanup]
        public void TestCleanup()
        {
            // this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public void GetAllMenu_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var testMenu = GetTestMenu();
            // Act
            //var result = unitUnderTest.GetAllMenu();
            var result = _menuRepository.GetAllMenu();

            // Assert
            Assert.AreNotEqual(result, testMenu);
        }

        [TestMethod]
        public void GetReportDetails_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var testMenu = GetTestMenu();
            // Act
            var result = _menuRepository.GetReportDetails(_userId);
            // Assert
            Assert.AreNotEqual(testMenu, result);
        }

        private List<Menu> GetTestMenu()
        {
            var testMenu = new List<Menu>
            {
                new Menu()
                {
                    BusinessReportId = "1",
                    Description = "desc",
                    FavouritesDescription = "fdesc",
                    MenuId = 19,
                    OrderId = 1,
                    Organization = "org",
                    CssIcon = "ico",
                    IsReport = true,
                    OperationalReportId = "2",
                    ParentId = 1,
                    Tooltip = "sample"
                }
            };

            return testMenu;
        }


    }
}
