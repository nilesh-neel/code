using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class BagListRepositoryTests : BaseRepositoryTest
    {
        private BagListRepository _bagListRepository;

        [TestInitialize]
        public void TestInitialize()
        {
            string userEmailId = "xyz@abc.com";
            var spMock = SetupReturn(new spFetchMybaglistOtherUsers_Result()
            {
                OrganizationPartyID = 2,
                UserApplicationRoleID = 1,
                UserEmail = "test",
                UserID = 1,
                UserFirstName = "test",
                UserLastName = "test"
            });

            var mockReturnString = SetupReturn("test");
            
            string bagTags = "[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]";

            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.spFetchUserExistingBagtags(userEmailId)).Returns(() => mockReturnString.Object);
                dbMock.Setup(b => b.spFetchUserExistingBagtags(null)).Returns(() => null);
                dbMock.Setup(b => b.spRemoveBagtags(bagTags, userEmailId)).Returns(() => mockReturnString.Object);
                dbMock.Setup(b => b.spRemoveBagtags(null,null)).Returns(() => null);
                dbMock.Setup(b => b.spSaveBagtags(bagTags, userEmailId));
            });            

            _bagListRepository = Container.Resolve<BagListRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            //this.mockRepository.VerifyAll();
        }

        #region GetUserExistingBagTags

        [TestMethod]
        public void GetUserExistingBagTags_StateUnderTest_ExpectedBehavior()
        {
            //Arrange
            string userEmailId = "xyz@abc.com";
            // Act
            var result = _bagListRepository.GetUserExistingBagTags(userEmailId).Result;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void GetUserExistingBagTags_StateUnderTest_ExpectedBehavior_InvalidParams()
        {
            //Arrange
            string userEmailId = null;

            // Act
            var result = _bagListRepository.GetUserExistingBagTags(userEmailId).Result;

        }

        #endregion

        #region RemoveBagTags

        [TestMethod]
        public void RemoveBagTags_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string bagTags = "[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]";
            string userEmailId = "xyz@abc.com";
            
            // Act
            var result = _bagListRepository.RemoveBagTags(bagTags, userEmailId).Result;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void RemoveBagTags_StateUnderTest_ExpectedBehavior_InvalidParams()
        {
            // Arrange
            string bagTags = null;
            string userEmailId = null;

            // Act
            var result = _bagListRepository.RemoveBagTags(bagTags, userEmailId).Result;
            
        }

        #endregion

        [TestMethod]
        public async Task SaveBagTags_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            string bagTags = "[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]";
            string userEmailId = "xyz@abc.com";
            var result = dataLayer.Setup(x => x.spSaveBagtags(bagTags, userEmailId));
            var data = _bagListRepository.SaveBagTags(bagTags, userEmailId);
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetUserExistingBagTags_StateUnderTest_NotExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            string userEmailId = "xyz@abc.com";

            var result = dataLayer.Setup(x => x.spFetchUserExistingBagtags(userEmailId));
            var data = _bagListRepository.GetUserExistingBagTags(userEmailId);
            Assert.AreNotEqual(result, data);
        }

        [TestMethod]
        public async Task RemoveBagTags_StateUnderTest_NotExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            string bagTags = "[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]";
            string userEmailId = "xyz@abc.com";

            var result = dataLayer.Setup(x => x.spRemoveBagtags(bagTags, userEmailId));
            var data = _bagListRepository.RemoveBagTags(bagTags, userEmailId);
            Assert.AreNotEqual(result, data);
        }

        [TestMethod]
        public async Task SaveBagTags_StateUnderTest_NotExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            string bagTags = "[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]";
            string userEmailId = "xyz@abc.com";
            var result = dataLayer.Setup(x => x.spSaveBagtags(bagTags, userEmailId));
            var data = _bagListRepository.SaveBagTags(bagTags, userEmailId);
            Assert.AreNotEqual(result, data);
        }

    }
}
