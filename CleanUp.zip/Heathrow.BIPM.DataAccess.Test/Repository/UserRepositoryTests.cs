using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class UserRepositoryTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;
        private UserRepository _userRepository;
        private string _userId = "gayathri.kannan@heathrow.com";
        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();

            //RegisterResettableType<BaggageDbContext>(); 

            var spUser = new spFetchUserList_Result()
            {
                OrganizationPartyID = 1,
                UserApplicationRoleID = 2,
                UserEmail = "a@b.com",
                UserFirstName = "first",
                UserID = 1,
                UserLastName = "last"
            };

            var fakeVWUser = new VWUser[]
            {
                    new VWUser() {ActiveIndicator = "Y",OrganisationPartyID = 1,UserEmail = "gayathri.kannan@heathrow.com",UserFirstName = "test",UserID = 1,UserLastName = "test"},
            };

            var spMock = SetupReturn(new spFetchUserDetails_Result()
            {
                FirstName = "Gayathri",
                LastName = "Kannan",
                OperationalActivityID = 5,
                TerminalFacilityID = 4,
                TerminalDescription = "Heathrow Terminal 3",
                Email = "gayathri.kannan@heathrow.com",
                UserID = 6,
                OrganisationPartyName = "test"
            });

            var mockDbObj = new Mock<BaggageDbContext>("constructor");

            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.VWUser).ReturnsDbSet(fakeVWUser);
                dbMock.Setup(b => b.spFetchUserDetails(_userId)).Returns(() => spMock.Object);
            });
            User user = new User()
            {
                UserId = "13243",
                OperationalArea = new Lookup() { LookupTypeName = "PBA/Reflight", RowId = 5 },
                Location = new Lookup() { LookupTypeName = "Heathrow Terminal 3", RowId = 4 },
                UserPhoto = "test",
                PhoneNumber = "131231313",
                Organization = "test",
                Email = "gayathri.kannan@heathrow.com",
                FirstName = "Gayathri",
                LastName = "Kannan"
            };

            RegisterResettableType<IUser>(() => mock =>
            {
                mock.Setup(s => s.UpdateOperationalAreaAndLocation(user).Result);
                mock.Setup(s => s.Fetch("1").Result);
            });

            Context = Container.Resolve<BaggageDbContext>();
            _userRepository = Container.Resolve<UserRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task UpdateOperationalAreaAndLocation_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateUserRepository();
            User objUser = new User
            {
                UserId = "13243",
                OperationalArea = new Lookup() { RowId = 1, LookupTypeName = "test", Selected = 1 },
                Location = new Lookup() { RowId = 1, LookupTypeName = "test", Selected = 1 },
                UserPhoto = "test",
                PhoneNumber = "131231313",
                Organization = "test",
                Email = "gayathri.kannan@heathrow.com",
                FirstName = "Gayathri",
                LastName = "Kannan"
            };

            var result = dataLayer.Setup(x => x.spUpdateOperationAreaLocation(objUser.UserId,
                objUser.OperationalArea.RowId, objUser.Location.RowId));
            // Act
            //var result = await unitUnderTest.UpdateOperationalAreaAndLocation(
            //    objUser);
            var data = _userRepository.UpdateOperationalAreaAndLocation(objUser);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task UpdateOperationalAreaAndLocation_StateUnderTest_UnexpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateUserRepository();
            User objUser = new User
            {
                UserId = "0",
                OperationalArea = new Lookup() { RowId = 1, LookupTypeName = "test", Selected = 1 },
                Location = new Lookup() { RowId = 1, LookupTypeName = "test", Selected = 1 },
                UserPhoto = "test",
                PhoneNumber = "131231313",
                Organization = "test",
                Email = "gayathri.kannan@heathrow.com",
                FirstName = "Gayathri",
                LastName = "Kannan"
            };

            var result = dataLayer.Setup(x => x.spUpdateOperationAreaLocation(objUser.UserId,
                objUser.OperationalArea.RowId, objUser.Location.RowId));
            // Act
            //var result = await unitUnderTest.UpdateOperationalAreaAndLocation(
            //    objUser);
            var data = _userRepository.UpdateOperationalAreaAndLocation(objUser).Result;

            // Assert
            Assert.IsTrue(data == 999);
        }

        [TestMethod]
        public async Task Fetch_StateUnderTest_ExpectedBehavior()
        {
            var testUser = GetTestUser();
            // Act
            var result =await _userRepository.Fetch(_userId);
            // Assert
            Assert.AreNotEqual(testUser, result);
            Assert.IsNotNull(testUser[0].Email);
            Assert.IsNotNull(testUser[0].FirstName);
            Assert.IsNotNull(testUser[0].LastName);
            Assert.IsNotNull(testUser[0].OrganisationId);
            Assert.IsNotNull(testUser[0].OrganisationName);
            Assert.IsNotNull(testUser[0].Organization);

            Assert.IsNotNull(testUser[0].PhoneNumber);
            Assert.IsNotNull(testUser[0].RoleId);
            Assert.IsNotNull(testUser[0].RoleName);
            Assert.IsNotNull(testUser[0].UserPhoto);



        }

        public IList<User> GetTestUser()
        {
            IList<User> testUser = new List<User>
            {
              new User
            {
                UserId = "0",
                OperationalArea = new Lookup() { RowId = 1, LookupTypeName = "test", Selected = 1 },
                Location = new Lookup() { RowId = 1, LookupTypeName = "test", Selected = 1 },
                UserPhoto = "test",
                PhoneNumber = "131231313",
                Organization = "test",
                Email = "gayathri.kannan@heathrow.com",
                FirstName = "Gayathri",
                LastName = "Kannan",
                RoleId=1,
                RoleName="testRole",
                OrganisationId=1,
                OrganisationName="testOrganisation"
            }
            };
            return testUser;

        }

    }
}
