using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class ShareRepositoryTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;
        private ShareRepository _shareRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();

            var spMock = SetupReturn(new spFetchUserGroups_Result()
            {
                OrganisationPartyID = 1,
                OrganisationGroupName = "test"
            });

            var spMock1 = SetupReturn(new spFetchGroupRecipients_Result()
            {
                UserID = 13243,
                UserFirstName = "Gayathri",
                UserLastName = "Kannan",
                UserEmail = "gayathri.kannan@heathrow.com",
                OrganisationPartyID = 1,
                HomePageName = "test"
            });

            IList<Share> TestShareCollection = new List<Share>()
            {
                new Share()
                {
                    GroupId = 1,
                    GroupName = "test",
                    RecipientId = "1"
                    //RecipientName = "test"
                }
            };

            var mockDbObj = new Mock<BaggageDbContext>("constructor");

            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.spFetchUserGroups("gayathri.kannan@heathrow.com")).Returns(() => spMock.Object);
                dbMock.Setup(b => b.spFetchGroupRecipients(1)).Returns(() => spMock1.Object);
            });

            RegisterResettableType<IShare>(() => mock =>
            {
                mock.Setup(s => s.FetchAudienceGroup("xyz@abc.com").Result).Returns(GroupList());
                mock.Setup(s => s.FetchRecipients(12).Result);
            });

            Context = Container.Resolve<BaggageDbContext>();
            _shareRepository = Container.Resolve<ShareRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task FetchAudienceGroup_StateUnderTest_ExpectedBehavior()
        {
            var testAudienceGroup = GroupList();
            // Act
            var result = _shareRepository.FetchAudienceGroup("gayathri.kannan@heathrow.com");
            // Assert
            Assert.AreNotEqual(testAudienceGroup, result);
        }       

        [TestMethod]
        public async Task FetchRecipients_StateUnderTest_NotExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateShareRepository();
            int audienceGroupId = 10;

            var result = dataLayer.Setup(x => x.spFetchGroupRecipients(audienceGroupId));
            // Act
            //var result = await unitUnderTest.FetchRecipients(
            //    audienceGroupId);
            var data = _shareRepository.FetchRecipients(audienceGroupId);

            // Assert
            Assert.IsNotNull(result);
        }       

        private static IList<Share> GroupList()
        {
            IList<Share> groupList = new List<Share>
            {
                new Share
                {
                    GroupId = 10,
                    GroupName = "Group1"
                }
            };
            return groupList;
        }

        private static IList<Share> RecipientList()
        {
            IList<Share> recipientList = new List<Share>
            {
                new Share
                {
                    GroupId = 10,
                    RecipientId = "5",
                    RecipientName = "Group1"
                }
            };
            return recipientList;
        }
    }
}
