using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class AlertsRepositoryTests : BaseRepositoryTest
    {
        #region local

        private AlertsRepository _alertsRepository;
        private string _userId = "test.test@heathrow.com";

        #endregion

        #region Initialize Test

        [TestInitialize]
        public void TestInitialize()
        {
            var spMock = SetupReturn(new spAlertNotification_Result()
            {
                AlertCreatedDatetime = DateTime.Now,
                AlertID = 1,
                AlertMessage = "test",
                MandatoryIndicator = 1,
                ResponseTypeID = 1,
                UserEmail = "test",
                UserID = 1
            });
            var spMock1 = SetupReturn(new spTodaysAlert_Result()
            {
                AlertCreatedDatetime = DateTime.Now,
                AlertID = 1,
                AlertMessage = "test",
                ResponseTypeID = 1,
                AlertTitle = "test",
                TodaysLocation = 12
            });
            var spMock2 = SetupReturn(new spFetchAlert_Result()
            {
                AlertCreatedDatetime = DateTime.Now,
                ResponseTypeID = 1,
                AlertTitle = "test",
                MandatoryIndicator = 1
            });
            var spMock3 = SetupReturn(new spFetchConfiguredAlert_Result()
            {
                AlertCreatedDatetime = DateTime.Now,
                AlertConfigurationID = 12,
                AlertTitle = "test",
                MandatoryIndicator = 1,
                OperationalActivityId = "1,2,3,4",
                TerminalId = "1,2,3"
            });
            var fakeVWMeasure = new VWMeasure[]
            {
                new VWMeasure() {Identifier = "test", MeasureCategoryID = 2, MeasureID = 1},
            };
            var fakeVWTopic = new VWTopic[]
            {
                new VWTopic() {Identifier = "test", MeasureCategoryID = 2},
            };
            var fakeVWTodaysAlert = new VWTodaysAlert[]
            {
                new VWTodaysAlert() {AlertMessage = "test", AlertID = 2, ResponseTypeID = 1},
            };
            var mockDbObj = new Mock<BaggageDbContext>("constructor");


            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.VWMeasure).ReturnsDbSet(fakeVWMeasure);
                dbMock.Setup(b => b.VWTopic).ReturnsDbSet(fakeVWTopic);
                dbMock.Setup(b => b.spAlertNotification(_userId)).Returns(() => spMock.Object);
                dbMock.Setup(b => b.spTodaysAlert(_userId)).Returns(() => spMock1.Object);
                dbMock.Setup(b => b.spFetchAlert(_userId, null)).Returns(() => spMock2.Object);
                dbMock.Setup(b => b.spFetchAlert(_userId, 1)).Returns(() => spMock2.Object);
                dbMock.Setup(b => b.spFetchConfiguredAlert(_userId, null)).Returns(() => spMock3.Object);
                dbMock.Setup(b => b.spFetchConfiguredAlert(_userId, 1)).Returns(() => spMock3.Object);
                dbMock.Setup(b => b.VWTodaysAlert).ReturnsDbSet(fakeVWTodaysAlert);
                dbMock.Setup(b => b.spUpdateAlert(_userId, 1, 1, 1, 1, 1, 1));
            });
            Alerts alert = new Alerts()
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,


                ResponseType = 1,
                SelectedFrequency = 1,
                // SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                // SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                ThresholdValue = "1",
                Measure="1",
                TimeWindow = 1,
                Title = "title"

            };

            _alertsRepository = Container.Resolve<AlertsRepository>();
        }

        #endregion

        [TestCleanup]
        public void TestCleanup()
        {
            //this.mockRepository.VerifyAll();
        }

        #region GetAlertCount

        [TestMethod]
        public void GetAlertCount_StateUnderTest_ExpectedBehavior()
        {
            // Act
            var data = _alertsRepository.GetAlertCount(_userId).Result;

            // Assert
            Assert.IsNotNull(data);
        }

        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void GetAlertCount_StateUnderTest_ExpectedBehavior_InvalidParams()
        {
            // Act
            var data = _alertsRepository.GetAlertCount(null).Result;

        }
        #endregion

        #region GetAlertNotification

        [TestMethod]
        public void GetAlertNotification_StateUnderTest_ExpectedBehavior()
        {
            // Act
            var data = _alertsRepository.GetAlertNotification(_userId).Result;

            // Assert
            Assert.IsNotNull(data);
        }

        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void GetAlertNotification_StateUnderTest_ExpectedBehavior_InvalidParams()
        {
            // Act
            var data = _alertsRepository.GetAlertNotification(null).Result;

        }
        #endregion

        #region  GetTodaysAlert

        [TestMethod]
        public void GetTodaysAlert_StateUnderTest_ExpectedBehavior()
        {
            // Act
            var data = _alertsRepository.GetTodaysAlert(_userId).Result;

            // Assert
            Assert.IsNotNull(data);
        }

        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void GetTodaysAlert_StateUnderTest_ExpectedBehavior_InvalidParams()
        {
            // Act
            var data = _alertsRepository.GetTodaysAlert(null).Result;

        }
        #endregion

        #region GetMyAlertSettings

        [TestMethod]
        public void GetMyAlertSettings_StateUnderTest_ExpectedBehavior()
        {
            // Act
            var data = _alertsRepository.GetMyAlertSettings(_userId).Result;

            // Assert
            Assert.IsNotNull(data);
        }

        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void GetMyAlertSettings_StateUnderTest_ExpectedBehavior_InvalidParams()
        {
            // Act
            var result = _alertsRepository.GetMyAlertSettings(null).Result;

        }
        #endregion

        #region GetAlertsById

        [TestMethod]
        public void GetAlertsById_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            int alertId = 1;

            // Act
            var result = _alertsRepository.GetAlertsById(_userId, alertId).Result;

            // Assert
            Assert.IsNotNull(result);
        }
        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void GetAlertsById_StateUnderTest_ExpectedBehavior_InvalidParams()
        {
            // Arrange
            int alertId = 0;

            // Act
            var result = _alertsRepository.GetAlertsById(null, alertId).Result;

        }
        #endregion


        [TestMethod]
        public async Task GetTopicForMeasure_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAlertsRepository();
            string selectedId = "1"; //""; //TODO;

            var result = menuDataLayer.Setup(x => x.VWMeasure);
            // Act
            //var result = await unitUnderTest.GetTopicForMeasure(
            //    selectedId);
            var data = _alertsRepository.GetTopicForMeasure(selectedId);

            // Assert
            Assert.IsNotNull(result);
        }

        #region GetConfiguredAlert

        [TestMethod]
        public void GetConfiguredAlert_StateUnderTest_ExpectedBehavior()
        {
            // Act
            var result = _alertsRepository.GetConfiguredAlert(_userId).Result;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void GetConfiguredAlert_StateUnderTest_ExpectedBehavior_InvalidParams()
        {
            // Act
            var result = _alertsRepository.GetConfiguredAlert(null).Result;
        }

        #endregion

        #region GetConfiguredAlertById

        [TestMethod]
        public void GetConfiguredAlertById_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var alertId = 1;
            // Act
            var data = _alertsRepository.GetConfiguredAlertById(_userId, alertId).Result;

            // Assert
            Assert.IsNotNull(data);
        }

        [TestMethod]
        [ExpectedException(typeof(System.AggregateException))]
        public void GetConfiguredAlertById_StateUnderTest_ExpectedBehavior_InvalidParams()
        {
            // Arrange
            var alertId = 0;

            // Act
            var data = _alertsRepository.GetConfiguredAlertById(null, alertId).Result;

            // Assert
            Assert.IsNull(data);
        }

        #endregion        

        [TestMethod]
        public async Task InsertUpdate_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAlertsRepository();
            Alerts alert = new Alerts()
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,


                ResponseType = 1,
                SelectedFrequency = 1,
                // SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                // SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,

                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title"

            };

            var testAlert = GetTestAlerts();
            var result = menuDataLayer.Setup(x => x.spInsertUpdateAlerts(""));
            // Act
            //var result = await unitUnderTest.InsertUpdate(
            //    alert);
            var data = _alertsRepository.InsertUpdate(alert);

            // Assert
            Assert.AreNotEqual(testAlert, result);
        }

        private static List<Alerts> GetTestAlerts()
        {
            var testProducts = new List<Alerts>();
            testProducts.Add(new Alerts
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                MandatoryOptional = 1,
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                // SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                ThresholdValue = "1",
                TimeWindow = 1,
                Title = "title",

            });
            testProducts.Add(new Alerts
            {
                AlertId = 2,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,


                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //   SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title",

            });
            testProducts.Add(new Alerts
            {
                AlertId = 3,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,


                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //  SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,

                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title",

            });
            testProducts.Add(new Alerts
            {
                AlertId = 4,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,

                MandatoryOptional = 1,

                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,

                ResponseType = 1,
                SelectedFrequency = 1,
                //  SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                //  SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,

                ThresholdValue = "1",

                TimeWindow = 1,
                Title = "title",

            });

            return testProducts;
        }
    }
}
