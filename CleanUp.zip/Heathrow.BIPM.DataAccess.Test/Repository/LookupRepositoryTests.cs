using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class LookupRepositoryTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;
        private LookupRepository _lookupRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            var fakeVWMeasure = new VWMeasure[]
            {
                new VWMeasure() {Identifier = "Test", MeasureCategoryID = 2, MeasureID = 1},
            };
            var fakeVWTopic = new VWTopic[]
            {
                new VWTopic() {Identifier = "Test", MeasureCategoryID = 2},
            };
            var fakeVWLocation = new VWLocation[]
            {
                new VWLocation() {Description = "Test", TerminalFacilityID = 2},
            };
            var fakeVWThreshold = new VWThreshold[]
            {
                new VWThreshold() {Identifier = "Test", ThresholdTypeID = 2},
            };
            var fakeVWFrequency = new VWFrequency[]
            {
                new VWFrequency() {Identifier = "Test", FrequencyID = 2},
            };
            var fakeVWTimeWindow = new VWTimeWindow[]
            {
                new VWTimeWindow() {Identifier = "Test", TimeWindowID = 2},
            };
            var fakeVWOrganization = new VWOrganization[]
            {
                new VWOrganization() {OrganizationPartyName = "Test", OrganizationPartyID = 2},
            };
            var fakeVWOperationalArea = new VWOperationalArea[]
            {
                new VWOperationalArea() {OperationalActivityIdentifier = "Test", OperationalActivityID = 2},
            };

            var mockDbObj = new Mock<BaggageDbContext>("constructor");
            
            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.VWMeasure).ReturnsDbSet(fakeVWMeasure);
                dbMock.Setup(b => b.VWTopic).ReturnsDbSet(fakeVWTopic);
                dbMock.Setup(b => b.VWLocation).ReturnsDbSet(fakeVWLocation);
                dbMock.Setup(b => b.VWThreshold).ReturnsDbSet(fakeVWThreshold);
                dbMock.Setup(b => b.VWFrequency).ReturnsDbSet(fakeVWFrequency);
                dbMock.Setup(b => b.VWTimeWindow).ReturnsDbSet(fakeVWTimeWindow);
                dbMock.Setup(b => b.VWOrganization).ReturnsDbSet(fakeVWOrganization);
                dbMock.Setup(b => b.VWOperationalArea).ReturnsDbSet(fakeVWOperationalArea);
            });
            
            RegisterResettableType<ILookup>(() => mock =>
            {
                mock.Setup(s => s.AllFrequency());
                mock.Setup(s => s.AllLocation());
                mock.Setup(s => s.AllMeasure());
                mock.Setup(s => s.AllOperationalArea());
                mock.Setup(s => s.AllOrganisation());
                mock.Setup(s => s.AllThreshold());
                mock.Setup(s => s.AllTimeWindow());
                mock.Setup(s => s.AllTopic());
            });

            _lookupRepository = Container.Resolve<LookupRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            //this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public void AllMeasure_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWMeasure);
            // Act
            //var result = unitUnderTest.AllMeasure();
            var data = _lookupRepository.AllMeasure();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllTopic_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWTopic);
            // Act
            //var result = unitUnderTest.AllTokpic();
            var data = _lookupRepository.AllTopic();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllLocation_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWLocation);
            // Act
            //var result = unitUnderTest.AllLocation();
            var data = _lookupRepository.AllLocation();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllThreshold_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWThreshold);
            // Act
            //var result = unitUnderTest.AllThreshold();
            var data = _lookupRepository.AllThreshold();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllFrequency_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWFrequency);
            // Act
            //var result = unitUnderTest.AllFrequency();
            var data = _lookupRepository.AllFrequency();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllTimeWindow_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWTimeWindow);
            // Act
            //var result = unitUnderTest.AllTimeWindow();
            var data = _lookupRepository.AllTimeWindow();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllOrganisation_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWOrganization);
            // Act
            //var result = unitUnderTest.AllOrganisation();
            var data = _lookupRepository.AllOrganisation();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void AllOperationalArea_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateLookupRepository();

            var result = dataLayer.Setup(x => x.VWOperationalArea);
            // Act
            //var result = unitUnderTest.AllOperationalArea();
            var data = _lookupRepository.AllOperationalArea();

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
