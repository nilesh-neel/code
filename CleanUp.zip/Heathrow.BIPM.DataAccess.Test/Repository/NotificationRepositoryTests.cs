using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class NotificationRepositoryTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;
        private NotificationRepository _notificationRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {

            var fakeVWNotificationLocation = new VWNotificationLocation[]
            {
                 new VWNotificationLocation() {NotificationID = 1, TerminalFacilityID = 2 }
            };

            var spMock = SetupReturn(new spFetchNotifications_Result()
            {
                ActiveIndicator = "1",
                MeasureCategoryID = 2,
                HelpURL = "test",
                NotificationDescription = "test",
                NotificationID = 1,
                NotificationTitle = "test",
                EmailNotificationIndicator = 0,
                OnScreenNotificationIndicator = 1,
                userEmail = 0,
                userOnScreen = 1,
                NotificationStartDateTime = DateTime.Now,
                NotificationEndDateTime = DateTime.Now,
                OrganizationPartyID = 1,
                OrganizationPartyName = "test",
                TerminalId = "1",
                TerminalDescription = "test",
                OperationalActivityId = "1",
                OperationalDescription = "test",
                NotificationCreatedDateTime = DateTime.Now,
                ModifiedDateTime = DateTime.Now,
                ModifiedBy = "test.test@test.com",
                CreatedBy = "test.test@test.com",
                Topics = "test"

            });

            Notification notification = new Notification()
            {
                NotificationId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableNotification = false,
                EndDate = DateTime.Now,
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                //Locations = "1",
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                OperationalArea = "1",
                Organisation = "1",
                ResponseType = 1,
                SelectedMeasure = 1,
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                Topic = "test",
                IsSnooze = true,
                IsConfigureEmail = false,
                AdditionalInformation = "test",
                DisableAlert = false,
                IsConfigureOnScreen = true,
                Location = "test",
                SelectedFrequency = 1
            };
            var mockDbObj = new Mock<BaggageDbContext>("constructor");

            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.VWNotificationLocation).ReturnsDbSet(fakeVWNotificationLocation);
                dbMock.Setup(b => b.spFetchNotifications("test", 1)).Returns(() => spMock.Object);
            });
            RegisterResettableType<INotification>(() => mock =>
            {
                mock.Setup(s => s.GetNotificationByNotificationId("user1", 1).Result);
                mock.Setup(s => s.GetScrollingNotification("user1").Result);
                mock.Setup(s => s.GetUserNotification("user1").Result);
                mock.Setup(s => s.InsertUpdate(notification).Result);
            });

            Context = Container.Resolve<BaggageDbContext>();
            _notificationRepository = Container.Resolve<NotificationRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            //this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task GetUserNotification_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateNotificationRepository();
            string userid = "user1";
            var testNotification = await GetTestNotificationList();

            var result = menuDataLayer.Setup(x => x.spFetchNotifications(userid, null));
            // Act
            //var result = await unitUnderTest.GetUserNotification(
            //    userid);
            var data = _notificationRepository.GetUserNotification(userid);

            // Assert
            Assert.AreNotEqual(testNotification, result);
        }
        private static Task<IEnumerable<Notification>> GetTestNotificationList()
        {
            IEnumerable<Notification> testProducts = new List<Notification>()
            { new Notification
            {
                NotificationId = 1,
                Description = "desc",

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Topic = "test"
            } };

            return Task.FromResult(testProducts);
        }

        [TestMethod]
        public async Task InsertUpdate_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateNotificationRepository();
            Notification notification = new Notification()
            {
                NotificationId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableNotification = false,
                EndDate = DateTime.Now,
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                //Locations = "1",
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                OperationalArea = "1",
                Organisation = "1",
                ResponseType = 1,
                SelectedMeasure = 1,
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                Topic = "test"
            };
            var result = menuDataLayer.Setup(x => x.spInsertUpdateNotifications(""));
            // Act
            //var result = await unitUnderTest.InsertUpdate(
            //    notification);
            var data = _notificationRepository.InsertUpdate(notification);

            // Assert
            Assert.AreNotEqual("Save Success", result);
        }

        [TestMethod]
        public async Task GetNotificationByNotificationId_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateNotificationRepository();
            string userId = "1";
            int notificationId = 1;

            var testNotification = await GetTestNotification();
            var result = menuDataLayer.Setup(x => x.spFetchNotifications(userId, notificationId));
            // Act
            //var result = await unitUnderTest.GetNotificationByNotificationId(
            //    userid,
            //    notificationId);
            var data = _notificationRepository.GetNotificationByNotificationId(userId, notificationId);

            // Assert
            Assert.AreNotEqual(testNotification, result);
        }

        private static Task<Notification> GetTestNotification()
        {
            var testNotification = new Notification()
            {
                CreatedBy = "David",
                NotificationId = 1,
            };

            return Task.FromResult(testNotification);
        }
    }
}
