﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Language;
using Moq.Language.Flow;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Linq;
using Unity;
using Unity.Injection;
using Unity.Lifetime;
using Unity.Registration;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    public class BaseRepositoryTest
    {
        protected UnityContainer Container;
        protected LifetimeResetter Resetter { get; set; }
        protected BaggageDbContext Context { get; set; }

        protected BaseRepositoryTest()
        {
            Resetter = new LifetimeResetter();
            Container = new UnityContainer();
        }

        protected static Mock<ObjectResult<T>> SetupReturn<T>(T whatToReturn)
        {
            Func<T, IEnumerator<T>> enumerator = new Func<T, IEnumerator<T>>(s => ((IEnumerable<T>)new[] { s }).GetEnumerator());
            var mock = new Mock<ObjectResult<T>>();
            mock.Setup(or => or.GetEnumerator()).Returns(() => enumerator(whatToReturn));
            return mock;
        }



        [TestInitialize]
        public void OnTestSetup()
        {
            Resetter.Reset();
        }

        protected void RegisterResettableType<T>(params InjectionMember[] injectionMembers)
        {
            Container.RegisterType<T>(new ResettableLifetimeManager(Resetter), injectionMembers);
        }

        protected void RegisterResettableType<T>(Func<Action<Mock<T>>> onCreatedCallbackFactory) where T : class
        {
            RegisterResettableType<T>(new InjectionFactory(c => CreateMockInstance(onCreatedCallbackFactory)));
        }

        protected T CreateMockInstance<T>(Func<Action<Mock<T>>> onCreatedCallbackFactory) where T : class
        {
            var mock = new Mock<T>();
            var onCreatedCallback = onCreatedCallbackFactory();
            onCreatedCallback?.Invoke(mock);
            return mock.Object;
        }

        protected class LifetimeResetter
        {
            public event EventHandler<EventArgs> OnReset;

            public void Reset()
            {
                OnReset?.Invoke(this, EventArgs.Empty);
            }
        }

        protected class ResettableLifetimeManager : LifetimeManager
        {
            public ResettableLifetimeManager(LifetimeResetter lifetimeResetter)
            {
                lifetimeResetter.OnReset += (o, args) => instance = null;
            }

            private object instance;

            public override object GetValue()
            {
                return instance;
            }

            public override void SetValue(object newValue)
            {
                instance = newValue;
            }

            public override void RemoveValue()
            {
                instance = null;
            }
        }
    }

    public static class DbSetMocking
    {
        private static Mock<DbSet<T>> CreateMockSet<T>(IQueryable<T> data)
            where T : class
        {
            var queryableData = data.AsQueryable();
            var mockSet = new Mock<DbSet<T>>();
            mockSet.As<IQueryable<T>>().Setup(m => m.Provider)
                .Returns(queryableData.Provider);
            mockSet.As<IQueryable<T>>().Setup(m => m.Expression)
                .Returns(queryableData.Expression);
            mockSet.As<IQueryable<T>>().Setup(m => m.ElementType)
                .Returns(queryableData.ElementType);
            mockSet.As<IQueryable<T>>().Setup(m => m.GetEnumerator())
                .Returns(queryableData.GetEnumerator());
            return mockSet;
        }

        public static IReturnsResult<TContext> ReturnsDbSet<TEntity, TContext>(
            this IReturns<TContext, DbSet<TEntity>> setup,
            TEntity[] entities)
            where TEntity : class
            where TContext : DbContext
        {
            var mockSet = CreateMockSet(entities.AsQueryable());
            return setup.Returns(mockSet.Object);
        }

      
    }

}
