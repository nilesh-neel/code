using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class NotesRepositoryTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;
        private NotesRepository _notesRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            var spMock = SetupReturn(new spFetchNotes_Result()
            {
                Bagtag = "2",
                FlightNumber = "2",
                NotesDesc = "test",
                CreatedDatetime = DateTime.Now,
                IsPublic = true,
                NotesId = 1,
                OrganizationId = 1,
                UniqueBagtagLogic = "test",
                UserFirstName = "test",
                UserLastName = "test"
            });

            var spSaveNotes = new spSaveNotes_Result()
            {
                Bagtag = "tag",
                CreatedDatetime = new DateTime(),
                FlightNumber = "12345",
                IsPublic = true,
                NotesDesc = "desc",
                NotesId = 123,
                OrganizationId = 12345,
                UniqueBagtagLogic = "bag",
                UserFirstName = "first",
                UserLastName = "last"
            };

            var spDeleteNotes = new spDeleteNotes_Result
            {
                UserFirstName = "first",
                UserLastName = "last",
                OrganizationId = 1,
                NotesId = 1,
                NotesDesc = "desc",
                IsPublic = true,
                Bagtag = "tag",
                CreatedDatetime = new DateTime(),
                FlightNumber = "1234",
                UniqueBagtagItem = "tag"
            };

            var mockDbObj = new Mock<BaggageDbContext>("constructor");

            string notesValue = "Bt1";
            string notesType = "5673";
            string notesUblValue = "Fl1";
            string userId = "";
            int notesId = 15;

            NotesEntity note = new NotesEntity
            {
                NotesId = 0,
                NoteDescription = "Notes Description added",
                UblValue = "12345",
                OrganizationId = 1,
                IsPublic = 1,
                CreatedDate = "12/24/2018",
                UserId = "Admin",
                UserLastName = "test",
                UserFirstName = "test",
                NotesType = "test",
                NotesValue = "test"
            };

            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.spFetchNotes(notesValue, notesUblValue, notesType, userId)).Returns(() => spMock.Object);
                dbMock.Setup(b => b.spSaveNotes(note.NotesId, note.NoteDescription, note.NotesValue,
                  Convert.ToBoolean(note.IsPublic), note.UserId, note.UblValue, note.NotesType));
                dbMock.Setup(b => b.spDeleteNotes(notesId, userId, notesValue, notesType));
            });

            RegisterResettableType<INotes>(() => mock =>
            {
                mock.Setup(s => s.FetchNotes("Bt1","5673", "Fl1","").Result);
                mock.Setup(s => s.DeleteNotes(1,"5673", "Fl1","").Result);
                mock.Setup(s => s.SaveNotes(note).Result);
            });

            Context = Container.Resolve<BaggageDbContext>();
            _notesRepository = Container.Resolve<NotesRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            //this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task SaveNotes_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateNotesRepository();
            NotesEntity note = new NotesEntity
            {
                NotesId = 0,
                NoteDescription = "Notes Description added",
                UblValue = "12345",
                OrganizationId = 1,
                IsPublic = 1,
                CreatedDate = "12/24/2018",
                UserId = "Admin",
                UserLastName = "test",
                UserFirstName = "test",
                NotesType = "test",
                NotesValue = "test"
            };
            var testNotes = NotesList();

            var result = dataLayer.Setup(x => x.spSaveNotes(note.NotesId, note.NoteDescription, note.NotesValue,
                  Convert.ToBoolean(note.IsPublic), note.UserId, note.UblValue, note.NotesType));
        
            var data = _notesRepository.SaveNotes(note);

            // Assert
            Assert.AreNotEqual(testNotes, result);
        }

        [TestMethod]
        public async Task FetchNotes_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateNotesRepository();
            string notesValue = "Bt1";
            string notesType = "5673";
            string notesUblValue = "Fl1";
            string userId = "";

            var result = dataLayer.Setup(x => x.spFetchNotes(notesValue, notesUblValue, notesType, userId));

            var data = _notesRepository.FetchNotes(notesValue, notesUblValue, notesType, userId);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task DeleteNotes_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateNotesRepository();
            int notesId = 15;
            string notesValue = "Bt1";
            string notesType = "B"; 
            string userId = "use@xy.com";

            var result = dataLayer.Setup(x => x.spDeleteNotes(notesId, userId, notesValue, notesType));
            // Act
            //var result = await unitUnderTest.DeleteNotes(
            //    notesId,
            //    notesValue,
            //    notesType,
            //    userId);
            var data = _notesRepository.DeleteNotes(notesId, userId, notesValue, notesType);

            // Assert
            Assert.IsNotNull(result);
        }

        private static Task<IList<NotesEntity>> NotesList(bool isDeleted = false)
        {
            IList<NotesEntity> notesList = new List<NotesEntity>
            {
                new NotesEntity
                {
                    NotesId = 5,
                    UblValue = "12345",
                    NoteDescription = "Flight is delayed",
                    OrganizationId=1,
                    IsPublic=1,
                    CreatedDate= "12/24/2018",
                    UserId="Admin",
                    UserFirstName="nilesh",
                    NotesValue = "test",
                    NotesType = "test",
                    UserLastName = "test"
                }
            };
            return Task.FromResult(notesList);
        }
    }
}
