using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class FavouritesRepositoryTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;
        private FavouritesRepository _favouritesRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            var spMock = SetupReturn(new spGetFavourites_Result()
            {
                MenuId = 2,
                Description = "test",
                FavouriteId = 1,
                IsReport = 1,
                ReportObjectId = "test",
                UserId = "test"
            });
            Favourites favourites = new Favourites()
            {
                FavouriteId = 1,
                FavouriteLink = new Menu() { Description = "test" },
                UserId = "1"
            };
            var mockDbObj = new Mock<BaggageDbContext>("constructor");

            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.spGetFavourites("test")).Returns(() => spMock.Object);
            });
            RegisterResettableType<IFavourites>(() => mock =>
            {
                mock.Setup(s => s.GetUserFavourites("test").Result);
                mock.Setup(s => s.Save(favourites).Result);
            });

            Context = Container.Resolve<BaggageDbContext>();
            _favouritesRepository = Container.Resolve<FavouritesRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            //this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task GetUserFavourites_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateFavouritesRepository();
            string userId = "1"; //TODO;

            var result = menuDataLayer.Setup(x => x.spGetFavourites(userId));
            // Act
            //var result = await unitUnderTest.GetUserFavourites(
            //    userId);
            var data = _favouritesRepository.GetUserFavourites(userId);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task Save_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateFavouritesRepository();
            Favourites favourites = new Favourites()
            {
                FavouriteId = 1,
                FavouriteLink = new Menu() {Description = "test" },
                UserId = "1"
            }; 

            var result = menuDataLayer.Setup(x => x.spSaveFavourites("1", 1));
            // Act
            //var result = await unitUnderTest.Save(
            //    favourites);
            var data = _favouritesRepository.Save(favourites);

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
