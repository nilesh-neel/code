using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class AssignHomePageRepositoryTests : BaseRepositoryTest
    {
        private AssignHomePageRepository _assignHomePageRepository;

        [TestInitialize]
        public void TestInitialize()
        {
            var spMock = SetupReturn(new spFetchUserGroups_Result
            {
                OrganisationPartyID = 2,
                OrganisationGroupName = "test"
            });
            var spMock1 = SetupReturn(new spFetchGroupRecipients_Result()
            {
                OrganisationPartyID = 2,
                HomePageName = "test",
                UserEmail = "test",
                UserFirstName = "test",
                UserID = 1,
                UserLastName = "test"
            });
            var spMock2 = SetupReturn(new spFetchUserDashboard_Result()
            {
                ReportId = "2",
                WorkSpaceId = "test"
            });

            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.spFetchUserGroups("test")).Returns(() => spMock.Object);
                dbMock.Setup(b => b.spFetchGroupRecipients(1)).Returns(() => spMock1.Object);
                dbMock.Setup(b => b.spFetchUserDashboard("test")).Returns(() => spMock2.Object);
            });
            
            Context = Container.Resolve<BaggageDbContext>();
            _assignHomePageRepository = Container.Resolve<AssignHomePageRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            //this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task GetUserGroups_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAssignHomePageRepository();

            var testAssign = GetTestAssign();
            var result = dataLayer.Setup(x => x.spFetchUserGroups("xyz@abc.com"));
            // Act
            //var result = await unitUnderTest.GetUserGroups();
            var data = _assignHomePageRepository.GetUserGroups("xyz@abc.com");

            // Assert
            Assert.AreNotEqual(testAssign, result);
        }

        [TestMethod]
        public async Task GetGroupRecipients_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAssignHomePageRepository();
            int userGroupId = 19;

            var testAssign = GetTestAssign();
            var result = dataLayer.Setup(x => x.spFetchGroupRecipients(userGroupId));
            // Act
            //var result = await unitUnderTest.GetGroupRecipients(
            //    userGroupId);
            var data = _assignHomePageRepository.GetGroupRecipients(userGroupId);

            // Assert
            Assert.AreNotEqual(testAssign, result);
        }

        [TestMethod]
        public async Task SaveHomepage_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAssignHomePageRepository();
            string homepages = "HomePage1";

            var result = dataLayer.Setup(x => x.spSaveHomePage(homepages));
            // Act
            //var result = await unitUnderTest.SaveHomepage(
            //    homepages);
            var data = _assignHomePageRepository.SaveHomepage(homepages);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task FetchUserHomepage_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateAssignHomePageRepository();
            string userEmailId = "HomePage2"; //TODO;

            var result = dataLayer.Setup(x => x.spFetchUserDashboard(userEmailId));
            // Act
            //var result = await unitUnderTest.FetchUserHomepage(
            //    userEmailId);
            var data = _assignHomePageRepository.FetchUserHomepage(userEmailId);

            // Assert
            Assert.IsNotNull(result);
        }

        private static List<AssignHomePage> GetTestAssign()
        {
            var testAssign = new List<AssignHomePage>
            {
                new AssignHomePage()
                {
                    Description = "Page description",
                    Homepage = "Homepage1",
                    UserEmail = "xyz@abc.com",
                    UserFirstName = "Lawrence",
                    UserGroupId = 19,
                    UserId = 1
                }
            };

            return testAssign;
        }

    }
}
