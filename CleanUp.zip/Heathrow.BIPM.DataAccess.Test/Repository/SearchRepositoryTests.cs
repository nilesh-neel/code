using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class SearchRepositoryTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;
        private SearchRepository _searchRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();

            var spMock = SetupReturn(new spGetSearch_Result()
            {
                PBITableName = "test",
                PBIColumnName = "test",
                PBIOpearator = "test",
                MenuId = 4
            });

            var mockDbObj = new Mock<BaggageDbContext>("constructor");

            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.spGetSearch("10834948", "B")).Returns(() => spMock.Object);
            });

            RegisterResettableType<ISearch>(() => mock =>
            {
                mock.Setup(s => s.SearchData("10834948","B").Result);
            });

            Context = Container.Resolve<BaggageDbContext>();
            _searchRepository = Container.Resolve<SearchRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task SearchData_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateSearchRepository();
            string searchText = "10834948";
            string prefix = "B";

            var result = dataLayer.Setup(x => x.spGetSearch(searchText, prefix));
            // Act
            //var result = await unitUnderTest.SearchData(
            //    searchText,
            //    prefix);
            var data = _searchRepository.SearchData(searchText, prefix);

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
