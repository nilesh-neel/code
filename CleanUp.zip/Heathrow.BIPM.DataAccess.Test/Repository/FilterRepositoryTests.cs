using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class FilterRepositoryTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;
        private FilterRepository _filterRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            var fakeVWNotLoadedCategoryType = new VWNotLoadedCategoryType[]
            {
                new VWNotLoadedCategoryType() { CategoryDescription = "Desc", NotLoadedBagCategoryID = 1, NotLoadedBagCategoryIdentifier = "test"}
            };

            var fakeVWNotLoadedSubCategoryType = new VWNotLoadedSubCategoryType[]
            {
                new VWNotLoadedSubCategoryType() { NotLoadedBagSubCategoryID = 1, NotLoadedBagSubCategoryIdentifier ="apan",SubCategoryDescription = "desc"}
            };

            var spMock = SetupReturn(new spGetFilterDetails_Result()
            {
                FilterID = 2,
                FilterJSON = "2",
                MenuID = 19
            });
            var fakeVWBaggageSystem = new VWBaggageSystem[]
            {
                new VWBaggageSystem() { Name = "Test", BagSystemID = 2},
            };
            var mockDbObj = new Mock<BaggageDbContext>("constructor");
            FilterEntity filterData = new FilterEntity
            {
                FilterId = 1,
                MenuId = 10,
                UserId = "user1",
                FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:7512125605]}"
            };
            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.VWNotLoadedCategoryType).ReturnsDbSet(fakeVWNotLoadedCategoryType);
                dbMock.Setup(b => b.VWNotLoadedSubCategoryType).ReturnsDbSet(fakeVWNotLoadedSubCategoryType);
                dbMock.Setup(b => b.VWBaggageSystem).ReturnsDbSet(fakeVWBaggageSystem);
                dbMock.Setup(b => b.spGetFilterDetails(1,"test")).Returns(() => spMock.Object);
            });
            RegisterResettableType<IFilter>(() => mock =>
            {
                mock.Setup(s => s.FilterByMenuId(1, "1").Result);
                mock.Setup(s => s.FilterConfiguration().Result);
                mock.Setup(s => s.SaveFilter(filterData).Result);
            });

            Context = Container.Resolve<BaggageDbContext>();
            _filterRepository = Container.Resolve<FilterRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            //this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task SaveFilter_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateFilterRepository();
            FilterEntity filterData = new FilterEntity
            {
                FilterId = 1,
                MenuId = 10,
                UserId = "user1",
                FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:7512125605]}"
            };

            var result = dataLayer.Setup(x => x.spSaveFilterDetail(filterData.UserId, filterData.MenuId, filterData.FilterText,
                    filterData.FilterId));
            // Act
            //var result = await unitUnderTest.SaveFilter(
            //    filterData);
            var data = _filterRepository.SaveFilter(filterData);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task FilterByMenuId_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateFilterRepository();
            int menuId = 19;
            string userId = "1";

            var result = dataLayer.Setup(x => x.spGetFilterDetails(menuId, userId));
            // Act
            //var result = await unitUnderTest.FilterByMenuId(
            //    menuId,
            //    userId);
            var data = _filterRepository.FilterByMenuId(menuId, userId);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task FilterConfiguration_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateFilterRepository();

            var result = dataLayer.Setup(x => x.VWBaggageSystem);
            // Act
            //var result = await unitUnderTest.FilterConfiguration();
            var data = _filterRepository.FilterConfiguration();

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
