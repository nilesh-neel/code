using Heathrow.BIPM.Core.Entity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class PdfRepositoryTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;
        private IPdf _pdfRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            var fakePdfMapping = new PdfMapping[]
            {
                new PdfMapping() {CreatedBy = "test",
                CreatedDate = DateTime.Now,
                MenuId = 19,
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                PageNo = "4",
                PdfId = 1,
                PdfName = "sample.pdf"},
            };
            var mockDbObj = new Mock<BaggageDbContext>("constructor");

            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {
                dbMock.Setup(b => b.PdfMapping).ReturnsDbSet(fakePdfMapping);
            });

            RegisterResettableType<IPdf>(() => mock =>
            {
                mock.Setup(s => s.GetPdfMenu(2).Result).Returns(GetTestPdf());
            });

            _pdfRepository = Container.Resolve<PdfRepository>();

        }

        [TestCleanup]
        public void TestCleanup()
        {
            //this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task GetPdfMenu_StateUnderTest_ExpectedBehavior()
        {
            var menuDataLayer = new Mock<BaggageDbContext>();

            // Arrange
            //var unitUnderTest = this.CreatePdfRepository();
            int menuId = 19;

            var testPdf = GetTestPdf();
            var result = menuDataLayer.Setup(x => x.PdfMapping);
            // Act
            var data = _pdfRepository.GetPdfMenu(19);
            //var result = await unitUnderTest.GetPdfMenu(
            //    menuId);

            // Assert
            Assert.AreNotEqual(testPdf, result);
        }
        private static IEnumerable<PdfMappings> GetTestPdf()
        {
            var testPdf = new List<PdfMappings>
            {
                new PdfMappings()
                {
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    MenuId = 19,
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                    PageNo = "4",
                    PdfId = 1,
                    PdfName = "sample.pdf"
                }
            };

            return testPdf;
        }
    }
}
