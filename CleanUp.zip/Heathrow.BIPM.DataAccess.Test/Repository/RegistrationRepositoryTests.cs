using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.DataAccess.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity;

namespace Heathrow.BIPM.DataAccess.Test.Repository
{
    [TestClass]
    public class RegistrationRepositoryTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;
        private RegistrationRepository _registrationRepository;

        private Mock<BaggageDbContext> mockBaggageDbContext;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBaggageDbContext = this.mockRepository.Create<BaggageDbContext>();

            Registration registration = new Registration()
            {
                BagLocation = new List<Lookup>() { new Lookup { RowId = 1, LookupTypeName = "test", Selected = 1 } },
                FirstName = "Jhon",
                LastName = "David",
                Email = "jhon@xy.com",
                SelectedLocation = 1,
                AccessReason = "test",
                SelectedOperationalArea = 0,
                SelectedOrganisation = 1,
                BagOperationalArea = new List<Lookup>() { new Lookup { RowId = 1, LookupTypeName = "test", Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { RowId = 1, LookupTypeName = "test", Selected = 1 } }
            };

            var mockDbObj = new Mock<BaggageDbContext>("constructor");
            RegisterResettableType<BaggageDbContext>(() => dbMock =>
            {               
                dbMock.Setup(b => b.spRegistrationRequest(registration.FirstName,registration.LastName,
                    registration.SelectedLocation,registration.SelectedOperationalArea, registration.AccessReason,registration.SelectedOrganisation,registration.Email));
            });

            RegisterResettableType<IRegistration>(() => mock =>
            {
                mock.Setup(s => s.Save(registration).Result);
            });

            Context = Container.Resolve<BaggageDbContext>();
            _registrationRepository = Container.Resolve<RegistrationRepository>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task Save_StateUnderTest_ExpectedBehavior()
        {
            var dataLayer = new Mock<BaggageDbContext>();
            // Arrange
            //var unitUnderTest = this.CreateRegistrationRepository();
            Registration registration = new Registration()
            {
                BagLocation = new List<Lookup>() { new Lookup { RowId = 1, LookupTypeName = "test", Selected = 1 } },
                FirstName = "Jhon",
                LastName = "David",
                Email = "jhon@xy.com",
                SelectedLocation = 1,
                AccessReason = "test",
                SelectedOperationalArea = 0,
                SelectedOrganisation = 1,
                BagOperationalArea = new List<Lookup>() { new Lookup { RowId = 1, LookupTypeName = "test", Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { RowId = 1, LookupTypeName = "test", Selected = 1 } }
            };

            var result = dataLayer.Setup(x => x.spRegistrationRequest(
               registration.FirstName, registration.LastName, registration.SelectedLocation, registration.SelectedOperationalArea,
               registration.AccessReason, registration.SelectedOrganisation, registration.Email));
            // Act
            //var result = await unitUnderTest.Save(
            //    registration);
            var data = _registrationRepository.Save(registration);

            // Assert
            Assert.IsNotNull(result);
        }
               
    }
}
