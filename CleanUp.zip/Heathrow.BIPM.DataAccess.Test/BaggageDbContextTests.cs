using Heathrow.BIPM.DataAccess;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using Heathrow.BIPM.DataAccess.Test.Repository;
using Unity;
namespace Heathrow.BIPM.DataAccess.Test
{
    [TestClass]
    public class BaggageDbContextTests : BaseRepositoryTest
    {
        private MockRepository mockRepository;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private BaggageDbContext CreateBaggageDbContext()
        {
            return Container.Resolve<BaggageDbContext>();
        }

        [TestMethod]
        public void spSaveHomePage_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string xmlData = null;

            // Act
            var result = unitUnderTest.spSaveHomePage(
                xmlData);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchReportId_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string userId = null;

            // Act
            var result = unitUnderTest.spFetchReportId(
                userId);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchUserList_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();

            // Act
            var result = unitUnderTest.spFetchUserList();

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spRemoveBagtags_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_BagTag = null;
            string p_UpdatedUser = null;

            // Act
            var result = unitUnderTest.spRemoveBagtags(
                p_BagTag,
                p_UpdatedUser);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spSaveBagtags_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_BagTag = null;
            string p_UpdatedUser = null;

            // Act
            var result = unitUnderTest.spSaveBagtags(
                p_BagTag,
                p_UpdatedUser);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spGetFilterConfiguration_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            Nullable<int> p_MenuID = null;

            // Act
            var result = unitUnderTest.spGetFilterConfiguration(
                p_MenuID);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spGetFilterControls_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            Nullable<int> p_MenuID = null;

            // Act
            var result = unitUnderTest.spGetFilterControls(
                p_MenuID);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spGetFilterDetails_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            Nullable<int> p_MenuID = null;
            string p_UserID = null;

            // Act
            var result = unitUnderTest.spGetFilterDetails(
                p_MenuID,
                p_UserID);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchReportDetails_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserId = null;

            // Act
            var result = unitUnderTest.spFetchReportDetails(
                p_UserId);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spGetFavourites_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserId = null;

            // Act
            var result = unitUnderTest.spGetFavourites(
                p_UserId);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spSaveFavourites_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserId = null;
            Nullable<int> p_MenuId = null;

            // Act
            var result = unitUnderTest.spSaveFavourites(
                p_UserId,
                p_MenuId);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchUserExistingBagtags_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_updateduser = null;

            // Act
            var result = unitUnderTest.spFetchUserExistingBagtags(
                p_updateduser);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spSaveFilterDetail_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserID = null;
            Nullable<int> p_MenuID = null;
            string p_FilterText = null;
            Nullable<long> p_FilterID = null;

            // Act
            var result = unitUnderTest.spSaveFilterDetail(
                p_UserID,
                p_MenuID,
                p_FilterText,
                p_FilterID);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spTodaysAlert_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserID = null;

            // Act
            var result = unitUnderTest.spTodaysAlert(
                p_UserID);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spGetSearch_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_SearchText = null;
            string p_SearchPrefix = null;

            // Act
            var result = unitUnderTest.spGetSearch(
                p_SearchText,
                p_SearchPrefix);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spInsertUpdateAlerts_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string xmldata = null;

            // Act
            var result = unitUnderTest.spInsertUpdateAlerts(
                xmldata);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spUpdateOperationAreaLocation_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserId = null;
            Nullable<int> p_OperationalArea = null;
            Nullable<int> p_Location = null;

            // Act
            var result = unitUnderTest.spUpdateOperationAreaLocation(
                p_UserId,
                p_OperationalArea,
                p_Location);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spRegistrationRequest_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_FirstName = null;
            string p_LastName = null;
            Nullable<int> p_LocationID = null;
            Nullable<int> p_OperationalAreaID = null;
            string p_AccessReason = null;
            Nullable<int> p_OrganizationID = null;
            string p_Email = null;

            // Act
            var result = unitUnderTest.spRegistrationRequest(
                p_FirstName,
                p_LastName,
                p_LocationID,
                p_OperationalAreaID,
                p_AccessReason,
                p_OrganizationID,
                p_Email);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spDeleteNotes_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            Nullable<int> p_NotesId = null;
            string p_UserId = null;
            string p_NotesValue = null;
            string p_NotesType = null;

            // Act
            var result = unitUnderTest.spDeleteNotes(
                p_NotesId,
                p_UserId,
                p_NotesValue,
                p_NotesType);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchNotes_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_NotesValue = null;
            string p_NotesUBLValue = null;
            string p_NotesType = null;
            string p_UserId = null;

            // Act
            var result = unitUnderTest.spFetchNotes(
                p_NotesValue,
                p_NotesUBLValue,
                p_NotesType,
                p_UserId);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spSaveNotes_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            Nullable<long> p_NotesId = null;
            string p_Notesdesc = null;
            string p_NotesValue = null;
            Nullable<bool> p_Ispublic = null;
            string p_UserId = null;
            string p_UBLValue = null;
            string p_NotesType = null;

            // Act
            var result = unitUnderTest.spSaveNotes(
                p_NotesId,
                p_Notesdesc,
                p_NotesValue,
                p_Ispublic,
                p_UserId,
                p_UBLValue,
                p_NotesType);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchUserDashboard_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserId = null;

            // Act
            var result = unitUnderTest.spFetchUserDashboard(
                p_UserId);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spUpdateAlert_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserEmail = null;
            Nullable<int> p_ResponseID = null;
            Nullable<int> p_AlertID = null;
            Nullable<int> p_Email = null;
            Nullable<int> p_OnScreen = null;
            Nullable<int> p_Subscribe = null;
            Nullable<int> p_Snooze = null;

            // Act
            var result = unitUnderTest.spUpdateAlert(
                p_UserEmail,
                p_ResponseID,
                p_AlertID,
                p_Email,
                p_OnScreen,
                p_Subscribe,
                p_Snooze);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchConfiguredAlert_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserID = null;
            Nullable<int> p_AlertID = null;

            // Act
            var result = unitUnderTest.spFetchConfiguredAlert(
                p_UserID,
                p_AlertID);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spInsertUpdateNotifications_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string xmldata = null;

            // Act
            var result = unitUnderTest.spInsertUpdateNotifications(
                xmldata);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchUserDetails_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserId = null;

            // Act
            var result = unitUnderTest.spFetchUserDetails(
                p_UserId);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchUserGroups_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UpdatedUser = null;

            // Act
            var result = unitUnderTest.spFetchUserGroups(
                p_UpdatedUser);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchGroupRecipients_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            Nullable<int> organisationPartyID = null;

            // Act
            var result = unitUnderTest.spFetchGroupRecipients(
                organisationPartyID);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spAlertNotification_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserID = null;

            // Act
            var result = unitUnderTest.spAlertNotification(
                p_UserID);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchAlert_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserID = null;
            Nullable<int> p_AlertID = null;

            // Act
            var result = unitUnderTest.spFetchAlert(
                p_UserID,
                p_AlertID);

            // Assert
            Assert.Fail();
        }

        [TestMethod]
        public void spFetchNotifications_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var unitUnderTest = this.CreateBaggageDbContext();
            string p_UserID = null;
            Nullable<int> p_NotificationID = null;

            // Act
            var result = unitUnderTest.spFetchNotifications(
                p_UserID,
                p_NotificationID);

            // Assert
            Assert.Fail();
        }
    }
}
