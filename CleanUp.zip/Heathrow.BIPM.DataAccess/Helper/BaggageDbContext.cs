﻿//----------------------------------------------------------------------
//Class Name   : BaggageDbContext
//Purpose      : This is the default entity framework partial class use to initialize the connection string
//               and other entity framework task 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using Heathrow.BIPM.Utility.Common;
using Heathrow.BIPM.Utility.Constants;

namespace Heathrow.BIPM.DataAccess
{
    public partial class BaggageDbContext
    {
        private static string _sConnName;
        public static string ConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(_sConnName))
                {
                    _sConnName =
                        KestrelKeyVaultUtility.Get(
                            AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.KSDbContext)).Result;
                    return _sConnName;
                }
                return _sConnName;
            }
        }
        public BaggageDbContext()
            : base(ConnectionString)
        {
        }

    }
}
