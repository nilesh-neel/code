﻿/****************************************************************************************************************
Class Name   : INotes.cs 
Purpose      : This class implements the Core Interfacce for the Notes Module to the web application project.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Getting the logged-in userId globally from SignedInUserId  | 10/Dec/2018       | Requirement changed
Vignesh (686552)   | Notes Entitiy updated for Save                             | 10/Dec/2018       | New param added in Entity
Vignesh (686552)   | code cleanup and updated                                   | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                             | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.DataAccess.Interface
{
    public interface INotes
    {
        Task<IList<NotesEntity>> SaveNotes(NotesEntity note);
        Task<IList<NotesEntity>> FetchNotes(string notesValue, string notesType, string notesUblValue, string userId);
        Task<IList<NotesEntity>> DeleteNotes(int notesId, string notesValue, string notesType, string userId);
    }
}
