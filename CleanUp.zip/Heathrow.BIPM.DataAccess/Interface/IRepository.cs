﻿//----------------------------------------------------------------------
//Class Name   : GenericRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Interface
{
    public interface IRepository<TEntity> : IDisposable where TEntity : class
    {
        IEnumerable<TEntity> All();
        IEnumerable<TEntity> AllInclude(params Expression<Func<TEntity, object>>[] includeProperties);
        IEnumerable<TEntity> FindByInclude(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties);
        IEnumerable<TEntity> FindBy(Expression<Func<TEntity, bool>> predicate);
        void Insert(TEntity entity);
        void Update(TEntity entity);
        IEnumerable<TEntity> ExecuteQuery(string spQuery, params object[] parameters);
        TEntity ExecuteQuerySingle(string query, object[] parameters);

        /**************************Async Call Start***********************************/
        IQueryable<TEntity> GetAllIncluding(params Expression<Func<TEntity, object>>[] includeProperties);
        Task<IEnumerable<TEntity>> AllAsync();
        Task<ICollection<TEntity>> FindByAsyn(Expression<Func<TEntity, bool>> predicate);
        Task<TEntity> GetByIdAsync(object id);
        Task InsertAsync(TEntity entity);
        Task UpdateAsync(TEntity entity);
        Task DeleteAsync(TEntity entity);
        Task DeleteAllAsync(IList<TEntity> entity);
        IQueryable<TEntity> Table { get; }
        Task<IEnumerable<TEntity>> ExecuteQueryAsync(string spQuery);
        Task<IEnumerable<TEntity>> ExecuteQueryAsync(string spQuery, object[] parameters);
        Task<TEntity> ExecuteQuerySingleAsync(string spQuery);

        /*************************Async Call End***********************************/


    }
}
