﻿//----------------------------------------------------------------------
//Class Name   : GenericRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//Vignesh(686552)   | Fetching the user groups by logged-in user EmailId    | 05/Dec/2018       | Logic changed
//Vignesh(686552)   | Fetch Dashboard list in groups                        | 10/Dec/2018       | Logic changed
//Vignesh(686552)   | code cleanup and updated                              | 24/Dec/2018       | Code cleanup
//Vignesh(686552)   | CCAP issue fix                                        | 07/Jan/2019       | CCAP warnings
//----------------------------------------------------------------------


using System.Collections.Generic;
using Heathrow.BIPM.Core.Entity;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Interface
{
    public interface IAssignHomePage
    {

        Task<IList<AssignHomePage>> GetUserGroups(string userEmailId);
        Task<IList<AssignHomePage>> GetGroupRecipients(int userGroupId);
        Task<string> SaveHomepage(string homepages);

        Task<PowerBiReportDetails> FetchUserHomepage(string userEmailId);
    }
}
