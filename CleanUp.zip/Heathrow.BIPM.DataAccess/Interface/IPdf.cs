﻿//----------------------------------------------------------------------
//Class Name   : IPdf
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Vivekanandan
//Created Date : 04/Dec/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------


using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.DataAccess.Interface
{
    public interface IPdf
    {
        Task<IEnumerable<PdfMappings>> GetPdfMenu(int menuId);
    }
}
