﻿//----------------------------------------------------------------------
//Class Name   : IMapper.cs
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using System.Collections.Generic;

namespace Heathrow.BIPM.DataAccess.Interface
{
    public interface IMapper<T1, T2>
    {
        T2 MapTo(T1 input);
         T1 MapFrom(T2 input);
        IEnumerable<T2> MapTo(IEnumerable<T1> input);
        IEnumerable<T1> MapFrom(IEnumerable<T2> input);

    }
}
