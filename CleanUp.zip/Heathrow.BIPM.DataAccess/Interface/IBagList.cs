﻿/****************************************************************************************************************
Class Name   : IBagList.cs 
Purpose      : This class implements the Core Interfacce for the BagList Module to the web application project.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetch/Remove/Save bagtags using user's EmailId instead of userId   | 05/Dec/2018       | Logic changed
Vignesh (686552)   | BagList Entitiy as param for Post method                           | 10/Dec/2018       | Entity properties added
Vignesh (686552)   | code cleanup and updated                                           | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                                     | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Interface
{
    public interface IBagList
    {

        Task<string> SaveBagTags(string bagTags, string userEmailId);

        Task<string> GetUserExistingBagTags(string userEmailId);

        Task<string> RemoveBagTags(string bagTags, string userEmailId);
    }
}
