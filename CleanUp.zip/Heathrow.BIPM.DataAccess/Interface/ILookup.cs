﻿//----------------------------------------------------------------------
//Class Name   : ILookup.cs
//Purpose      : Interface consists of method declarations implemented in DAL
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using System.Collections.Generic;
using Heathrow.BIPM.Core.Entity;

namespace Heathrow.BIPM.DataAccess.Interface
{
    public interface ILookup
    {
        IEnumerable<Lookup> AllMeasure();

        IEnumerable<Lookup> AllTopic();

        IEnumerable<Lookup> AllLocation();

        IEnumerable<Lookup> AllThreshold();

        IEnumerable<Lookup> AllFrequency();

        IEnumerable<Lookup> AllTimeWindow();

        IEnumerable<Lookup> AllOrganisation();

        IEnumerable<Lookup> AllOperationalArea();
    }
}
