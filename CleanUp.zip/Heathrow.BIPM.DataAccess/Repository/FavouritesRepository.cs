﻿//----------------------------------------------------------------------
//Class Name   : GenericRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Nilesh              FDS Change                                   15/02/2019          Update for menu icon hover issue
//----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using System.Globalization;

namespace Heathrow.BIPM.DataAccess.Repository
{
    public class FavouritesRepository : GenericRepository<Favourites>, IFavourites
    {

        public FavouritesRepository(BaggageDbContext context) : base(context)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<List<Favourites>> GetUserFavourites(string userId)
        {
            try
            {
                var oFavMenu = await Task.Run(() => Context.spGetFavourites(userId)).ConfigureAwait(false);

                return oFavMenu?.Select(a => new Favourites
                {
                    FavouriteId = a.FavouriteId,
                    UserId = userId,
                    FavouriteLink = new Menu
                    {

                        MenuId = a.MenuId ?? 2,
                        Description = a.Description,
                        IsReport = Convert.ToBoolean(a.IsReport, CultureInfo.InvariantCulture),
                        OperationalReportId = a.ReportObjectId
                        // BusinessUrl = a.BusinessUrl
                    }
                }).ToList();


            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="favourites"></param>
        /// <returns></returns>
        public async Task<int> Save(Favourites favourites)
        {
            try
            {
                var oFavMenu = await Task.Run(() => Context.spSaveFavourites(favourites.UserId, favourites.FavouriteLink.MenuId).FirstOrDefault()).ConfigureAwait(false);
                return oFavMenu != null ? Convert.ToInt32(oFavMenu, CultureInfo.InvariantCulture) : 999;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
