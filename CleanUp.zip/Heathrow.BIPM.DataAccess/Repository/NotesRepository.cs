﻿//----------------------------------------------------------------------
//Class Name   : NotesRepository 
//Purpose      : This is Data Service js file use to connect with the server side api/controller call. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Vignesh AshokKumar
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//Vignesh(686552)   | Getting the logged-in userId globally from SignedInUserId  | 10/Dec/2018       | Requirement changed
//Vignesh(686552)   | Notes Entitiy properties updated                           | 10/Dec/2018       | New param added in Entity
//Vignesh(686552)   | code cleanup and updated                                   | 24/Dec/2018       | Code cleanup
//Vignesh(686552)   | CCAP issue fix                                             | 07/Jan/2019       | CCAP warnings
//----------------------------------------------------------------------

using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.Utility.Constants;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Repository
{
    /// <summary>
    /// 
    /// </summary>
    public class NotesRepository : GenericRepository<NotesEntity>, INotes
    {

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="context"></param>
        public NotesRepository(BaggageDbContext context) : base(context)
        {

        }

        /// <summary>
        ///  NotesRepository SaveNotes method to save the newly created note
        /// </summary>
        /// <param name="note">Notes Entity as input parameter</param>
        /// <returns></returns>
        public async Task<IList<NotesEntity>> SaveNotes(NotesEntity note)
        {
            try
            {
                var oSaveNotes = await Task.Run(() => Context.spSaveNotes(note.NotesId, note.NoteDescription, note.NotesValue,
                  Convert.ToBoolean(note.IsPublic), note.UserId, note.UblValue, note.NotesType).ToList()).ConfigureAwait(false);

                return oSaveNotes?.Select(a => new NotesEntity
                {
                    NotesId = Convert.ToInt32(a.NotesId, CultureInfo.InvariantCulture),
                    NoteDescription = a.NotesDesc,
                    IsPublic = Convert.ToInt16(a.IsPublic, CultureInfo.InvariantCulture),
                    UserFirstName = a.UserFirstName,
                    UserLastName = a.UserLastName,                    
                    CreatedDate = a.CreatedDatetime.ToString(MessageConstants.TimeFormat, DateTimeFormatInfo.InvariantInfo)
                }).ToList();
            }

            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///  NotesRepository FetchNotes method to fetch the existing notes
        /// </summary>
        /// <param name="notesValue">notes Value value as input parameter</param>
        /// <param name="notesType">notes Type value as input parameter</param>
        /// <param name="notesUblValue">notes UBL  value as input parameter</param>
        /// <param name="userId">Logged-in UserId value as input parameter</param>
        /// <returns>Notes as List</returns>
        public async Task<IList<NotesEntity>> FetchNotes(string notesValue, string notesType, string notesUblValue, string userId)
        {
            try
            {

                var notesList = await Task.Run(() => Context.spFetchNotes(notesValue, notesUblValue, notesType, userId).ToList()).ConfigureAwait(false);

                return notesList?.Select(a => new NotesEntity
                {
                    NotesId = a.NotesId,
                    NoteDescription = a.NotesDesc,
                    NotesValue = a.UniqueBagtagLogic,
                    OrganizationId = Convert.ToInt16(a.OrganizationId,CultureInfo.InvariantCulture),
                    IsPublic = Convert.ToInt16(a.IsPublic, CultureInfo.InvariantCulture),
                    UserFirstName = a.UserFirstName,
                    UserLastName = a.UserLastName,
                    CreatedDate = a.CreatedDatetime.ToString(MessageConstants.TimeFormat, DateTimeFormatInfo.InvariantInfo)
                }).ToList();
            }

            catch (Exception)
            {
                throw;
            }
        }


        /// <summary>
        /// NotesRepository DeleteNotes method to delete the respective note
        /// </summary>
        /// <param name="notesId">NotesId value as input parameter</param>
        /// <param name="notesValue">notes Value value as input parameter</param>
        /// <param name="userId">Logged-in UserId value as input parameter</param>
        /// <returns>Notes as List</returns>
        public async Task<IList<NotesEntity>> DeleteNotes(int notesId, string notesValue, string notesType, string userId)
        {
            try
            {
                var oDeleteNotes = await Task.Run(() => Context.spDeleteNotes(notesId, userId, notesValue, notesType).ToList()).ConfigureAwait(false);
                return oDeleteNotes?.Select(a => new NotesEntity
                {
                    NotesId = a.NotesId,
                    NoteDescription = a.NotesDesc,
                    IsPublic = Convert.ToInt16(a.IsPublic, CultureInfo.InvariantCulture),
                    UserFirstName = a.UserFirstName,
                    UserLastName = a.UserLastName,
                    CreatedDate = a.CreatedDatetime.ToString(MessageConstants.TimeFormat, DateTimeFormatInfo.InvariantInfo)

                }).ToList();
            }

            catch (Exception)
            {
                throw;
            }
        }

    }
}
