﻿//----------------------------------------------------------------------
//Class Name   : GenericRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Nilesh               FDS Change                                  08/02/2019         Update code for DB context DI
//----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.DataAccess.Repository
{
    public class GenericRepository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        internal BaggageDbContext Context;
        internal DbSet<TEntity> DbSet;
        private bool _disposed;


        public GenericRepository(BaggageDbContext context)
        {
            Context = context;
            Context.Configuration.ProxyCreationEnabled = false;
            DbSet = Context.Set<TEntity>();
        }

        public IEnumerable<TEntity> All()
        {
            return DbSet.AsNoTracking().ToList();
        }

        public IEnumerable<TEntity> AllInclude
        (params Expression<Func<TEntity, object>>[] includeProperties)
        {
            return GetAllIncluding(includeProperties).ToList();
        }

        public IEnumerable<TEntity> FindByInclude(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties)
        {
            var query = GetAllIncluding(includeProperties);
            IEnumerable<TEntity> results = query.Where(predicate).ToList();
            return results;
        }

        private IQueryable<TEntity> GetAllIncluding(params Expression<Func<TEntity, object>>[] includeProperties)
        {
            IQueryable<TEntity> queryable = DbSet.AsNoTracking();

            return includeProperties.Aggregate
              (queryable, (current, includeProperty) => current.Include(includeProperty));
        }
        public IEnumerable<TEntity> FindBy(Expression<Func<TEntity, bool>> predicate)
        {
            try
            {
                IEnumerable<TEntity> results = DbSet.AsNoTracking()
             .Where(predicate).ToList();
                return results;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public void Insert(TEntity entity)
        {
            try
            {
                DbSet.Add(entity);
                Context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }

        }

        public void Update(TEntity entity)
        {
            try
            {
                DbSet.Attach(entity);
                Context.Entry(entity).State = EntityState.Modified;
                Context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
        
        public IEnumerable<TEntity> ExecuteQuery(string spQuery, object[] parameters)
        {
            return Context.Database.SqlQuery<TEntity>(spQuery, parameters).ToList();
        }

        public TEntity ExecuteQuerySingle(string query, object[] parameters)
        {

            return Context.Database.SqlQuery<TEntity>(query, parameters).FirstOrDefault();

        }

        #region "Async Call"
        public virtual IQueryable<TEntity> Table => DbSet;

        public virtual async Task<TEntity> GetByIdAsync(object id)
        {
            return await DbSet.FindAsync(id).ConfigureAwait(false);
        }

        public async Task<IEnumerable<TEntity>> AllAsync()
        {
            return await DbSet.AsNoTracking().ToListAsync().ConfigureAwait(false);
        }

        public virtual async Task InsertAsync(TEntity entity)
        {
            try
            {
                if (entity != null)
                {
                    DbSet.Add(entity);
                    await Context.SaveChangesAsync().ConfigureAwait(false);
                }

            }
            catch (DbEntityValidationException dbEx)
            {
                var msg = string.Empty;

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        msg += FormattableString.Invariant($"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}") + Environment.NewLine;
                    }
                }

                var fail = new Exception(msg, dbEx);
                throw fail;
            }
        }

        public virtual async Task UpdateAsync(TEntity entity)
        {
            try
            {
                if (entity != null)
                {
                    await Context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            catch (DbEntityValidationException dbEx)
            {
                var msg = string.Empty;

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        msg += Environment.NewLine +
                              FormattableString.Invariant($"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}");
                    }
                }

                var fail = new Exception(msg, dbEx);
                throw fail;
            }
        }


        public virtual async Task DeleteAsync(TEntity entity)
        {
            try
            {
                if (entity != null)
                {
                    DbSet.Remove(entity);
                    await Context.SaveChangesAsync().ConfigureAwait(false);
                }
            }
            catch (DbEntityValidationException dbEx)
            {
                var msg = string.Empty;

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        msg += Environment.NewLine +
                               FormattableString.Invariant($"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}");
                    }
                }

                var fail = new Exception(msg, dbEx);
                throw fail;
            }
        }

        public virtual async Task DeleteAllAsync(IList<TEntity> entity)
        {
            try
            {
                foreach (var item in entity)
                {
                    DbSet.Remove(item);
                }
                await Context.SaveChangesAsync().ConfigureAwait(false);
            }
            catch (DbEntityValidationException dbEx)
            {
                var msg = string.Empty;

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        msg += Environment.NewLine +
                              FormattableString.Invariant($"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}");
                    }
                }

                var fail = new Exception(msg, dbEx);

                throw fail;
            }
        }
        IQueryable<TEntity> IRepository<TEntity>.GetAllIncluding(params Expression<Func<TEntity, object>>[] includeProperties)
        {
            IQueryable<TEntity> result = DbSet;
            foreach (var property in includeProperties)
            {
                result = result.Include(property);
            }
            return result;
        }

        public async Task<ICollection<TEntity>> FindByAsyn(Expression<Func<TEntity, bool>> predicate)
        {
            try
            {
                return await DbSet.Where(predicate).ToListAsync().ConfigureAwait(false);
            }
            catch (Exception)
            {

                throw;
            }

        }
        public async Task<IEnumerable<TEntity>> ExecuteQueryAsync(string spQuery)
        {

            return await Context.Database.SqlQuery<TEntity>(spQuery).ToListAsync().ConfigureAwait(false);
        }
        public async Task<TEntity> ExecuteQuerySingleAsync(string spQuery)
        {
            try
            {
                return await Context.Database.SqlQuery<TEntity>(spQuery).FirstOrDefaultAsync().ConfigureAwait(false);
            }
            catch (Exception)
            {
                throw;
            }

        }
        public async Task<IEnumerable<TEntity>> ExecuteQueryAsync(string spQuery, object[] parameters)
        {
            return await Context.Database.SqlQuery<TEntity>(spQuery, parameters).ToListAsync().ConfigureAwait(false);
        }
        #endregion "End Of Async Call"

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
            {
                return;
            }

            if (disposing)
            {
                var dbConnection = Context.Database.Connection;
                if (dbConnection != null && dbConnection.State == System.Data.ConnectionState.Open)
                {
                    dbConnection.Close();
                }
            }

            Context.Dispose();
            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        // <summary>
        /// Finalizer method
        /// </summary>
        ~GenericRepository()
        {
            Dispose(false);
        }


    }
}