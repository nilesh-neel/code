﻿//----------------------------------------------------------------------
//Class Name   : GenericRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Nilesh               FDS Change                                  08/02/2019         Update code for DB context DI
//----------------------------------------------------------------------


using System;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.Utility.Constants;

namespace Heathrow.BIPM.DataAccess.Repository
{
    public class RegistrationRepository : GenericRepository<Registration>, IRegistration
    {
        public RegistrationRepository(BaggageDbContext context) : base(context)
        {

        }

        private bool RegistrationCheck(Registration registration)
        {
            var nullCheck = registration.FirstName != null && registration.LastName != null && registration.SelectedLocation != 0;
            var selectionCheck = registration.SelectedOperationalArea != 0 && registration.SelectedOrganisation != 0 && registration.Email != null;
            if(nullCheck && selectionCheck)
            {
                return true;
            }
            else
            {
                return false;
            }            
        }

        private async Task<string> CheckSuccess(System.Data.Entity.Core.Objects.ObjectResult<string> success, Registration registration)
        {
            if (success != null)
            {
                if (success.ToString() == MessageConstants.AlreadyExist)
                {
                    return MessageConstants.AlreadyExistMsg;
                }
                else
                {
                    return string.Join(",", await Task.Run(() => (Context.spRegistrationRequest(
               registration.FirstName, registration.LastName, registration.SelectedLocation, registration.SelectedOperationalArea,
               registration.AccessReason, registration.SelectedOrganisation, registration.Email))).ConfigureAwait(false));
                }
            }
            else
            {
                return MessageConstants.SuperAdmin;
            }
        }

        public async Task<string> Save(Registration registration)
        {
            try
            {
                var checkReturn = RegistrationCheck(registration);

                if (checkReturn)
                {
                    var success = await Task.Run(() => (Context.spRegistrationRequest(
                    registration.FirstName, registration.LastName, registration.SelectedLocation, registration.SelectedOperationalArea,
                    registration.AccessReason, registration.SelectedOrganisation, registration.Email))).ConfigureAwait(false);

                    return await CheckSuccess(success,registration).ConfigureAwait(false);  
                }
                else
                {
                    return MessageConstants.Reenter;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }
    }
}


