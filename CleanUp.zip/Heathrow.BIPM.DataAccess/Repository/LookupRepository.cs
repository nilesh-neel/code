﻿//----------------------------------------------------------------------
//Class Name   : LookUpRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Vaishnavi.R(687417)| Functional Requirement                    | 01/03/2019        | Included view to load dropdown values
//Nilesh               FDS Change                                  08/02/2019         Update code for DB context DI
//----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.DataAccess.Repository
{
    public class LookupRepository : GenericRepository<Lookup>, ILookup
    {
        public LookupRepository(BaggageDbContext context) : base(context)
        {
         
        }

        /// <summary>
        /// To Load Measure Dropdown
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> AllMeasure()
        {
            try
            {
                var measure =Context.VWMeasure;

                return measure?.Select(measureItem => new Lookup
                {
                    RowId = measureItem.MeasureID,
                    LookupTypeName = measureItem.Identifier
                }).ToList();

            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// To Load Topic Dropdown
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> AllTopic()
        {
            try
            {
                var topic =Context.VWTopic;

                return topic?.Select(topicItem => new Lookup
                {
                    RowId = topicItem.MeasureCategoryID,
                    LookupTypeName = topicItem.Identifier
                }).ToList();

            }

            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// To Load Location Dropdown
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> AllLocation()
        {
            try
            {
                var location =Context.VWLocation;

                return location?.Select(locationItem => new Lookup
                {
                    RowId = locationItem.TerminalFacilityID,
                    LookupTypeName = locationItem.Description

                }).ToList();

            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// To Load Threshold Dropdown
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> AllThreshold()
        {
            try
            {
                var threshold =Context.VWThreshold;

                return threshold?.Select(thresholdItem => new Lookup
                {
                    RowId = thresholdItem.ThresholdTypeID,
                    LookupTypeName = thresholdItem.Identifier

                }).ToList();

            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// To Load Frequency Dropdown
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> AllFrequency()
        {
            try
            {
                var frequency =Context.VWFrequency;

                return frequency?.Select(frequencyItem => new Lookup
                {
                    RowId = frequencyItem.FrequencyID,
                    LookupTypeName = frequencyItem.Identifier

                }).ToList();

            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// To Load TimeWindow Dropdown
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> AllTimeWindow()
        {
            try
            {
                var timeWindow =Context.VWTimeWindow;

                return timeWindow?.Select(timeWindowItem => new Lookup
                {
                    RowId = timeWindowItem.TimeWindowID,
                    LookupTypeName = timeWindowItem.Identifier

                }).ToList();

            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// To Load Organization Dropdown
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> AllOrganisation()
        {
            try
            {
                var organisation =Context.VWOrganization;

                return organisation?.Select(organisationItem => new Lookup
                {
                    RowId = organisationItem.OrganizationPartyID,
                    LookupTypeName = organisationItem.OrganizationPartyName

                }).ToList();


            }
            catch (Exception)
            {
                throw;
            }
        }


        /// <summary>
        /// To Load Operational Area Dropdown
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Lookup> AllOperationalArea()
        {
            try
            {
                var operationalArea =Context.VWOperationalArea;

                return operationalArea?.Select(operationalAreaItem => new Lookup
                {
                    RowId = operationalAreaItem.OperationalActivityID,
                    LookupTypeName = operationalAreaItem.OperationalActivityIdentifier

                }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}



