﻿//----------------------------------------------------------------------
//Class Name   : SearchRepository 
//Purpose      :  Fetching Report data from the database and return data to business layer. 
//               
//Created By   : Kannan
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Kannan              FDS Change                                   15/02/2019        CodeShare Flight included
//----------------------------------------------------------------------

using System;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.DataAccess.Repository
{
    /// <summary>
    /// Search Repository 
    /// </summary>
    public class SearchRepository : GenericRepository<FilterSelection>, ISearch
    {
        private ReportConfiguration _searchData = null;
        /// <summary>
        /// Search constructor
        /// </summary>
        /// <param name="context"></param>
        public SearchRepository(BaggageDbContext context) : base(context)
        {
          
        }

        /// <summary>
        ///  Fetching data based on the search criteria.
        /// </summary>
        /// <param name="searchText"></param>
        /// <param name="prefix"></param>
        /// <returns></returns>
        public async Task<ReportConfiguration> SearchData(string searchText, string prefix)
        {
            var objSearch = await Task.Run(() => Context.spGetSearch(searchText, prefix)).ConfigureAwait(false);
            try
            {
                var result = objSearch?.FirstOrDefault();

                if (result != null)
                {
                    _searchData = new ReportConfiguration()
                    {
                        TableName = result.PBITableName,
                        ColumnName = result.PBIColumnName,
                        Operator = result.PBIOpearator,
                        MenuId  = result.MenuId
                    };
                }

                return _searchData;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
