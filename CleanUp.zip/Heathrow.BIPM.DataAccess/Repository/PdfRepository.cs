﻿//----------------------------------------------------------------------
//Class Name   : PdfRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Vivekanandan
//Created Date : 04/Dec/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Nilesh               FDS Change                                  08/02/2019         Update code for DB context DI
//----------------------------------------------------------------------


using Heathrow.BIPM.DataAccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Repository
{
    public class PdfRepository : GenericRepository<PdfMapping>, IPdf
    {
        public PdfRepository(BaggageDbContext context) : base(context)
        {
         
        }

        /// <summary>
        ///  get pdf details for menu id.
        /// </summary>
        /// <param name="menuId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Core.Entity.PdfMappings>> GetPdfMenu(int menuId)
        {
            try
            {
                var pdfs = await Task.Run(() => Context.PdfMapping.Where(a => a.MenuId == menuId)).ConfigureAwait(false);
                return pdfs?.Select(a => new Core.Entity.PdfMappings
                {
                    PdfId = a.PdfId,
                    PdfName = a.PdfName,
                    PageNo = a.PageNo,
                    MenuId = a.MenuId
                }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
