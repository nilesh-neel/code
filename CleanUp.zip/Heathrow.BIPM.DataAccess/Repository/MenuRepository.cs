﻿//----------------------------------------------------------------------
//Class Name   : GenericRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Nilesh               FDS Change                                  08/02/2019         Update code for DB context DI
//----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.DataAccess.Repository
{
    public class MenuRepository : GenericRepository<Menu>, IMenu
    {
        public MenuRepository(BaggageDbContext context) : base(context)
        {
        }

        /// <summary>
        ///  get all menu
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public IEnumerable<Menu> GetAllMenu()
        {
            try
            {
                return Context.VWMenu?.Select(m => new Menu
                {
                    MenuId = m.MenuId,
                    CssIcon = m.CssIcon,
                    Description = m.MenuDesc,
                    FavouritesDescription = m.Favourites,
                    OrderId = m.OrderId,
                    ParentId = m.ParentId,
                    Tooltip = m.Tooltip,
                    BreadCrumb = m.BreadCrumb,
                    IsVisible = m.IsVisible,
                    IsMultiLevel = m.IsMultiLevel


                }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///  get report details for logged in user
        /// </summary>
        /// <param name="strUserId"></param>
        /// <returns></returns>
        public IList<PowerBiReportDetails> GetReportDetails(string strUserId)
        {
            var result = Context.spFetchReportDetails(strUserId).ToList();

            return result?.Select(s => new PowerBiReportDetails
            {
                MenuId = s.MenuId,
                FilterType = s.FilterType,
                IsReport = s.IsReport,
                ReportId = s.ReportId,
                ReportSection = s.ReportSection,
                ReportType = Convert.ToInt32(!String.IsNullOrEmpty(s.ReportType) ? s.ReportType : "1", CultureInfo.InvariantCulture),
                WorkSpaceId = s.WorkSpaceId,
                PbiRoles = s.PbiRoles
            }).ToList();
        }
    }

}
