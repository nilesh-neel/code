﻿/****************************************************************************************************************
Class Name   : NotificationRepository 
Purpose      : This is used to retrieve notification record based on user id and/or notification id 
                
Created By   : Vaishnavi.R
Created Date : 18/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Vaishnavi.R(687417)| Optimization                              |02/27/2019         |Included javascript injection for text fields
Vaishnavi.R(687417)| FDS requirement                           |02/08/2019         |Comma separated values from view 
Vaishnavi.R(687417)| Code Optimization                         |01/29/2019         |Added separate method to bind notification(s) from result set
Vignesh (686552)   | Coding Convention                         |01/08/2019         | Updated constant text
**********************************************************************************************************************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using System.Xml.Linq;
using Microsoft.Security.Application;
using Heathrow.BIPM.Utility.Constants;

namespace Heathrow.BIPM.DataAccess.Repository
{
    public class NotificationRepository : GenericRepository<Notification>, INotification
    {
        public NotificationRepository(BaggageDbContext context) : base(context)
        {

        }


        /// <summary>
        /// This is used to return the list of notifications for the logged in user
        /// </summary>
        /// <param name="userid"></param>
        /// <returns>Notification List</returns>
        public async Task<IEnumerable<Notification>> GetUserNotification(string userid)
        {
            try
            {
                var notification = await Task.Run(() => Context.spFetchNotifications(userid, null)).ConfigureAwait(false);
                if (notification == null)
                {
                    throw new ArgumentException(MessageConstants.NullResult);
                }
            //    return notification?.Select(notificationItem => BindNotification(notificationItem).Result).ToList();

                return notification?.Select(notificationItem => BindNotification(notificationItem)).ToList();

            }
            catch (Exception)
            {
                throw;
            }
        }

        private int SelectionProperties(bool value)
        {
            if (value == true)
            {
                return 1;
            }
            else
            {
                return 0;
            }

        }

        /// <summary>
        /// This is used to insert or update a notification
        /// </summary>
        /// <param name="notification"></param>
        /// <returns></returns>
        public async Task<string> InsertUpdate(Notification notification)
        {
            var result = 0;
            try
            {
                if (notification != null)
                {
                    var createdDate = notification.NotificationId == 0 ? DateTime.Now : notification.CreatedDate;

                    if (notification.Description != null && notification.SelectedLocation != null)
                    {
                        var notificationXML = new XElement
                       (MessageConstants.Notifications,
                       new XElement(MessageConstants.NotificationId, notification.NotificationId),
                       new XElement(MessageConstants.NotificationDescription, Encoder.HtmlEncode(notification.Description)),
                       new XElement(MessageConstants.HelpUrl, Encoder.HtmlEncode(notification.AdditionalInformation)),
                       //Multiselectdropdown                    
                       from c in notification.SelectedLocation
                       select new XElement(MessageConstants.Locations,
                              new XElement(MessageConstants.LocationId, c)),

                       from c in notification.SelectedOperationalArea
                       select new XElement(MessageConstants.OperationalAreas,
                          new XElement(MessageConstants.OperationalAreaId, c)),
                       new XElement(MessageConstants.TopicId, notification.SelectedTopic),
                       new XElement(MessageConstants.OrganizationId, notification.SelectedOrganisation),
                       //Checkbox
                       new XElement(MessageConstants.Application, SelectionProperties(notification.IsOnScreen)),
                       new XElement(MessageConstants.Mobile, SelectionProperties(notification.IsMobile)),
                       new XElement(MessageConstants.Email, SelectionProperties(notification.IsEmail)),

                   

                       new XElement(MessageConstants.DisableNotification, (SelectionProperties(notification.DisableNotification) == 1) ? 0 : 1),
                       new XElement(MessageConstants.StartDate, notification.StartDate),
                       new XElement(MessageConstants.EndDate, notification.EndDate),
                       new XElement(MessageConstants.CreatedBy, notification.CreatedBy),
                       new XElement(MessageConstants.ModifiedBy, notification.ModifiedBy),
                       new XElement(MessageConstants.Created, createdDate)
                        );
                        result =  await Task.Run(() => Context.spInsertUpdateNotifications(notificationXML.ToString())).ConfigureAwait(false);
                    }
                }
                else
                {
                    throw new ArgumentException(MessageConstants.NullObject);
                }
                if (result == 0)
                {
                    return MessageConstants.SaveFail;
                }
                else
                {
                    return MessageConstants.SaveSuccess;
                }
            }
            catch (Exception)
            {
                return MessageConstants.SaveFail;
            }
        }

        /// <summary>
        /// This is used to return a selected notification based on id
        /// </summary>
        /// <param name="notificationid"></param>
        /// <returns>Notification List</returns>
        public async Task<Notification> GetNotificationByNotificationId(string userid, int notificationId)
        {
            try
            {
                if (notificationId == 0)
                {
                    throw new ArgumentException(MessageConstants.NullObject);
                }

                Notification notification = new Notification();
                var notificationResultSet = await Task.Run(() => Context.spFetchNotifications(userid, notificationId)).ConfigureAwait(false);
                var notificationItem = notificationResultSet.FirstOrDefault();
               // return await BindNotification(notificationItem).ConfigureAwait(false);
                return BindNotification(notificationItem);
            }
            catch (Exception)
            {
                throw;
            }

        }


        /// <summary>
        /// This is used to return the list of scrolling notification
        /// </summary>
        /// <param name="userid"></param>
        /// <returns>Notification List</returns>
        async Task<IEnumerable<Notification>> INotification.GetScrollingNotification(string userid)
        {
            try
            {
                if (userid == null)
                {
                    throw new ArgumentException(MessageConstants.NullObject);
                }
                Notification notification = new Notification();

                var result = await Task.Run(() => Context.VWTodaysNotification.Where(x => x.UserEmail == userid)
                             .Select(notificationItem => new Notification
                             {
                                 Description = notificationItem.NotificationDescription,
                                 AdditionalInformation=notificationItem.HelpURL
                             })
                             .ToList()).ConfigureAwait(false);

                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }




        /*  private async Task<Notification> BindNotification(spFetchNotification_Result notification)
          {
              try
              {
                  Notification notifications = new Notification
                  {
                      NotificationId = notification.NotificationID,
                      Description = notification.NotificationDescription,
                      SelectedTopic = notification.MeasureCategoryID,
                      ModifiedBy = notification.ModifiedBy,
                      CreatedBy = notification.CreatedBy,
                      HelpUrl = new Uri(notification.HelpURL),
                      StartDate = notification.NotificationStartDateTime ?? DateTime.Now,
                      EndDate = notification.NotificationEndDateTime ?? DateTime.Now,
                      ModifiedDate = (notification.ModifiedDateTime) ?? DateTime.Now,
                      DateAndTime = notification.NotificationCreatedDateTime,
                      CreatedDate = notification.NotificationCreatedDateTime,
                      SelectedOrganisation = notification.OrganisationPartyID ?? 1,
                      IsOnScreen = true,
                      IsEmail = (notification.EmailNotificationIndicator == 1) ? true : false,
                      IsMobile = false,
                      DisableNotification = (notification.ActiveIndicator == "0") ? true : false
                  };
                  var locations = await Task.Run(() => Context.VWNotificationLocation.Where(x => x.NotificationID == notifications.NotificationId).
                      Select(notificationItem => notificationItem.TerminalFacilityID).Cast<int>().ToList()).ConfigureAwait(false);
                  var operationalArea = await Task.Run(() => Context.VWNotificationOperationalArea.Where(x => x.NotificationID == notifications.NotificationId).
                      Select(notificationItem => notificationItem.OperationalActivityID).Cast<int>().ToList()).ConfigureAwait(false);
                  notifications.Locations = await Task.Run(() => string.Join(",", Context.VWLocation.Where(p => locations.Contains(p.TerminalFacilityID))
                                  .Select(p => p.Description.ToString()))).ConfigureAwait(false);
                  notifications.OperationalArea = await Task.Run(() => string.Join(",", Context.VWOperationalArea.
                      Where(p => operationalArea.Contains(p.OperationalActivityID)).Select(p => p.OperationalActivityIdentifier.ToString()))).ConfigureAwait(false);
                  notifications.Organisation = await Task.Run(() => (from a in Context.VWOrganization
                                                                     where a.OrganizationPartyID == notifications
                                    .SelectedOrganisation
                                                                     select a.OrganizationPartyName).SingleOrDefault()).ConfigureAwait(false);
                  notifications.Topic = await Task.Run(() => (from a in Context.VWTopic
                                                              where a.MeasureCategoryID == notifications.
                                    SelectedTopic
                                                              select a.Identifier).SingleOrDefault()).ConfigureAwait(false);
                  ((List<int>)notifications.SelectedOperationalArea).AddRange(operationalArea);
                  ((List<int>)notifications.SelectedLocation).AddRange(locations);
                  return notifications;
              }
              catch (Exception)
              {
                  throw;
              }

          }*/



/// <summary>
/// This is used to bind the notification
/// </summary>
/// <param name="notification"></param>
/// <returns>Notification List</returns>

private Notification BindNotification(spFetchNotifications_Result notification)
        {
            try
            {
                var selectedOperationalArea = Array.ConvertAll<string, int>(notification.OperationalActivityId.Split(','), Convert.ToInt32);
                var selectedLocation = Array.ConvertAll<string, int>(notification.TerminalId.Split(','), Convert.ToInt32);

                Notification notifications =  new Notification
                {
                    NotificationId = notification.NotificationID,
                    Description = notification.NotificationDescription,
                    SelectedTopic = notification.MeasureCategoryID,
                    Location = notification.TerminalDescription,
                    ModifiedBy = notification.ModifiedBy,
                    CreatedBy = notification.CreatedBy,
                    AdditionalInformation = notification.HelpURL?? "",
                    StartDate = notification.NotificationStartDateTime??DateTime.Now,
                    EndDate = notification.NotificationEndDateTime??DateTime.Now,
                    ModifiedDate = (notification.ModifiedDateTime) ?? DateTime.Now,
                    DateAndTime = notification.NotificationCreatedDateTime,
                    CreatedDate = notification.NotificationCreatedDateTime,
                    //SelectedLocation = notification.TerminalId.Split(',').Select(int.Parse).ToArray(),
                    //SelectedOperationalArea = notification.OperationalActivityId.Split(',').Select(int.Parse).ToArray(),
                    SelectedOrganisation = notification.OrganizationPartyID,
                    IsOnScreen = (notification.userOnScreen==1)?true:false,
                    IsEmail = (notification.userEmail == 1) ? true : false,
                    IsConfigureEmail= (notification.EmailNotificationIndicator == 1) ? true : false,
                    IsConfigureOnScreen= (notification.OnScreenNotificationIndicator == 1) ? true : false,
                    IsMobile = false,
                    Organisation = notification.OrganizationPartyName,
                    OperationalArea = notification.OperationalDescription,
                    Topic = notification.Topics,
                    DisableNotification = (notification.ActiveIndicator == "0") ? true : false
                };
                ((List<int>)notifications.SelectedOperationalArea).AddRange(selectedOperationalArea);
                ((List<int>)notifications.SelectedLocation).AddRange(selectedLocation);
                return  notifications;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }
    }
}
