﻿/****************************************************************************************************************
Class Name   : AlertsRepository 
Purpose      : This is used to retrieve alerts based on user id and/or alert id
Created By   : Vaishnavi.R
Created Date : 18/Sep/2018
Version      : 1.0
History      :       
Modified By          | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
Vaishanvi.R(687417)  | FDS requirement                           | 02/18/2019        | Included stored procedure to update alert user response
Anupama Kumari(694315)| FDS requirement                           | 02/14/2019        | Included 'GetTopicForMeasure' method
Vivekanandan(738022) | FDS requirement                           | 01/24/2019        | Included 'GetTodaysAlert' method with View
Nilesh More(405285)  | Code optimization                         | 01/17/2019        | Added separate method to bind alert(s) from result set
Vignesh(686552)      | Coding Convention                         | 01/08/2019        | Updated constant text
Vaishnavi.R(687417)  | FDS requirement                           | 01/07/2019        | Included method 'GetAlertNotification' for alert(bell) icon
Vivekanandan(738022) | FDS requirement                           | 01/03/2019        | Included stored procedure for Insertion and Updation of alerts
**********************************************************************************************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using System.Xml.Linq;
using Microsoft.Security.Application;
using Heathrow.BIPM.Utility.Constants;


namespace Heathrow.BIPM.DataAccess.Repository
{
    public class AlertsRepository : GenericRepository<Alerts>, IAlerts
    {

        public AlertsRepository(BaggageDbContext context) : base(context)
        {

        }

        private int SelectionProperties(bool value)
        {
            if (value == true)
            {
                return 1;
            }
            else
            {
                return 0;
            }

        }


        /// <summary>
        /// This is used to return a triggered alert based on userid
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<TodaysAlert>> GetAlertNotification(string userId)
        {
            try
            {
                if (userId == null)
                {
                    throw new ArgumentException(MessageConstants.NullObject);
                }
             
                TodaysAlert alert = new TodaysAlert();
                var alertResultSet = await Task.Run(() => Context.spAlertNotification(userId)).ConfigureAwait(false);
              
                return alertResultSet?.Select(alertItem => new TodaysAlert
                {
                    AlertId = alertItem.AlertID,
                    Message = alertItem.AlertMessage,
                    Time = alertItem.AlertCreatedDatetime.ToString(),
                    ResponseType = alertItem.ResponseTypeID,
                    Mandatory=alertItem.MandatoryIndicator
                    

            }).ToList();
            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// This is used to return a triggered alert count based on userid
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<int> GetAlertCount(string userId)
        {
            try
            {
                if (userId == null)
                {
                    throw new ArgumentException(MessageConstants.NullObject);
                }
                return await Task.Run(() => Context.VWTodaysAlert.Where(responseID => responseID.ResponseTypeID == null).Where(x => x.UserEmail == userId).Count()).ConfigureAwait(false);
            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// This is used to return a todays alert based on userid
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<TodaysAlert>> GetTodaysAlert(string userId)
        {
            try
            {
                if (userId == null)
                {
                    throw new ArgumentException(MessageConstants.NullObject);
                }
                TodaysAlert alert = new TodaysAlert();

                var result = await Task.Run(() => Context.VWTodaysAlert.Where(x => x.UserEmail == userId)
                             .Select(alertItem => new TodaysAlert
                             {
                                 AlertId = alertItem.AlertID,
                                 Message = alertItem.AlertMessage,
                                 CreatedDate = alertItem.AlertCreatedDatetime ?? DateTime.Now,
                                 ResponseType = alertItem.ResponseTypeID,
                                 Title = alertItem.AlertTitle,
                                 Mandatory = alertItem.MandatoryIndicator,
                                 TodaysLocation = Context.VWLocation.Where(terminalId => terminalId.TerminalFacilityID == alertItem.TodaysLocation)
                                 .Select(location => location.Description).FirstOrDefault(),
                                 Topic = alertItem.Topic,
                                 EventId = alertItem.AlertEventId ?? 0
                             })
                             .OrderByDescending(x => x.CreatedDate).ToList()).ConfigureAwait(false);

                return result;
            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// This is used to return the list of alerts for the logged in user
        /// </summary>
        /// <param name="userid"></param>
        /// <returns>Alert List</returns>
        public async Task<IEnumerable<MyAlertSettings>> GetMyAlertSettings(string emailId)
        {
            try
            {
                var alerts = await Task.Run(() => Context.spFetchAlert(emailId, null)).ConfigureAwait(false);
                if (alerts == null)
                {
                    throw new ArgumentException(MessageConstants.NullResult);
                }
                return alerts?.Select(alertItem => BindMyAlertSettings(alertItem)).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This is used to return a selected alert based on id
        /// </summary>
        /// <param name="alertId"></param>
        /// <returns></returns>
        public async Task<MyAlertSettings> GetAlertsById(string userId, int alertId)
        {
            try
            {
                if (alertId == 0)
                {
                    throw new ArgumentException(MessageConstants.NullObject);
                }

                var alertResultSet = await Task.Run(() => Context.spFetchAlert(userId, alertId)).ConfigureAwait(false);
                var alertItem = alertResultSet.FirstOrDefault();
                return BindMyAlertSettings(alertItem);
            }
            catch (Exception)
            {
                throw;
            }

        }
        private MyAlertSettings BindMyAlertSettings(spFetchAlert_Result alertItem)
        {
            try
            {
                MyAlertSettings alerts = new MyAlertSettings
                {
                    AlertId = alertItem.AlertConfigurationID ?? 1,
                    Location = alertItem.TerminalDescription,
                    Description = alertItem.AlertDescription,
                    Measure = alertItem.MeasureDescription,
                    Threshold = alertItem.ThresholdDescription,
                    ThresholdValue = alertItem.ThresholdValue,
                    MandatoryOptional = alertItem.MandatoryIndicator,
                    Title = alertItem.AlertTitle,
                    Topic = alertItem.MeasureCategoryDescription,
                    IsSubscribe = (alertItem.SubscriptionIndicator == 1) ? true : false,
                    IsOnScreen = (alertItem.AlertOnScreenDisplayIndicator == 1) ? true : false,
                    IsEmail = (alertItem.AlertEmailDisplayIndicator == 1) ? true : false,
                    IsSnooze = (alertItem.AlertBlankedIndicator == 1) ? true : false,
                    IsConfigureEmail=(alertItem.ConfigureEmail==1)?true:false,
                    IsMobile = false
                };

                return alerts;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }
        /// <summary>
        /// This is used to return topic or measure based on selected id
        /// </summary>
        /// <param name="selectedId"></param>
        /// <returns>Topic or Measure</returns>
        public async Task<Alerts> GetTopicForMeasure(string selectedId)
        {
            try
            {
                Alerts alertItem = new Alerts();
                List<Lookup> lookUpObject = new List<Lookup>();
                if (selectedId == null)
                {
                    throw new ArgumentException(MessageConstants.NullObject);
                }
                else
                {
                    var changeRequestOrigin = selectedId.Split('_')[1];
                    var id = Convert.ToInt32(selectedId.Split('_')[0]);
                    if (changeRequestOrigin == "MeasureChange")
                    {
                        var TopicId = await Task.Run(() => (from a in Context.VWMeasure where a.MeasureID == id select a.MeasureCategoryID).SingleOrDefault()).ConfigureAwait(false);

                        if (TopicId != default(int))
                        {
                            var lookUp = new Lookup
                            {
                                RowId = (int)TopicId,
                                LookupTypeName = await Task.Run(() => (from a in Context.VWTopic where a.MeasureCategoryID == TopicId select a.Identifier).SingleOrDefault()).ConfigureAwait(false)
                            };
                            lookUpObject.Add(lookUp);
                            alertItem.BagTopic = lookUpObject;
                        }
                    }
                    else
                    {
                        var MeasureId = await Task.Run(() => Context.VWMeasure.Where(a => a.MeasureCategoryID == id).Select(measure => measure.MeasureID).Cast<int>().ToList()).ConfigureAwait(false);

                        foreach (int value in MeasureId)
                        {
                            var lookUp = new Lookup
                            {
                                RowId = value,
                                LookupTypeName = await Task.Run(() => (from a in Context.VWMeasure where a.MeasureID == value select a.Identifier).SingleOrDefault()).ConfigureAwait(false)
                            };
                            lookUpObject.Add(lookUp);
                        }
                        alertItem.BagMeasure = lookUpObject;
                    }
                    return alertItem;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }


        /// <summary>
        /// This is used to return the list configured alert
        /// </summary>
        /// <param name="userid"></param>
        /// <returns>Alert List</returns>
        public async Task<IEnumerable<ConfigureAlerts>> GetConfiguredAlert(string emailId)
        {
            try
            {
                if (emailId == null)
                {
                    throw new ArgumentException(MessageConstants.NullResult);
                }
                var alerts = await Task.Run(() => Context.spFetchConfiguredAlert(emailId, null)).ConfigureAwait(false);
                return alerts?.Select(alertItem => BindConfigureAlerts(alertItem)).ToList();
            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// This is used to return a selected alert based on id
        /// </summary>
        /// <param name="alertId"></param>
        /// <param name="userid"></param>
        /// <returns>Notification List</returns>
        public async Task<Alerts> GetConfiguredAlertById(string userId, int alertId)
        {
            try
            {
                if (alertId == 0)
                {
                    throw new ArgumentException(MessageConstants.NullObject);
                }
                Alerts alert = new Alerts();
                var alertResultSet = await Task.Run(() => Context.spFetchConfiguredAlert(userId, alertId)).ConfigureAwait(false);
                var alertItem = alertResultSet.FirstOrDefault();
                alertItem.AlertConfigurationID = alertId;
                return BindConfigureAlertsByID(alertItem);
            }
            catch (Exception)
            {
                throw;
            }

        }
        private ConfigureAlerts BindConfigureAlerts(spFetchConfiguredAlert_Result alertItem)
        {
            try
            {
                ConfigureAlerts alerts = new ConfigureAlerts
                {
                    AlertId = alertItem.AlertConfigurationID,
                    Location = alertItem.TerminalDescription,
                    Description = alertItem.AlertDescription,
                    Measure = alertItem.MeasureDescription,
                    Threshold = alertItem.ThresholdDescription,
                    ThresholdValue = alertItem.ThresholdValue,
                    Frequency = alertItem.AlertFrequencyDescription,
                    TimeWindow = alertItem.TimeWindowID ?? 1,
                    MandatoryOptional = alertItem.MandatoryIndicator,
                    Title = alertItem.AlertTitle,
                    Topic = alertItem.MeasureCategoryDescription,
                    CreatedDate = alertItem.AlertCreatedDatetime,
                    CreatedBy = alertItem.AlertCreatedBy,
                    StartDate = alertItem.AlertStartDatetime,
                    EndDate = alertItem.AlertEndDatetime,
                    ModifiedBy = alertItem.AlertModifiedBy,
                    ModifiedDate = alertItem.AlertModifiedDatetime,
                    Organization = alertItem.OrganizationPartyName,
                    OperationalArea = alertItem.OperationalDescription,
                    DisableAlert=(alertItem.AlertActiveIndicator==1)?false:true,                  
                    IsOnScreen = (alertItem.AlertOnScreenDisplayIndicator==1)?true:false,
                    IsEmail = (alertItem.AlertEmailDisplayIndicator==1)?true:false,
                    IsMobile = (alertItem.AlertMobileDisplayIndicator==1)?true:false
                };

                return alerts;
            }
            catch (Exception e)
            {
                throw;
            }

        }
        private Alerts BindConfigureAlertsByID(spFetchConfiguredAlert_Result alertItem)
        {
            try
            {
                var selectedOperationalArea = Array.ConvertAll<string, int>(alertItem.OperationalActivityId.Split(','), Convert.ToInt32);
                var selectedLocation = Array.ConvertAll<string, int>(alertItem.TerminalId.Split(','), Convert.ToInt32);

                Alerts alerts = new Alerts
                {
                    AlertId = alertItem.AlertConfigurationID,
                   
                    Description = alertItem.AlertDescription,
                 
                   
                    ThresholdValue = alertItem.ThresholdValue,
                  
                    TimeWindow = alertItem.TimeWindowID ?? 1,
                    MandatoryOptional = alertItem.MandatoryIndicator,
                    Title = alertItem.AlertTitle,
                   
                    CreatedDate = alertItem.AlertCreatedDatetime,
                    CreatedBy = alertItem.AlertCreatedBy,
                    StartDate = alertItem.AlertStartDatetime,
                    EndDate = alertItem.AlertEndDatetime,
                    ModifiedBy = alertItem.AlertModifiedBy,
                    ModifiedDate = alertItem.AlertModifiedDatetime,
                   
                    DisableAlert = (alertItem.AlertActiveIndicator == 1) ? false : true,
                    SelectedMeasure = alertItem.MeasureID,
                    SelectedOrganisation = alertItem.OrganizationPartyID ?? 1,
                    SelectedThreshold = alertItem.ThresholdTypeID ?? 1,
                    SelectedTopic = alertItem.MeasureCategoryID ?? 1,
                    SelectedFrequency = alertItem.FrequencyID ?? 1,
                    SelectedTimeWindow = alertItem.TimeWindowID ?? 1,
                    IsOnScreen = (alertItem.AlertOnScreenDisplayIndicator == 1) ? true : false,
                    IsEmail = (alertItem.AlertEmailDisplayIndicator == 1) ? true : false,
                    IsMobile = (alertItem.AlertMobileDisplayIndicator == 1) ? true : false
                };
                ((List<int>)alerts.SelectedOperationalArea).AddRange(selectedOperationalArea);
                ((List<int>)alerts.SelectedLocation).AddRange(selectedLocation);
                return alerts;
            }
            catch (Exception e)
            {
                throw;
            }

        }


        /// <summary>
        /// This is used to insert or update an alert
        /// </summary>
        /// <param name="alert"></param>
        /// <returns>Alert List</returns>
        public async Task<string> InsertUpdate(Alerts alert)
        {
            var result = 0;
            try
            {
                if (alert != null)
                {
                    var insertCondition = alert.Title.Contains(MessageConstants.Response) || alert.Measure == MessageConstants.EditAlertForm;
                    var nullCheck = alert.Description != null && alert.Title != null;
                    var selectionCheck = alert.SelectedLocation != null && alert.SelectedThreshold != 0;


                    if (insertCondition && alert.AlertId != 0)
                    {
                        var objAlert = await Task.Run(() => Context.spUpdateAlert(alert.ModifiedBy, alert.ResponseType,
                            alert.AlertId, SelectionProperties(alert.IsEmail), (alert.IsSubscribe) ? 1 : 0,
                            (alert.MandatoryOptional==1)?1:SelectionProperties(alert.IsSubscribe), SelectionProperties(alert.IsSnooze))).ConfigureAwait(false);
                        var response = (objAlert == 1) ? MessageConstants.SaveSuccess : MessageConstants.SaveFail;
                        return response;
                    }

                    if (nullCheck && selectionCheck)
                    {
                        //insert new alert
                        var xEle = new XElement(MessageConstants.Alerts,
                        new XElement(MessageConstants.AlertId, alert.AlertId),
                        new XElement(MessageConstants.Title, Encoder.HtmlEncode(alert.Title.Trim())),
                        new XElement(MessageConstants.AlertDescription, Encoder.HtmlEncode(alert.Description.Trim())),
                        //Multiselectdropdown                                 
                        new XElement(MessageConstants.Locations,
                        from c in alert.SelectedLocation
                        select new XElement(MessageConstants.LocationId, c)
                        ),
                          new XElement(MessageConstants.OperationalAreas,
                        from c in alert.SelectedOperationalArea
                        select new XElement(MessageConstants.OperationalAreaId, c)
                        ),

                        //DropDown
                        new XElement(MessageConstants.TopicId, alert.SelectedTopic),
                        new XElement(MessageConstants.OrganizationId, alert.SelectedOrganisation),
                        new XElement(MessageConstants.ThresholdId, alert.SelectedThreshold),
                        new XElement(MessageConstants.MeasureId, alert.SelectedMeasure),
                        new XElement(MessageConstants.FrequencyId, alert.SelectedFrequency),
                        new XElement(MessageConstants.TimeWindowId, alert.SelectedTimeWindow),

                        new XElement(MessageConstants.ThresholdValue, Encoder.HtmlEncode(alert.ThresholdValue.Trim())),
                        new XElement(MessageConstants.Mandatory, alert.MandatoryOptional),

                        //Checkbox
                        new XElement(MessageConstants.Subscribe, (alert.MandatoryOptional==0)?0:1),
                        new XElement(MessageConstants.Mobile, SelectionProperties(alert.IsMobile)),
                        new XElement(MessageConstants.Onscreen, (alert.MandatoryOptional == 0) ? 0 : 1),
                        new XElement(MessageConstants.DisableAlert, (SelectionProperties(alert.DisableAlert) == 1) ? 0 : 1),
                        new XElement(MessageConstants.CreatedBy, alert.CreatedBy),
                        new XElement(MessageConstants.ModifiedBy, alert.ModifiedBy),
                        new XElement(MessageConstants.Email, SelectionProperties(alert.IsEmail)),
                        new XElement(MessageConstants.StartDate, alert.StartDate),
                        new XElement(MessageConstants.EndDate, alert.EndDate)

                    );
                        result = await Task.Run(() => Context.spInsertUpdateAlerts(xEle.ToString())).ConfigureAwait(false);

                    }
                    if (result == 0)
                    {
                        return MessageConstants.SaveFail;
                    }
                    else
                    {
                        return MessageConstants.SaveSuccess;
                    }
                }
                else
                {
                    throw new ArgumentException(MessageConstants.NullObject);
                }
            }
            catch (Exception)
            {
                return MessageConstants.SaveFail;
            }
        }

        /*   private Alerts BindAlerts(spFetchAlert_Result alertItem)
      {
          try
          {
              Alerts alerts = new Alerts
              {
                  AlertId = (int)nullableValuecheck(alertItem.AlertConfigurationID),
                  Description = alertItem.AlertDescription,
                  ThresholdValue = alertItem.ThresholdValue,
                  DisableAlert = (alertItem.ActiveIndicator == "1") ? true : false,
                  MandatoryOptional = alertItem.MandatoryIndicator,
                  Title = alertItem.AlertTitle,
                  Time = alertItem.AlertCreatedDatetime.ToString(),
                  CreatedBy = alertItem.AlertCreatedBy,
                  CreatedDate = (alertItem.AlertCreatedDatetime) ?? DateTime.Now,
                  StartDate = alertItem.AlertStartDatetime,
                  EndDate = alertItem.AlertEndDatetime,
                  ModifiedBy = alertItem.AlertModifiedBy,
                  ModifiedDate = alertItem.AlertModifiedDatetime,
                  SelectedMeasure = alertItem.MeasureID,
                  SelectedOrganisation = (int)nullableValuecheck(alertItem.OrganizationPartyID),
                  SelectedThreshold = (int)nullableValuecheck(alertItem.ThresholdTypeID),
                  SelectedTopic = (int)nullableValuecheck(alertItem.MeasureCategoryID),
                  SelectedFrequency = (int)nullableValuecheck(alertItem.FrequencyID),
                  SelectedTimeWindow = (int)nullableValuecheck(alertItem.TimeWindowID),
                  IsSubscribe = (alertItem.SubscriptionIndicator == 1) ? true : false,
                  IsOnScreen = (alertItem.AlertOnScreenDisplayIndicator == 1) ? true : false,
                  IsEmail = (alertItem.AlertEmailDisplayIndicator == 1) ? true : false,
                  IsMobile = false,
                  ResponseType = alertItem.ResponseTypeID,
              };
              alerts.Frequency = (from a in Context.VWFrequency where a.FrequencyID == alerts.SelectedFrequency select a.Identifier).SingleOrDefault();
              alerts.Threshold = (from a in Context.VWThreshold where a.ThresholdTypeID == alerts.SelectedThreshold select a.Identifier).SingleOrDefault();
              alerts.Measure = (from a in Context.VWMeasure where a.MeasureID == alerts.SelectedMeasure select a.Identifier).SingleOrDefault();
              alerts.TimeWindow = (from a in Context.VWTimeWindow where a.TimeWindowID == alerts.SelectedTimeWindow select a.TimeWindowID).SingleOrDefault();
              alerts.SelectedTopic = (from a in Context.VWMeasure where a.MeasureID == alerts.SelectedMeasure select a.MeasureCategoryID ?? 1).SingleOrDefault();
              alerts.Topic = (from a in Context.VWTopic where a.MeasureCategoryID == alerts.SelectedTopic select a.Identifier).SingleOrDefault();
              var locations = Context.VWAlertLocation.Where(alertId => alertId.AlertID == alerts.AlertId).Select(alertLocation => alertLocation.TerminalFacilityID).Cast<int>().ToList();
              alerts.Location = string.Join(",", Context.VWLocation.Where(p => locations.Contains(p.TerminalFacilityID))
                                .Select(p => p.Description.ToString()));
              ((List<int>)alerts.SelectedLocation).AddRange(locations);

              return alerts;
          }
          catch (Exception)
          {
              throw;
          }

      }
      */

        /*   private Alerts BindConfigureAlerts(spFetchConfiguredAlerts_Result alertItem)
   {
       try
       {

           Alerts alerts = new Alerts
           {
               AlertId = alertItem.AlertConfigurationID,
               Description = alertItem.AlertDescription,
               ThresholdValue = alertItem.ThresholdValue,
               MandatoryOptional = alertItem.MandatoryIndicator,
               Title = alertItem.AlertTitle,
               CreatedDate = alertItem.AlertCreatedDatetime,
               CreatedBy = alertItem.AlertCreatedBy,
               StartDate = alertItem.AlertStartDatetime,
               EndDate = alertItem.AlertEndDatetime,
               ModifiedBy = alertItem.AlertModifiedBy,
               ModifiedDate = alertItem.AlertModifiedDatetime,
               SelectedMeasure = alertItem.MeasureID,
               SelectedOrganisation = alertItem.OrganisationPartyID ?? 1,
               SelectedThreshold = alertItem.ThresholdTypeID,
               SelectedFrequency = alertItem.AlertFrequencyID,
               SelectedTimeWindow = alertItem.TimeWindowID ?? 1,
               DisableAlert = (alertItem.DisableAlert == 0) ? true : false,
               IsOnScreen = (alertItem.AlertOnScreenDisplayIndicator == 1) ? true : false,
               IsEmail = (alertItem.AlertEmailDisplayIndicator == 1) ? true : false,
               IsMobile = false
           };
           alerts.Organization = (from a in Context.VWOrganization where a.OrganizationPartyID == alerts.SelectedOrganisation select a.OrganizationPartyName).SingleOrDefault();
           alerts.Frequency = (from a in Context.VWFrequency where a.FrequencyID == alerts.SelectedFrequency select a.Identifier).SingleOrDefault();
           alerts.Threshold = (from a in Context.VWThreshold where a.ThresholdTypeID == alerts.SelectedThreshold select a.Identifier).SingleOrDefault();
           alerts.Measure = (from a in Context.VWMeasure where a.MeasureID == alerts.SelectedMeasure select a.Identifier).SingleOrDefault();
           alerts.SelectedTopic = (from a in Context.VWMeasure where a.MeasureID == alerts.SelectedMeasure select a.MeasureCategoryID ?? 1).SingleOrDefault();
           alerts.TimeWindow = (from a in Context.VWTimeWindow where a.TimeWindowID == alerts.SelectedTimeWindow select a.TimeWindowID).SingleOrDefault();
           alerts.SelectedTopic = (from a in Context.VWMeasure where a.MeasureID == alerts.SelectedMeasure select a.MeasureCategoryID ?? 1).SingleOrDefault();
           alerts.Topic = (from a in Context.VWTopic where a.MeasureCategoryID == alerts.SelectedTopic select a.Identifier).SingleOrDefault();
           var locations = Context.VWAlertLocation.Where(alertId => alertId.AlertID == alerts.AlertId).
               Select(alertLocation => alertLocation.TerminalFacilityID).Cast<int>().ToList();
           var operationalArea = Context.VWAlertOperationalArea.Where(alertId => alertId.AlertID == alerts.AlertId).
               Select(alertOperational => alertOperational.OperationalActivityID).Cast<int>().ToList();
           alerts.OperationalArea = string.Join(",", Context.VWOperationalArea.Where(p => operationalArea.Contains(p.OperationalActivityID))
                                          .Select(p => p.OperationalActivityIdentifier.ToString()));
           alerts.Location = string.Join(",", Context.VWLocation.Where(p => locations.Contains(p.TerminalFacilityID))
                          .Select(p => p.Description.ToString()));
           ((List<int>)alerts.SelectedOperationalArea).AddRange(operationalArea);
           ((List<int>)alerts.SelectedLocation).AddRange(locations);

           return alerts;
       }
       catch (Exception)
       {
           throw;
       }

   }*/

    }
}