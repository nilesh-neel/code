﻿//----------------------------------------------------------------------
//Class Name   : GenericRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Vignesh
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No     | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No>    |  dd/MMM/yyyy      | <Reason For Modifications>
//Vignesh(686552)   | Fetching the user groups by logged-in EmailId  | 05/Dec/2018       | Logic changed
//Vignesh(686552)   | Fetch Dashboard list in groups                 | 10/Dec/2018       | Logic changed
//Vignesh(686552)   | code cleanup and updated                       | 24/Dec/2018       | Code cleanup
//Vignesh(686552)   | CCAP issue fix                                 | 07/Jan/2019       | CCAP warnings
//----------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Heathrow.BIPM.Utility.Constants;

namespace Heathrow.BIPM.DataAccess.Repository
{
    public class AssignHomePageRepository : GenericRepository<AssignHomePage>, IAssignHomePage
    {
        public AssignHomePageRepository(BaggageDbContext context) : base(context)
        {

        }

        public async Task<IList<AssignHomePage>> GetUserGroups(string userEmailId)
        {
            try
            {
                var oFetchUserGrp = await Task.Run(() => Context.spFetchUserGroups(userEmailId).ToList()).ConfigureAwait(false);
                if (oFetchUserGrp.Count > 0)
                {
                    return oFetchUserGrp?.Select(a => new AssignHomePage
                    {
                        UserGroupId = a.OrganisationPartyID,
                        Description = a.OrganisationGroupName
                    }).ToList();
                }
                else
                {
                    return null;
                }

            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<IList<AssignHomePage>> GetGroupRecipients(int userGroupId)
        {
            try
            {
                var oFetchRecipients = await Task.Run(() => Context.spFetchGroupRecipients(userGroupId).ToList()).ConfigureAwait(false);
                if (oFetchRecipients.Count > 0)
                {
                    return oFetchRecipients?.Select(a => new AssignHomePage
                    {
                        UserEmail = a.UserEmail,
                        UserFirstName = a.UserFirstName,
                        Homepage = a.HomePageName,
                        UserGroupId=a.OrganisationPartyID
                    }).ToList();
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<string> SaveHomepage(string homepages)
        {
            try
            {
                var oSaveHomePage = await Task.Run(() => Context.spSaveHomePage(homepages).ToString(CultureInfo.InvariantCulture)).ConfigureAwait(false);
                return MessageConstants.Success;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<PowerBiReportDetails> FetchUserHomepage(string userEmailId)
        {
            try
            {
                var oUserDashboard = await Task.Run(() => Context.spFetchUserDashboard(userEmailId).FirstOrDefault()).ConfigureAwait(false);

                if (oUserDashboard != null)
                {

                    return new PowerBiReportDetails()
                    {
                        ReportId = oUserDashboard.ReportId,
                        WorkSpaceId = oUserDashboard.WorkSpaceId
                    };
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
