﻿//----------------------------------------------------------------------
//Class Name   : UserRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Anupama Kumari
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Anupama             FDS Change                                    20/03/2019       Getting the user details already in database
//Anupama             FDS Change                                    20/03/2019       Change in stored procedure to get the user details
//----------------------------------------------------------------------

using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.DataAccess.Repository
{
    public class UserRepository : GenericRepository<User>, IUser
    {
        public UserRepository(BaggageDbContext context) : base(context)
        {
        }

        /// <summary>
        ///  save data for logged in user.
        /// </summary>
        /// <param name="objUser"></param>
        /// <returns></returns>
        public async Task<int> UpdateOperationalAreaAndLocation(User objUser)
        {
            var saveUser = await Task.Run(() => Context.spUpdateOperationAreaLocation(objUser.UserId,
                objUser.OperationalArea.RowId, objUser.Location.RowId)).ConfigureAwait(false);
            return saveUser != default(int) ? Convert.ToInt32(saveUser) : 999;
        }


        /// <summary>
        ///  get data for logged in user.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<IList<User>> Fetch(string userId)
        {
            try
            {
                var userDetails = await Task.Run(() => Context.spFetchUserDetails(userId).ToList()).ConfigureAwait(false);

                return userDetails?.Select(a => new User
                {
                    UserId = a.UserID.ToString(),
                    Email = a.Email,
                    FirstName = a.FirstName,
                    LastName = a.LastName,
                    RoleId = Convert.ToInt32(a.RoleId),
                    RoleName = a.UserRole,
                    OrganisationId = a.OrganisationPartyID,
                    OrganisationName = a.OrganisationPartyName,
                    OperationalArea = new Lookup
                    {
                        RowId = a.OperationalActivityID,
                        LookupTypeName = a.OperationalActivity
                    },
                    Location = new Lookup
                    {
                        RowId = (int)a.TerminalFacilityID,
                        LookupTypeName = a.TerminalDescription
                    }
                }).ToList();
            }

            catch (Exception)
            {
                throw;
            }
        }
    }
}
