﻿//----------------------------------------------------------------------
//Class Name   : FilterRepository 
//Purpose      :  Save & retreive operation in the database and return data to business layer. 
//               
//Created By   : Kannan
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//Kannan              FDS Change                                   10/01/2019        Change in dropdown values
//----------------------------------------------------------------------

using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.DataAccess.Repository;
using System.Globalization;

namespace Heathrow.BIPM.DataAccess
{

    /// <summary>
    ///  Save Filter configuration into  Data source 
    /// </summary>
    public class FilterRepository : GenericRepository<FilterEntity>, IFilter
    {
        private readonly FilterEntity _filterDto;
        private readonly FilterControlEntity _filterControlDto;

        /// <summary>

        ///   Filter Repository constructor
        /// </summary>
        /// <param name="context"></param>
        public FilterRepository(BaggageDbContext context) : base(context)
        {
            Context = context;
            _filterDto = new FilterEntity();
            _filterControlDto = new FilterControlEntity();
        }

        /// <summary>
        /// Save the filter configuration into Database based user selection
        /// </summary>
        /// <param name="filterData"></param>
        /// <returns> integer</returns>
        public async Task<int> SaveFilter(FilterEntity filterData)
        {
            filterData.FilterText = filterData.FilterItemSelection != null
                ? JsonConvert.SerializeObject(filterData.FilterItemSelection)
                : string.Empty;

            try
            {
                if (string.IsNullOrEmpty(filterData.FilterText))
                {
                    return -1;
                }

                var filter = await Task.Run(() => Context.spSaveFilterDetail(filterData.UserId, filterData.MenuId, filterData.FilterText,
                    filterData.FilterId).FirstOrDefault()).ConfigureAwait(false);

                return filter != null ? Convert.ToInt32(filter, CultureInfo.InvariantCulture) : -1;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///  Get all Filter selection  data from Database based on menu Id
        /// </summary>
        /// <param name="menuId"></param>
        /// <param name="userId"></param>
        /// <exception cref="ApplicationException"></exception>
        /// <returns></returns>
        public async Task<FilterEntity> FilterByMenuId(int menuId, string userId)
        {
            List<spGetFilterDetails_Result> filterCollection = await Task.Run(() => Context.spGetFilterDetails(menuId, userId).ToList()).ConfigureAwait(false);

            IList<FilterSelection> configList = await Task.Run(() => FilterMappingConfiguration(menuId)).ConfigureAwait(false);
            try
            {
                if (configList.Count <= 0)
                {
                    return _filterDto;
                }

                if (filterCollection.Count > 0)
                {
                    var filterData = filterCollection[0].FilterID > 0 ? JsonConvert.DeserializeObject<IList<FilterSelection>>(filterCollection[0].FilterJSON) : null;
                    _filterDto.FilterId = filterCollection[0].FilterID;
                    _filterDto.MenuId = filterCollection[0].MenuID;
                    ((List<FilterSelection>)_filterDto.FilterItemSelection).AddRange(filterData);
                }
                return _filterDto;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Get Filter configuration
        /// </summary>
        /// <returns>Filter control data</returns>

        public async Task<FilterControlEntity> FilterConfiguration()
        {
            try
            {
                await Task.Run(() => FillDropDownList()).ConfigureAwait(false);

                return _filterControlDto;
            }
            catch (Exception)
            {
                throw;
            }

        }
        /// <summary>
        ///  Fill the Dropdown data source based on filter selection
        /// </summary>
        /// <param name="configList"></param>
        private FilterControlEntity FillDropDownList()
        {
            try
            {

                Context.VWBaggageSystem.OrderBy(e => e.Name).ToList().ForEach(bag =>
                {
                    _filterControlDto.BaggageSystemList.Add(new DropDownFilter
                    {
                        Value = bag.Name
                    });
                });

                Context.VWLastSeenLocation.OrderBy(e => e.Name).ToList().ForEach(loc =>
                {
                    _filterControlDto.LastSeenLocationList.Add(new DropDownFilter
                    {
                        Value = loc.Name
                    });
                });

                Context.VWInOutboundTerminal.OrderBy(d => d.ShortName).ToList().ForEach(terminal =>
                {
                    _filterControlDto.OutboundTerminalList.Add(new DropDownFilter
                    {
                        Value = terminal.ShortName
                    });
                });

                Context.VWNotLoadedCategoryType.OrderBy(s => s.CategoryDescription).ToList().ForEach(notLoaded =>
                {
                    _filterControlDto.NotLoadedCategoryList.Add(new NotLoadedDropDown
                    {
                        Label = notLoaded.CategoryDescription,
                        Value = notLoaded.NotLoadedBagCategoryIdentifier

                    });
                });

                Context.VWNotLoadedSubCategoryType.OrderBy(s => s.SubCategoryDescription).ToList().ForEach(notLoadedSub =>
                {
                    _filterControlDto.NotLoadedSubCategoryList.Add(new NotLoadedDropDown
                    {
                        Label = notLoadedSub.SubCategoryDescription,
                        Value = notLoadedSub.NotLoadedBagSubCategoryIdentifier
                    });
                });

                Context.VWInOutboundHandler.OrderBy(d => d.Description).ToList().ForEach(handler =>
                {
                    _filterControlDto.OutboundHandlerList.Add(new DropDownFilter
                    {
                        Value = handler.Description
                    });
                });

                Context.VWInOutboundAirline.OrderBy(i => i.IATAAirlineName).ToList().ForEach(airline =>
                {
                    _filterControlDto.OutboundAirlineList.Add(new DropDownFilter
                    {
                        Value = airline.IATAAirlineName
                    });
                });

                Context.VWDestination.OrderBy(i => i.IATATypeCode).ToList().ForEach(dest =>
                {
                    _filterControlDto.DestinationList.Add(new DropDownFilter
                    {
                        Value = dest.IATATypeCode
                    });
                });

                Context.VWInOutboundAircraftCategory.OrderBy(a => a.Description).ToList().ForEach(aircraft =>
                {
                    _filterControlDto.OutboundAircraftList.Add(new DropDownFilter
                    {
                        Value = aircraft.Description
                    });
                });
                return _filterControlDto;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Get Report mapping configuration
        /// </summary>
        /// <returns></returns>
        private IList<FilterSelection> FilterMappingConfiguration(int menuId)
        {
            List<spGetFilterConfiguration_Result> oMappingConfig = Context.spGetFilterConfiguration(menuId)?.ToList();

            oMappingConfig?.ForEach(map =>
            {
                _filterDto.PBIMappingList.Add(new FilterSelection
                {
                    TableName = map.PBITableName,
                    ColumnName = map.PBIColumnName,
                    Operator = map.PBIOperator,
                    ControlMappingId = map.ControlID,
                });
            });

            return _filterDto.PBIMappingList;
        }
    }
}
