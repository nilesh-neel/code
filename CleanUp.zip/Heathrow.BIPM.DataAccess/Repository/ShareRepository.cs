﻿//----------------------------------------------------------------------
//Class Name   : ShareRepository 
//Purpose      : This is Data Service js file use to connect with the server side api/controller call. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Vignesh AshokKumar
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No       | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No>      |  dd/MMM/yyyy      | <Reason For Modifications>
//Vignesh(686552)   | Fetch organisation/recipients using logged-in user's EmailId instead of userId | 05/Dec/2018 | Logic changed
//Vignesh(686552)   | code cleanup and updated                                                       | 24/Dec/2018       | Code cleanup
//Vignesh(686552)   | CCAP issue fix                                                                 | 07/Jan/2019       | CCAP warnings
//----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;



namespace Heathrow.BIPM.DataAccess.Repository
{
    public class ShareRepository : GenericRepository<Share>, IShare
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="context"></param>
        public ShareRepository(BaggageDbContext context) : base(context)
        {
          
        }

        /// <summary>
        /// Fetching the Audience Group
        /// </summary>
        /// <returns>Audience Group as List</returns>
        #region Fetch Audience Group
        public async Task<IList<Share>> FetchAudienceGroup(string userEmailId)
        {
            try
            {
                var oFetchAudienceGrp = await Task.Run(() => Context.spFetchUserGroups(userEmailId).ToList()).ConfigureAwait(false);
                return oFetchAudienceGrp?.Select(a => new Share
                {
                    GroupId = a.OrganisationPartyID,
                    GroupName = a.OrganisationGroupName
                }).ToList();
            }
            
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Fetch Recipients
        /// <summary>
        ///  Fetching the Group Recipients based on the selected Audience Group
        /// </summary>
        /// <param name="audienceGroupId">Selected AudienceGrpId as input parameter</param>
        /// <returns>Recipients as List</returns>
        public async Task<IList<Share>> FetchRecipients(int audienceGroupId)
        {
            try
            {
                var oFetchRecipients = await Task.Run(() => Context.spFetchGroupRecipients(audienceGroupId).ToList()).ConfigureAwait(false);
                return oFetchRecipients?.Select(a => new Share
                {
                    GroupId = Convert.ToInt32(a.OrganisationPartyID),
                    RecipientId = a.UserEmail,
                    RecipientName = a.UserFirstName,
                    
                }).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion
    }
}
