﻿//----------------------------------------------------------------------
//Class Name   : BagListRepository 
//Purpose      : This is Data Service js file use to connect with the server side api/controller call. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Vignesh AshokKumar
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//Vignesh(686552)   | Fetch/Remove/Save bagtags using user's EmailId instead of userId   | 05/Dec/2018       | Logic changed
//Vignesh(686552)   | BagList Entitiy as param for Post method                           | 10/Dec/2018       | Entity properties added
//Vignesh(686552)   | code cleanup and updated                                           | 24/Dec/2018       | Code cleanup
//Vignesh(686552)   | CCAP issue fix                                                     | 07/Jan/2019       | CCAP warnings
//----------------------------------------------------------------------

using System;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.DataAccess.Repository
{
 
    public class BagListRepository : GenericRepository<BagList>,IBagList
    {
       
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="context"></param>
        public BagListRepository(BaggageDbContext context) : base(context)
        {
           
        }

        /// <summary>
        ///  Fetching the Existing BagTags of the respective User
        /// </summary>
        /// <param name="userId">userId as input parameter</param>
        /// <returns>Existing Bagtags as string</returns>
        public async Task<string> GetUserExistingBagTags(string userEmailId)
        {
            try
            {
                var oBagTags = await Task.Run(() => Context.spFetchUserExistingBagtags(userEmailId).FirstOrDefault()).ConfigureAwait(false);
                if (oBagTags != null)
                {
                    return oBagTags.ToString().Length > 0 ? oBagTags.ToString() : "";
                }
                else
                {
                    return "";
                }
            }
            catch (Exception)
            {
                throw;
            }
        }


        /// <summary>
        /// Removing BagTags selected by the User
        /// </summary>
        /// <param name="bagTags">Bagtags as input parameter</param>
        /// <param name="userId">userId as input parameter</param>
        /// <returns>Remaining Bagtags as string</returns>
        public async Task<string> RemoveBagTags(string bagTags, string userEmailId)
        {
            try
            {
                var oRemoveBagTags = await Task.Run(() => Context.spRemoveBagtags(bagTags, userEmailId).FirstOrDefault()).ConfigureAwait(false);
                if(oRemoveBagTags != null)
                {
                    return oRemoveBagTags.ToString();
                }
                else
                {
                    return "";
                }
                
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Saving the Added BagTags selected by the User
        /// </summary>
        /// <param name="bagTags">Bagtags as input parameter</param>
        /// <param name="userId">userId as input parameter</param>
        /// <returns>Updated Bagtags as string</returns>
        public async Task<string> SaveBagTags(string bagTags, string userEmailId)
        {
            try
            {
                var oSaveBagTags = await Task.Run(() => Context.spSaveBagtags(bagTags, userEmailId).FirstOrDefault()).ConfigureAwait(false);

                if (oSaveBagTags != null)
                {
                    return oSaveBagTags.ToString();
                }
                else
                {
                    return "";
                }
                
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
    
}
