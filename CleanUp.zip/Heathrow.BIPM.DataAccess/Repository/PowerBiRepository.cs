﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;

namespace Heathrow.BIPM.DataAccess.Repository
{
    public class PowerBiRepository : GenericRepository<ProcessCycle>, IPowerBi
    {
        public PowerBiRepository(BaggageDbContext context) : base(context)
        {
        }
        public IList<PowerBiReportDetails> GetReportDetails(string strUserId)
        {
            var result = Context.spFetchReportDetails(strUserId).ToList();

            return result?.Select(s => new PowerBiReportDetails
            {
                MenuId = s.MenuId,
                FilterType = s.FilterType,
                IsReport = s.IsReport,
                ReportId = s.ReportId,
                ReportSection = s.ReportSection,
                ReportType = Convert.ToInt32(!String.IsNullOrEmpty(s.ReportType) ? s.ReportType : "1", CultureInfo.InvariantCulture),
                WorkSpaceId = s.WorkSpaceId,
                PbiRoles = s.PbiRoles,
                ReportRefreshDateTime = s.LastRefreshedDateTime.Value.ToString("dd/MM/yyyy, HH:mm")
            }).ToList();
        }

        public string ReportLastRefreshDateTime(int reportType)
        {
            //Operational
            if (reportType == 1)
            {
                return Context.ProcessCycle.Max(d => d.EndTime).Value.ToString("dd/MM/yyyy, HH:mm");
                //operDate.HasValue ? operDate.Value.ToString("MM/dd/yyyy HH:mm:ss") : "";
            }
            else
            {//Business
                return Context.CubeProcessLog.Max(d => d.EndTime).Value.ToString("dd/MM/yyyy, HH:mm");
            }
        }


        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }
    }
}
