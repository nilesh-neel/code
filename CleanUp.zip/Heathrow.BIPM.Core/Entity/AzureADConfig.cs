﻿/****************************************************************************************************************
Class Name   : AzureAdConfig.cs 
Purpose      : This is the Entity file in the application...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.Configuration;

namespace Heathrow.BIPM.Core.Entity
{
    public class AzureAdConfig
    {
        protected AzureAdConfig()
        {

        }
        public static Uri AadAuthorityUri => new Uri(ConfigurationManager.AppSettings["AADAuthorityUri"]);
        public static string AzureAdTenant => ConfigurationManager.AppSettings["AzureADTenant"];
        public static string ClientId => ConfigurationManager.AppSettings["ClientId"];
        public static string ClientSecret => ConfigurationManager.AppSettings["ClientSecret"];
        public static Uri RedirectUrl => new Uri(ConfigurationManager.AppSettings["RedirectUrl"]);
        public static Uri WebApiUrl => new Uri(ConfigurationManager.AppSettings["WebApiUrl"]);
        public static string WebApiResourceId => ConfigurationManager.AppSettings["WebApiResourceId"];
        public static string MSGraphApiResourceId => ConfigurationManager.AppSettings["GraphApiResourceId"];
        public static string ApplicationName => ConfigurationManager.AppSettings["ApplicationName"];
        public static string AppInsightsInstrumentationId => ConfigurationManager.AppSettings["AppInsightsInstrumentationId"];
        public static int SessionAndCookieTimeOut => Convert.ToInt32(ConfigurationManager.AppSettings["SessionAndCookieTimeOut"]);
    }
}
