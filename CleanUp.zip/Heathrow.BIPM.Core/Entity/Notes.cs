﻿/****************************************************************************************************************
Class Name   : Notes.cs 
Purpose      : This is the Entity file for Notes Module in the application...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Getting the logged-in userId globally from SignedInUserId  | 10/Dec/2018       | Requirement changed
Vignesh (686552)   | Notes Entitiy properties updated                           | 10/Dec/2018       | New param added in Entity
Vignesh (686552)   | code cleanup and updated                                   | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                             | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

namespace Heathrow.BIPM.Core.Entity
{
    /// <summary>
    /// Notes DTO
    /// </summary>
    public class NotesEntity
    {
        /// <summary>
        /// NotesId
        /// </summary>
        public int NotesId { get; set; }

        /// <summary>
        /// NoteDesc
        /// </summary>
        public string NoteDescription { get; set; }

        /// <summary>
        /// UserId
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// Flightnumber
        /// </summary>
        public string NotesValue { get; set; }
        
        public int OrganizationId { get; set; }

        /// <summary>
        /// Ispublic
        /// </summary>
        public int IsPublic { get; set; }

        /// <summary>
        /// NotesType
        /// </summary>
        public string NotesType { get; set; }
        

        /// <summary>
        /// UserFirstName
        /// </summary>
        public string UserFirstName { get; set; }
        /// <summary>
        /// UserLastName
        /// </summary>
        public string UserLastName { get; set; }

        /// <summary>
        /// CreatedDate
        /// </summary>
        public string CreatedDate { get; set; }


        /// <summary>
        /// UniqueBagTagItem
        /// </summary>

        public string UblValue { get; set; }


    }
}
