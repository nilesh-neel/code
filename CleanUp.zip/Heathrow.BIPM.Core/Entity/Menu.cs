﻿/****************************************************************************************************************
Class Name   : Menu.cs 
Purpose      : This is the Entity file in the application...
Created By   : Nilesh
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.ComponentModel.DataAnnotations;

namespace Heathrow.BIPM.Core.Entity
{
    public class Menu
    {
        [Required(ErrorMessage = "Required MenuId")]
        public int MenuId { get; set; }
        public string Description { get; set; }
        public string OperationalReportId { get; set; }
        public string BusinessReportId { get; set; }
        public string Organization { get; set; }
        public int? ParentId { get; set; }
        public int? OrderId { get; set; }
        public string CssIcon { get; set; }
        public bool IsReport { get; set; }
        public string Tooltip { get; set; }
        public string FavouritesDescription { get; set; }
        public string BreadCrumb { get; set; }
        public bool? IsVisible { get; set; }
        public bool? IsMultiLevel { get; set; }
    }
}
