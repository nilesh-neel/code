﻿/****************************************************************************************************************
Class Name   : PowerBiEmbedConfig.cs 
Purpose      : This is the Entity file in the application...
Created By   : Nilesh
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Collections.Generic;
using System;

namespace Heathrow.BIPM.Core.Entity
{
    public class PowerBiEmbedConfig
    {
        public string Id { get; set; }

        public Uri EmbedUrl { get; set; }

        public object EmbedToken { get; set; }

        public string LastRefreshDateTime { get; set; }
        public bool? IsEffectiveIdentityRolesRequired { get; set; }

        public bool? IsEffectiveIdentityRequired { get; set; }

        public bool EnableRls { get; set; }

        public string UserName { get; set; }

        public string Roles { get; set; }

        public string FilterType { get; set; }

        public string ReportSection { get; set; }
        public string ErrorMessage { get; set; }
        public string PowerBIType { get; set; }

        private readonly List<object> values = new List<object>();
        public IList<object> Values { get { return values; } }
        public FilterEntity FilterDetails { get; set; }
    }
}
