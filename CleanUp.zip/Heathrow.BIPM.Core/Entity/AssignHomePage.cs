﻿/****************************************************************************************************************
Class Name   : AssignHomePage.cs 
Purpose      : This is the Entity file in the application...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetching the user groups by logged-in user EmailId | 05/Dec/2018       | Logic changed
Vignesh (686552)   | Fetch Dashboard list in groups                     | 10/Dec/2018       | Logic changed
Vignesh (686552)   | code cleanup and updated                           | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                     | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/


using System.Collections.Generic;

namespace Heathrow.BIPM.Core.Entity
{
    public class AssignHomePage
    {

        public int UserGroupId { get; set; }
        public string Description { get; set; }
        public int UserId { get; set; }

        public string UserEmail { get; set; }
        public string UserFirstName { get; set; }

        public string Homepage { get; set; }
        public List<UserHomePage> UsersHomePage { get; set; }
    }


    public class UserHomePage
    {
        public string PageName { get; set; }
        public string UserId { get; set; }
        public string GroupId { get; set; }
        public string ReportId { get; set; }
    }

}
