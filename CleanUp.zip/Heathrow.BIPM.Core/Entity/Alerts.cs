﻿/****************************************************************************************************************
Class Name   : Alerts.cs 
Purpose      : This is the Entity file in the application...
Created By   : Vaishnavi.R
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.ComponentModel.DataAnnotations;

namespace Heathrow.BIPM.Core.Entity
{
    public class Alerts:Response
    {
        public int AlertId { get; set; }
        [Required(ErrorMessage = "Description Required")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Title Required")]
        public string Title { get; set; }
        public string Measure { get; set; }
        public string ThresholdValue { get; set; }
        public int TimeWindow { get; set; }       
        public int MandatoryOptional { get; set; }
    }
}
