﻿/****************************************************************************************************************
Class Name   : ExceptionInfo.cs 
Purpose      : This is the Entity file for BagList Module in the application...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

namespace Heathrow.BIPM.Core.Entity
{
    public class ExceptionInfo
    {
        public string SignedInUserId { get; set; }
        public string ApplicationName { get; set; }
        public string ExceptionMessage { get; set; }
        public string ExceptionSource { get; set; }
        public string InnerException { get; set; }
        public string StackTrace { get; set; }
        public string TargetSite { get; set; }
        public string EmailId { get; set; }
        public string UserId { get; set; }
    }
}
