﻿/****************************************************************************************************************
Class Name   : TodaysAlert.cs 
Purpose      : This class is used for todays alert tab
Created By   : Vaishnavi.R
Created Date : 05/March/2019
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;

namespace Heathrow.BIPM.Core.Entity
{
    public class TodaysAlert
    {
        public int AlertId { get; set; }
        public string Message { get; set; }
        public string Title { get; set; }
        public DateTime CreatedDate { get; set; }
        public int? ResponseType { get; set; }
        public string TodaysLocation { get; set; }
        public string Topic { get; set; }
        public string Time { get; set; }
        public int Mandatory { get; set; }
        public int EventId { get; set; }

    }
}
