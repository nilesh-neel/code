﻿/****************************************************************************************************************
Class Name   : ConfigureAlerts.cs 
Purpose      : This is the Entity file in the application...
Created By   : Vaishnavi
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System;

namespace Heathrow.BIPM.Core.Entity
{
 public class ConfigureAlerts
    {
        public int AlertId { get; set; }
        public string Description { get; set; }
        public string Frequency { get; set; }
  
        public string Location { get; set; }
        public string Measure { get; set; }
        public string Organization { get; set; }
        public string OperationalArea { get; set; }
        public string Threshold { get; set; }
        public string ThresholdValue { get; set; }
        public string Title { get; set; }
        public string Topic { get; set; }
        public int TimeWindow { get; set; }
        public int MandatoryOptional { get; set; }
        public int? ResponseType { get; set; }
        public bool IsSnooze { get; set; }
        public bool IsSubscribe { get; set; }
        public bool IsOnScreen { get; set; }
        public bool IsEmail { get; set; }
        public bool IsMobile { get; set; }
        public bool DisableAlert { get; set; }
        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string ModifiedBy { get; set; }

        public DateTime ModifiedDate { get; set; }

    }
}
