﻿/****************************************************************************************************************
Class Name   : esponse.cs 
Purpose      : This class is used to hold common properties for both alerts and notification module
Created By   : Vaishnavi.R
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.Collections.Generic;

namespace Heathrow.BIPM.Core.Entity
{
  public class Response
    { 
        public int? ResponseType { get; set; }
        public bool IsSnooze { get; set; }
        public bool IsSubscribe { get; set; }

        public bool IsOnScreen { get; set; }

        public bool IsEmail { get; set; }
 
        public bool IsMobile { get; set; }

        public bool DisableAlert { get; set; }

        public bool DisableNotification { get; set; }

        private readonly List<int> selectedOperationalArea = new List<int>();
        private readonly List<int> selectedLocation = new List<int>();

        public IList<int> SelectedOperationalArea { get { return selectedOperationalArea; } }

        public int SelectedOrganisation { get; set; }

        public int SelectedTopic { get; set; }

        public int SelectedThreshold { get; set; }

        public IList<int> SelectedLocation { get { return selectedLocation; } }

        public int SelectedFrequency { get; set; }

        public int SelectedTimeWindow { get; set; }

        public int SelectedMeasure { get; set; }
        public DateTime DateAndTime { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public string ModifiedBy { get; set; }

        public DateTime ModifiedDate { get; set; }

        public IEnumerable<Lookup> BagLocation { get; set; }

        public IEnumerable<Lookup> BagMeasure { get; set; }

        public IEnumerable<Lookup> BagOperationalArea{ get; set; }

        public IEnumerable<Lookup> BagOrganisation { get; set; }

        public IEnumerable<Lookup> BagTopic { get; set; }

        public IEnumerable<Lookup> BagThreshold { get; set; }

        public IEnumerable<Lookup> BagFrequency { get; set; }

        public IEnumerable<Lookup> BagTimeWindow { get; set; }

    }
}
