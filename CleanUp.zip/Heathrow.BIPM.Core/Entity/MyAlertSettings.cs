﻿/****************************************************************************************************************
Class Name   : myAlertSettings.cs 
Purpose      : This is the Entity file in the application...
Created By   : Nilesh
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

namespace Heathrow.BIPM.Core.Entity
{
  public class MyAlertSettings
    {
        public int AlertId { get; set; }
        public string Measure { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }       
        public string Topic { get; set; }
        public string Location { get; set; }     
        public int MandatoryOptional { get; set; }
        public string Threshold { get; set; }
        public string ThresholdValue { get; set; }
        public bool IsSubscribe { get; set; }
        public bool IsOnScreen { get; set; }
        public bool IsEmail { get; set; }
        public bool IsMobile { get; set; }
        public bool IsSnooze { get; set; }
        public bool IsConfigureEmail { get; set; }
    }
}
