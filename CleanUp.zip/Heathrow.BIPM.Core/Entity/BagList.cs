﻿/****************************************************************************************************************
Class Name   : BagList.cs 
Purpose      : This is the Entity file for BagList Module in the application...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Fetch/Remove/Save bagtags using user's EmailId instead of userId   | 05/Dec/2018       | Logic changed
Vignesh (686552)   | BagList Entitiy as param for Post method                           | 10/Dec/2018       | Entity properties added
Vignesh (686552)   | code cleanup and updated                                           | 24/Dec/2018       | Code cleanup
Vignesh (686552)   | CCAP issue fix                                                     | 07/Jan/2019       | CCAP warnings
****************************************************************************************************************/

using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Heathrow.BIPM.Core.Entity
{
    /// <summary>
    /// BagList DTO
    /// </summary>
    [ComplexType]
    public class BagList
    {
        /// <summary>
        /// BagListID
        /// </summary>
        public int BagListId { get; set; }

        /// <summary>
        /// Bagtags
        /// </summary>
        public string BagTags { get; set; }

        /// <summary>
        /// UserId
        /// </summary>
        public int UserId { get; set; }

        /// <summary>
        /// OthersMybaglistUserId
        /// </summary>
        public int OtherUserId { get; set; }

        /// <summary>
        /// UserFirstname
        /// </summary>
        public string UserFirstName { get; set; }

        /// <summary>
        /// UserLasttname
        /// </summary>
        public string UserLastName { get; set; }

        /// <summary>
        /// UserEmail
        /// </summary>
        public string UserEmail { get; set; }

        /// <summary>
        /// UserOrg
        /// </summary>
        public string UserOrg { get; set; }

        /// <summary>
        /// UserRole
        /// </summary>
        public string UserRole { get; set; }

        /// <summary>
        /// BagtagsJson
        /// </summary>
        public string BagTagsJson { get; set; }

        /// <summary>
        /// UpdatedDate
        /// </summary>
        public DateTime UpdatedDate { get; set; }

    }
   
}
