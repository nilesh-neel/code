﻿/****************************************************************************************************************
Class Name   : AzureAdUser.cs 
Purpose      : This is the Entity file in the application...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Collections.Generic;
using System.IO;

namespace Heathrow.BIPM.Core.Entity
{
    public class AzureAdUser
    {
        public string Id { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public Stream Avatar { get; set; }
        public string Name { get; set; }
        public IEnumerable<Lookup> JobRoles { get; set; }
        public string Phone { get; set; }
        public IEnumerable<Lookup> Locations { get; set; }
        public string Organization { get; set; }
        public string Role { get; set; }
    }

    

}
