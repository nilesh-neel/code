﻿/****************************************************************************************************************
Class Name   : Notifications.cs 
Purpose      : This is the Entity file in the application...
Created By   : Vaishnavi.R
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

namespace Heathrow.BIPM.Core.Entity
{
    public class Notification : Response
    {   //Today's Notification     


        public string Description { get; set; }

        public string Topic { get; set; }


        public string Location { get; set; }


        //Notification Settings

 
        public int NotificationId { get; set; }

        public string Organisation { get; set; }

        public string OperationalArea { get; set; }

        //Configure Notifications

        public string AdditionalInformation { get; set; }

        public bool IsConfigureEmail { get; set; }
        public bool IsConfigureOnScreen { get; set; }



    }

}
