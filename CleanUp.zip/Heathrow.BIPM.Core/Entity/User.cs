﻿/****************************************************************************************************************
Class Name   : User.cs 
Purpose      : This is the Entity file in the application...
Created By   : Nilesh
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

namespace Heathrow.BIPM.Core.Entity
{
    public class User
    {
        public string UserId { get; set; }
        public Lookup OperationalArea { get; set; }
        public Lookup Location { get; set; }
        public string UserPhoto { get; set; }
        public string PhoneNumber { get; set; }
        public string Organization { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public int OrganisationId { get; set; }
        public string OrganisationName { get; set; }

    }
}
