﻿/****************************************************************************************************************
Class Name   : FilterCollection.cs 
Purpose      : This is the Entity file in the application...
Created By   : Kannan
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Collections.Generic;

namespace Heathrow.BIPM.Core.Entity
{
    /// <summary>
    ///This entity use to handle the Data Transfer Object in the Filter module 
    /// </summary>

    public class FilterEntity
    {
        public long FilterId { get; set; }

        public string UserId { get; set; }

        public int MenuId { get; set; }

        public string FilterText { get; set; }

        private readonly List<FilterSelection> pbiMappingList = new List<FilterSelection>();
        public IList<FilterSelection> PBIMappingList { get { return pbiMappingList; } }


        private readonly List<FilterSelection> filterItemSelection = new List<FilterSelection>();
        public IList<FilterSelection> FilterItemSelection { get { return filterItemSelection; } }

    }

    // Filter Control configuration

    public class FilterControlEntity
    {
        private readonly List<NotLoadedDropDown> notLoadedCategoryList = new List<NotLoadedDropDown>();
        public IList<NotLoadedDropDown> NotLoadedCategoryList { get { return notLoadedCategoryList; } }

        private readonly List<NotLoadedDropDown> notLoadedSubCategoryList = new List<NotLoadedDropDown>();
        public IList<NotLoadedDropDown> NotLoadedSubCategoryList { get { return notLoadedSubCategoryList; } }

        private readonly List<DropDownFilter> baggageSystemList = new List<DropDownFilter>();
        public IList<DropDownFilter> BaggageSystemList { get { return baggageSystemList; } }

        private readonly List<DropDownFilter> outboundAircraftList = new List<DropDownFilter>();
        public IList<DropDownFilter> OutboundAircraftList { get { return outboundAircraftList; } }

        private readonly List<DropDownFilter> destinationList = new List<DropDownFilter>();
        public IList<DropDownFilter> DestinationList { get { return destinationList; } }

        private readonly List<DropDownFilter> outboundAirlineList = new List<DropDownFilter>();
        public IList<DropDownFilter> OutboundAirlineList { get { return outboundAirlineList; } }

        private readonly List<DropDownFilter> outboundTerminalList = new List<DropDownFilter>();
        public IList<DropDownFilter> OutboundTerminalList { get { return outboundTerminalList; } }


        private readonly List<DropDownFilter> lastSeenLocationList = new List<DropDownFilter>();
        public IList<DropDownFilter> LastSeenLocationList { get { return lastSeenLocationList; } }

        private readonly List<DropDownFilter> outboundHandlerList = new List<DropDownFilter>();
        public IList<DropDownFilter> OutboundHandlerList { get { return outboundHandlerList; } }

    }

    /// <summary>
    ///  The Entity use to fill Filter DropDown Control
    /// </summary>
    public class DropDownFilter
    {
        public string Value { get; set; }

    }

    /// <inheritdoc />
    /// <summary>
    ///  This Entity use to fill NotLoaded DropDown Control 
    /// </summary>
    public class NotLoadedDropDown : DropDownFilter
    {
        public string Label { get; set; }
        public int CategoryId { get; set; }
    }

    /// <summary>
    /// This is entity use to handle Filter mapping of all control  
    /// </summary>
    public class FilterSelection
    {
        public string TableName { get; set; }
        public string ColumnName { get; set; }

        private readonly List<string> columnValue = new List<string>();
        public List<string> ColumnValue { get { return columnValue; } }
        public string Operator { get; set; }
        public int ControlMappingId { get; set; }
    }

    /// <summary>
    /// This entity use to handler Report Configuration for search 
    /// </summary>
    public class ReportConfiguration : PowerBiEmbedConfig
    {
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        
        private readonly List<string> columnValue = new List<string>();
        public List<string> ColumnValue { get { return columnValue; } }
        
        public string Operator { get; set; }
        public string PowerBiReportId { get; set; }
        public int MenuId { get; set; }
    }

}



