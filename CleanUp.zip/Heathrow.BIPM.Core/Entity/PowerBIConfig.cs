﻿/****************************************************************************************************************
Class Name   : PowerBIConfig.cs 
Purpose      : This is the Entity file in the application...
Created By   : Nilesh
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.Configuration;


namespace Heathrow.BIPM.Core.Entity
{
    public class PowerBIConfig : AzureAdConfig
    {
        public static string PowerBIApiResource
        {
            get { return ConfigurationManager.AppSettings["PowerBiAPIResource"]; }
        }
        public static Uri PowerBIApiUrl
        {
            get { return new Uri(ConfigurationManager.AppSettings["PowerBiApiUrl"]); }
        }
        public static string PowerBINativeAppId
        {
            get { return ConfigurationManager.AppSettings["PowerBiNativeAppId"]; }
        }
    }
}
