﻿/****************************************************************************************************************
Class Name   : LookupEnt.cs 
Purpose      : This is the Lookup Entity file in the application...
Created By   : Kannan
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

namespace Heathrow.BIPM.Core.Entity
{
  public  class Lookup
    {
        public int RowId { get; set; }
        public string LookupTypeName { get; set; }     
        public int Selected { get; set; }
    }
}
