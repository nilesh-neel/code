﻿/****************************************************************************************************************
Class Name   : Registration.cs 
Purpose      : This is the Entity file in the application...
Created By   : Nilesh
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.Collections.Generic;

namespace Heathrow.BIPM.Core.Entity
{
    public class Registration
    { 
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int SelectedOperationalArea { get; set; }
        public int SelectedOrganisation { get; set; }
        public int SelectedLocation { get; set; }
        public string AccessReason { get; set; }

        public IEnumerable<Lookup> BagLocation { get; set; }
        public IEnumerable<Lookup> BagOperationalArea { get; set; }
        public IEnumerable<Lookup> BagOrganisation { get; set; }

    }

}
