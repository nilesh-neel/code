﻿/****************************************************************************************************************
Class Name   : PowerBiReportDetails.cs 
Purpose      : This is the Entity file in the application...
Created By   : Nilesh
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

namespace Heathrow.BIPM.Core.Entity
{
    public class PowerBiReportDetails
    {
        public int MenuId { get; set; }
        public string WorkSpaceId { get; set; }
        public int ReportType { get; set; }
        public string ReportId { get; set; }
        public string ReportSection { get; set; }
        public string FilterType { get; set; }
        public int? IsReport { get; set; }
        public string PbiRoles { get; set; }
        public string ReportRefreshDateTime { get; set; }
    }
}

