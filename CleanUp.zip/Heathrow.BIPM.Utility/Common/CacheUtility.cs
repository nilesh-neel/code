﻿/*************************************************************************************************************
Class Name   : CacheUtility.cs
Purpose      : Used to define utility functions for Cache.
Created By   : Nilesh
Created Date : 03/Dec/2018
Version      : 1.0
History      :
Modified By        | CR<CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR<CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
************************************************************************************************************/

using System;
using System.Runtime.Caching;


namespace Heathrow.BIPM.Utility.Common
{
    public static class CacheUtility
    {
        #region Public Functions

        #region Get & Set Functions
        /// <summary>
        /// Used to get the value of Cache irrespective of return type.
        /// </summary>
        /// <typeparam name="T">Generic Type; it can either be string, int, objet etc</typeparam>
        /// <param name="cacheKey">Cache Key</param>
        /// <param name="durationInMinutes">Time how log item availabe in cache</param>
        /// <param name="getItemCallback">Call back method if item not availabe in cache or first time call and store iteam in cache</param>
        /// <returns></returns>
        public static T GetOrSet<T>(string cacheKey, int durationInMinutes, Func<T> getItemCallback) where T : class
        {
            if (MemoryCache.Default.Get(cacheKey) is T item)
            {
                return item;
            }

            if (getItemCallback == null)
            {
                throw new ArgumentNullException(nameof(getItemCallback));
            };
            item = getItemCallback();
            MemoryCache.Default.Add(cacheKey, item, DateTime.Now.AddMinutes(durationInMinutes));
            return item;
        }
        #endregion


        #region Other Utility Function
        /// <summary>
        /// Used to check whether session key exist or not.
        /// </summary>
        /// <param name="strSessionKey">Session Key</param>
        /// <returns>boolean value</returns>
        //public static bool IsKeyExist(string strSessionKey)
        //{
        //    return HttpContext.Current.Session[strSessionKey] != null;
        //}

        //#region Wrapper Functions - Wrapped Common Functions from HttpContext.Current.Session Class
        //public static void RemoveItem(string strSessionKey)
        //{
        //    HttpContext.Current.Session.Remove(strSessionKey);
        //}
        //public static void RemoveAllItems()
        //{
        //    HttpContext.Current.Session.RemoveAll();
        //}
        //public static void Clear()
        //{
        //    HttpContext.Current.Session.Clear();
        //}
        //public static void Abandon()
        //{
        //    HttpContext.Current.Session.Abandon();
        //}
        #endregion
        #endregion
    }
}
