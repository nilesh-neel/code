﻿/*************************************************************************************************************
Class Name   : SessionUtility.cs
Purpose      : Used to define utility functions for Sessions.
Created By   : Nilesh
Created Date : 03/Dec/2018
Version      : 1.0
History      :
Modified By        | CR<CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR<CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
************************************************************************************************************/

using System.Web;

namespace Heathrow.BIPM.Utility.Common
{
    public static class SessionUtility
    {
        #region Private Member Variables

        #endregion

        #region Public Functions

        #region Get & Set Functions
        #region "Get & Set Functions For Generic Type Value"
        /// <summary>
        /// Used to get the value of session irrespective of return type.
        /// </summary>
        /// <typeparam name="T">Generic Type; it can either be string, int, DataSet etc.</typeparam>
        /// <param name="key">Session Key</param>
        /// <returns>Generic Value; it can either be string, int, DataSet etc.</returns>
        public static T Get<T>(string key)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session[key] == null)
            {
                if (typeof(T) == typeof(string))
                { 
                    return (T)(object)string.Empty;
                }
                return default(T);
            }
            else
            { 
                return (T)(HttpContext.Current != null ? HttpContext.Current.Session[key] : string.Empty);
            }
        }

        /// <summary>
        /// Used to set the value of session irrespective of the type of value.
        /// </summary>
        /// <typeparam name="T">Generic Type; it can either be string, int, DataSet etc.</typeparam>
        /// <param name="key">Session Key</param>
        /// <param name="value">Generic Value; it can either be string, int, DataSet etc.</param>
        public static void Set<T>(string key, T value)
        {
            if (value != null) //null values not allowed as it makes no sense to assign null value; instead use Remove function.
            { 
                HttpContext.Current.Session[key] = value;
            }
        }
        #endregion

       
        #endregion


        #endregion
    }
}
