﻿/*************************************************************************************************************
Class Name   : KestrelKeyVaultUtility.cs
Purpose      : Used to define utility functions for key vault.
Created By   : Nilesh
Created Date : 03/Dec/2018
Version      : 1.0
History      :
Modified By        | CR<CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR<CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
************************************************************************************************************/

using System;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using Microsoft.Azure.KeyVault;
using Microsoft.Identity.Client;

namespace Heathrow.BIPM.Utility.Common
{
    public static class KestrelKeyVaultUtility
    {

        public static async Task<string> Get(string strKey)
        {
            try
            {
                var keyValClient = new KeyVaultClient(new KeyVaultClient.AuthenticationCallback(GetToken));
                var secretKey = await keyValClient.GetSecretAsync(strKey).ConfigureAwait(false);
                return secretKey.Value;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public static async Task<string> GetToken(string authority, string resource, string scope)
        {
            var _clientApp = new ConfidentialClientApplication(AzureAdConfig.ClientId, authority, AzureAdConfig.RedirectUrl.ToString(),
                new ClientCredential(AzureAdConfig.ClientSecret), null, null);
            AuthenticationResult result = await _clientApp.AcquireTokenForClientAsync(new string[] { resource + "/.default" }).ConfigureAwait(false);
            if (result == null)
            {
                throw new InvalidOperationException("Failed to obtain the JWT token");
            }
            return result.AccessToken;
        }
    }

}
