﻿/*************************************************************************************************************
Class Name   : TokenUtility.cs
Purpose      : Used to define utility functions for token.
Created By   : Nilesh
Created Date : 03/Dec/2018
Version      : 1.0
History      :
Modified By        | CR<CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR<CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
************************************************************************************************************/

using System;
using System.Security.Claims;
using Heathrow.BIPM.Core.Entity;
using System.Threading.Tasks;
using Heathrow.BIPM.Utility.Constants;
using Microsoft.Identity.Client;
using System.Web;
using System.Linq;
using System.Security;

namespace Heathrow.BIPM.Utility.Common
{
    public static class TokenUtility
    {
        public static async Task<string> GetAccessTokenAsync(string resourceId, bool isPowerBI)
        {

            try
            {
                string signedInUserId = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value;
                string tenantID = ClaimsPrincipal.Current.FindFirst("http://schemas.microsoft.com/identity/claims/tenantid").Value;
                string userObjectId = ClaimsPrincipal.Current.FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier").Value;

                if (isPowerBI)
                {
                    var pbiUser = KestrelKeyVaultUtility.Get(AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.PBUserName)).Result;
                    var pbiSecret = KestrelKeyVaultUtility.Get(AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.PBUserSecret)).Result;
                    PublicClientApplication pbiApp = new PublicClientApplication(PowerBIConfig.PowerBINativeAppId, AzureAdConfig.AadAuthorityUri.ToString());

                    var pbiScopes = new string[] { PowerBIConfig.PowerBIApiResource };
                    var securePassword = new SecureString();
                    foreach (char c in pbiSecret) // you should fetch the password
                    { 
                        securePassword.AppendChar(c); // keystroke by keystroke
                    }

                    var result = await pbiApp.AcquireTokenByUsernamePasswordAsync(pbiScopes, pbiUser, securePassword).ConfigureAwait(false);
                    return result.AccessToken;

                }
                else
                {
                    TokenCache userTokenCache = new KsSessionTokenCacheUtility(signedInUserId, new HttpContextWrapper(HttpContext.Current)).GetMsalCacheInstance();
                    ConfidentialClientApplication cc = new ConfidentialClientApplication(AzureAdConfig.ClientId, AzureAdConfig.AadAuthorityUri.ToString(), AzureAdConfig.RedirectUrl.ToString(),
                        new ClientCredential(AzureAdConfig.ClientSecret), userTokenCache, null);
                    var accounts = await cc.GetAccountsAsync().ConfigureAwait(false);
                    var webApiPbi = await cc.AcquireTokenSilentAsync(new string[] { resourceId }, accounts.FirstOrDefault()).ConfigureAwait(false);
                    //var result = await cc.AcquireTokenSilentAsync(new string[] { "https://graph.microsoft.com/user.readbasic.all" }, accounts.FirstOrDefault());
                    return webApiPbi.AccessToken;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
