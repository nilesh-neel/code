﻿/****************************************************************************************************************
Class Name   : MailUtility.cs 
Purpose      : Used to define utility functions for sending mail
Created By   : Nilesh
Created Date : 03/Dec/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Mail to be triggered to recipients individually | 18/Feb/2019 | Requirement changed
****************************************************************************************************************/

#region Using Directives
using System;
using System.Globalization;
using System.Net.Mail;
using System.Net;
using Heathrow.BIPM.Utility.Constants;

#endregion

namespace Heathrow.BIPM.Utility.Common
{
    public static class MailUtility
    {
        #region "Private Variables"
        
        public enum MailSentStatus
        {
            Success = 0,
            Fail = 99
        }
        #endregion

        #region "SendMail"
        /// <summary>
        /// Send Mail functionality
        /// </summary>
        /// <param name="recipient"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <returns></returns>
        public static int SendMail(string recipient, string subject, string body, AlternateView alternateView)
        {
            try
            {
               
                string username =  KestrelKeyVaultUtility.Get(AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.PBUserName)).Result;
                string secret = KestrelKeyVaultUtility.Get(AppSettingsUtility.GetAppSettingsKeyValue(AppSettingsConstants.PBUserSecret)).Result;
                string smtpServer = AppSettingsConstants.SmtpSever;
                var nullCheck = !string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(secret);
                var selectionCheck = !string.IsNullOrEmpty(recipient) && !string.IsNullOrEmpty(subject) && !string.IsNullOrEmpty(body);

                if (nullCheck && selectionCheck)
                {
                    using (SmtpClient smtpClient = new SmtpClient())
                    {
                        NetworkCredential basicCredential = new NetworkCredential(username, secret);
                        using (MailMessage message = new MailMessage())
                        {
                            MailAddress fromAddress = new MailAddress(@username);

                            // setup up the host, increase the timeout to 5 minutes
                            smtpClient.Host = smtpServer;
                            smtpClient.Port = 587;
                            smtpClient.UseDefaultCredentials = false;
                            smtpClient.EnableSsl = true;
                            smtpClient.Credentials = basicCredential;
                            smtpClient.Timeout = (60 * 5 * 1000);

                            message.From = fromAddress;
                            message.Subject = subject + " - " +
                                              DateTime.Now.Date.ToString(CultureInfo.InvariantCulture).Split(' ')[0];
                            message.IsBodyHtml = true;
                            message.AlternateViews.Add(alternateView);
                            message.Body = body;

                            string[] strRecipientslist = recipient.Split(',');
                            foreach (string receipient in strRecipientslist)
                            {
                                message.To.Add(receipient);
                            }

                            smtpClient.Send(message);
                        }
                        return (int)MailSentStatus.Success;
                    }
                }
                else
                {
                    return (int)MailSentStatus.Fail;
                }
            }
            catch (Exception)
            {                                
                throw;
            }
        }
        #endregion
    }
}
