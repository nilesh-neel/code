﻿/****************************************************************************************************************
Class Name   : ExceptionLogging.cs 
Purpose      : This file is used to handle the Exceptions globally across the application and track those exceptions in the Azure Appinsights .......
Created By   : Vignesh AshokKumar 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.Collections.Generic;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using Heathrow.BIPM.Core.Entity;
using System.Globalization;

namespace Heathrow.BIPM.Utility.Common
{
    public static class LogUtility
    {
        public static void LogException(Exception exception, string signInUser)
        {
            #region AppInsights Telemetryconfig code
            TelemetryConfiguration configuration = TelemetryConfiguration.Active;
            configuration.InstrumentationKey = AzureAdConfig.AppInsightsInstrumentationId;

            TelemetryClient telemetryClient = new TelemetryClient(configuration);
            if (exception == null)
            {
                return;
            }
            Exception ex = new FormatException(exception.Message); // error you want to log

            var properties = new Dictionary<string, string>
            {
                { "Application", Convert.ToString(AzureAdConfig.ApplicationName,CultureInfo.CurrentCulture)},
                { "Source", exception.Source},
                {"Inner Exception",Convert.ToString(exception.InnerException,CultureInfo.CurrentCulture)},
                {"StackTrace",exception.StackTrace },
                {"Target Site",Convert.ToString(exception.TargetSite.ReflectedType,CultureInfo.CurrentCulture)},
                { "User ID",signInUser},{"Email",signInUser}
            };
            // Send the exception telemetry:
            telemetryClient.TrackException(ex, properties, null);

            telemetryClient.TrackTrace(exception.StackTrace.ToString()); // used to log audit logs

            telemetryClient.Flush();
            #endregion
        }
    }
}
