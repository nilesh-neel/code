﻿/****************************************************************************************************************
Class Name   : AppSettingsUtility.cs 
Purpose      : Used to define utility functions for appSettings keys of web.config
Created By   : Nilesh 
Created Date : 03/Dec/2017
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region "Using Directives"

using System.Configuration;

#endregion
namespace Heathrow.BIPM.Utility.Common
{
   public static class AppSettingsUtility
    {
        #region Public Methods

        /// <summary>
        /// GetAppSettingsKeyValue function will return value of appSettings Key defined in web.config
        /// </summary>
        /// <returns></returns>
        public static string GetAppSettingsKeyValue(string key)
        {
            return GetAppSettingsKeyValue(key, string.Empty);
        }
        public static string GetAppSettingsKeyValue(string strKey, string defaultValue)
        {
            return !string.IsNullOrEmpty(ConfigurationManager.AppSettings[strKey]) ? ConfigurationManager.AppSettings[strKey] : defaultValue;
        }

        #endregion
    }
}
