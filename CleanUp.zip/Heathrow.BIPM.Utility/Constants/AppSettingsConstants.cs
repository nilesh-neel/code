﻿/****************************************************************************************************************
Class Name   : AppSettingsConstants.cs 
Purpose      : Used to define constants/names for Application setting availabe in web.config file. 
Created By   : Nilesh More 
Created Date : 03/Dec/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Configuration;

namespace Heathrow.BIPM.Utility.Constants
{
    public static class AppSettingsConstants
    {
        #region EmailSMS

        public static readonly string SendMailUserName = ConfigurationManager.AppSettings["SendMailUsername"];
        public static readonly string SendMailSecret = ConfigurationManager.AppSettings["SendMailSecret"];
        public static readonly string FromMailAddress = ConfigurationManager.AppSettings["FromMailaddress"];
        public static readonly string EncryptionKey = ConfigurationManager.AppSettings["EncryptionKey"];
        //Report default Configuration
        public static readonly string DefaultEmbedUrl = "https://app.powerbi.com/reportEmbed?reportId=2a4981ad-6ff6-41dc-a88b-c2b50edf10c3&groupId=0fc4287c-461d-46bc-a2da-ec29f0962ab3";
        public static readonly string DefaultId = "2a4981ad-6ff6-41dc-a88b-c2b50edf10c3";
        public static readonly string DefaultType = "report";

        //PowerBiModule
     
        public static readonly string AuthorityUrl = "https://login.microsoftonline.com/2133b7ab-6392-452c-aa20-34afbe98608e/oauth2/authorize";
        public static readonly string ResourceUrl = "https://analysis.windows.net/powerbi/api";
        public static readonly string ReportsFilterValue = "2a4981ad-6ff6-41dc-a88b-c2b50edf10c3";
        public static readonly string NativeAppClientId = "9eecd6a0-0204-4463-a816-9e0d6966e8fa";
        public static readonly string CollectionName = "POC - DB Approach - Shared";
        public static readonly string WorkspaceId = "f574865f-76fc-4441-9322-6d64f5bbcaca";

        public static readonly string UserHomeScreenWorkspaceId = "0fc4287c-461d-46bc-a2da-ec29f0962ab3";
        public static readonly string HomeEmbedUrl = "https://app.powerbi.com/dashboardEmbed?dashboardId=";
        public static readonly string AmberGroupId = "&groupId=";
        public static readonly string Resource = "resource";
        public static readonly string ClientId = "client_id";
        public static readonly string GrantType = "grant_type";
        public static readonly string UserName = "username";
        public static readonly string Scope = "scope";
        public static readonly string OpenId = "openid";
        public static readonly string ClientSecret = "client_secret";
        public static readonly string View = "view";

        //UserProfile
        public static readonly string UserProfileImage = "/images/Icons/userProfile.png";
        public static readonly string ThreeDots = "...";

        //Utilities
        public static readonly string Entity = "entity";
        public static readonly string Id = "Id";
        

        // MailUtility
        public static readonly string SmtpSever = "smtp.office365.com";
        #endregion

        #region "Kestrel Azure Key Vault"
        public static readonly string KSDbContext = "KestrelDBContext";
        public static readonly string PBUserName = "PbiUserId";
        public static readonly string PBUserSecret = "PbiSecret";

        #endregion

        // Report 
        public static readonly int ReportType = 1;
        public static readonly string ReportId = "da8f3015-e0c1-41bd-aae7-08894b6b6d99";
        public static readonly string FlightPrefix = "F";
    }
}
