﻿/****************************************************************************************************************
Class Name   : SessionConstants.cs 
Purpose      : Used to define constants/names for all Session Variables. 
Created By   : Nilesh More 
Created Date : 03/Dec/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

namespace Heathrow.BIPM.Utility.Constants
{
    public static class SessionConstants
    {
        public static readonly string LoggedInUserId = "LoggedInUser";
        public static readonly string LoggedUser = "LogInUser";
        public static readonly string UserPhoto = "Photo";
        public static readonly string PbiReportDetails = "PbiReportForCurrentUser";
    }
}
