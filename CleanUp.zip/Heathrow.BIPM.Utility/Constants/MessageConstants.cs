﻿/****************************************************************************************************************
Class Name   : MessageConstants.cs 
Purpose      : Used to define constants for common messages (for all validations). 
Created By   : Nilesh More 
Created Date : 03/Dec/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
Vignesh (686552)   | Constants added up for Share report via Email | 18/Feb/2019 | Requirement changed
****************************************************************************************************************/

using System.Collections.Generic;

namespace Heathrow.BIPM.Utility.Constants
{
    public static class MessageConstants
    {
        public static readonly string DataSavedSuccessfully = "Data Saved Successfully";
        public static readonly string FileNotFound = "File Not Found.";
        public static readonly string FileDownloadedSuccessfully = "File Downloaded Successfully.";
        public static readonly string AccessDenied = "Access Denied. You are not authorized user.";
        public static readonly string SystemErrorMessage = "System or network error. Please contact support team.";

        //Owin Startup

        public static readonly string OwinCookieName = ".KsBaggage";
        public static readonly string CliamTypeTenant = "http://schemas.microsoft.com/identity/claims/tenantid";

        public static readonly IList<string> CrosHeaders = new List<string>()
            {"Accept", "Authorization", "Cache-Control", "Content-Type", "Access-Control-Allow-Origin"};
        public static readonly IList<string> CrosMethods = new List<string>() { "POST", "GET", "OPTIONS", "DELETE", "PUT" };


        // Error Message
        public static readonly string SaveFilterActionError = "Error is occured while saving filters";
        public static readonly string FilterActionError = "Error is occured while retrieving the filters";
        public static readonly string SearchActionError = "Error is occured while retrieving the search";


        // AuthProvider Module

        public static readonly string AccessTokenErr = "Error message when unable to retrieve the access token silently.";
        public static readonly string Prefer = "Prefer";
        public static readonly string TimeZone = "outlook.timezone=\"";
        public static readonly string SlashQuote = "\"";
        public static readonly string BearerSmall = "bearer";
        public static readonly string Bearer = "Bearer";

        //Alerts/Notifications Module

        public static readonly string Configured = "Configured";
        public static readonly string Configure = "Configure";
        public static readonly string AlertNotification = "AlertNotification";
        public static readonly string NullResult = "Result set is null";
        public static readonly string NullObject = "Object is null";

        public static readonly string SaveSuccess = "Save Success";
        public static readonly string SaveFail = "Save Fail";

        public static readonly string Response = "Response";
        public static readonly string Alerts = "Alerts";
        public static readonly string AlertId = "AlertId";
        public static readonly string Title = "Title";
        public static readonly string AlertDescription = "AlertDescription";
        public static readonly string Locations = "Locations";
        public static readonly string LocationId = "LocationID";
        public static readonly string OperationalAreas = "OperationalAreas";
        public static readonly string OperationalAreaId = "OperationalAreaID";
        public static readonly string TopicId = "TopicID";
        public static readonly string OrganizationId = "OrganisationID";
        public static readonly string ThresholdId = "ThresholdID";
        public static readonly string MeasureId = "MeasureID";
        public static readonly string FrequencyId = "FrequencyID";
        public static readonly string TimeWindowId = "TimeWindowID";
        public static readonly string ThresholdValue = "ThresholdValue";
        public static readonly string Mandatory = "Mandatory";
        public static readonly string Subscribe = "Subscribe";

        public static readonly string Mobile = "Mobile";
        public static readonly string Onscreen = "OnScreen";
        public static readonly string DisableNotification = "DisableNotification";
        public static readonly string DisableAlert = "DisableAlert";
        public static readonly string CreatedBy = "CreatedBy";
        public static readonly string ModifiedBy = "ModifiedBy";
        public static readonly string User1 = "User1";
        public static readonly string StartDate = "StartDate";
        public static readonly string EndDate = "EndDate";

        public static readonly string EditAlertForm = "EditAlertForm";
        //Validation Messages
        public static readonly string StartDateGTEndDate = "Start Date is greater than End Date";
        //Success Message
        public static readonly string EditSuccess = "Alert saved successfully for EditAlertForm";
        public static readonly string ConfigureSuccess = "Alert saved successfully for configureAlert";
        public static readonly string AlertSuccess = "Alert saved successfully";
        public static readonly string AlertFail = "Error in saving Alert";
        //Views
        public static readonly string LandingPage = "_LandingPage";
        public static readonly string NewAlert = "_NewAlert";
        public static readonly string EditAlertSettings = "_EditAlertSettings";
        public static readonly string EditAlertConfigure = "_EditAlertConfigure";
        //API route
        public static readonly string AlertByID = "api/AlertByID?alertId=";
        public static readonly string ConfigureAlertByID = "api/ConfigureAlertByID?alertId=";
        public static readonly string APIAlert = "api/Alerts";

        //Notification Views
        public static readonly string NewNotification = "_NewNotification";
        public static readonly string EditNotificationSetting = "_EditNotificationSetting";
        public static readonly string EditNotificationConfigure = "_EditNotificationConfigure";

        //Success Message Notification
        public static readonly string NotificationSettingSuccess = "Notification saved successfully for myNotificationSettingForm";
        public static readonly string NotificationConfigureSuccess = "Notification saved successfully for configureNotificationForm";
        public static readonly string NotificationSuccess = "Notification saved successfully";
        public static readonly string NotificationFail = "Error in saving Notification";


        //Notification Repository
        public static readonly string Application = "Application";

        public static readonly string Notifications = "Notifications";
        public static readonly string NotificationId = "NotificationID";
        public static readonly string NotificationDescription = "Description";
        public static readonly string HelpUrl = "HelpURL";
        public static readonly string Created = "CreatedDate";
        public static readonly string Email = "Email";
        public static readonly string Setting = "setting";
        //Base Controller
        public static readonly string LogOn = "LogInUser";
        public static readonly string Photo = "photo";
        public static readonly string SignIn = "SignIn";
        public static readonly string Account = "Account";

        //Dashboard controller
        public static readonly string Report = "report";
        public static readonly string CalledReportId = "calledreportid";
        public static readonly string ReportType = "ReportType";
        public static readonly string UniqueBagItem = "UBL";
        public static readonly string BagTag = "bagTag";
        public static readonly string Amber = "&";
        public static readonly string MsGraphApiUserDetailsEndpoint = "https://graph.microsoft.com/beta/me/";
        public static readonly string MsGraphApiUserPhotoEndpoint = "https://graph.microsoft.com/beta/me/photo/$value";


        //ExceptionController

        public static readonly string FilePath = "~/Views/Exception/Error.cshtml";
        public static readonly string ContentType = "text/html";

        //Notification Controller
        public static readonly string Api = "api/NotificationByID?id=";
        public static readonly string ApiNotifications = "api/Notifications";

        //share controller
        public static readonly string htmlStructureStart = "<html><head><style>table{border-collapse:collapse;}th,td{border:1px solid black;padding:5px;text-align:left;vertical-align:top;white-space:nowrap}body{color:rgb(110,117,122);font-family:\"Arial\";font-size: 16px;}</style></head><body>Dear Kestrel User,<br><br>";
        public static readonly string htmlSharedWithYou = " has shared this Kestrel report with you:<br>";
        public static readonly string reportNameStartTag = @"<br>";
        public static readonly string htmlReportAccess = "<br> Please click here to access the report<br>";
        public static readonly string reportLinkStartTag = @"<a style=""color: #663366"" href =";
        public static readonly string reportLinkMiddleTag = ">";
        public static readonly string reportLinkEndTag = "</a>";
        public static readonly string htmlStructureEnd = @"<br><br>Thank you for using Kestrel.<br><br>Kind Regards,<br>Kestrel Team<br><a style=""color: #663366"" href=""https://dev-kestrel.azurewebsites.net"">https://dev-kestrel.azurewebsites.net</a><br><br>";
        public static readonly string htmlResponseMonitored = @"<br> Responses to this mailbox are not monitored. If you have questions, please Email <a style=""color: #663366"" href=""KestrelSupport@heathrow.com"">KestrelSupport@heathrow.com</a><br>";
        public static readonly string htmlEndTag = "<br><br></body></html>";
        public static readonly string kestrelLogoPath = "images//LogosAndImages//Kestrel_Mail_Logo.jpg";
        public static readonly string imgStartTag = @"<img src='cid:";
        public static readonly string imgEndTag = @"'/>";
        public static readonly string kestrelReport = "Kestrel report '";
        public static readonly string isSharedWithYou = "' is shared with you";
        //Registration

        public static readonly string DataUnavailable = "Data unavailable";

        //ExceptionHandlers
        public static readonly string ServiceUnhandledException = "An unhandled exception was thrown by service.";
        public static readonly string InternalServerErr = "Internal Server Error. Please try again later.";

        //PowerBi Module
        public static readonly string AuthenticationFailed = "Authentication Failed.";
        public static readonly string NoReportInWorkspace = "No report with the given ID was found in the workspace. Make sure ReportId is valid.";
        public static readonly string NoReportsForUser = "No reports were found for the user";
        public static readonly string ErrFormat = "Status: {0} ({1})\r\nResponse: {2}\r\nRequestId: {3}";
        public static readonly string RequestId = "RequestId";
        public static readonly string EmbedTokenFailed = "Failed to generate embed token.";
        public static readonly string DefaultReport = "1bebcfe9-c1a2-4abd-8715-5afadd864469";
        public static readonly string FailedToken = "Failed to generate embed token.";

        //Registration Module
        public static readonly string SuperAdmin = "Super admin not found";

        //BaseController
        public static readonly string JsonHelpers = "Do not use the standard Json helpers to return JSON data to the client.  Use either JsonSuccess or JsonError instead.";

        //AssignHome PageRepository
        public static readonly string Success = "Success";

        //Notes Repository
        public static readonly string TimeFormat = "dd/MM/yyyy, HH:mm";

        //Power Bi Constant
        public static readonly string Dashboard = "dashboard";

        //Registration mail msg
        public static readonly string RegistrationMessage = "Registration request";
        public static readonly string Reenter = "Please re enter the details";
        public static readonly string AlreadyExist = "This record already exists!";
        public static readonly string AlreadyExistMsg = "You have already registered";
    }
}
