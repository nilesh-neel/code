﻿/****************************************************************************************************************
Class Name   : CacheConstants.cs 
Purpose      : Used to define constants/names for all Cache. 
Created By   : Nilesh More 
Created Date : 03/Dec/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

#region Using Directives

#endregion
namespace Heathrow.BIPM.Utility.Constants
{
    public static class CacheConstants
    {
        #region Public Variables
        public static readonly string TestCache = "TestCache";
        public static readonly string MenuList = "Menu";
        public static readonly string PbiClientCache = "PowerBiClientCache";

        #endregion
    }
}
