using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class PdfModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IPdf> mockPdf;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockPdf = this.mockRepository.Create<IPdf>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private PdfModule CreatePdfModule()
        {
            return new PdfModule(
                this.mockPdf.Object);
        }

        [TestMethod]
        public async Task Getpdfmenu_StateUnderTest_ExpectedBehavior()
        {
            var pdfBusinessLayer = new Mock<IPdf>();
            // Arrange
            var unitUnderTest = this.CreatePdfModule();
            int menuId = 19; 

            var testPdf = GetTestPdf();
            var module = new PdfModule(pdfBusinessLayer.Object);

            pdfBusinessLayer.Setup(x => x.GetPdfMenu(menuId)).Returns(GetTestPdf1);

            var result = module.Getpdfmenu(menuId);
            // Act
            //var result = await unitUnderTest.Getpdfmenu(
            //    menuId);

            // Assert
            Assert.AreNotEqual(testPdf, result);
        }

        private static IList<PdfMappings> GetTestPdf()
        {
            var testPdf = new List<PdfMappings>
            {
                new PdfMappings()
                {
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    MenuId = 19,
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                    PageNo = "4",
                    PdfId = 1,
                    PdfName = "sample.pdf"
                }
            };

            return testPdf;
        }

        private static Task<IEnumerable<PdfMappings>> GetTestPdf1()
        {
            IEnumerable<PdfMappings> testPdf = new List<PdfMappings>
            {
                new PdfMappings()
                {
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    MenuId = 19,
                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,
                    PageNo = "4",
                    PdfId = 1,
                    PdfName = "sample.pdf"
                }
            };

            return Task.FromResult(testPdf);
        }
    }
}
