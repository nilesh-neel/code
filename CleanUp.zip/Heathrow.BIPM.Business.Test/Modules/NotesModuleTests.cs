using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class NotesModuleTests
    {
        private MockRepository mockRepository;

        private Mock<INotes> mockNotes;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockNotes = this.mockRepository.Create<INotes>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private NotesModule CreateNotesModule()
        {
            return new NotesModule(
                this.mockNotes.Object);
        }

        [TestMethod]
        public async Task DeleteNotes_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange

            //int notesId = 0; //TODO;
            //string notesValue = ""; //TODO;
            //string notesType = ""; //TODO;
            //string userId = ""; //TODO;
            //// Act
            //var result = await unitUnderTest.DeleteNotes(
            //    notesId,
            //    notesValue,
            //    notesType,
            //    userId);
            //// Assert
            //Assert.Fail();

            var unitUnderTest = this.CreateNotesModule();
            Mock<INotes> notesDataAccessLayer = new Mock<INotes>();
            notesDataAccessLayer.Setup(x => x.DeleteNotes(15, "Bt1", "B", "use@xy.com"))
                .Returns(NotesList(true));
            var notesBusiness = new NotesModule(notesDataAccessLayer.Object);
            var testNotes = NotesList();
            IList<NotesEntity> listResult = await notesBusiness.DeleteNotes(15, "Bt1", "B", "use@xy.com");
            Assert.AreEqual(listResult[0].NotesId, testNotes.Result[0].NotesId);
            Assert.IsNotNull(testNotes.Result[0].CreatedDate);
            Assert.IsNotNull(testNotes.Result[0].OrganizationId);
            Assert.IsNotNull(testNotes.Result[0].UserFirstName);
            Assert.IsNotNull(testNotes.Result[0].UserLastName);

        }

        [TestMethod]
        public async Task Fetch_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //var unitUnderTest = this.CreateNotesModule();
            //string notesValue = ""; //TODO;
            //string notesType = ""; //TODO;
            //string notesUblValue = ""; //TODO;
            //string userId = ""; //TODO;
            //// Act
            //var result = await unitUnderTest.Fetch(
            //    notesValue,
            //    notesType,
            //    notesUblValue,
            //    userId);
            //// Assert
            //Assert.Fail();

            Mock<INotes> notesDataAccessLayer = new Mock<INotes>();
            notesDataAccessLayer.Setup(x => x.FetchNotes("Bt1", "Fl1", "5673", ""))
                .Returns(NotesList());
            var notesBusiness = new NotesModule(notesDataAccessLayer.Object);
            var testNotes = NotesList();
            IList<NotesEntity> listResult = await notesBusiness.Fetch("Bt1", "Fl1", "5673", "");
            Assert.AreEqual(listResult[0].NotesId, testNotes.Result[0].NotesId);
        }

        [TestMethod]
        public async Task Save_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //var unitUnderTest = this.CreateNotesModule();
            //NotesEntity notes = null; //TODO;
            //// Act
            //var result = await unitUnderTest.Save(
            //    notes);
            //// Assert
            //Assert.Fail();

            Mock<INotes> notesDataAccessLayer = new Mock<INotes>();
            var data = new NotesEntity
            {
                NotesId = 0,
                NoteDescription = "Notes Description added",
                UblValue = "12345",
                OrganizationId = 1,
                IsPublic = 1,
                CreatedDate = "12/24/2018",
                UserId = "Admin",
            };

            notesDataAccessLayer.Setup(x => x.SaveNotes(data))
                .Returns(NotesList(true));
            var notesBusiness = new NotesModule(notesDataAccessLayer.Object);
            var testNotes = NotesList();
            IList<NotesEntity> listResult = await notesBusiness.Save(data);
            Assert.AreEqual(listResult[0].NotesId, testNotes.Result[0].NotesId);

        }

        private static Task<IList<NotesEntity>> NotesList(bool isDeleted = false)
        {
            IList<NotesEntity> notesList = new List<NotesEntity>
            {
                new NotesEntity
                {
                    NotesId = 5,
                    UblValue = "12345",
                    NoteDescription = "Flight is delayed",
                    OrganizationId=1,
                    IsPublic=1,
                    CreatedDate= "12/24/2018",
                    UserId="Admin",
                    UserFirstName = "fname",
                    UserLastName="lname"
                }
            };
            return Task.FromResult(notesList);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        //private static Task<NotesEntity> TestNotesCollection()
        //{
        //    return Task.FromResult(new NotesEntity
        //    {
        //        NotesId = 5,
        //        NoteDescription = "Mock Desc",
        //        OrganizationId = 1,
        //        UblValue = "12345",
        //        IsPublic = 1,
        //        CreatedDate = "12/24/2018",
        //        UserId = "Admin",
        //        UserFirstName = "fname",
        //        UserLastName = "lname"
        //    });
        //}
    }
}
