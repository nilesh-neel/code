using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class AssignHomePageModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IAssignHomePage> mockAssignHomePage;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockAssignHomePage = this.mockRepository.Create<IAssignHomePage>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private AssignHomePageModule CreateAssignHomePageModule()
        {
            return new AssignHomePageModule(
                this.mockAssignHomePage.Object);
        }

        [TestMethod]
        public async Task GetUserGroups_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            var unitUnderTest = this.CreateAssignHomePageModule();
            //// Act
            //var result = await unitUnderTest.GetUserGroups();
            //// Assert
            //Assert.Fail();

            var assignDataAccessLayer = new Mock<IAssignHomePage>();
            assignDataAccessLayer.Setup(x => x.GetUserGroups("xyz@abc.com")).Returns(GetTestAssignList());
            var testAssign = GetTestAssign();
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);
            IList<AssignHomePage> listResult = await assignBusiness.GetUserGroups("xyz@abc.com");
            Assert.AreEqual(listResult[0].UserGroupId, testAssign[0].UserGroupId);
            Assert.AreEqual(listResult[0].Description, testAssign[0].Description);
            Assert.AreEqual(listResult[0].Homepage, testAssign[0].Homepage);
            Assert.AreEqual(listResult[0].UserEmail, testAssign[0].UserEmail);
            Assert.AreEqual(listResult[0].UserFirstName, testAssign[0].UserFirstName);


        }

        [TestMethod]
        public async Task GetGroupRecipients_StateUnderTest_ExpectedBehavior()
        {
            var assignDataAccessLayer = new Mock<IAssignHomePage>();
            assignDataAccessLayer.Setup(x => x.GetGroupRecipients(19)).Returns(GetTestAssignList());
            var testAssign = GetTestAssign();
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);
            IList<AssignHomePage> listResult = await assignBusiness.GetGroupRecipients(19);
            Assert.AreEqual(listResult[0].UserId, testAssign[0].UserId);

        }


        [TestMethod]
        public async Task GetGroupRecipients_StateUnderTest_NotExpectedBehavior()
        {
            var assignDataAccessLayer = new Mock<IAssignHomePage>();
            assignDataAccessLayer.Setup(x => x.GetGroupRecipients(0)).Returns(GetTestAssignList());
            var testAssign = GetTestAssign();
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);
            IList<AssignHomePage> listResult = await assignBusiness.GetGroupRecipients(0);
            //Assert.AreNotEqual(listResult[0].UserId, testAssign[0].UserId);

        }

        [TestMethod]
        public async Task SaveHomepage_StateUnderTest_ExpectedBehavior()
        {
            var assignDataAccessLayer = new Mock<IAssignHomePage>();
            string testAssign = "HomePage";
            assignDataAccessLayer.Setup(x => x.SaveHomepage("HomePage1")).Returns(GetSuccess());
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);

            List<UserHomePage> homeList = new List<UserHomePage>();
            homeList.Add(
            new UserHomePage
            {
                GroupId = "1",
                PageName = "HomePage1",
                ReportId = "1b29b902-273c-43e8-a92b-eda66b2043c5",
                UserId = "9"
            }
            );

            var data = new AssignHomePage
            {
                UsersHomePage = homeList
            };

            string result = await assignBusiness.SaveHomepage(data, "xyz@abc.com");
            Assert.IsNull(result);
        }

        [TestMethod]
        public async Task SaveHomepage_StateUnderTest_NotExpectedBehavior()
        {
            var assignDataAccessLayer = new Mock<IAssignHomePage>();
            assignDataAccessLayer.Setup(x => x.SaveHomepage("HomePage1")).Returns(GetSuccess());
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);
            string result = await assignBusiness.SaveHomepage(null, "xyz@abc.com");
            Assert.IsNull(result);
        }

        [TestMethod]
        public async Task GetUserDashboard_StateUnderTest_ExpectedBehavior()
        {
            var assignDataAccessLayer = new Mock<IAssignHomePage>();
            assignDataAccessLayer.Setup(x => x.FetchUserHomepage("xyz@abc.com")).Returns(GetReportDetails());
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);
            PowerBiReportDetails result = await assignBusiness.GetUserDashboard("xyz@abc.com");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetUserDashboard_StateUnderTest_NotExpectedBehavior()
        {
            var assignDataAccessLayer = new Mock<IAssignHomePage>();
            assignDataAccessLayer.Setup(x => x.FetchUserHomepage("xyz@abc.com")).Returns(GetReportDetails());
            var assignBusiness = new AssignHomePageModule(assignDataAccessLayer.Object);
            PowerBiReportDetails result = await assignBusiness.GetUserDashboard(null);
            Assert.IsNull(result);
        }

        private static Task<string> GetSuccess()
        {
            return Task.FromResult("Success");
        }


        private static Task<PowerBiReportDetails> GetReportDetails()
        {
            var reportDetail = new PowerBiReportDetails()
            {
                FilterType = "Type1",
                IsReport = 1
            };
            return Task.FromResult(reportDetail);
        }

        private static List<AssignHomePage> GetTestAssign()
        {
            var testAssign = new List<AssignHomePage>
            {
                new AssignHomePage()
                {
                    Description = "Page description",
                    Homepage = "Homepage1",
                    UserEmail = "xyz@abc.com",
                    UserFirstName = "Lawrence",
                    UserGroupId = 19,
                    UserId = 1
                }
            };

            return testAssign;
        }

        private static Task<IList<AssignHomePage>> GetTestAssignList()
        {
            IList<AssignHomePage> testAssign = new List<AssignHomePage>
            {
                new AssignHomePage()
                {
                    Description = "Page description",
                    Homepage = "Homepage1",
                    UserEmail = "xyz@abc.com",
                    UserFirstName = "Lawrence",
                    UserGroupId = 19,
                    UserId = 1
                }
            };

            return Task.FromResult(testAssign);
        }
    }
}
