using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class BagListModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IBagList> mockBagList;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBagList = this.mockRepository.Create<IBagList>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }



        [TestMethod]
        public async Task GetUserExistingbagtags_StateUnderTest_ExpectedBehavior()
        {
            Mock<IBagList> baglistDataAccessLayer = new Mock<IBagList>();
            baglistDataAccessLayer.Setup(x => x.GetUserExistingBagTags("xyz@abc.com"))
                .Returns(ExistingBagtags());
            var bagListBusiness = new BagListModule(baglistDataAccessLayer.Object);
            string result = await bagListBusiness.GetUserExistingbagtags("xyz@abc.com");
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task RemoveBagTags_StateUnderTest_ExpectedBehavior()
        {
            Mock<IBagList> baglistDataAccessLayer = new Mock<IBagList>();
            baglistDataAccessLayer.Setup(x => x.RemoveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", "xyz@abc.com"))
                .Returns(ExistingBagtags());
            var bagListBusiness = new BagListModule(baglistDataAccessLayer.Object);
            string result = await bagListBusiness.RemoveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", "xyz@abc.com");
            Assert.IsNotNull(result);

        }

        [TestMethod]
        public async Task SaveBagTags_StateUnderTest_ExpectedBehavior()
        {
            Mock<IBagList> baglistDataAccessLayer = new Mock<IBagList>();
            baglistDataAccessLayer.Setup(x => x.SaveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", "xyz@abc.com"))
                .Returns(ExistingBagtags());
            var bagListBusiness = new BagListModule(baglistDataAccessLayer.Object);
            string result = await bagListBusiness.SaveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", "xyz@abc.com");
            Assert.IsNotNull(result);

        }

        [TestMethod]
        public async Task GetUserExistingbagtags_StateUnderTest_NotExpectedBehavior()
        {
            Mock<IBagList> baglistDataAccessLayer = new Mock<IBagList>();
            baglistDataAccessLayer.Setup(x => x.GetUserExistingBagTags("xyz@abc.com"))
                .Returns(ExistingBagtags());
            var bagListBusiness = new BagListModule(baglistDataAccessLayer.Object);
            string result = await bagListBusiness.GetUserExistingbagtags(null);
            Assert.AreNotEqual(result, null);
        }

        [TestMethod]
        public async Task RemoveBagTags_StateUnderTest_NotExpectedBehavior()
        {

            Mock<IBagList> baglistDataAccessLayer = new Mock<IBagList>();
            baglistDataAccessLayer.Setup(x => x.RemoveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", "xyz@abc.com"))
                .Returns(ExistingBagtags());
            var bagListBusiness = new BagListModule(baglistDataAccessLayer.Object);
            string result = await bagListBusiness.RemoveBagTags(null, "xyz@abc.com");
            Assert.AreNotEqual(result, null);

        }

        [TestMethod]
        public async Task SaveBagTags_StateUnderTest_NotExpectedBehavior()
        {
            Mock<IBagList> baglistDataAccessLayer = new Mock<IBagList>();
            baglistDataAccessLayer.Setup(x => x.SaveBagTags("[{'TableName':'BagItemListFact','ColumnName':'TagNumber','ColumnValue':['3589177579,3589219538']}]", "xyz@abc.com"))
                .Returns(ExistingBagtags());
            var bagListBusiness = new BagListModule(baglistDataAccessLayer.Object);
            string result = await bagListBusiness.SaveBagTags(null, "xyz@abc.com");
            Assert.AreNotEqual(result,null);

        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static Task<string> ExistingBagtags()
        {
            return Task.FromResult("[{'TableName':'dummyBagItem','ColumnName':'dummyTagNumber','ColumnValue':['3589177579,3589219538']}]");
        }
    }
}
