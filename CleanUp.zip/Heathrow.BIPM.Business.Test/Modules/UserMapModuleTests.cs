using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;
using Heathrow.BIPM.Business.Modules;
using System.Collections.Generic;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class UserMapModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IUser> mockUser;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockUser = this.mockRepository.Create<IUser>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private IUserMapModule CreateUserMapModule()
        {
            return new UserMapModule(
                this.mockUser.Object);
        }


        [TestMethod]
        public async Task UpdateOperationalAreaAndLocation_StateUnderTest_ExpectedBehavior()
        {
            var unitUnderTest = this.CreateUserMapModule();
            var mock = new Mock<IUser>();
            mock.Setup(x => x.UpdateOperationalAreaAndLocation(GetTestUserObject()));

            UserMapModule module = new UserMapModule(mock.Object);
            // Act
            var result1 = await module.UpdateOperationalAreaAndLocation(GetTestUserObject());
            // Assert
            Assert.AreNotEqual("Save Success", result1);
        }

        [TestMethod]
        public async Task Fetch_StateUnderTest_ExpectedBehavior()
        {
            var userRepoLayer = new Mock<IUser>();
            userRepoLayer.Setup(x => x.Fetch("gayathri.kannan@heathrow.com"))
        .Returns(GetTestUser());

            IList<User> testUser = await GetTestUser();
            var module = new UserMapModule(userRepoLayer.Object);
            // Act
            IList<User> result = await module.Fetch("gayathri.kannan@heathrow.com");
            // Assert
            Assert.AreEqual(testUser.GetEnumerator().Current, result.GetEnumerator().Current);
        }

       
        private static Task<IList<User>> GetTestUser()
        {
            IList<User> userList = new List<User>();
            var testUser = new User()
            {
                UserId = "13243",
                OperationalArea = new Lookup
                {
                    RowId = 3,
                    LookupTypeName = "Ramp"
                },
                Location = new Lookup
                {
                    RowId = 4,
                    LookupTypeName = "Heathrow Terminal 3"
                },
                Email = "gayathri.kannan@heathrow.com",
                FirstName = "Gayathri",
                LastName = "Kannan"
            };
            userList.Add(testUser);

            return Task.FromResult(userList);
        }

        private static User GetTestUserObject()
        {
            var testUser = new User()
            {
                UserId = "13243",
                OperationalArea = new Lookup
                {
                    RowId = 3,
                    LookupTypeName = "Ramp"
                },
                Location = new Lookup
                {
                    RowId = 4,
                    LookupTypeName = "Heathrow Terminal 3"
                },
                Email = "gayathri.kannan@heathrow.com"
            };
            return testUser;
        }
    }
}
