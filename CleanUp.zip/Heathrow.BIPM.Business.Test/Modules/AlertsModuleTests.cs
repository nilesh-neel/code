using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class AlertsModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IAlerts> mockAlerts;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockAlerts = this.mockRepository.Create<IAlerts>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private AlertsModule CreateAlertsModule()
        {
            return new AlertsModule(
                this.mockAlerts.Object);
        }

        [TestMethod]
        public async Task GetAlertsById_StateUnderTest_ExpectedBehavior()
        {

            var mockAlerts = new Mock<IAlerts>();
            var unitUnderTest = this.CreateAlertsModule();
            mockAlerts.Setup(x => x.GetAlertsById("1", 1))
        .Returns(GetTestMyAlertSettings());

            var testAlert = await GetTestMyAlertSettings();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetAlertsById("1", 1);
            // Assert
            Assert.AreEqual(testAlert.AlertId, result.AlertId);
        }
        [TestMethod]
        public async Task GetAlertsById_StateUnderTest_ExpectedBehavior1()
        {
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetAlertsById("", 1))
        .Returns(GetTestMyAlertSettings());
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetAlertsById(null, 0);
            // Assert
            Assert.AreEqual(result, null);
        }

        [TestMethod]
        public async Task GetAlerts_StateUnderTest_ExpectedBehavior()
        {  // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetMyAlertSettings("user1"))
        .Returns(GetTestAlertList());

            var testAlert = await GetTestAlertList();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetAlerts("user1");
            // Assert
            Assert.AreEqual(testAlert.GetEnumerator().Current, result.GetEnumerator().Current);
        }
        [TestMethod]
        public async Task GetAlerts_StateUnderTest_ExpectedBehavior1()
        {  // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetMyAlertSettings("User1"))
        .Returns(GetTestAlertList());

            var testAlert = await GetTestAlertList();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetAlerts(null);
            // Assert
            Assert.AreEqual(result, null);
        }

        [TestMethod]
        public async Task InsertUpdate_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(p => p.InsertUpdate(
                new Alerts()
                {
                    AlertId = 1,
                    Description = "desc",
                    BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                    CreatedBy = "test",
                    CreatedDate = DateTime.Now,
                    DateAndTime = DateTime.Now,
                    DisableAlert = false,
                    DisableNotification = false,
                    EndDate = DateTime.Now,

                    IsEmail = false,
                    IsMobile = true,
                    IsOnScreen = true,
                    IsSubscribe = false,
                    MandatoryOptional = 1,

                    ModifiedBy = "test",
                    ModifiedDate = DateTime.Now,


                    ResponseType = 1,
                    SelectedFrequency = 1,
                    // SelectedLocation = new int[] { 1, 2 },
                    SelectedMeasure = 1,
                    // SelectedOperationalArea = new int[] { 1, 2 },
                    SelectedOrganisation = 1,
                    SelectedThreshold = 1,
                    SelectedTimeWindow = 1,
                    SelectedTopic = 1,
                    StartDate = DateTime.Now,
                    ThresholdValue = "1",
                    Measure="1",
                    TimeWindow = 1,
                    Title = "title",
                    IsSnooze = true


                }));
            AlertsModule module = new AlertsModule(mockAlerts.Object);
            // Act
            var result1 = await module.InsertUpdate(new Alerts()
            {
                AlertId = 1,
                Description = "desc",
                BagFrequency = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagLocation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagMeasure = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOperationalArea = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagOrganisation = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagThreshold = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTimeWindow = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                BagTopic = new List<Lookup>() { new Lookup { LookupTypeName = "bag1", RowId = 1, Selected = 1 } },
                CreatedBy = "test",
                CreatedDate = DateTime.Now,
                DateAndTime = DateTime.Now,
                DisableAlert = false,
                DisableNotification = false,
                EndDate = DateTime.Now,

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                MandatoryOptional = 1,
                Measure = "1",
                ModifiedBy = "test",
                ModifiedDate = DateTime.Now,
                ResponseType = 1,
                SelectedFrequency = 1,
                // SelectedLocation = new int[] { 1, 2 },
                SelectedMeasure = 1,
                // SelectedOperationalArea = new int[] { 1, 2 },
                SelectedOrganisation = 1,
                SelectedThreshold = 1,
                SelectedTimeWindow = 1,
                SelectedTopic = 1,
                StartDate = DateTime.Now,
                ThresholdValue = "1",
                TimeWindow = 1,
                Title = "title",

            });
            // Assert
            Assert.AreNotEqual("Save Fail", result1);
        }

        [TestMethod]
        public async Task GetAlertNotification_StateUnderTest_ExpectedBehavior()
        {

            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetAlertNotification("user1"))
        .Returns(GetTodaysAlert());
            var testAlert = await GetTodaysAlert();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetAlertNotification("user1");

            // Assert
            Assert.AreEqual(testAlert.GetEnumerator().Current, result.GetEnumerator().Current);

        }

        [TestMethod]
        public async Task GetAlertCount_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetAlertCount("user1"))
        .Returns(GetTestAlertCount());
            var testAlert = await GetTestAlertCount();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetAlertCount("user1");

            // Assert
            Assert.AreEqual(testAlert, result);

        }

        [TestMethod]
        public async Task GetAlertCount_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetAlertCount("user1"))
        .Returns(GetTestAlertCount());
            var testAlert = await GetTodaysAlert();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetAlertCount(null);

            // Assert
            Assert.AreEqual(0, result);
        }
        [TestMethod]
        public async Task GetAlertNotification_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetAlertNotification("user1"))
        .Returns(GetTodaysAlert());
            var testAlert = await GetTodaysAlert();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetAlertNotification(null);

            // Assert
            Assert.AreEqual(null, result);

        }

        [TestMethod]
        public async Task GetTodaysAlert_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetTodaysAlert("user1"))
        .Returns(GetTodaysAlert());
            var testAlert = await GetTodaysAlert();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetTodaysAlert("user1");

            // Assert
            Assert.AreEqual(testAlert.GetEnumerator().Current, result.GetEnumerator().Current);

        }

        [TestMethod]
        public async Task GetTodaysAlert_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetTodaysAlert("user1"))
        .Returns(GetTodaysAlert());
            var testAlert = await GetTodaysAlert();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetTodaysAlert(null);

            // Assert
            Assert.AreEqual(result, null);
        }

        [TestMethod]
        public async Task GetConfiguredAlert_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetConfiguredAlert("user1"))
        .Returns(GetTestConfigureAlertList());

            var testAlert = await GetTestConfigureAlertList();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetConfiguredAlert("user1");
            // Assert
            Assert.AreEqual(testAlert.GetEnumerator().Current, result.GetEnumerator().Current);
        }
        [TestMethod]
        public async Task GetConfiguredAlert_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetConfiguredAlert("1"))
        .Returns(GetTestConfigureAlertList());
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetConfiguredAlert(null);
            // Assert
            Assert.AreEqual(null, result);
        }

        [TestMethod]
        public async Task GetConfiguredAlertById_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetConfiguredAlertById("user", 1))
        .Returns(GetTestAlert());

            var testAlert = await GetTestAlert();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetConfiguredAlertById("user", 1);
            // Assert
            Assert.AreEqual(testAlert.AlertId, result.AlertId);
        }
        [TestMethod]
        public async Task GetConfiguredAlertById_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetConfiguredAlertById("user", 1))
        .Returns(GetTestAlert());
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetConfiguredAlertById(null, 1);
            // Assert
            Assert.AreEqual(null, result);
        }


        [TestMethod]
        public async Task GetTopicForMeasure_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetTopicForMeasure("user1"))
        .Returns(GetTestAlert());
            var testAlert = await GetTestAlert();
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetTopicForMeasure("user1");

            // Assert
            Assert.AreEqual(testAlert.AlertId, result.AlertId);
        }
        [TestMethod]
        public async Task GetTopicForMeasure_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var mockAlerts = new Mock<IAlerts>();
            mockAlerts.Setup(x => x.GetTopicForMeasure("user1"))
        .Returns(GetTestAlert());
            var module = new AlertsModule(mockAlerts.Object);
            // Act
            var result = await module.GetTopicForMeasure(null);

            // Assert
            Assert.AreEqual(null, result);
        }

        private static Task<IEnumerable<TodaysAlert>> GetTodaysAlert()
        {
            IEnumerable<TodaysAlert> testProducts = new List<TodaysAlert>()
            { new TodaysAlert
            {
                AlertId = 4,
                CreatedDate = System.DateTime.Now,
                ResponseType = 1,
                Title = "title",
                Topic = "test",
                Message="Alert msg",
                Time="10:50:00.000",
                TodaysLocation="Terminal-1"

            } };

            return Task.FromResult(testProducts);
        }
        private static Task<IEnumerable<MyAlertSettings>> GetTestAlertList()
        {
            IEnumerable<MyAlertSettings> testProducts = new List<MyAlertSettings>()
            { new MyAlertSettings
            {
                AlertId = 1,
                Description = "desc",

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",
                MandatoryOptional = 1,
                Measure = "1",
                IsSnooze=true,
                Threshold = "1",
                ThresholdValue = "1",
                Title = "title",
                Topic = "test",
                IsConfigureEmail=true

            } };

            return Task.FromResult(testProducts);
        }
        private static Task<MyAlertSettings> GetTestMyAlertSettings()
        {
            var testAlert = new MyAlertSettings()
            {
                AlertId = 1,
                Description = "desc",

                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",
                MandatoryOptional = 1,
                Measure = "1",

                Threshold = "1",
                ThresholdValue = "1",

                Title = "title",
                Topic = "test"
            };

            return Task.FromResult(testAlert);
        }
        private static Task<Alerts> GetTestAlert()
        {
            var testAlert = new Alerts()
            {
                BagFrequency = new List<Lookup>() { },
                CreatedBy = "David",
                AlertId = 1,
            };

            return Task.FromResult(testAlert);
        }

        private static Task<IEnumerable<ConfigureAlerts>> GetTestConfigureAlertList()
        {
            IEnumerable<ConfigureAlerts> testProducts = new List<ConfigureAlerts>()
            { new ConfigureAlerts
            {
                AlertId = 1,
                Description = "desc",
                DisableAlert=false,
               CreatedDate=DateTime.Now,
               EndDate=DateTime.Now,
               CreatedBy="User1",
               ModifiedBy="User2",
               Frequency="1 hr",
               ModifiedDate=DateTime.Now,
               IsSnooze=false,
               OperationalArea="1",
               Organization="Cognizant",
               ResponseType=1,
               StartDate=DateTime.Now,
               TimeWindow=1,
                IsEmail = false,
                IsMobile = true,
                IsOnScreen = true,
                IsSubscribe = false,
                Location = "1",
                MandatoryOptional = 1,
                Measure = "1",
                Threshold = "1",
                ThresholdValue = "1",
                Title = "title",
                Topic = "test"
            } };

            return Task.FromResult(testProducts);
        }
        private static Task<int> GetTestAlertCount()
        {

            return Task.FromResult(1);
        }
    }
}
