using System;
using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class MenuModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IMenu> mockMenu;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockMenu = this.mockRepository.Create<IMenu>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private MenuModule CreateMenuModule()
        {
            return new MenuModule(
                this.mockMenu.Object);
        }

        [TestMethod]
        public void GetAllMenu_StateUnderTest_ExpectedBehavior()
        {
            var unitUnderTest = this.CreateMenuModule();
            var menuDataAccessLayer = new Mock<IMenu>();
            menuDataAccessLayer.Setup(x => x.GetAllMenu()).Returns(GetTestMenu());
            var testMenu = GetTestMenu();
            var menuBusiness = new MenuModule(menuDataAccessLayer.Object);
            IEnumerable<Menu> listResult = menuBusiness.GetAllMenu();
            Assert.IsNotNull(listResult);
        }


        [TestMethod]
        public void GetMenu_StateUnderTest_ExpectedBehavior()
        {
            var menuDataAccessLayer = new Mock<IMenu>();
            menuDataAccessLayer.Setup(x => x.GetAllMenu()).Returns(GetTestMenu());
            var testMenu = GetTestMenu();
            var menuBusiness = new MenuModule(menuDataAccessLayer.Object);
            IEnumerable<Menu> listResult = menuBusiness.GetMenus();
            Assert.IsNotNull(listResult);
        }


        [TestMethod]
        public void GetAllVisibleMenu_StateUnderTest_ExpectedBehavior()
        {
            var menuDataAccessLayer = new Mock<IMenu>();
            menuDataAccessLayer.Setup(x => x.GetAllMenu()).Returns(GetTestMenu());
            var testMenu = GetTestMenu();
            var menuBusiness = new MenuModule(menuDataAccessLayer.Object);
            IList<Menu> result = menuBusiness.GetMenus() as List<Menu>;
            var obj =result != null ? result.Where(s => s.IsVisible == true) : null;
            Assert.IsNotNull(result);
        }


        [TestMethod]
        public void GetUserReports_StateUnderTest_ExpectedBehavior()
        {
            var menuDataAccessLayer = new Mock<IMenu>();
            menuDataAccessLayer.Setup(x => x.GetReportDetails("xyz@abc.com")).Returns(PbiReportDetails());
            var testMenu = GetTestMenu();
            var menuBusiness = new MenuModule(menuDataAccessLayer.Object);
            IList<PowerBiReportDetails> listResult = menuBusiness.GetUserReports("xyz@abc.com");
            Assert.IsNotNull(listResult);
        }
        
        private List<Menu> GetTestMenu()
        {
            var testMenu = new List<Menu>
            {
                new Menu()
                {
                    BusinessReportId = "1",
                    Description = "desc",
                    FavouritesDescription = "fdesc",
                    MenuId = 19,
                    OrderId = 1,
                    Organization = "org",
                    CssIcon = "ico",
                    IsReport = true,
                    OperationalReportId = "2",
                    ParentId = 1,
                    Tooltip = "sample",
                    BreadCrumb = "test",
                    IsMultiLevel =true,
                    IsVisible = true
                }
            };

            return testMenu;
        }

        private List<PowerBiReportDetails> PbiReportDetails()
        {
            List<PowerBiReportDetails> pbiList = new List<PowerBiReportDetails>
            {
                new PowerBiReportDetails
                {
                    MenuId = 18,
                    FilterType = "1",
                    //sReport = true,
                    ReportId = "08414021-b1dd-4da4-9322-ad256f2abd3d",
                    ReportSection = "ReportSectionc426823d236c1c717a74",
                    ReportType = Convert.ToInt32("1", CultureInfo.InvariantCulture),
                    WorkSpaceId = "9267fd29-3222-4dfc-9680-902f44dbda89",
                    PbiRoles = "pbi",
                    ReportRefreshDateTime="2017-6-12 12:30:00"
                }
            };
            return pbiList;
        }
    }
}
