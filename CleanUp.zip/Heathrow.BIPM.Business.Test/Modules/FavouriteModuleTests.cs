using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class FavouriteModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IFavourites> mockFavourites;
        private Mock<IMenuModule> mockMenuModule;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockFavourites = this.mockRepository.Create<IFavourites>();
            this.mockMenuModule = this.mockRepository.Create<IMenuModule>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

          [TestMethod]
        public async Task Save_StateUnderTest_ExpectedBehavior()
        {
            var favRepoLayer = new Mock<IFavourites>();
            var menuRepoLayer = new Mock<IMenuModule>();
            favRepoLayer.Setup(x => x.Save(new Favourites
            {
                FavouriteId = 37,
                UserId = "gayathri.kannan@heathrow.com",
                FavouriteLink = new Menu
                {
                    MenuId = 21,
                    Description = "Baggage Status - Outbound",
                    IsReport = true,
                    OperationalReportId = "251b74f5-369c-41d2-85d5-6ea65ba1d3f3"
                }
            }));

            FavouriteModule module = new FavouriteModule(favRepoLayer.Object);
            // Act
            var result1 = await module.Save(new Favourites
            {
                FavouriteId = 37,
                UserId = "gayathri.kannan@heathrow.com",
                FavouriteLink = new Menu
                {
                    MenuId = 21,
                    Description = "Baggage Status - Outbound",
                    IsReport = true,
                    OperationalReportId = "251b74f5-369c-41d2-85d5-6ea65ba1d3f3"
                }
            });
            // Assert
            Assert.AreNotEqual("Save Success", result1);
        }

        [TestMethod]
        public async Task GetUserFavourites_StateUnderTest_ExpectedBehavior()
        {
            var favRepoLayer = new Mock<IFavourites>();
            var menuRepoLayer = new Mock<IMenuModule>();
            favRepoLayer.Setup(x => x.GetUserFavourites("gayathri.kannan@heathrow.com"))
        .Returns(GetTestFavourite());

            List<Favourites> testFavourite = await GetTestFavourite();
            var module = new FavouriteModule(favRepoLayer.Object);
            // Act
            IEnumerable<Favourites> result = await module.GetUserFavourites("gayathri.kannan@heathrow.com");
            // Assert
            Assert.AreEqual(testFavourite.GetEnumerator().Current, result.GetEnumerator().Current);
        }

        private static Task<List<Favourites>> GetTestFavourite()
        {
            List<Favourites> favouritesList = new List<Favourites>();
            var testFAvourite = new Favourites()
            {
                FavouriteId = 37,
                UserId = "gayathri.kannan@heathrow.com",
                FavouriteLink = new Menu
                {
                    MenuId = 21,
                    Description = "Baggage Status - Outbound",
                    IsReport = true,
                    OperationalReportId = "251b74f5-369c-41d2-85d5-6ea65ba1d3f3"
                }
            };
            favouritesList.Add(testFAvourite);

            return Task.FromResult(favouritesList);
        }
    }
}
