using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class ShareModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IShare> mockShare;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockShare = this.mockRepository.Create<IShare>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private ShareModule CreateShareModule()
        {
            return new ShareModule(
                this.mockShare.Object);
        }

        [TestMethod]
        public async Task GetAudienceGroup_StateUnderTest_ExpectedBehavior()
        {
            var unitUnderTest = this.CreateShareModule();
            Mock<IShare> shareDataAccessLayer = new Mock<IShare>();
            shareDataAccessLayer.Setup(x => x.FetchAudienceGroup("xyz@abc.com")).Returns(GroupList());

            var shareBusiness = new ShareModule(shareDataAccessLayer.Object);
            var testShare = TestShareCollection();
            IList<Share> listResult = await shareBusiness.GetAudienceGroup("xyz@abc.com");
            Assert.AreEqual(listResult[0].GroupId, testShare[0].GroupId);
        }

        [TestMethod]
        public async Task GetGroupRecipients_StateUnderTest_ExpectedBehavior()
        {
            Mock<IShare> shareDataAccessLayer = new Mock<IShare>();
            shareDataAccessLayer.Setup(x => x.FetchRecipients(10))
                .Returns(Task.FromResult(TestShareCollection()));

            var shareBusiness = new ShareModule(shareDataAccessLayer.Object);
            var testShare = TestShareCollection();
            IList<Share> listResult = await shareBusiness.GetGroupRecipients(10);
            Assert.AreEqual(listResult[0].GroupId, testShare[0].GroupId);
        }

        [TestMethod]
        public async Task GetGroupRecipients_StateUnderTest_NotExpectedBehavior()
        {
            Mock<IShare> shareDataAccessLayer = new Mock<IShare>();
            shareDataAccessLayer.Setup(x => x.FetchRecipients(0))
                .Returns(Task.FromResult(TestShareCollection()));

            var shareBusiness = new ShareModule(shareDataAccessLayer.Object);
            var testShare = TestShareCollection();
            IList<Share> listResult = await shareBusiness.GetGroupRecipients(0);
           Assert.AreNotEqual(listResult, testShare);
        }

        private static Task<IList<Share>> GroupList()
        {
            IList<Share> groupList = new List<Share>
            {
                new Share
                {
                    GroupId = 10,
                    GroupName = "Group1"
                }
            };
            return Task.FromResult(groupList);
        }

        private static IList<Share> TestShareCollection() =>
           new List<Share>
           {
                new Share
                {
                    GroupId = 10,
                    GroupName = "Group1",
                    RecipientId = "recipient@heathrow.com",
                    RecipientName = "Recipient1",
                }
           };
    }
}
