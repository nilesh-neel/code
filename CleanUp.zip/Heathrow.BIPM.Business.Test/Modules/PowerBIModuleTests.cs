using System;
using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class PowerBIModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IMenuModule> mockMenuModule;
        private Mock<IFilterModule> mockFilterModule;
        private Mock<IAssignHomePageModule> mockAssignHomePageModule;
        private Mock<IPowerBi> mockPowerBi;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockMenuModule = this.mockRepository.Create<IMenuModule>();
            this.mockFilterModule = this.mockRepository.Create<IFilterModule>();
            this.mockAssignHomePageModule = this.mockRepository.Create<IAssignHomePageModule>();
            this.mockPowerBi = this.mockRepository.Create<IPowerBi>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        private PowerBIModule CreatePowerBIModule()
        {
            var appIdentity = new ClaimsIdentity();
            appIdentity.AddClaim(new Claim(ClaimTypes.Upn, "abc.def@hello.com"));
            ClaimsPrincipal.Current.AddIdentity(appIdentity);

            return new PowerBIModule(
                this.mockMenuModule.Object,
                this.mockFilterModule.Object,
                this.mockAssignHomePageModule.Object,
                this.mockPowerBi.Object);
        }

        [TestMethod]
        public async Task RefreshDate_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string refreshDate = DateTime.Now.ToString("dd/MM/yyyy, HH:mm");
            mockPowerBi.Setup(s => s.ReportLastRefreshDateTime(2)).Returns(refreshDate);

            var unitUnderTest = this.CreatePowerBIModule();
         
            //// Act
            var result = unitUnderTest.ReportLastRefreshDateTime(2);

            // Assert
            Assert.AreEqual(refreshDate, result);
        }

        [TestMethod]
        public async Task EmbedReportV2_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            //var unitUnderTest = this.CreatePowerBIModule();
            //int menuId = 0; //TODO;
            //int reportType = 0; //TODO;

            //// Act
            //var result = await unitUnderTest.EmbedReportV2(
            //    menuId,
            //    reportType);

            // Assert
            Assert.IsTrue(true);
        }

        [TestMethod]
        public async Task GetDashboardInGroup_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            //var unitUnderTest = this.CreatePowerBIModule();

            //// Act
            //var result = await unitUnderTest.GetDashboardInGroup();

            // Assert
            Assert.IsTrue(true);
        }
    }
}
