using Heathrow.BIPM.Business.Interface;
using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.DataAccess.Interface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;
using Heathrow.BIPM.Core.Entity;
using System.Collections.Generic;
using System;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class SearchModuleTests
    {
        private MockRepository mockRepository;

        private Mock<ISearch> mockSearch;
        private Mock<IBpmPowerBi> mockBpmPowerBi;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockSearch = this.mockRepository.Create<ISearch>();
            this.mockBpmPowerBi = this.mockRepository.Create<IBpmPowerBi>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }

        [TestMethod]
        public async Task SearchData_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
           
            var bpmPowerBIRepoLayer = new Mock<IBpmPowerBi>();
            var searchRepoLayer = new Mock<ISearch>();
            searchRepoLayer.Setup(x => x.SearchData("0000103439", "B"))
             .Returns(TestSearch());
            bpmPowerBIRepoLayer.Setup(m => m.EmbedReportV2(19, 1))
                .Returns(ReportResult());

            var testResult = TestSearch();
            var module = new SearchModule(searchRepoLayer.Object, bpmPowerBIRepoLayer.Object);

            var response = await module.SearchData("0000103439", "B");

            Assert.AreEqual(testResult.Result.MenuId, response.MenuId);
            Assert.IsNotNull(testResult.Result.ColumnName);
            Assert.IsNotNull(testResult.Result.Operator);
            Assert.IsNotNull(testResult.Result.PowerBiReportId);
            Assert.IsNotNull(testResult.Result.TableName);

        }


        private static Task<ReportConfiguration> TestSearch()
        {
            var search = new ReportConfiguration
            {
                ColumnName = "bagItem",
                MenuId = 19,
                Operator = "In",
                PowerBIType = "1",
                TableName = "TestBagItem",
                PowerBiReportId = "18"

            };
            search.ColumnValue.AddRange(new List<string> { "0000103439" });
            return Task.FromResult(search);
        }
        private static Task<List<PowerBiEmbedConfig>> ReportResult()
        {
            List<PowerBiEmbedConfig> reportList = new List<PowerBiEmbedConfig>();

            var embeddedReport = new PowerBiEmbedConfig
            {
                EmbedToken = "00000013",
                EmbedUrl = new Uri("http://powerbi.com/product"),
                Id = "19",
                ReportSection = "testSection",
                PowerBIType = "1",

            };
            var embeddedReportsub = new PowerBiEmbedConfig
            {
                EmbedToken = "00000014",
                EmbedUrl = new Uri("http://powerbi.com/product"),
                Id = "19",
                ReportSection = "testSection1",
                PowerBIType = "2",
                LastRefreshDateTime= "2018-06-01 17:15:00.000",
                EnableRls=true,
                FilterType="1",
                Roles="Admin",
                UserName="Admin",
                IsEffectiveIdentityRequired=true,
                ErrorMessage="Connection failure"


            };
            reportList.Add(embeddedReport);
            reportList.Add(embeddedReportsub);

            return Task.FromResult(reportList);
        }
    }
}
