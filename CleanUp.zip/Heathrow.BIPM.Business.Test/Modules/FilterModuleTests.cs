using Heathrow.BIPM.Business.Modules;
using Heathrow.BIPM.Core.Entity;
using Heathrow.BIPM.DataAccess.Interface;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Business.Test.Modules
{
    [TestClass]
    public class FilterModuleTests
    {
        private MockRepository mockRepository;

        private Mock<IFilter> mockFilter;

        [TestInitialize]
        public void TestInitialize()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockFilter = this.mockRepository.Create<IFilter>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            this.mockRepository.VerifyAll();
        }


        [TestMethod]
        public async Task SaveFilter_StateUnderTest_ExpectedBehavior()
        {
           
            var filterRepoLayer = new Mock<IFilter>();

            filterRepoLayer.Setup(x => x.SaveFilter(
                new FilterEntity
                {
                    FilterId = 1,
                    MenuId = 18,
                    UserId = "user1",
                    FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:7512125605]}"
                }
            ));

            FilterEntity data = new FilterEntity
            {
                MenuId = 10,
                UserId = "user1",
                FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:0000103438]}"
            };

            var module = new FilterModule(filterRepoLayer.Object);

            var result = await module.SaveFilter(data);

            Assert.IsNotNull(result);
            Assert.AreNotEqual(result, data);
        }

        [TestMethod]
        public async Task FilterByMenuId_StateUnderTest_ExpectedBehavior()
        {
      
            var filterRepoLayer = new Mock<IFilter>();

            filterRepoLayer.Setup(x => x.FilterByMenuId(19, string.Empty))
                   .Returns(Task.FromResult(TestFilterCollection()));

            FilterEntity testFilter = TestFilterCollection();

            var module = new FilterModule(filterRepoLayer.Object);

            FilterEntity result = await module.FilterByMenuId(19, string.Empty);
            Assert.AreEqual(testFilter.FilterText,result.FilterText);
            Assert.AreEqual(testFilter.FilterId, result.FilterId);
            Assert.AreEqual(testFilter.FilterItemSelection.GetEnumerator().Current, result.FilterItemSelection.GetEnumerator().Current);
            Assert.AreEqual(testFilter.MenuId, result.MenuId);
            Assert.AreEqual(testFilter.UserId, result.UserId);
            Assert.AreEqual(testFilter.PBIMappingList.GetEnumerator().Current, result.PBIMappingList.GetEnumerator().Current);
        }

        [TestMethod]
        public async Task FilterConfiguration_StateUnderTest_ExpectedBehavior()
        {
   
            var filterRepoLayer = new Mock<IFilter>();

            filterRepoLayer.Setup(x => x.FilterConfiguration())
                     .Returns(Task.FromResult(TestFilterControl()));

            FilterControlEntity testFilter = TestFilterControl();

            var module = new FilterModule(filterRepoLayer.Object);

            FilterControlEntity result = await module.FilterConfiguration();
            Assert.AreEqual(result.BaggageSystemList.Count, testFilter.BaggageSystemList.Count);
        }

        private static FilterEntity TestFilterCollection()
        {
            var collection = new FilterEntity
            {
                FilterId = 10,
                FilterText = "Filter :[{TableName:BagItem,ColumnName:BagItemID,ColumnValue:7512125605]}",
                MenuId = 19,
                UserId = "Admin",
            };

            var pbiList = new List<string> { "0000103439", "0000103438" };

            var filterselection = new FilterSelection();
            filterselection.ColumnName = "TagNumber";
            filterselection.ControlMappingId = 5;
            filterselection.Operator = "In";
            filterselection.TableName = "BagItem";
            ((List<string>)filterselection.ColumnValue).AddRange(pbiList);
            collection.PBIMappingList.Add(filterselection);
            collection.FilterItemSelection.Add(filterselection);
            return collection;
        }

        private static FilterControlEntity TestFilterControl()
        {
            var collection = new FilterControlEntity();

            collection.BaggageSystemList.Add(new DropDownFilter { Value = "10" });
            collection.NotLoadedCategoryList.Add(new NotLoadedDropDown { Value = "1", Label = "RIS" });
            collection.NotLoadedSubCategoryList.Add(new NotLoadedDropDown { Value = "1", Label = "Late arrival" });
            collection.OutboundAircraftList.Add(new DropDownFilter { Value = "All" });
            collection.OutboundAirlineList.Add(new DropDownFilter { Value = "BA2304" });
            collection.OutboundHandlerList.Add(new DropDownFilter { Value = "None" });
            collection.OutboundTerminalList.Add(new DropDownFilter { Value = "T2" });
            collection.LastSeenLocationList.Add(new DropDownFilter { Value = "All" });
            collection.DestinationList.Add(new DropDownFilter { Value = "0A1" });

            return collection;
        }
    }
}
